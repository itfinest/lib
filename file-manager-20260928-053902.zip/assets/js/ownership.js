/** @author Ertha Dwi Setiyawan */
document.addEventListener('alpine:init', () => {
  Alpine.data('ownershipPage', () => ({
    form: { path: '', expected_owner: '', expected_group: '' },
    phase: 'idle',
    data: null,
    errorMessage: '',
    controller: null,

    async init() {
      const params = new URLSearchParams(location.search);
      Object.keys(this.form).forEach((key) => { this.form[key] = params.get(key) || ''; });
      if (this.form.path) { this.analyze(); return; }
      try {
        const payload = await FM.api('api/system');
        this.form.path = payload.data.default_path || payload.data.roots[0] || '';
      } catch (error) {
        FM.toast('error', 'Informasi server gagal dimuat', error.message);
      }
    },
    async analyze() {
      if (this.controller) this.controller.abort();
      this.controller = new AbortController();
      const params = new URLSearchParams({ r: 'ownership' });
      Object.entries(this.form).forEach(([key, value]) => { if (value) params.set(key, value); });
      history.replaceState(null, '', `?${params}`);
      this.phase = 'loading';
      try {
        const payload = await FM.api('api/analysis/ownership', { query: this.form, signal: this.controller.signal });
        this.data = payload.data;
        this.phase = 'content';
      } catch (error) {
        if (error.name === 'AbortError') return;
        this.errorMessage = error.message;
        this.phase = 'error';
      }
    },
    share(row) {
      const total = this.data.owners.reduce((sum, r) => sum + r.files + r.dirs + r.other, 0);
      return total ? Math.round(((row.files + row.dirs + row.other) * 1000) / total) / 10 : 0;
    },
    issueBlocks() {
      const blocks = [{ key: 'orphans', title: 'Pemilik atau grup tidak dikenal', count: this.data.orphans.count, items: this.data.orphans.items, empty: 'Semua UID dan GID memiliki akun di server ini.' }];
      if (this.data.expected.owner || this.data.expected.group) {
        blocks.push({
          key: 'mismatch',
          title: `Tidak sesuai ${[this.data.expected.owner, this.data.expected.group].filter(Boolean).join(':')}`,
          count: this.data.mismatch.count,
          items: this.data.mismatch.items,
          empty: 'Semua item sudah memakai pemilik dan grup yang diharapkan.',
        });
      }
      return blocks;
    },
  }));
});
