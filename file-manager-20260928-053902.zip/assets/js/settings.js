/** @author Ertha Dwi Setiyawan */
/* Settings page: loads the effective settings, saves them after the current
   password is confirmed, and warns before leaving with unsaved changes. */
document.addEventListener('alpine:init', () => {
  const toLines = (list) => (list || []).join('\n');
  // The app name and user name are rendered by the server in the layout, so changing them needs a page reload.
  const FLASH_KEY = 'fm-settings-flash';

  Alpine.data('settingsPage', () => ({
    phase: 'loading',
    errorMessage: '',
    busy: false,
    confirmReset: false,
    // The form is kept in the DOM with x-show while loading, so its bindings read roots before load() fills it.
    form: { roots: [] },
    pristine: '',
    overridden: [],
    clientIp: '',
    unix: true,
    recovery: false,
    errors: {},
    shown: {},
    // Folder picker for the folder settings; pickerField is the setting it fills, empty when closed.
    pickerField: '',
    picker: { path: '', folders: [], parent: null, loading: false, error: '' },

    init() {
      try {
        const flash = sessionStorage.getItem(FLASH_KEY);
        if (flash) { sessionStorage.removeItem(FLASH_KEY); FM.toast('success', flash); }
      } catch (error) { /* storage blocked: the message was already applied */ }
      this.load();
      window.addEventListener('beforeunload', (event) => {
        if (!this.dirty()) return;
        event.preventDefault();
        event.returnValue = '';
      });
    },
    async load() {
      this.phase = 'loading';
      try {
        const payload = await FM.api('api/settings');
        const values = payload.data.values;
        this.form = Object.assign({}, values, {
          roots: values.roots.length ? values.roots.slice() : [''],
          allowed_ips: toLines(values.allowed_ips),
          compress_exclude: toLines(values.compress_exclude),
          hidden_names: toLines(values.hidden_names),
          blocked_extensions: values.blocked_extensions.join(', '),
          blocked_names: values.blocked_names.join(', '),
          new_password: '',
          new_password_confirm: '',
          current_password: '',
        });
        this.pristine = this.snapshot();
        this.shown = { app_name: values.app_name, username: values.username };
        this.overridden = payload.data.overridden;
        this.clientIp = payload.data.client_ip;
        this.unix = payload.data.unix;
        this.recovery = payload.data.recovery;
        this.errors = {};
        this.confirmReset = false;
        this.phase = 'content';
      } catch (error) {
        this.errorMessage = error.message;
        this.phase = 'error';
      }
    },
    snapshot() {
      const copy = Object.assign({}, this.form);
      delete copy.current_password;
      return JSON.stringify(copy);
    },
    dirty() { return this.phase === 'content' && this.snapshot() !== this.pristine; },
    finish(message, reload) {
      if (!reload) { FM.toast('success', message); return this.load(); }
      this.pristine = this.snapshot();
      try { sessionStorage.setItem(FLASH_KEY, message); } catch (error) { /* the reload still applies the change */ }
      window.location.reload();
      return null;
    },
    // Picker keys are setting names, or "roots.<index>" for one row of the root list.
    fieldValue(key) { return key.startsWith('roots.') ? this.form.roots[Number(key.slice(6))] : this.form[key]; },
    togglePicker(key) {
      if (this.pickerField === key) { this.pickerField = ''; return; }
      this.pickerField = key;
      this.loadPicker(this.fieldValue(key) || '');
    },
    addRoot() {
      if (this.form.roots.length >= 20) return;
      this.form.roots.push('');
      const index = this.form.roots.length - 1;
      this.$nextTick(() => document.getElementById(`set-root-${index}`)?.focus());
    },
    removeRoot(index) {
      if (this.form.roots.length === 1) return;
      this.form.roots.splice(index, 1);
      this.pickerField = '';
      this.clear('roots');
      this.$nextTick(() => document.getElementById(`set-root-${Math.max(0, index - 1)}`)?.focus());
    },
    async loadPicker(path) {
      this.picker.loading = true;
      this.picker.error = '';
      try {
        const payload = await FM.api('api/folders', { query: { path } });
        Object.assign(this.picker, payload.data, { path: payload.data.cwd });
        this.picker.loading = false;
      } catch (error) {
        // A typed path that does not resolve still opens the picker, at the default folder.
        if (path !== '') return this.loadPicker('');
        this.picker.error = error.message;
        this.picker.loading = false;
      }
      return null;
    },
    pickFolder(path) {
      if (this.pickerField.startsWith('roots.')) {
        this.form.roots[Number(this.pickerField.slice(6))] = path;
        this.clear('roots');
      } else {
        this.form[this.pickerField] = path;
        this.clear(this.pickerField);
      }
      if (path !== this.picker.path) this.loadPicker(path);
    },
    changed(key) { return this.overridden.includes(key); },
    fieldError(key) { return this.errors[key] || ''; },
    clear(key) { if (this.errors[key]) this.errors[key] = ''; },
    focusError() {
      this.$nextTick(() => this.$root.querySelector('[aria-invalid="true"]')?.focus());
    },
    async save() {
      this.busy = true;
      this.errors = {};
      try {
        const payload = await FM.api('api/settings/save', { method: 'POST', body: this.form });
        await this.finish(payload.message, this.form.app_name !== this.shown.app_name || this.form.username !== this.shown.username);
      } catch (error) {
        this.errors = error.errors || {};
        // Field errors are shown inline; a toast would also cover the save button.
        if (!Object.keys(this.errors).length) FM.toast('error', error.message);
        this.focusError();
      } finally {
        this.busy = false;
      }
    },
    async reset() {
      this.busy = true;
      this.errors = {};
      try {
        const payload = await FM.api('api/settings/reset', { method: 'POST', body: { current_password: this.form.current_password } });
        await this.finish(payload.message, true);
      } catch (error) {
        this.errors = error.errors || {};
        this.confirmReset = false;
        if (!Object.keys(this.errors).length) FM.toast('error', error.message);
        this.focusError();
      } finally {
        this.busy = false;
      }
    },
  }));
});
