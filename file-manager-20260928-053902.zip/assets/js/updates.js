/** @author Ertha Dwi Setiyawan */
/* Update page: builds a package of the installed application, uploads and checks
   a package, installs it after the current password is confirmed, and stages a
   backup so restoring it passes the same checks. */
document.addEventListener('alpine:init', () => {
  // The page reloads after an install so the new scripts and styles load; the message survives the reload.
  const FLASH_KEY = 'fm-updates-flash';
  const KINDS = {
    added: { label: 'Baru', chip: 'chip-success' },
    changed: { label: 'Diubah', chip: 'chip-warning' },
    deleted: { label: 'Dihapus', chip: 'chip-danger' },
  };
  const CHECKS = {
    ok: { icon: 'circle-check', tone: 'text-success-700', label: 'Lolos' },
    warn: { icon: 'triangle-alert', tone: 'text-warning-700', label: 'Peringatan' },
    fail: { icon: 'circle-x', tone: 'text-danger-700', label: 'Gagal' },
  };

  Alpine.data('updatesPage', () => ({
    phase: 'loading',
    errorMessage: '',
    zip: true,
    bundle: false,
    uploadBytes: 0,
    staged: null,
    backups: [],
    file: null,
    password: '',
    errors: {},
    busy: '',

    init() {
      try {
        const flash = sessionStorage.getItem(FLASH_KEY);
        if (flash) { sessionStorage.removeItem(FLASH_KEY); FM.toast('success', flash); }
      } catch (error) { /* storage blocked: the update itself already applied */ }
      this.load();
    },
    async load() {
      this.phase = 'loading';
      try {
        const payload = await FM.api('api/updates');
        this.apply(payload.data);
        this.phase = 'content';
      } catch (error) {
        this.errorMessage = error.message;
        this.phase = 'error';
      }
    },
    apply(data) {
      this.zip = data.zip;
      this.bundle = data.bundle;
      this.uploadBytes = data.upload_bytes;
      this.staged = data.staged;
      this.backups = data.backups || [];
    },
    bundleUrl() { return FM.downloadUrl('api/updates/bundle', {}); },
    kind(key) { return KINDS[key]; },
    check(status) { return CHECKS[status] || CHECKS.warn; },
    originText() {
      if (!this.staged) return '';
      return this.staged.origin === 'backup' ? 'Cadangan' : 'Unggahan';
    },
    pickFile(event) {
      this.file = event.target.files[0] || null;
      this.errors.package = '';
    },
    async upload() {
      if (!this.file) { this.errors = { package: 'Pilih berkas paket .zip terlebih dahulu.' }; return; }
      if (this.file.size > this.uploadBytes) {
        this.errors = { package: `Ukuran berkas melebihi batas unggahan (${FM.formatBytes(this.uploadBytes)}).` };
        return;
      }
      const form = new FormData();
      form.append('package', this.file);
      await this.stage('upload', () => FM.api('api/updates/upload', { method: 'POST', form }));
    },
    async restore(backup) {
      await this.stage(backup.id, () => FM.api('api/updates/stage-backup', { method: 'POST', body: { id: backup.id } }));
    },
    async stage(busy, request) {
      this.busy = busy;
      this.errors = {};
      try {
        const payload = await request();
        this.apply(payload.data);
        this.password = '';
        this.file = null;
        if (this.$refs.fileInput) this.$refs.fileInput.value = '';
        FM.toast(this.staged && this.staged.installable ? 'success' : 'warning', payload.message);
        this.$nextTick(() => this.$refs.result?.focus());
      } catch (error) {
        this.errors = error.errors || {};
        if (!Object.keys(this.errors).length) FM.toast('error', error.message);
      } finally {
        this.busy = '';
      }
    },
    async discard() {
      this.busy = 'discard';
      try {
        const payload = await FM.api('api/updates/discard', { method: 'POST' });
        this.staged = null;
        this.password = '';
        FM.toast('success', payload.message);
      } catch (error) {
        FM.toast('error', error.message);
      } finally {
        this.busy = '';
      }
    },
    async install() {
      if (!this.password) { this.errors = { current_password: 'Masukkan kata sandi saat ini untuk memasang pembaruan.' }; return; }
      this.busy = 'install';
      this.errors = {};
      try {
        const payload = await FM.api('api/updates/install', { method: 'POST', body: { current_password: this.password } });
        try { sessionStorage.setItem(FLASH_KEY, payload.message); } catch (error) { /* the reload still shows the new version */ }
        window.location.reload();
      } catch (error) {
        this.errors = error.errors || {};
        if (!Object.keys(this.errors).length) FM.toast('error', 'Pembaruan tidak terpasang', error.message);
        this.busy = '';
        // A failed install may have restored a backup and removed the staged package, so the page state is refreshed.
        if (error.status !== 422 || !Object.keys(this.errors).length) this.load();
      }
    },
  }));
});
