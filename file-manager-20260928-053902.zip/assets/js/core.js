/** @author Ertha Dwi Setiyawan */
/* Shared runtime: API client, notifications, list pages, the operation
   preview/apply dialog, the sidebar, and the session timeout warning. */
(function () {
  'use strict';

  const meta = (name) => document.querySelector(`meta[name="${name}"]`)?.content || '';
  const ICONS = meta('icons-url') || 'assets/icons.svg';
  const TOAST_LEAVE_MS = 160;
  const MODAL_LEAVE_MS = 150;
  let csrf = meta('csrf-token');

  /* Login page address that returns to the current page after signing in again. */
  function loginUrl() {
    const next = location.search.replace(/^\?/, '');
    return next ? `?r=login&next=${encodeURIComponent(next)}` : '?r=login';
  }

  class ApiError extends Error {
    constructor(status, message, data) {
      super(message);
      this.status = status;
      this.data = data || null;
      // A validation failure sends field messages keyed by name; a failed apply sends a list of step errors.
      const errors = (data && data.errors) || {};
      this.errors = Array.isArray(errors) ? {} : errors;
      this.details = Array.isArray(errors) ? errors.filter((line) => typeof line === 'string' && line !== '') : [];
    }
  }

  async function api(route, options = {}) {
    const { method = 'GET', query = null, body = null, form = null, signal } = options;
    const params = new URLSearchParams({ r: route });
    if (query) {
      Object.entries(query).forEach(([key, value]) => {
        if (value !== '' && value !== null && value !== undefined && value !== false) params.set(key, value === true ? '1' : value);
      });
    }
    const headers = { Accept: 'application/json' };
    let payloadBody;
    if (method !== 'GET') {
      headers['X-CSRF-Token'] = csrf;
      if (form) {
        payloadBody = form;
      } else {
        headers['Content-Type'] = 'application/json';
        payloadBody = JSON.stringify(body || {});
      }
    }
    let response;
    let payload = null;
    session.pending++;
    try {
      response = await fetch(`?${params}`, { method, headers, body: payloadBody, signal, credentials: 'same-origin' });
      try { payload = await response.json(); } catch (error) { payload = null; }
    } catch (error) {
      if (error.name === 'AbortError') throw error;
      throw new ApiError(0, 'Tidak dapat terhubung ke server. Periksa koneksi, lalu coba lagi.');
    } finally {
      session.pending--;
    }
    if (response.status === 401 && route !== 'api/auth/login') {
      window.location.href = loginUrl();
      throw new ApiError(401, payload?.message || 'Sesi berakhir. Silakan masuk kembali.');
    }
    if (!response.ok || !payload || payload.status !== 'success') {
      throw new ApiError(response.status, payload?.message || `Permintaan gagal diproses (kode ${response.status}). Coba lagi.`, payload?.data);
    }
    session.touch();
    return payload;
  }

  function downloadUrl(route, query) {
    const params = new URLSearchParams({ r: route });
    Object.entries(query || {}).forEach(([key, value]) => {
      if (value !== '' && value !== null && value !== undefined) params.set(key, value);
    });
    return `?${params}`;
  }

  const numberFormat = new Intl.NumberFormat('id-ID');
  // No locale: dates follow the browser's language, clock style, and timezone.
  const dateFormat = new Intl.DateTimeFormat(undefined, { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });

  function formatBytes(bytes) {
    const value = Number(bytes) || 0;
    if (value < 1024) return `${numberFormat.format(value)} B`;
    const units = ['KB', 'MB', 'GB', 'TB'];
    let size = value / 1024;
    let unit = 0;
    while (size >= 1024 && unit < units.length - 1) { size /= 1024; unit++; }
    return `${new Intl.NumberFormat('id-ID', { maximumFractionDigits: 1 }).format(size)} ${units[unit]}`;
  }

  function formatDate(value) {
    if (!value) return '';
    const date = typeof value === 'number' ? new Date(value * 1000) : new Date(value);
    return Number.isNaN(date.getTime()) ? '' : dateFormat.format(date);
  }

  function debounce(fn, wait) {
    let timer = null;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), wait);
    };
  }

  function pageNumbers(current, last) {
    if (last <= 7) return Array.from({ length: last }, (_, i) => i + 1);
    const pages = [1];
    const start = Math.max(2, current - 1);
    const end = Math.min(last - 1, current + 1);
    if (start > 2) pages.push('gap-start');
    for (let p = start; p <= end; p++) pages.push(p);
    if (end < last - 1) pages.push('gap-end');
    pages.push(last);
    return pages;
  }

  /* Keeps Tab inside an open dialog; returns focus to the opener on close. */
  const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), summary, [tabindex]:not([tabindex="-1"])';
  function trapFocus(event, container) {
    if (event.key !== 'Tab' || !container) return;
    const nodes = [...container.querySelectorAll(FOCUSABLE)].filter((node) => node.offsetParent !== null);
    if (!nodes.length) return;
    const first = nodes[0];
    const last = nodes[nodes.length - 1];
    if (event.shiftKey && document.activeElement === first) { last.focus(); event.preventDefault(); }
    else if (!event.shiftKey && document.activeElement === last) { first.focus(); event.preventDefault(); }
  }
  /* Returns focus to the control that opened a dialog, or to the main region when that control is gone (row menus, closed modals). */
  function restoreFocus(element) {
    if (element && element.isConnected && element.offsetParent !== null) element.focus();
    else document.getElementById('main')?.focus();
  }
  function focusFirst(container) {
    const target = container?.querySelector('[data-autofocus]') || container?.querySelector(FOCUSABLE);
    target?.focus();
  }

  /* Downloads with a progress card on every page. With the download worker (download-worker.js at the
     application root) the browser's download manager saves the file, so the transfer and its card
     survive moving between pages, which are full page loads. Without it (service workers need HTTPS
     or localhost) the file streams into the current page instead. */
  const DOWNLOAD_CHANNEL = 'fm-downloads';
  // An in-page download is held in memory until it is saved, so above this size the browser's own download manager takes it.
  const DOWNLOAD_MEMORY_LIMIT = 1024 * 1024 * 1024;
  const DOWNLOAD_REDRAW_MS = 100;
  // A finished download stays on screen briefly; on a fast connection it would otherwise vanish before it is seen.
  const DOWNLOAD_DONE_MS = 1500;
  const DOWNLOAD_KEEPALIVE_MS = 15000;
  const DOWNLOAD_WORKER_WAIT_MS = 4000;
  // A download the browser takes over directly reports nothing back, so its frame is removed after this delay.
  const DOWNLOAD_FRAME_MS = 60000;
  // Kept out of Alpine's reactive state, which cannot wrap these objects.
  const inPageControllers = new Map();
  const downloadFrames = new Map();
  let downloadChannel = null;
  let downloadWorker = Promise.resolve(false);

  /* Hands a download URL to the browser in a hidden frame. Navigating the page itself would cancel a
     download started just before it, so several files could not be requested at once. */
  function openDownloadFrame(id, url) {
    const frame = document.createElement('iframe');
    frame.hidden = true;
    frame.src = url;
    document.body.appendChild(frame);
    downloadFrames.set(id, frame);
  }

  function closeDownloadFrame(id) {
    downloadFrames.get(id)?.remove();
    downloadFrames.delete(id);
  }

  /* The file name the server gave an attachment (a folder arrives as "name.zip" or "name.tar.gz"). */
  function attachmentName(response, fallback) {
    const header = response.headers.get('Content-Disposition') || '';
    const match = /filename\*=UTF-8''([^;]+)/i.exec(header);
    if (!match) return fallback;
    try { return decodeURIComponent(match[1]); } catch (error) { return fallback; }
  }

  function registerDownloadWorker() {
    if (!('serviceWorker' in navigator) || !window.isSecureContext || !window.BroadcastChannel) return;
    const ready = navigator.serviceWorker.register('download-worker.js', { scope: './', updateViaCache: 'none' })
      .then(() => navigator.serviceWorker.ready)
      .then(() => true)
      .catch(() => false);
    downloadWorker = Promise.race([ready, new Promise((resolve) => setTimeout(() => resolve(false), DOWNLOAD_WORKER_WAIT_MS))]);
  }

  /* Session timeout warning, driven by the server's idle limit. */
  const session = {
    idleMs: (Number(meta('idle-minutes')) || 30) * 60000,
    last: Date.now(),
    // Requests still running. The server counts a request as activity until it ends, so a long
    // compress or upload never lets the idle timer send the page to the login screen mid-way.
    pending: 0,
    touch() { this.last = Date.now(); if (window.Alpine) Alpine.store('session').warning = false; },
    async track(promise) {
      this.pending++;
      try {
        return await promise;
      } finally {
        this.pending--;
        this.touch();
      }
    },
  };

  /* Generic server-driven list: search (debounced), filters, sort, numbered
     pagination, page length, URL persistence, and the loading/empty/error phases. */
  function listPage(config) {
    return {
      route: config.route,
      prefix: config.prefix || '',
      defaults: Object.assign({ page: 1, per_page: '10', search: '', sort_by: config.sort?.[0] || '', sort_dir: config.sort?.[1] || 'asc' }, config.filters || {}),
      state: {},
      items: [],
      pagination: { current_page: 1, last_page: 1, total: 0, per_page: 10 },
      phase: 'loading',
      errorMessage: '',
      notice: '',
      controller: null,
      extra: {},

      init() {
        this.state = this.readUrl();
        this.searchDebounced = debounce(() => { this.state.page = 1; this.load(); }, 300);
        if (config.autoload !== false) this.load();
        if (config.init) config.init.call(this);
      },
      readUrl() {
        const params = new URLSearchParams(location.search);
        const state = {};
        Object.keys(this.defaults).forEach((key) => {
          const value = params.get(this.prefix + key);
          state[key] = value !== null ? value : this.defaults[key];
        });
        state.page = Number(state.page) || 1;
        return state;
      },
      writeUrl() {
        const params = new URLSearchParams(location.search);
        Object.keys(this.defaults).forEach((key) => {
          const value = this.state[key];
          if (value === '' || value === null || String(value) === String(this.defaults[key])) params.delete(this.prefix + key);
          else params.set(this.prefix + key, value);
        });
        history.replaceState(history.state, '', `${location.pathname}?${params}`);
      },
      query() {
        return Object.assign({}, this.state, config.query ? config.query.call(this) : {});
      },
      async load() {
        if (this.controller) this.controller.abort();
        const controller = new AbortController();
        this.controller = controller;
        this.phase = 'loading';
        this.writeUrl();
        try {
          const payload = await api(this.route, { query: this.query(), signal: controller.signal });
          if (controller !== this.controller) return;
          const data = payload.data;
          this.items = data.items || [];
          this.pagination = data.pagination || this.pagination;
          this.extra = data;
          this.notice = payload.message || '';
          if (this.state.page > this.pagination.last_page) { this.state.page = this.pagination.last_page; }
          this.phase = this.items.length ? 'content' : (this.isFiltered() ? 'filtered' : 'empty');
          if (config.loaded) config.loaded.call(this, data);
        } catch (error) {
          if (error.name === 'AbortError' || controller !== this.controller) return;
          this.errorMessage = error.message;
          this.phase = 'error';
        }
      },
      reload() { this.load(); },
      // Keys such as the current folder are navigation, not filters: they never count as "filtered" and survive a reset.
      keepKeys: ['page', 'per_page', 'sort_by', 'sort_dir'].concat(config.keep || []),
      isFiltered() {
        return Object.keys(this.defaults).some((key) => !this.keepKeys.includes(key) && String(this.state[key] ?? '') !== String(this.defaults[key] ?? ''));
      },
      setFilter() { this.state.page = 1; this.load(); },
      resetFilters() {
        Object.keys(this.defaults).forEach((key) => {
          if (!this.keepKeys.includes(key)) this.state[key] = this.defaults[key];
        });
        this.state.page = 1;
        this.load();
      },
      sortBy(column) {
        if (this.state.sort_by === column) this.state.sort_dir = this.state.sort_dir === 'asc' ? 'desc' : 'asc';
        else { this.state.sort_by = column; this.state.sort_dir = 'asc'; }
        this.state.page = 1;
        this.load();
      },
      sortIcon(column) {
        if (this.state.sort_by !== column) return `${ICONS}#arrow-up-down`;
        return `${ICONS}#${this.state.sort_dir === 'asc' ? 'arrow-up' : 'arrow-down'}`;
      },
      ariaSort(column) {
        if (this.state.sort_by !== column) return 'none';
        return this.state.sort_dir === 'asc' ? 'ascending' : 'descending';
      },
      goTo(page) {
        if (typeof page !== 'number' || page < 1 || page > this.pagination.last_page || page === this.pagination.current_page) return;
        this.state.page = page;
        this.load();
      },
      pages() { return pageNumbers(this.pagination.current_page, this.pagination.last_page); },
      rowNumber(index) { return (this.pagination.current_page - 1) * this.pagination.per_page + index + 1; },
      rangeText() {
        if (!this.pagination.total) return '0 data';
        const from = (this.pagination.current_page - 1) * this.pagination.per_page + 1;
        const to = Math.min(this.pagination.total, from + this.items.length - 1);
        return `${numberFormat.format(from)}–${numberFormat.format(to)} dari ${numberFormat.format(this.pagination.total)}`;
      },
    };
  }

  document.addEventListener('alpine:init', () => {
    Alpine.store('toasts', {
      items: [],
      iconUrl: ICONS,
      seq: 0,
      icon(type) {
        return `${ICONS}#${{ success: 'circle-check', error: 'circle-alert', warning: 'triangle-alert', info: 'info' }[type] || 'info'}`;
      },
      // action: optional { label, run } shown as a button on the notification.
      push(type, title, message = '', action = null) {
        const id = ++this.seq;
        this.items.push({ id, type, title, message, action, leaving: false });
        if (this.items.length > 4) this.items.shift();
        // Errors and notifications with an action stay until dismissed; routine confirmations fade on their own.
        if (type !== 'error' && !action) setTimeout(() => this.dismiss(id), type === 'success' ? 5000 : 8000);
      },
      runAction(toast) {
        this.dismiss(toast.id);
        toast.action.run();
      },
      dismiss(id) {
        const toast = this.items.find((t) => t.id === id);
        if (!toast || toast.leaving) return;
        toast.leaving = true;
        setTimeout(() => { this.items = this.items.filter((t) => t.id !== id); }, TOAST_LEAVE_MS);
      },
    });

    Alpine.store('session', { warning: false });

    Alpine.store('downloads', {
      items: [],
      init() {
        if (window.BroadcastChannel) {
          downloadChannel = new BroadcastChannel(DOWNLOAD_CHANNEL);
          downloadChannel.onmessage = (event) => {
            if (event.data && event.data.type === 'job') this.update(event.data.job);
          };
          // Downloads started on another page are still running in the worker; ask for them.
          downloadChannel.postMessage({ type: 'list' });
        }
        setInterval(() => {
          const controller = navigator.serviceWorker && navigator.serviceWorker.controller;
          if (controller && this.items.some((job) => job.worker && job.state === 'running')) controller.postMessage({ type: 'keepalive' });
        }, DOWNLOAD_KEEPALIVE_MS);
        // Only an in-page download is lost when the page closes; a worker download carries on.
        window.addEventListener('beforeunload', (event) => {
          if (this.items.some((job) => !job.worker && job.state === 'running')) { event.preventDefault(); event.returnValue = ''; }
        });
      },
      async start(item) {
        if (this.items.some((job) => job.path === item.path && job.state === 'running')) return;
        const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
        // A folder is packed into an archive on the server first; its size is known only once that is done.
        const archive = item.type === 'dir';
        if (await downloadWorker) {
          this.items.push({ id, path: item.path, name: item.name, loaded: 0, total: archive ? 0 : item.size || 0, state: 'running', worker: true, archive });
          // The worker answers with the file as an attachment, or with 204 on failure, so the page never leaves.
          openDownloadFrame(id, downloadUrl('api/files/download', { path: item.path, dl: id }));
          return;
        }
        const url = downloadUrl('api/files/download', { path: item.path });
        if (!archive && item.size > DOWNLOAD_MEMORY_LIMIT) {
          openDownloadFrame(id, url);
          setTimeout(() => closeDownloadFrame(id), DOWNLOAD_FRAME_MS);
          Alpine.store('toasts').push('info', `Mengunduh ${item.name}`, 'Berkas di atas 1 GB diunduh langsung oleh browser. Kemajuannya tampil di daftar unduhan browser.');
          return;
        }
        await this.inPage(id, item, url);
      },
      /* Downloads the files and folders among the selected items; each folder arrives as an archive.
         Without the worker each download is held in memory until it is saved, so they run one after another. */
      async startMany(items) {
        const targets = items.filter((item) => item.type === 'file' || item.type === 'dir');
        const skipped = items.length - targets.length;
        if (!targets.length) {
          Alpine.store('toasts').push('warning', 'Tidak ada item yang dapat diunduh', 'Symlink tidak dapat diunduh langsung. Buka lokasi tujuannya, lalu unduh berkas atau folder di sana.');
          return;
        }
        if (skipped) Alpine.store('toasts').push('info', `${numberFormat.format(skipped)} symlink tidak ikut diunduh`, 'Buka lokasi tujuannya, lalu unduh berkas atau folder di sana.');
        for (const item of targets) await this.start(item);
      },
      async inPage(id, item, url) {
        const controller = new AbortController();
        inPageControllers.set(id, controller);
        const archive = item.type === 'dir';
        this.items.push({ id, path: item.path, name: item.name, loaded: 0, total: archive ? 0 : item.size || 0, state: 'running', worker: false, archive });
        const job = this.items.find((entry) => entry.id === id);
        try {
          const response = await fetch(url, { credentials: 'same-origin', signal: controller.signal });
          if (response.status === 401) { window.location.href = loginUrl(); return; }
          if (!response.ok) {
            let payload = null;
            try { payload = await response.json(); } catch (error) { payload = null; }
            throw new Error(payload?.message || `Permintaan gagal diproses (kode ${response.status}). Coba lagi.`);
          }
          job.total = Number(response.headers.get('Content-Length')) || job.total;
          if (archive && job.total > DOWNLOAD_MEMORY_LIMIT) {
            // Too large to hold in the page: the browser's download manager takes the archive instead.
            controller.abort();
            openDownloadFrame(id, url);
            setTimeout(() => closeDownloadFrame(id), DOWNLOAD_FRAME_MS);
            this.items = this.items.filter((entry) => entry.id !== id);
            Alpine.store('toasts').push('info', `Mengunduh ${item.name}`, 'Arsip di atas 1 GB diunduh langsung oleh browser. Server menyiapkan arsipnya sekali lagi, lalu kemajuannya tampil di daftar unduhan browser.');
            return;
          }
          const reader = response.body.getReader();
          const chunks = [];
          let received = 0;
          let drawn = 0;
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            chunks.push(value);
            received += value.length;
            // Redrawing on every chunk would re-render the card hundreds of times per second.
            if (performance.now() - drawn > DOWNLOAD_REDRAW_MS) { job.loaded = received; drawn = performance.now(); }
          }
          job.loaded = received;
          const href = URL.createObjectURL(new Blob(chunks, { type: 'application/octet-stream' }));
          const link = document.createElement('a');
          link.href = href;
          link.download = archive ? attachmentName(response, item.name) : item.name;
          document.body.appendChild(link);
          link.click();
          link.remove();
          setTimeout(() => URL.revokeObjectURL(href), 60000);
          this.settle(job, 'done');
        } catch (error) {
          if (error.name === 'AbortError') this.settle(job, 'cancelled');
          else this.settle(job, 'error', error.message === 'Failed to fetch' ? 'Koneksi terputus. Periksa koneksi, lalu coba lagi.' : error.message);
        } finally {
          inPageControllers.delete(id);
        }
      },
      /* Progress reported by the worker, for downloads started on this page or on an earlier one. */
      update(data) {
        let job = this.items.find((entry) => entry.id === data.id);
        if (!job) {
          if (data.state !== 'running') return;
          this.items.push({ id: data.id, path: data.path, name: data.name, loaded: 0, total: 0, state: 'running', worker: true });
          job = this.items.find((entry) => entry.id === data.id);
        }
        job.loaded = data.loaded;
        job.total = data.total || job.total;
        if (data.state !== 'running') this.settle(job, data.state, data.error);
      },
      settle(job, state, error) {
        if (job.state !== 'running') return;
        job.state = state;
        if (state === 'done') {
          job.total = job.total || job.loaded;
          job.loaded = job.total;
          setTimeout(() => this.remove(job.id), DOWNLOAD_DONE_MS);
          return;
        }
        this.remove(job.id);
        if (state === 'cancelled') Alpine.store('toasts').push('info', `Unduhan ${job.name} dibatalkan.`);
        else Alpine.store('toasts').push('error', `${job.name} gagal diunduh`, error || '');
      },
      remove(id) {
        closeDownloadFrame(id);
        this.items = this.items.filter((entry) => entry.id !== id);
      },
      cancel(job) {
        if (job.worker) downloadChannel?.postMessage({ type: 'cancel', id: job.id });
        else inPageControllers.get(job.id)?.abort();
      },
      percent(job) { return job.total ? Math.min(100, Math.round((job.loaded / job.total) * 100)) : 0; },
      text(job) {
        if (job.state === 'done') return `Selesai · ${formatBytes(job.total)}`;
        if (job.archive && !job.loaded) return 'Menyiapkan arsip di server...';
        if (!job.total) return `${formatBytes(job.loaded)} diterima`;
        return `${formatBytes(job.loaded)} dari ${formatBytes(job.total)} · ${this.percent(job)}%`;
      },
    });

    /* Generic server-driven list: search (debounced), filters, sort, numbered
       pagination, page length, URL persistence, and the loading/empty/error phases. */
    Alpine.data('listPage', listPage);

    /* One dialog for every change: dry-run preview, confirmation, apply, result. */
    // The operation dialog has no form fields to mark, so a field error is shown as the message itself
    // instead of the generic "check the marked fields" text.
    const dialogMessage = (error) => {
      const fields = Object.values(error.errors || {}).filter((value) => typeof value === 'string' && value !== '');
      return fields.length ? fields.join(' ') : error.message;
    };

    Alpine.data('opDialog', () => ({
      open: false,
      phase: 'idle',
      request: null,
      preview: null,
      result: null,
      errorMessage: '',
      confirmText: '',
      opener: null,

      init() {
        window.addEventListener('fm:op', (event) => this.start(event.detail));
      },
      async start(request) {
        this.request = Object.assign({ title: 'Pratinjau perubahan', confirmLabel: 'Terapkan', typedConfirm: '' }, request);
        this.preview = null;
        this.result = null;
        this.errorMessage = '';
        this.confirmText = '';
        this.opener = document.activeElement;
        this.open = true;
        this.phase = 'previewing';
        this.$nextTick(() => focusFirst(this.$refs.dialog));
        try {
          const payload = await api('api/ops/preview', { method: 'POST', body: { op: this.request.op, params: this.request.params } });
          if (!this.open) return;
          this.preview = payload.data;
          this.phase = 'ready';
        } catch (error) {
          if (!this.open) return;
          this.errorMessage = dialogMessage(error);
          this.phase = 'preview-error';
        }
      },
      canApply() {
        if (this.phase !== 'ready' && this.phase !== 'apply-error') return false;
        if (!this.preview || this.preview.noop) return false;
        return !this.request.typedConfirm || this.confirmText.trim().toUpperCase() === this.request.typedConfirm;
      },
      async apply() {
        if (!this.canApply()) return;
        this.phase = 'applying';
        this.errorMessage = '';
        try {
          const payload = await api('api/ops/apply', { method: 'POST', body: { op: this.request.op, params: this.request.params } });
          // onSuccess(result) may add a detail line and an action button to the confirmation.
          const extra = (this.request.onSuccess && !payload.data.noop && this.request.onSuccess(payload.data)) || {};
          Alpine.store('toasts').push('success', payload.message || 'Perubahan diterapkan.', extra.message || '', extra.action || null);
          window.dispatchEvent(new CustomEvent('fm:op-done', { detail: { op: this.request.op, result: payload.data } }));
          this.close(true);
        } catch (error) {
          this.errorMessage = dialogMessage(error);
          this.result = error.data;
          this.phase = 'apply-error';
          Alpine.store('toasts').push('error', this.errorMessage, (error.details || []).join(' '));
          // A partial failure still changed something on disk, so the page refreshes behind the dialog.
          if (error.data && error.data.history_id) {
            window.dispatchEvent(new CustomEvent('fm:op-done', { detail: { op: this.request.op, result: error.data } }));
          }
        }
      },
      close(force) {
        if (this.phase === 'applying' && !force) return;
        this.open = false;
        this.phase = 'idle';
        const opener = this.opener;
        this.$nextTick(() => restoreFocus(opener));
      },
      trap(event) { trapFocus(event, this.$refs.dialog); },
      formatNumber(value) { return numberFormat.format(value || 0); },
    }));

    Alpine.data('sessionWatch', () => ({
      remaining: 0,
      init() {
        setInterval(() => {
          if (session.pending > 0) session.touch();
          const left = session.idleMs - (Date.now() - session.last);
          this.remaining = Math.max(0, Math.ceil(left / 60000));
          Alpine.store('session').warning = left > 0 && left <= 2 * 60000;
          if (left <= 0) window.location.href = loginUrl();
        }, 15000);
      },
      async extend() {
        try {
          await api('api/system');
          Alpine.store('toasts').push('success', 'Sesi diperpanjang.');
        } catch (error) {
          Alpine.store('toasts').push('error', error.message);
        }
      },
    }));
  });

  function initSidebar() {
    const root = document.documentElement;
    const sidebar = document.getElementById('sidebar');
    const backdrop = document.getElementById('sidebar-backdrop');
    const button = document.getElementById('menu-button');
    if (!sidebar || !button) return;
    const desktop = window.matchMedia('(min-width: 1024px)');
    const writeMini = (mini) => { try { localStorage.setItem('fm-sidebar', mini ? 'mini' : 'full'); } catch (error) { /* in-memory state only */ } };
    const setMini = (mini) => {
      root.dataset.sidebar = mini ? 'mini' : 'full';
      sidebar.querySelectorAll('.nav-link').forEach((link) => {
        if (mini) link.setAttribute('title', link.dataset.label);
        else link.removeAttribute('title');
      });
    };
    const drawerOpen = () => root.dataset.drawer === 'open';
    const setDrawer = (open, returnFocus) => {
      root.dataset.drawer = open ? 'open' : 'closed';
      if (open) sidebar.querySelector('a')?.focus();
      else if (returnFocus) button.focus();
    };
    const sync = () => {
      const mini = root.dataset.sidebar === 'mini';
      const expanded = desktop.matches ? !mini : drawerOpen();
      button.setAttribute('aria-expanded', String(expanded));
      button.setAttribute('aria-label', desktop.matches
        ? (mini ? 'Luaskan navigasi' : 'Ciutkan navigasi')
        : (expanded ? 'Sembunyikan navigasi' : 'Tampilkan navigasi'));
    };
    button.addEventListener('click', () => {
      if (desktop.matches) {
        const mini = root.dataset.sidebar !== 'mini';
        setMini(mini);
        writeMini(mini);
      } else {
        setDrawer(!drawerOpen(), false);
      }
      sync();
    });
    backdrop?.addEventListener('click', () => { setDrawer(false, true); sync(); });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !desktop.matches && drawerOpen()) { setDrawer(false, true); sync(); }
    });
    desktop.addEventListener('change', () => { setDrawer(false, false); sync(); });
    root.dataset.drawer = 'closed';
    setMini(root.dataset.sidebar === 'mini');
    sync();
  }

  function initTheme() {
    const root = document.documentElement;
    const button = document.getElementById('theme-button');
    const system = window.matchMedia('(prefers-color-scheme: dark)');
    const readSaved = () => { try { return localStorage.getItem('fm-theme'); } catch (error) { return null; } };
    const apply = (dark) => {
      root.dataset.theme = dark ? 'dark' : 'light';
      if (!button) return;
      const label = dark ? 'Gunakan tema terang' : 'Gunakan tema gelap';
      button.setAttribute('aria-label', label);
      button.setAttribute('title', label);
    };
    button?.addEventListener('click', () => {
      const dark = root.dataset.theme !== 'dark';
      apply(dark);
      try { localStorage.setItem('fm-theme', dark ? 'dark' : 'light'); } catch (error) { /* this page keeps the choice until it is closed */ }
    });
    // Without a saved choice the page keeps following the system setting while it is open.
    system.addEventListener('change', (event) => { if (!readSaved()) apply(event.matches); });
    apply(root.dataset.theme === 'dark');
  }

  function initLogout() {
    const form = document.getElementById('logout-form');
    if (!form) return;
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = form.querySelector('button');
      button.disabled = true;
      try {
        const payload = await api('api/auth/logout', { method: 'POST' });
        window.location.href = payload.data?.redirect || '?r=login';
      } catch (error) {
        button.disabled = false;
        if (window.Alpine) Alpine.store('toasts').push('error', error.message);
      }
    });
  }

  registerDownloadWorker();

  document.addEventListener('DOMContentLoaded', () => {
    initSidebar();
    initTheme();
    initLogout();
  });

  window.FM = {
    api,
    ApiError,
    downloadUrl,
    formatBytes,
    formatDate,
    formatNumber: (value) => numberFormat.format(value || 0),
    debounce,
    trapFocus,
    focusFirst,
    restoreFocus,
    icons: ICONS,
    modalLeaveMs: MODAL_LEAVE_MS,
    setCsrf(token) { csrf = token; },
    loginUrl,
    /* Keeps the idle timer from ending the session while a request made outside FM.api (an upload) runs. */
    trackRequest(promise) { return session.track(promise); },
    toast(type, title, message) { Alpine.store('toasts').push(type, title, message); },
    /* Downloads a file or a folder (an item with path, name, type, and size) with the shared progress card. */
    download(item) { return Alpine.store('downloads').start(item); },
    /* Downloads every file and folder among the given items, each with its own progress card. */
    downloadMany(items) { return Alpine.store('downloads').startMany(items); },
    /* Opens the shared preview dialog for an operation. */
    operate(op, params, options = {}) {
      window.dispatchEvent(new CustomEvent('fm:op', { detail: Object.assign({ op, params }, options) }));
    },
    /* Applies an operation without a dry run (create, rename, save); returns the payload. */
    apply(op, params) {
      return api('api/ops/apply', { method: 'POST', body: { op, params } });
    },
    listPage,
    /* Create/edit modal plus delete confirmation for the settings lists (presets, policies). */
    crudMixin(options) {
      return {
        formOpen: false,
        form: Object.assign({}, options.blank),
        pristine: '',
        confirmDiscard: false,
        errors: {},
        busy: false,
        deleting: null,
        opener: null,
        openForm(item) {
          this.opener = document.activeElement;
          this.form = Object.assign({}, options.blank, item || {});
          this.pristine = JSON.stringify(this.form);
          this.errors = {};
          this.confirmDiscard = false;
          this.formOpen = true;
          this.$nextTick(() => focusFirst(this.$refs.formModal));
        },
        closeForm(force) {
          if (this.busy) return;
          if (!force && JSON.stringify(this.form) !== this.pristine) { this.confirmDiscard = true; return; }
          this.formOpen = false;
          const opener = this.opener;
          this.$nextTick(() => restoreFocus(opener));
        },
        async save() {
          this.busy = true;
          this.errors = {};
          try {
            const payload = await api(options.saveRoute, { method: 'POST', body: this.form });
            Alpine.store('toasts').push('success', payload.message);
            this.busy = false;
            this.closeForm(true);
            this.load();
          } catch (error) {
            this.errors = error.errors || {};
            if (!Object.keys(this.errors).length) Alpine.store('toasts').push('error', error.message);
            if (error.status === 404) { this.busy = false; this.closeForm(true); this.load(); }
          } finally {
            this.busy = false;
          }
        },
        askDelete(item) {
          this.opener = document.activeElement;
          this.deleting = item;
          this.$nextTick(() => focusFirst(this.$refs.delModal));
        },
        async confirmDelete() {
          this.busy = true;
          try {
            const payload = await api(options.deleteRoute, { method: 'POST', body: { id: this.deleting.id } });
            Alpine.store('toasts').push('success', payload.message);
            this.deleting = null;
            if (this.items.length === 1 && this.state.page > 1) this.state.page -= 1;
            this.load();
          } catch (error) {
            Alpine.store('toasts').push('error', error.message);
            if (error.status === 404) { this.deleting = null; this.load(); }
          } finally {
            this.busy = false;
          }
        },
      };
    },
    SEVERITY: {
      critical: { label: 'Kritis', chip: 'chip-danger' },
      high: { label: 'Tinggi', chip: 'chip-danger' },
      medium: { label: 'Sedang', chip: 'chip-warning' },
      low: { label: 'Rendah', chip: 'chip-neutral' },
    },
  };
})();
