/** @author Ertha Dwi Setiyawan */
document.addEventListener('alpine:init', () => {
  Alpine.data('webserverPage', () => ({
    info: null,
    detectPhase: 'loading',
    detectError: '',
    form: { path: '', user: '' },
    errors: {},
    result: null,
    checkPhase: 'idle',
    checkError: '',

    init() {
      const params = new URLSearchParams(location.search);
      this.form.path = params.get('path') || '';
      this.form.user = params.get('user') || '';
      this.detect();
      if (this.form.path && this.form.user) this.check();
    },
    async detect() {
      this.detectPhase = 'loading';
      try {
        const [detected, system] = await Promise.all([FM.api('api/webserver/detect'), FM.api('api/system')]);
        this.info = detected.data;
        if (!this.form.path) this.form.path = system.data.default_path || system.data.roots[0] || '';
        if (!this.form.user && this.info.accounts.length) this.form.user = this.info.accounts[0].name;
        this.detectPhase = 'content';
      } catch (error) {
        this.detectError = error.message;
        this.detectPhase = 'error';
      }
    },
    async check() {
      this.errors = {};
      history.replaceState(null, '', `?${new URLSearchParams({ r: 'webserver', path: this.form.path, user: this.form.user })}`);
      this.checkPhase = 'loading';
      try {
        const payload = await FM.api('api/webserver/check', { query: this.form });
        this.result = payload.data;
        this.checkPhase = 'content';
      } catch (error) {
        this.errors = error.errors || {};
        this.checkError = error.message;
        this.checkPhase = Object.keys(this.errors).length ? 'idle' : 'error';
      }
    },
    blocks() {
      const r = this.result;
      return [
        {
          key: 'traverse', title: 'Folder induk yang menghalangi', tone: 'chip-danger',
          count: r.traverse_blocked.length, items: r.traverse_blocked,
          help: 'Akun web server membutuhkan izin x pada setiap folder induk untuk mencapai folder situs.',
          empty: 'Semua folder induk dapat dilalui.',
        },
        {
          key: 'unreadable', title: 'Tidak dapat dibaca', tone: 'chip-warning',
          count: r.unreadable.count, items: r.unreadable.items,
          help: 'Berkas atau folder yang tidak dapat dibaca akun web server dapat menyebabkan galat 403 atau 500.',
          empty: 'Semua berkas dan folder dapat dibaca.',
        },
        {
          key: 'writable', title: 'Dapat ditulisi di luar folder tulis', tone: 'chip-danger',
          count: r.unexpected_writable.count, items: r.unexpected_writable.items,
          help: 'Kode yang dapat ditulisi akun web server memudahkan penyerang menanam skrip bila aplikasi berhasil dibobol.',
          empty: 'Akses tulis hanya ada di folder yang cocok dengan pola folder tulis.',
        },
        {
          key: 'notwritable', title: 'Folder tulis yang tidak dapat ditulisi', tone: 'chip-warning',
          count: r.not_writable.count, items: r.not_writable.items,
          help: 'Folder seperti storage atau uploads harus dapat ditulisi agar aplikasi berjalan normal.',
          empty: 'Semua folder tulis dapat ditulisi.',
        },
      ];
    },
  }));
});
