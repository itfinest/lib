/** @author Ertha Dwi Setiyawan */
document.addEventListener('alpine:init', () => {
  // Operations whose automatic snapshot can be rolled back from here. Trash has its own restore flow.
  const UNDOABLE = ['chmod', 'chown', 'preset', 'acl', 'rollback', 'audit_fix'];

  Alpine.data('historyPage', () => Object.assign(FM.listPage({
    route: 'api/history',
    sort: ['at', 'desc'],
    filters: { op: '', status: '', category: '' },
    init() {
      try { this.ops = JSON.parse(this.$el.dataset.ops || '{}'); } catch (error) { this.ops = {}; }
      window.addEventListener('fm:op-done', () => this.load());
    },
  }), {
    ops: {},
    detail: null,
    detailOpen: false,
    opener: null,
    opLabel(op) { return this.ops[op] || op; },
    canUndo(item) { return !!item && item.ok && !!item.snapshot_id && UNDOABLE.includes(item.op); },
    undo(item) {
      FM.operate('rollback', { snapshot_id: item.snapshot_id }, { title: `Batalkan: ${item.summary}`, confirmLabel: 'Batalkan Perubahan' });
    },
    show(item) {
      this.opener = document.activeElement;
      this.detail = item;
      this.detailOpen = true;
      this.$nextTick(() => FM.focusFirst(this.$refs.modal));
    },
    undoDetail() {
      const item = this.detail;
      this.closeDetail();
      this.$nextTick(() => this.undo(item));
    },
    closeDetail() {
      // detail stays set so the record is still visible while the close animation runs.
      this.detailOpen = false;
      const opener = this.opener;
      this.$nextTick(() => FM.restoreFocus(opener));
    },
    exportUrl() {
      return FM.downloadUrl('api/history/export', { op: this.state.op, status: this.state.status, category: this.state.category, search: this.state.search });
    },
  }));
});
