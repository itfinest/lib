/** @author Ertha Dwi Setiyawan */
document.addEventListener('alpine:init', () => {
  Alpine.data('sizesPage', () => ({
    form: { path: '', hidden: false },
    phase: 'idle',
    data: null,
    errorMessage: '',
    controller: null,

    async init() {
      const params = new URLSearchParams(location.search);
      this.form.hidden = params.get('hidden') === '1';
      if (params.get('path')) { this.analyze(params.get('path')); return; }
      try {
        const payload = await FM.api('api/system');
        this.form.path = payload.data.default_path || payload.data.roots[0] || '';
      } catch (error) {
        FM.toast('error', 'Informasi server gagal dimuat', error.message);
      }
    },
    async analyze(path) {
      if (!path) return;
      this.form.path = path;
      if (this.controller) this.controller.abort();
      this.controller = new AbortController();
      const params = new URLSearchParams({ r: 'sizes', path });
      if (this.form.hidden) params.set('hidden', '1');
      history.replaceState(null, '', `?${params}`);
      this.phase = 'loading';
      try {
        const payload = await FM.api('api/analysis/sizes', { query: { path, hidden: this.form.hidden }, signal: this.controller.signal });
        this.data = payload.data;
        this.phase = this.data.items.length ? 'content' : 'empty';
      } catch (error) {
        if (error.name === 'AbortError') return;
        this.errorMessage = error.message;
        this.phase = 'error';
      }
    },
  }));
});
