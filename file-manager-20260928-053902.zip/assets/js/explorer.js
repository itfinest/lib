/** @author Ertha Dwi Setiyawan */
/* File manager page: listing, folder tree, selection, and every file and
   permission action. Changes that need a dry run go through the shared
   operation dialog (FM.operate); quick ones call FM.apply directly. */
document.addEventListener('alpine:init', () => {
  const ARCHIVE = /\.(zip|tar|tar\.gz|tgz|tar\.bz2|tbz2|tar\.xz|txz)$/i;
  const PERM_ROWS = [
    { label: 'Pemilik', shift: 6 },
    { label: 'Grup', shift: 3 },
    { label: 'Lainnya', shift: 0 },
  ];
  const PERM_COLS = [
    { label: 'Baca', bit: 4 },
    { label: 'Tulis', bit: 2 },
    { label: 'Eksekusi', bit: 1 },
  ];
  const SPECIAL = [
    { label: 'Setuid', bit: 0o4000 },
    { label: 'Setgid', bit: 0o2000 },
    { label: 'Sticky', bit: 0o1000 },
  ];
  const DANGER_LABEL = {
    mode_777: 'Izin 777',
    world_writable_file: 'Ditulisi semua',
    world_writable_dir: 'Ditulisi semua',
    setuid: 'Setuid',
    setgid: 'Setgid',
    sensitive_readable: 'Sensitif terbuka',
    orphan_owner: 'Pemilik tak dikenal',
    broken_symlink: 'Symlink rusak',
  };

  const ACCESS_TEXT = {
    read: { file: ['Isi berkas dapat dibaca', 'Isi berkas tidak dapat dibaca'], dir: ['Isi folder dapat ditampilkan', 'Isi folder tidak dapat ditampilkan'] },
    exec: ['Dapat dijalankan sebagai program', 'Tidak dapat dijalankan sebagai program'],
    edit: { file: ['Isi berkas dapat diubah', 'Isi berkas tidak dapat diubah'], dir: ['Nama folder dapat diganti', 'Nama folder tidak dapat diganti'], link: ['Dapat diubah', 'Symlink tidak dapat diubah langsung'] },
    delete: ['Dapat dihapus', 'Tidak dapat dihapus'],
    add: ['Dapat ditambah berkas atau folder', 'Tidak dapat ditambah berkas atau folder'],
  };
  /* Walks a dropped file or folder and collects every file with its path relative to the drop. */
  async function collectEntry(entry, prefix, out) {
    if (entry.isFile) {
      const file = await new Promise((resolve, reject) => entry.file(resolve, reject));
      out.push({ file, path: prefix + file.name });
      return;
    }
    const reader = entry.createReader();
    // readEntries returns at most about 100 children per call, so it is called until it returns none.
    for (;;) {
      const children = await new Promise((resolve, reject) => reader.readEntries(resolve, reject));
      if (!children.length) return;
      for (const child of children) await collectEntry(child, `${prefix}${entry.name}/`, out);
    }
  }

  /* PHP drops every file past max_file_uploads and the whole body past post_max_size, so large selections go in several requests. */
  function uploadBatches(files, maxCount, maxBytes) {
    const batches = [];
    let current = [];
    let bytes = 0;
    files.forEach((entry) => {
      if (current.length && (current.length >= maxCount || bytes + entry.file.size > maxBytes)) {
        batches.push(current);
        current = [];
        bytes = 0;
      }
      current.push(entry);
      bytes += entry.file.size;
    });
    if (current.length) batches.push(current);
    return batches;
  }

  // Windows servers have no Unix mode bits or owners; the server says which one it is.
  const unixMeta = document.querySelector('meta[name="unix-permissions"]');

  /* Items marked with Salin or Potong, kept for the tab so they can be pasted after a reload. */
  const CLIPBOARD_KEY = 'fm-clipboard';
  function readClipboard() {
    try {
      const saved = JSON.parse(sessionStorage.getItem(CLIPBOARD_KEY) || 'null');
      if (saved && ['copy', 'move'].includes(saved.kind) && Array.isArray(saved.paths) && saved.paths.length) {
        return { kind: saved.kind, paths: saved.paths, from: String(saved.from || '') };
      }
    } catch (error) { /* storage blocked or unreadable: nothing is marked */ }
    return null;
  }
  function writeClipboard(value) {
    try {
      if (value) sessionStorage.setItem(CLIPBOARD_KEY, JSON.stringify(value));
      else sessionStorage.removeItem(CLIPBOARD_KEY);
    } catch (error) { /* this page keeps the marked items until it is closed */ }
  }

  const parseMode = (value) => (/^0?[0-7]{3,4}$/.test(String(value)) ? parseInt(value, 8) : null);
  const octal = (mode) => mode.toString(8).padStart(4, '0');

  Alpine.data('explorer', () => {
    const base = FM.listPage({
      route: 'api/files',
      sort: ['name', 'asc'],
      keep: ['path'],
      filters: { path: '', type: '', owner: '', group: '', hidden: '0', danger: '0', recursive: '0' },
      loaded(data) {
        this.cwd = data.cwd;
        this.roots = data.roots;
        this.breadcrumbs = data.breadcrumbs;
        this.parent = data.parent;
        this.truncated = data.truncated;
        this.warnings = data.warnings || [];
        this.cwdAccess = data.cwd_access || { add: true };
        if (this.state.path !== data.cwd) {
          this.state.path = data.cwd;
          this.writeUrl();
        }
        this.selected = this.selected.filter((path) => this.items.some((item) => item.path === path));
        this.revealInTree(data.cwd);
        if (this.revealPath) this.highlight(this.revealPath);
      },
      init() {
        window.addEventListener('popstate', () => { this.state = this.readUrl(); this.selected = []; this.load(); });
        window.addEventListener('fm:op-done', () => { this.selected = []; this.load(); this.refreshTreeNode(this.cwd); });
        this.loadSystem();
        this.loadFavorites();
        window.addEventListener('keydown', (event) => this.shortcut(event));
      },
    });

    return Object.assign(base, {
      cwd: '',
      roots: [],
      breadcrumbs: [],
      parent: null,
      truncated: false,
      warnings: [],
      unix: !unixMeta || unixMeta.content !== '0',
      cwdAccess: { add: true },
      system: { acl: false, shell: false, tools: {}, blocks_scripts: false, preview_types: {}, limits: { edit_bytes: 1048576, upload_bytes: 0, chunk_bytes: 2097152, max_file_uploads: 20, post_bytes: 8388608 } },
      selected: [],
      // Set by reveal(): the item to select once its folder has loaded.
      revealPath: '',
      menuFor: null,
      // What the row menu renders. It keeps the last menu while the bottom sheet slides out after menuFor is cleared.
      menuView: null,
      filtersOpen: false,
      modal: '',
      modalOpen: false,
      modalTimer: null,
      form: {},
      errors: {},
      busy: false,
      modalOpener: null,
      principals: null,
      presets: [],
      picker: { path: '', folders: [], breadcrumbs: [], parent: null, loading: false, error: '' },
      detail: { open: false, loading: false, error: '', data: null },
      detailOpener: null,
      checksum: { loading: false, error: '', data: null },
      clipboard: readClipboard(),
      pasteOverwrite: false,
      textSearch: { q: '', caseSensitive: false, regex: false, names: '', skip: '', phase: 'idle', result: null, error: '', errors: {} },
      searchController: null,
      favorites: [],
      favoritesOpen: false,
      tree: {},
      treeRoots: [],
      upload: { files: [], progress: 0, dragging: false, reading: false },
      previewStatus: 'loading',
      PERM_ROWS,
      PERM_COLS,
      SPECIAL,

      async loadSystem() {
        try {
          const payload = await FM.api('api/system');
          this.system = payload.data;
          this.treeRoots = payload.data.roots;
          payload.data.roots.forEach((root) => this.ensureNode(root, root, 0));
          if (this.cwd) this.revealInTree(this.cwd);
        } catch (error) {
          FM.toast('error', 'Informasi server gagal dimuat', error.message);
        }
      },

      /* Navigation */
      navigate(path) {
        if (!path || path === this.cwd) return;
        history.pushState(history.state, '', location.href);
        this.state.path = path;
        this.state.page = 1;
        this.state.search = '';
        this.state.recursive = '0';
        this.selected = [];
        this.menuFor = null;
        this.revealPath = '';
        this.load();
      },
      open(item) {
        if (item.target_type === 'dir') this.navigate(item.path);
        else if (item.type === 'file' && this.previewKind(item)) this.preview(item);
        else if (item.type === 'file') this.edit(item);
        else this.showDetail(item);
      },
      goUp() { if (this.parent) this.navigate(this.parent); },
      /* Opens the folder that holds a path, lists only that item, and selects it. */
      reveal(path) {
        let folder = path.slice(0, path.lastIndexOf('/'));
        if (!folder.includes('/')) folder += '/';
        if (folder !== this.cwd) history.pushState(history.state, '', location.href);
        this.revealPath = path;
        this.state.path = folder;
        this.state.page = 1;
        this.state.search = path.split('/').pop();
        this.state.recursive = '0';
        this.selected = [];
        this.menuFor = null;
        this.load();
      },
      highlight(path) {
        this.revealPath = '';
        if (!this.items.some((item) => item.path === path)) {
          FM.toast('warning', 'Berkas tidak ditemukan di folder tujuan', path);
          return;
        }
        this.selected = [path];
        // The table and the mobile list both render the item; only one of them is visible.
        this.$nextTick(() => {
          const row = [...this.$root.querySelectorAll('[data-path]')].find((node) => node.dataset.path === path && node.offsetParent !== null);
          if (!row) return;
          row.scrollIntoView({ block: 'nearest' });
          row.querySelector('input[type="checkbox"]')?.focus();
        });
      },
      goToTyped() {
        const path = (this.form.jump || '').trim();
        if (path) this.navigate(path);
      },

      activeFilterCount() {
        return ['type', 'owner', 'group', 'hidden', 'danger', 'recursive'].filter((key) => String(this.state[key]) !== String(this.defaults[key])).length;
      },

      /* Presentation helpers */
      iconFor(item) {
        if (item.type === 'link') return item.broken ? 'unlink' : 'link';
        if (item.type === 'dir') return 'folder';
        if (ARCHIVE.test(item.name)) return 'file-archive';
        if (/\.(png|jpe?g|gif|svg|webp|ico|bmp)$/i.test(item.name)) return 'image';
        if (/\.(php|js|ts|css|scss|html?|json|xml|ya?ml|sh|py|rb|go|sql|vue|twig|ini|conf|env)$/i.test(item.name)) return 'file-code';
        return 'file-text';
      },
      dangerLabel(rule) { return DANGER_LABEL[rule] || rule; },
      /* Rights reported by the server. Read is absent for symlinks, add applies to folders only, and execute to files only. */
      accessList(type, access) {
        if (!access) return [];
        const kind = type === 'dir' ? 'dir' : (type === 'link' ? 'link' : 'file');
        const text = (key, ok) => {
          const pair = key === 'edit' || key === 'read' ? ACCESS_TEXT[key][kind] : ACCESS_TEXT[key];
          return ok ? pair[0] : pair[1];
        };
        const present = (value) => value !== null && value !== undefined;
        const rights = [];
        if (present(access.read)) rights.push({ key: 'read', label: kind === 'dir' ? 'Buka' : 'Baca', ok: Boolean(access.read) });
        rights.push({ key: 'edit', label: 'Ubah', ok: Boolean(access.edit) });
        rights.push({ key: 'delete', label: 'Hapus', ok: Boolean(access.delete) });
        if (present(access.add)) rights.push({ key: 'add', label: 'Tambah', ok: Boolean(access.add) });
        if (present(access.exec)) rights.push({ key: 'exec', label: 'Eksekusi', ok: Boolean(access.exec) });
        return rights.map((right) => Object.assign(right, {
          text: text(right.key, right.ok),
          title: text(right.key, right.ok) + (!right.ok && access.note ? `. ${access.note}` : ''),
        }));
      },
      sizeText(item) { return item.type === 'dir' ? '-' : FM.formatBytes(item.size); },
      dateText(item) { return FM.formatDate(item.mtime); },
      displayName(item) { return this.state.recursive === '1' ? item.rel : item.name; },
      isArchive(item) { return item.type === 'file' && ARCHIVE.test(item.name); },

      /* Row menu: positioned against the viewport so the table's scroll box never clips it. Below 640px,
         where dialogs are bottom sheets too, it opens as a sheet over a backdrop instead. */
      openMenu(item, event) {
        // A right-click opens the menu at the pointer; the row's own menu button still takes the focus back.
        const pointer = event.type === 'contextmenu';
        if (!pointer && this.menuFor && this.menuFor.item.path === item.path) { this.menuFor = null; return; }
        const opener = pointer ? event.currentTarget.querySelector('[aria-haspopup="menu"]') : event.currentTarget;
        const focusFirst = () => this.$refs.rowMenu?.querySelector('[role="menuitem"]')?.focus();
        if (!window.matchMedia('(min-width: 640px)').matches) {
          this.menuFor = { item, sheet: true, opener };
          this.menuView = this.menuFor;
          this.$nextTick(focusFirst);
          return;
        }
        const width = 224;
        const rect = pointer
          ? { top: event.clientY, bottom: event.clientY, right: event.clientX + width }
          : event.currentTarget.getBoundingClientRect();
        // Room between the button and each viewport edge, keeping a 4px gap to the button and 8px to the edge.
        const below = Math.max(0, window.innerHeight - rect.bottom - 12);
        const above = Math.max(0, rect.top - 12);
        const left = Math.min(window.innerWidth - width - 8, Math.max(8, rect.right - width));
        this.menuFor = { item, top: rect.bottom + 4, left, maxHeight: below, opener };
        this.menuView = this.menuFor;
        this.$nextTick(() => {
          const menu = this.$refs.rowMenu;
          if (menu && this.menuFor) {
            // The item list depends on the row, so the side is chosen from the rendered height. A menu taller
            // than both sides takes the roomier one and scrolls inside, so no item ends up off screen.
            const height = menu.scrollHeight + menu.offsetHeight - menu.clientHeight;
            if (height > below && above > below) {
              this.menuFor.maxHeight = above;
              this.menuFor.top = rect.top - 4 - Math.min(height, above);
            }
          }
          focusFirst();
        });
      },
      closeMenu(returnFocus) {
        const opener = this.menuFor?.opener;
        this.menuFor = null;
        if (returnFocus) opener?.focus();
      },
      menuAction(action) {
        const item = this.menuFor.item;
        this.menuFor = null;
        this[action](item);
      },

      /* Selection */
      isSelected(path) { return this.selected.includes(path); },
      toggle(path) {
        this.selected = this.isSelected(path) ? this.selected.filter((p) => p !== path) : [...this.selected, path];
      },
      allSelected() { return this.items.length > 0 && this.items.every((item) => this.isSelected(item.path)); },
      toggleAll() {
        const pagePaths = this.items.map((item) => item.path);
        this.selected = this.allSelected() ? this.selected.filter((p) => !pagePaths.includes(p)) : [...new Set([...this.selected, ...pagePaths])];
      },
      clearSelection() { this.selected = []; },
      selectedItems() { return this.items.filter((item) => this.isSelected(item.path)); },
      single() { const items = this.selectedItems(); return items.length === 1 ? items[0] : null; },
      targets(item) { return item ? [item.path] : [...this.selected]; },
      targetItems(item) { return item ? [item] : this.selectedItems(); },
      describe(paths) { return paths.length === 1 ? paths[0].split('/').pop() : `${FM.formatNumber(paths.length)} item`; },

      /* Modal plumbing */
      openModal(name, form, item) {
        this.menuFor = null;
        this.modalOpener = document.activeElement;
        this.errors = {};
        this.form = Object.assign({ item: item || null, paths: this.targets(item) }, form);
        clearTimeout(this.modalTimer);
        this.modal = name;
        this.modalOpen = true;
        this.$nextTick(() => FM.focusFirst(this.$refs.modal));
      },
      closeModal(force) {
        if (this.busy && !force) return;
        if (!force && this.modal === 'createFile' && this.form.content) {
          this.form.confirmDiscard = true;
          return;
        }
        if (this.modal === 'search') this.cancelSearch();
        this.modalOpen = false;
        // The form is unmounted only after the close animation, so it does not vanish mid-fade.
        this.modalTimer = setTimeout(() => { this.modal = ''; }, FM.modalLeaveMs);
        const opener = this.modalOpener;
        this.$nextTick(() => FM.restoreFocus(opener));
      },
      trapModal(event) { FM.trapFocus(event, this.$refs.modal); },
      fieldError(key) { return this.errors[key] || ''; },
      async quick(op, params, successReload = true) {
        this.busy = true;
        this.errors = {};
        try {
          const payload = await FM.apply(op, params);
          FM.toast('success', payload.message);
          this.closeModal(true);
          if (successReload) { this.load(); this.refreshTreeNode(this.cwd); }
          return payload;
        } catch (error) {
          this.errors = error.errors || {};
          if (!Object.keys(this.errors).length) FM.toast('error', error.message, (error.details || []).join(' '));
          return null;
        } finally {
          this.busy = false;
        }
      },
      operate(op, params, options) {
        this.closeModal(true);
        this.$nextTick(() => FM.operate(op, params, options));
      },

      /* Create, rename, edit, download */
      newFolder() { this.openModal('mkdir', { name: '' }); },
      newFile() { this.openModal('createFile', { name: '', content: '', confirmDiscard: false }); },
      submitMkdir() { this.quick('mkdir', { dir: this.cwd, name: this.form.name }); },
      submitCreateFile() { this.quick('create_file', { dir: this.cwd, name: this.form.name, content: this.form.content }); },
      rename(item) { this.openModal('rename', { name: item.name }, item); },
      submitRename() { this.quick('rename', { path: this.form.item.path, name: this.form.name }); },
      edit(item) { window.location.href = `?r=editor&path=${encodeURIComponent(item.path)}`; },

      /* Inline preview for the types the server streams (system.preview_types). */
      previewKind(item) {
        if (!item || item.type !== 'file') return '';
        const dot = item.name.lastIndexOf('.');
        const mime = dot > 0 ? this.system.preview_types[item.name.slice(dot + 1).toLowerCase()] : '';
        if (!mime) return '';
        return mime === 'application/pdf' ? 'pdf' : mime.split('/')[0];
      },
      previewUrl(item) { return FM.downloadUrl('api/files/preview', { path: item.path }); },
      preview(item) {
        this.previewStatus = 'loading';
        this.openModal('preview', {}, item);
      },
      download(item) { FM.download(item); },
      downloadSelected() { FM.downloadMany(this.selectedItems()); },

      /* Clipboard: mark items with Salin or Potong, then paste them into the open folder. */
      markClipboard(kind, item) {
        const paths = this.targets(item);
        this.menuFor = null;
        this.clipboard = { kind, paths, from: this.cwd };
        this.pasteOverwrite = false;
        writeClipboard(this.clipboard);
        FM.toast('info', `${this.describe(paths)} siap ${kind === 'move' ? 'dipindahkan' : 'disalin'}`, 'Buka folder tujuan, lalu pilih Tempel di Sini.');
      },
      copyToClipboard(item) { this.markClipboard('copy', item); },
      cutToClipboard(item) { this.markClipboard('move', item); },
      clearClipboard() {
        this.clipboard = null;
        writeClipboard(null);
      },
      pasteBlocked() { return !this.clipboard || !this.cwd || this.clipboard.from === this.cwd; },
      paste() {
        if (this.pasteBlocked()) return;
        const { kind, paths } = this.clipboard;
        const verb = kind === 'move' ? 'Pindahkan' : 'Salin';
        FM.operate(kind, { paths, dest: this.cwd, overwrite: this.pasteOverwrite }, {
          title: `${verb} ${this.describe(paths)} ke folder ini`,
          confirmLabel: verb,
          // Moved items are no longer at their old location; copied items can be pasted again elsewhere.
          onSuccess: () => { if (kind === 'move') this.clearClipboard(); return null; },
        });
      },

      duplicate(item) {
        const paths = this.targets(item);
        this.menuFor = null;
        FM.operate('duplicate', { paths }, { title: `Duplikat ${this.describe(paths)}`, confirmLabel: 'Duplikat' });
      },

      /* Text search inside the files of the open folder and its subfolders. */
      openSearch() { this.openModal('search', {}); },
      async runSearch() {
        const s = this.textSearch;
        if (this.searchController) this.searchController.abort();
        const controller = new AbortController();
        this.searchController = controller;
        s.errors = {};
        s.error = '';
        if (!s.q.trim()) { s.errors = { q: 'Isi teks yang dicari.' }; return; }
        s.phase = 'loading';
        try {
          const payload = await FM.api('api/files/search', {
            query: { path: this.cwd, q: s.q, case: s.caseSensitive ? '1' : '0', regex: s.regex ? '1' : '0', names: s.names, skip: s.skip },
            signal: controller.signal,
          });
          if (controller !== this.searchController) return;
          s.result = payload.data;
          s.phase = 'done';
        } catch (error) {
          if (error.name === 'AbortError' || controller !== this.searchController) return;
          s.errors = error.errors || {};
          s.error = Object.keys(s.errors).length ? '' : error.message;
          s.phase = 'idle';
        }
      },
      cancelSearch() {
        if (this.searchController) this.searchController.abort();
        this.searchController = null;
        if (this.textSearch.phase === 'loading') this.textSearch.phase = 'idle';
      },
      editorUrl(path, line) { return `?r=editor&path=${encodeURIComponent(path)}${line ? `&line=${line}` : ''}`; },
      revealFromSearch(path) {
        this.closeModal(true);
        this.reveal(path);
      },

      /* Checksum of the file shown in the detail drawer, computed on request because large files take a while. */
      async computeChecksum() {
        const path = this.detail.item.path;
        this.checksum = { loading: true, error: '', data: null };
        try {
          const payload = await FM.api('api/files/checksum', { query: { path } });
          if (this.detail.item && this.detail.item.path === path) this.checksum.data = payload.data;
        } catch (error) {
          this.checksum.error = error.message;
        } finally {
          this.checksum.loading = false;
        }
      },

      /* Web address of an item served by a web server (item.url is set only when one is known). */
      copyItemLink(item) { this.copyLink(item.url); },
      async copyLink(url) {
        let copied = false;
        try {
          await navigator.clipboard.writeText(url);
          copied = true;
        } catch (error) {
          // navigator.clipboard exists only on HTTPS and localhost; plain HTTP servers fall back to a selected text field.
          const field = document.createElement('textarea');
          field.value = url;
          field.setAttribute('readonly', '');
          field.style.position = 'fixed';
          field.style.left = '-9999px';
          document.body.appendChild(field);
          field.select();
          try { copied = document.execCommand('copy'); } catch (fallbackError) { copied = false; }
          field.remove();
        }
        if (copied) FM.toast('success', 'Link disalin ke clipboard.', url);
        else FM.toast('error', 'Clipboard tidak dapat diakses oleh browser ini. Salin link secara manual.', url);
      },

      /* Copy and move with a folder picker */
      copyItem(item) { this.transfer('copy', item); },
      moveItem(item) { this.transfer('move', item); },
      transfer(kind, item) {
        this.openModal('transfer', { kind, dest: this.cwd, overwrite: false }, item);
        this.loadPicker(this.cwd);
      },
      async loadPicker(path) {
        this.picker.loading = true;
        this.picker.error = '';
        try {
          const payload = await FM.api('api/folders', { query: { path, hidden: this.state.hidden } });
          Object.assign(this.picker, payload.data, { path: payload.data.cwd });
        } catch (error) {
          this.picker.error = error.message;
        } finally {
          this.picker.loading = false;
        }
      },
      pickFolder(path) { this.form.dest = path; this.loadPicker(path); },
      submitTransfer() {
        const verb = this.form.kind === 'move' ? 'Pindahkan' : 'Salin';
        this.operate(this.form.kind, { paths: this.form.paths, dest: this.form.dest, overwrite: this.form.overwrite }, {
          title: `${verb} ${this.describe(this.form.paths)}`,
          confirmLabel: verb,
        });
      },

      /* Delete: trash by default, permanent on request */
      remove(item) { this.openModal('delete', { permanent: false }, item); },
      submitDelete() {
        const count = this.describe(this.form.paths);
        if (this.form.permanent) {
          this.operate('delete', { paths: this.form.paths }, { title: `Hapus permanen ${count}`, confirmLabel: 'Hapus Permanen', typedConfirm: 'HAPUS' });
        } else {
          this.operate('trash', { paths: this.form.paths }, { title: `Pindahkan ${count} ke tempat sampah`, confirmLabel: 'Pindahkan ke Tempat Sampah' });
        }
      },

      /* Permissions (chmod) */
      chmod(item) {
        const items = this.targetItems(item);
        const dirs = items.filter((i) => i.type === 'dir');
        const files = items.filter((i) => i.type === 'file');
        const common = (list, fallback) => (list.length && list.every((i) => i.octal === list[0].octal) ? list[0].octal : fallback);
        this.openModal('chmod', {
          recursive: false,
          hasDirs: dirs.length > 0,
          hasFiles: files.length > 0,
          links: items.filter((i) => i.type === 'link').length,
          dirMode: common(dirs, '0755'),
          fileMode: common(files, '0644'),
          applyDirs: true,
          applyFiles: true,
        }, item);
      },
      showDirGrid() { return this.form.recursive || this.form.hasDirs; },
      showFileGrid() { return this.form.recursive || this.form.hasFiles; },
      hasBit(key, bit) { const mode = parseMode(this.form[key]); return mode !== null && (mode & bit) !== 0; },
      flipBit(key, bit) {
        const mode = parseMode(this.form[key]) ?? 0;
        this.form[key] = octal(mode ^ bit);
      },
      symbolic(key, isDir) {
        const mode = parseMode(this.form[key]);
        if (mode === null) return 'mode tidak valid';
        let out = isDir ? 'd' : '-';
        [[6, 0o4000, 's'], [3, 0o2000, 's'], [0, 0o1000, 't']].forEach(([shift, flag, ch]) => {
          const t = (mode >> shift) & 7;
          out += t & 4 ? 'r' : '-';
          out += t & 2 ? 'w' : '-';
          if (mode & flag) out += t & 1 ? ch : ch.toUpperCase();
          else out += t & 1 ? 'x' : '-';
        });
        return out;
      },
      submitChmod() {
        const f = this.form;
        const params = { paths: f.paths, recursive: f.recursive };
        if (this.showDirGrid() && (!f.recursive || f.applyDirs)) params.dir_mode = f.dirMode;
        if (this.showFileGrid() && (!f.recursive || f.applyFiles)) params.file_mode = f.fileMode;
        this.errors = {};
        ['dir_mode', 'file_mode'].forEach((key) => {
          if (params[key] !== undefined && parseMode(params[key]) === null) this.errors[key] = 'Gunakan 3 atau 4 digit oktal, misalnya 0755.';
        });
        if (!params.dir_mode && !params.file_mode) this.errors.dir_mode = 'Pilih minimal satu jenis item yang diubah izinnya.';
        if (Object.keys(this.errors).length) return;
        this.operate('chmod', params, { title: `Ubah izin ${this.describe(f.paths)}`, confirmLabel: 'Terapkan Izin' });
      },

      /* Ownership (chown) */
      async ensurePrincipals() {
        if (this.principals) return;
        try {
          const payload = await FM.api('api/principals');
          this.principals = payload.data;
        } catch (error) {
          this.principals = { users: [], groups: [] };
          FM.toast('warning', 'Daftar pengguna dan grup tidak dapat dimuat', error.message);
        }
      },
      chown(item) {
        const items = this.targetItems(item);
        const same = (key) => (items.length && items.every((i) => i[key] === items[0][key]) ? items[0][key] : '');
        this.openModal('chown', { owner: same('owner'), group: same('group'), recursive: false, hasDirs: items.some((i) => i.type === 'dir') }, item);
        this.ensurePrincipals();
      },
      submitChown() {
        if (!this.form.owner.trim() && !this.form.group.trim()) {
          this.errors = { owner: 'Isi pemilik, grup, atau keduanya.' };
          return;
        }
        this.operate('chown', { paths: this.form.paths, owner: this.form.owner.trim(), group: this.form.group.trim(), recursive: this.form.recursive }, {
          title: `Ubah pemilik ${this.describe(this.form.paths)}`,
          confirmLabel: 'Terapkan Pemilik',
        });
      },

      /* Presets */
      async preset(item) {
        const items = this.targetItems(item);
        this.openModal('preset', { preset_id: '', recursive: items.some((i) => i.type === 'dir'), hasDirs: items.some((i) => i.type === 'dir') }, item);
        try {
          const payload = await FM.api('api/presets', { query: { per_page: 'all', sort_by: 'name' } });
          this.presets = payload.data.items;
          if (!this.form.preset_id && this.presets.length) this.form.preset_id = this.presets[0].id;
        } catch (error) {
          FM.toast('error', 'Daftar preset gagal dimuat', error.message);
        }
      },
      presetById(id) { return this.presets.find((p) => p.id === id) || null; },
      submitPreset() {
        if (!this.form.preset_id) { this.errors = { preset_id: 'Pilih preset.' }; return; }
        const preset = this.presetById(this.form.preset_id);
        this.operate('preset', { paths: this.form.paths, preset_id: this.form.preset_id, recursive: this.form.recursive }, {
          title: `Terapkan preset "${preset ? preset.name : ''}"`,
          confirmLabel: 'Terapkan Preset',
        });
      },

      /* ACL */
      async acl(item) {
        const items = this.targetItems(item);
        this.openModal('acl', {
          action: 'modify', tag: 'user', qualifier: '', r: true, w: false, x: false,
          isDefault: false, recursive: false, hasDirs: items.some((i) => i.type === 'dir'), current: null, loadingCurrent: items.length === 1,
        }, item);
        this.ensurePrincipals();
        if (items.length === 1) {
          try {
            const payload = await FM.api('api/files/detail', { query: { path: items[0].path } });
            this.form.current = payload.data.acl;
          } catch (error) {
            FM.toast('error', 'ACL saat ini gagal dimuat', error.message);
          } finally {
            this.form.loadingCurrent = false;
          }
        }
      },
      aclSpec() {
        const f = this.form;
        const perms = `${f.r ? 'r' : '-'}${f.w ? 'w' : '-'}${f.x ? 'x' : '-'}`;
        const qualifier = ['mask', 'other'].includes(f.tag) ? '' : f.qualifier.trim();
        return f.action === 'remove' ? `${f.tag}:${qualifier}` : `${f.tag}:${qualifier}:${perms}`;
      },
      submitAcl() {
        const f = this.form;
        if (f.action === 'remove' && !f.qualifier.trim()) { this.errors = { spec: 'Isi nama pengguna atau grup yang entrinya dihapus.' }; return; }
        const title = f.action === 'clear' ? 'Hapus seluruh ACL tambahan' : (f.action === 'remove' ? `Hapus entri ACL ${this.aclSpec()}` : `Tetapkan entri ACL ${this.aclSpec()}`);
        this.operate('acl', { paths: f.paths, action: f.action, spec: this.aclSpec(), default: f.isDefault, recursive: f.recursive }, {
          title: `${title} pada ${this.describe(f.paths)}`,
          confirmLabel: 'Terapkan ACL',
        });
      },

      /* Archives */
      compress(item) {
        const paths = this.targets(item);
        const base = paths.length === 1 ? paths[0].split('/').pop() : `arsip-${new Date().toISOString().slice(0, 10)}`;
        // The archive defaults to the folder that holds the items ("/" or "D:/" when they sit at a root).
        let parent = paths[0].slice(0, paths[0].lastIndexOf('/'));
        if (!parent.includes('/')) parent += '/';
        // The default patterns (setting compress_exclude) are prefilled; the user can edit or clear them.
        // A default pattern that matches a selected item itself is left out, so compressing
        // a folder named "vendor" or a single .json file does not produce an empty archive.
        const names = paths.map((path) => path.split('/').pop().toLowerCase());
        const exclude = (this.system.compress_exclude || []).filter((pattern) => !names.some((name) => (pattern.startsWith('*.') ? name.endsWith(pattern.slice(1).toLowerCase()) : name === pattern.toLowerCase())));
        // The configured destination (setting compress_path) wins, unless it lies inside a selected
        // folder, where the server refuses it because the archive would try to include itself.
        const configured = this.system.compress_path || '';
        const dest = configured && !paths.some((path) => configured === path || configured.startsWith(path + '/')) ? configured : parent;
        this.openModal('compress', { name: base, format: this.system.tools.tar ? 'tar.gz' : 'zip', dest, exclude: exclude.join('\n') }, item);
        this.loadPicker(dest);
      },
      submitCompress() {
        this.operate('compress', { paths: this.form.paths, name: this.form.name, format: this.form.format, dest: this.form.dest, exclude: this.form.exclude }, {
          title: `Kompres ${this.describe(this.form.paths)}`,
          confirmLabel: 'Buat Arsip',
          onSuccess: (result) => {
            const archive = (result.targets || [])[0];
            if (!archive) return null;
            return { message: `Arsip tersimpan di ${archive}`, action: { label: 'Lihat Lokasi', run: () => this.reveal(archive) } };
          },
        });
      },
      extract(item) {
        this.openModal('extract', { dest: this.cwd }, item);
        this.loadPicker(this.cwd);
      },
      submitExtract() {
        this.operate('extract', { path: this.form.item.path, dest: this.form.dest }, {
          title: `Ekstrak ${this.form.item.name}`,
          confirmLabel: 'Ekstrak',
        });
      },

      /* Snapshot of the selection */
      snapshot(item) {
        const paths = this.targets(item);
        this.openModal('snapshot', { label: '', recursive: this.targetItems(item).some((i) => i.type === 'dir'), acl: false }, item);
        this.form.label = `Snapshot ${this.describe(paths)}`;
      },
      async submitSnapshot() {
        this.busy = true;
        this.errors = {};
        try {
          const payload = await FM.api('api/snapshots/create', { method: 'POST', body: { paths: this.form.paths, label: this.form.label, recursive: this.form.recursive, acl: this.form.acl } });
          FM.toast('success', payload.message);
          this.closeModal(true);
        } catch (error) {
          this.errors = error.errors || {};
          if (!Object.keys(this.errors).length) FM.toast('error', error.message);
        } finally {
          this.busy = false;
        }
      },

      openUpload() {
        this.upload = { files: [], progress: 0, dragging: false, reading: false };
        this.openModal('upload', { overwrite: false });
      },
      pickFiles(event) {
        // Files chosen with the folder button carry their path inside the chosen folder.
        this.upload.files = [...event.target.files].map((file) => ({ file, path: file.webkitRelativePath || file.name }));
        this.errors = {};
        event.target.value = '';
      },
      dragOverUpload(event) {
        const blocked = this.busy || this.upload.reading;
        event.dataTransfer.dropEffect = blocked ? 'none' : 'copy';
        this.upload.dragging = !blocked;
      },
      async dropFiles(event) {
        this.upload.dragging = false;
        if (this.busy || this.upload.reading) return;
        // The entries must be taken while the drop event runs; the browser empties the list afterwards.
        const entries = [...event.dataTransfer.items].filter((item) => item.kind === 'file').map((item) => item.webkitGetAsEntry()).filter(Boolean);
        this.errors = {};
        this.upload.reading = true;
        try {
          const files = [];
          for (const entry of entries) await collectEntry(entry, '', files);
          this.upload.files = files;
          if (!files.length) this.errors = { files: 'Folder yang dilepas tidak berisi berkas.' };
        } catch (error) {
          this.upload.files = [];
          this.errors = { files: 'Isi folder tidak dapat dibaca oleh browser. Pilih folder melalui tombol Pilih Folder.' };
        } finally {
          this.upload.reading = false;
        }
      },
      uploadTooBig() {
        const limit = this.system.limits.upload_bytes;
        return limit > 0 ? this.upload.files.filter((entry) => entry.file.size > limit) : [];
      },
      uploadSummary() {
        const bytes = this.upload.files.reduce((sum, entry) => sum + entry.file.size, 0);
        return `${FM.formatNumber(this.upload.files.length)} berkas, ${FM.formatBytes(bytes)}`;
      },
      sendUploadBatch(batch, onProgress) {
        const data = new FormData();
        data.append('dir', this.cwd);
        data.append('overwrite', this.form.overwrite ? '1' : '0');
        batch.forEach((entry) => {
          data.append('files[]', entry.file, entry.file.name);
          data.append('paths[]', entry.path);
        });
        return this.postUpload('api/files/upload', data, onProgress);
      },
      /* A file above the server upload limits goes in pieces; the server joins them and writes the file after the last one. */
      async sendChunked(entry, chunkBytes, onProgress) {
        const bytes = crypto.getRandomValues(new Uint8Array(16));
        const uploadId = [...bytes].map((byte) => byte.toString(16).padStart(2, '0')).join('');
        const size = entry.file.size;
        for (let offset = 0; offset < size; offset += chunkBytes) {
          const piece = entry.file.slice(offset, Math.min(offset + chunkBytes, size));
          const data = new FormData();
          data.append('upload_id', uploadId);
          data.append('dir', this.cwd);
          data.append('path', entry.path);
          data.append('offset', String(offset));
          data.append('size', String(size));
          data.append('overwrite', this.form.overwrite ? '1' : '0');
          data.append('chunk', piece, 'chunk');
          await this.postUpload('api/files/upload-chunk', data, (ratio) => onProgress((offset + piece.size * ratio) / size));
        }
      },
      /* Upload with progress (fetch has no upload progress, so XHR is used here). */
      postUpload(route, data, onProgress) {
        return FM.trackRequest(new Promise((resolve, reject) => {
          const xhr = new XMLHttpRequest();
          xhr.open('POST', `?r=${route}`);
          xhr.setRequestHeader('X-CSRF-Token', document.querySelector('meta[name="csrf-token"]').content);
          xhr.setRequestHeader('Accept', 'application/json');
          xhr.upload.onprogress = (event) => { if (event.lengthComputable) onProgress(event.loaded / event.total); };
          xhr.onload = () => {
            let payload = null;
            try { payload = JSON.parse(xhr.responseText); } catch (error) { payload = null; }
            if (xhr.status === 401) { window.location.href = FM.loginUrl(); return; }
            if (xhr.status >= 200 && xhr.status < 300 && payload && payload.status === 'success') {
              resolve(payload);
              return;
            }
            reject(new FM.ApiError(xhr.status, payload?.message || 'Unggahan gagal. Periksa koneksi, lalu coba lagi.', payload?.data));
          };
          xhr.onerror = () => reject(new FM.ApiError(0, 'Unggahan terputus. Periksa koneksi, lalu coba lagi.'));
          xhr.send(data);
        }));
      },
      async submitUpload() {
        const files = this.upload.files;
        const limits = this.system.limits;
        if (!files.length) { this.errors = { files: 'Pilih minimal satu berkas atau folder.' }; return; }
        if (this.uploadTooBig().length) { this.errors = { files: `Ukuran berkas melebihi batas ${FM.formatBytes(limits.upload_bytes)}.` }; return; }
        this.busy = true;
        this.errors = {};
        this.upload.progress = 0;
        let done = 0;
        try {
          // Names, conflicts, and folder clashes are checked for the whole selection before the first byte is sent.
          const check = await FM.api('api/files/upload-check', { method: 'POST', body: { dir: this.cwd, paths: files.map((entry) => entry.path), overwrite: this.form.overwrite } });
          const chunkBytes = limits.chunk_bytes;
          const large = files.filter((entry) => entry.file.size > chunkBytes);
          // Part of post_max_size is left for the multipart headers of each file.
          const batches = uploadBatches(files.filter((entry) => entry.file.size <= chunkBytes), Math.max(1, limits.max_file_uploads), Math.floor(limits.post_bytes * 0.9));
          const total = files.reduce((sum, entry) => sum + entry.file.size, 0) || 1;
          let sent = 0;
          const progress = (bytes) => { this.upload.progress = Math.round(((sent + bytes) / total) * 100); };
          for (const batch of batches) {
            const size = batch.reduce((sum, entry) => sum + entry.file.size, 0);
            await this.sendUploadBatch(batch, (ratio) => progress(size * ratio));
            sent += size;
            done += batch.length;
          }
          for (const entry of large) {
            await this.sendChunked(entry, chunkBytes, (ratio) => progress(entry.file.size * ratio));
            sent += entry.file.size;
            done += 1;
          }
          const folders = check.data.folders;
          FM.toast('success', `${FM.formatNumber(done)} berkas berhasil diunggah${folders ? ` dan ${FM.formatNumber(folders)} folder dibuat` : ''}.`);
          this.busy = false;
          this.closeModal(true);
          this.load();
        } catch (error) {
          this.busy = false;
          this.upload.progress = 0;
          this.errors = error.errors || {};
          const partial = done ? ` Sebanyak ${FM.formatNumber(done)} dari ${FM.formatNumber(files.length)} berkas sudah terunggah.` : '';
          if (!this.errors.files || partial) FM.toast('error', error.message + partial);
          if (done) this.load();
        }
      },

      /* Favorite folders */
      async loadFavorites() {
        try {
          const payload = await FM.api('api/favorites');
          this.favorites = payload.data.items;
        } catch (error) {
          FM.toast('error', 'Daftar favorit gagal dimuat', error.message);
        }
      },
      favoriteOf(path) {
        const key = this.unix ? path : path.toLowerCase();
        return this.favorites.find((fav) => (this.unix ? fav.path : fav.path.toLowerCase()) === key) || null;
      },
      async toggleFavorite() {
        const current = this.favoriteOf(this.cwd);
        if (current) { await this.removeFavorite(current); return; }
        try {
          const payload = await FM.api('api/favorites/save', { method: 'POST', body: { path: this.cwd } });
          this.favorites.push(Object.assign({ available: true }, payload.data));
          FM.toast('success', payload.message);
        } catch (error) {
          FM.toast('error', 'Folder gagal ditambahkan ke favorit', Object.values(error.errors || {})[0] || error.message);
        }
      },
      async removeFavorite(fav) {
        try {
          const payload = await FM.api('api/favorites/delete', { method: 'POST', body: { id: fav.id } });
          this.favorites = this.favorites.filter((entry) => entry.id !== fav.id);
          FM.toast('success', payload.message);
        } catch (error) {
          FM.toast('error', 'Favorit gagal dihapus', error.message);
          if (error.status === 404) this.loadFavorites();
        }
      },
      openFavorite(fav) {
        if (!fav.available) {
          FM.toast('warning', 'Folder favorit tidak dapat dibuka', `${fav.path} sudah tidak ada atau berada di luar folder root. Hapus favorit ini bila tidak dipakai lagi.`);
          return;
        }
        this.favoritesOpen = false;
        this.navigate(fav.path);
      },

      /* Keyboard shortcuts for the list. They stay out of the way of text fields, dialogs, and the row menu. */
      shortcut(event) {
        if (event.defaultPrevented || this.modalOpen || this.menuFor || this.detail.open) return;
        const target = event.target;
        const typing = target.closest('textarea, select, [contenteditable="true"]')
          || (target.tagName === 'INPUT' && !['checkbox', 'radio', 'button', 'submit'].includes(target.type));
        if (typing) return;
        // The operation dialog and other shared dialogs live outside this component.
        if ([...document.querySelectorAll('[role="dialog"][aria-modal="true"]')].some((el) => el.getClientRects().length)) return;
        const mod = event.ctrlKey || event.metaKey;
        const key = event.key.length === 1 ? event.key.toLowerCase() : event.key;
        const run = (action) => { event.preventDefault(); action(); };
        if (mod && !event.altKey) {
          if (key === 'a' && this.phase === 'content') run(() => { this.selected = [...new Set([...this.selected, ...this.items.map((item) => item.path)])]; });
          // Text the user selected on the page is copied as usual.
          else if ((key === 'c' || key === 'x') && this.selected.length && !String(window.getSelection() || '')) run(() => this.markClipboard(key === 'x' ? 'move' : 'copy'));
          else if (key === 'v' && !this.pasteBlocked()) run(() => this.paste());
          return;
        }
        if (event.altKey && key === 'ArrowUp') { run(() => this.goUp()); return; }
        if (event.altKey || (event.shiftKey && key !== '?')) return;
        if (key === 'Delete' && this.selected.length) run(() => this.remove());
        else if (key === 'F2' && this.single()) run(() => this.rename(this.single()));
        else if (key === 'Enter' && this.single() && !target.closest('button, a')) run(() => this.open(this.single()));
        else if (key === 'Backspace' && this.parent) run(() => this.goUp());
        else if (key === '?') run(() => this.openModal('shortcuts', {}));
      },

      /* Detail drawer */
      async showDetail(item) {
        this.menuFor = null;
        this.detailOpener = document.activeElement;
        this.detail = { open: true, loading: true, error: '', data: null, item };
        this.checksum = { loading: false, error: '', data: null };
        this.$nextTick(() => FM.focusFirst(this.$refs.detailPanel));
        try {
          const payload = await FM.api('api/files/detail', { query: { path: item.path } });
          this.detail.data = payload.data;
        } catch (error) {
          this.detail.error = error.message;
        } finally {
          this.detail.loading = false;
        }
      },
      closeDetail() {
        this.detail.open = false;
        const opener = this.detailOpener;
        this.$nextTick(() => FM.restoreFocus(opener));
      },

      /* Folder tree (lazy) */
      ensureNode(path, name, depth) {
        if (!this.tree[path]) this.tree[path] = { path, name, depth, open: false, loaded: false, loading: false, children: [] };
        return this.tree[path];
      },
      async loadNode(node) {
        node.loading = true;
        try {
          const payload = await FM.api('api/folders', { query: { path: node.path, hidden: this.state.hidden } });
          node.children = payload.data.folders.map((f) => this.ensureNode(f.path, f.name, node.depth + 1).path);
          node.loaded = true;
        } catch (error) {
          node.children = [];
        } finally {
          node.loading = false;
        }
      },
      async toggleNode(path) {
        const node = this.tree[path];
        if (!node) return;
        if (!node.loaded) await this.loadNode(node);
        node.open = !node.open;
      },
      async revealInTree(path) {
        // A root may end with a slash ("/" on Linux, "D:/" for a whole Windows drive).
        const prefix = (r) => (r.endsWith('/') ? r : `${r}/`);
        const root = this.treeRoots.find((r) => path === r || path.startsWith(prefix(r)));
        if (!root) return;
        let current = this.tree[root];
        const rest = path.slice(root.length).split('/').filter(Boolean);
        let walk = root;
        for (const segment of rest) {
          if (!current) return;
          if (!current.loaded) await this.loadNode(current);
          current.open = true;
          walk = prefix(walk) + segment;
          current = this.tree[walk];
        }
      },
      refreshTreeNode(path) {
        const node = this.tree[path];
        if (node && node.loaded) this.loadNode(node);
      },
      treeRows() {
        const rows = [];
        const visit = (path) => {
          const node = this.tree[path];
          if (!node) return;
          rows.push(node);
          if (node.open) node.children.forEach(visit);
        };
        this.treeRoots.forEach(visit);
        return rows;
      },
    });
  });
});
