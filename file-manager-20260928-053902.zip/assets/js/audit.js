/** @author Ertha Dwi Setiyawan */
document.addEventListener('alpine:init', () => {
  Alpine.data('auditPage', () => Object.assign(FM.listPage({
    route: 'api/audit/findings',
    sort: ['severity_rank', 'desc'],
    keep: ['id'],
    filters: { id: '', severity: '', rule: '' },
    autoload: false,
    loaded(data) {
      this.meta = data.meta;
      this.catalog = data.rules;
    },
    init() {
      this.loadRuns(true);
      window.addEventListener('fm:op-done', () => FM.toast('info', 'Jalankan audit ulang untuk memperbarui daftar temuan.'));
    },
  }), {
    runs: [],
    runsLoading: true,
    meta: null,
    catalog: [],
    runPath: '',
    usePolicies: true,
    running: false,
    runError: '',
    fixOpen: false,
    fixRules: [],
    fixError: '',

    async loadRuns(initial) {
      this.runsLoading = true;
      try {
        const [runs, system] = await Promise.all([FM.api('api/audit/runs'), initial ? FM.api('api/system') : Promise.resolve(null)]);
        this.runs = runs.data.items;
        this.catalog = runs.data.rules;
        if (system && !this.runPath) this.runPath = system.data.default_path || system.data.roots[0] || '';
        if (this.runs.length && !this.runs.some((r) => r.id === this.state.id)) this.state.id = this.runs[0].id;
        if (this.state.id) this.load();
      } catch (error) {
        FM.toast('error', 'Daftar hasil audit gagal dimuat', error.message);
      } finally {
        this.runsLoading = false;
      }
    },
    async run() {
      this.running = true;
      this.runError = '';
      try {
        const payload = await FM.api('api/audit/run', { method: 'POST', body: { path: this.runPath, policies: this.usePolicies } });
        FM.toast('success', payload.message);
        this.state.id = payload.data.id;
        this.state.severity = '';
        this.state.rule = '';
        this.state.search = '';
        this.state.page = 1;
        await this.loadRuns(false);
      } catch (error) {
        this.runError = error.errors.path || error.message;
      } finally {
        this.running = false;
      }
    },
    kpis() {
      const c = this.meta ? this.meta.counts : {};
      return [
        { key: 'critical', label: 'Kritis', value: c.critical || 0, tone: c.critical ? 'text-danger-700' : 'text-ink', caption: 'Perlu ditangani segera' },
        { key: 'high', label: 'Tinggi', value: c.high || 0, tone: c.high ? 'text-danger-700' : 'text-ink', caption: '' },
        { key: 'medium', label: 'Sedang', value: c.medium || 0, tone: c.medium ? 'text-warning-700' : 'text-ink', caption: '' },
        { key: 'low', label: 'Rendah', value: c.low || 0, tone: 'text-ink', caption: '' },
        { key: 'scanned', label: 'Entri diperiksa', value: this.meta ? this.meta.scanned : 0, tone: 'text-ink', caption: this.meta ? `${this.meta.path} · ${FM.formatNumber(this.meta.duration_ms)} ms` : '' },
      ];
    },
    rulesInRun() {
      const counts = this.meta ? this.meta.by_rule : {};
      return this.catalog.filter((r) => counts[r.id]).map((r) => Object.assign({}, r, { count: counts[r.id] }));
    },
    fixableRules() { return this.rulesInRun().filter((r) => r.fixable); },
    exportUrl(format) {
      return FM.downloadUrl('api/audit/export', { id: this.state.id, format, severity: this.state.severity, rule: this.state.rule });
    },
    openFix() {
      this.fixRules = this.fixableRules().map((r) => r.id);
      this.fixError = '';
      this.fixOpen = true;
      this.$nextTick(() => FM.focusFirst(this.$refs.modal));
    },
    submitFix() {
      if (!this.fixRules.length) { this.fixError = 'Pilih minimal satu jenis temuan.'; return; }
      this.fixOpen = false;
      FM.operate('audit_fix', { audit_id: this.state.id, rules: [...this.fixRules] }, { title: 'Perbaiki temuan audit', confirmLabel: 'Terapkan Perbaikan' });
    },
  }));
});
