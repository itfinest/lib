/** @author Ertha Dwi Setiyawan */
document.addEventListener('alpine:init', () => {
  const PREFS_KEY = 'fm-editor';
  // Theme names match the stylesheets bundled by tools/copy-vendor.js (CODEMIRROR_CSS).
  const THEMES = [
    { group: 'Terang', items: [['default', 'Terang'], ['eclipse', 'Eclipse'], ['idea', 'IntelliJ'], ['solarized light', 'Solarized Terang']] },
    { group: 'Gelap', items: [['material-darker', 'Material Gelap'], ['dracula', 'Dracula'], ['monokai', 'Monokai'], ['nord', 'Nord'], ['darcula', 'Darcula'], ['solarized dark', 'Solarized Gelap'], ['gruvbox-dark', 'Gruvbox Gelap']] },
  ];
  const THEME_NAMES = THEMES.flatMap((group) => group.items.map((item) => item[0]));
  const FONT_SIZES = [12, 13, 14, 15, 16, 18];
  const LANGUAGES = [
    ['text/plain', 'Teks Biasa'],
    ['application/x-httpd-php', 'PHP'],
    ['text/html', 'HTML'],
    ['text/javascript', 'JavaScript'],
    ['application/typescript', 'TypeScript'],
    ['text/jsx', 'JSX'],
    ['application/json', 'JSON'],
    ['text/css', 'CSS'],
    ['text/x-scss', 'SCSS'],
    ['text/x-less', 'LESS'],
    ['application/xml', 'XML'],
    ['text/x-sql', 'SQL'],
    ['text/x-python', 'Python'],
    ['text/x-sh', 'Shell'],
    ['application/x-powershell', 'PowerShell'],
    ['text/x-yaml', 'YAML'],
    ['text/x-markdown', 'Markdown'],
    ['text/x-properties', 'INI / Properties'],
    ['text/x-nginx-conf', 'Nginx'],
    ['text/x-dockerfile', 'Dockerfile'],
    ['text/x-toml', 'TOML'],
    ['text/x-diff', 'Diff'],
    ['text/x-go', 'Go'],
    ['text/x-csrc', 'C'],
    ['text/x-c++src', 'C++'],
    ['text/x-csharp', 'C#'],
    ['text/x-java', 'Java'],
  ];
  // Configuration files without a CodeMirror mode of their own read best as key/value files.
  const PROPERTIES_FILES = /^(\.env(\..+)?|\.htaccess|\.editorconfig|\.npmrc|php\.ini)$/i;
  const MAX_COUNTED_MATCHES = 10000;
  const MAX_HINTS = 200;

  // Suggestions for the word at the cursor, in order: the language add-on (HTML tags and attributes,
  // CSS properties, JavaScript names, SQL keywords), the language keywords, then words already in the file.
  function smartHint(editor, options) {
    const cursor = editor.getCursor();
    const words = CodeMirror.hint.anyword(editor, options);
    const helper = editor.getHelpers(cursor, 'hint')[0];
    const language = helper ? helper(editor, options) : null;
    // A tag or attribute suggestion replaces more than the word (for example "<di"), so it stands alone.
    // In HTML text the tag add-on lists every tag at the cursor without anything typed; that list is skipped.
    if (language && CodeMirror.cmpPos(language.from, words.from) !== 0) {
      if (language.list.length && editor.getRange(language.from, language.to) !== '') return language;
      language.list = [];
    }
    const prefix = editor.getRange(words.from, words.to);
    const lower = prefix.toLowerCase();
    const keywords = (editor.getHelper(cursor, 'hintWords') || []).filter((word) => word.toLowerCase().startsWith(lower));
    const seen = new Set([prefix]);
    const list = [];
    [...(language ? language.list : []), ...keywords, ...words.list].forEach((item) => {
      const text = typeof item === 'string' ? item : item.text;
      if (!text || seen.has(text) || list.length >= MAX_HINTS) return;
      seen.add(text);
      list.push(item);
    });
    return list.length ? { list, from: words.from, to: words.to } : null;
  }

  function readPrefs() {
    // Without a saved choice the editor starts in a theme that matches the app theme.
    const theme = document.documentElement.dataset.theme === 'dark' ? 'material-darker' : 'default';
    const prefs = { theme, fontSize: 13, wrap: true, tabIndent: true, autocomplete: true };
    try {
      const saved = JSON.parse(localStorage.getItem(PREFS_KEY) || '{}');
      if (THEME_NAMES.includes(saved.theme)) prefs.theme = saved.theme;
      if (FONT_SIZES.includes(saved.fontSize)) prefs.fontSize = saved.fontSize;
      if (typeof saved.wrap === 'boolean') prefs.wrap = saved.wrap;
      if (typeof saved.tabIndent === 'boolean') prefs.tabIndent = saved.tabIndent;
      if (typeof saved.autocomplete === 'boolean') prefs.autocomplete = saved.autocomplete;
    } catch (error) { /* storage blocked or unreadable: defaults apply */ }
    return prefs;
  }

  function detectEol(text) {
    const crlf = (text.match(/\r\n/g) || []).length;
    const lf = (text.match(/\n/g) || []).length - crlf;
    return crlf > lf ? 'CRLF' : 'LF';
  }

  // Reads the first 2,000 lines: tabs win when more lines start with a tab, otherwise the most
  // common step between consecutive indentation levels gives the width.
  function detectIndent(text) {
    let tabs = 0;
    let spaces = 0;
    let previous = 0;
    const steps = { 2: 0, 4: 0, 8: 0 };
    text.split('\n', 2000).forEach((line) => {
      if (!line.trim()) return;
      if (line[0] === '\t') { tabs++; previous = 0; return; }
      const width = line.length - line.replace(/^ +/, '').length;
      if (width) spaces++;
      const step = Math.abs(width - previous);
      if (steps[step] !== undefined) steps[step]++;
      previous = width;
    });
    if (tabs > spaces) return 'tabs';
    if (!spaces) return 'spaces-4';
    const best = Object.keys(steps).reduce((a, b) => (steps[b] > steps[a] ? b : a), '4');
    return `spaces-${steps[best] ? best : 4}`;
  }

  function detectLanguage(name) {
    if (PROPERTIES_FILES.test(name)) return { mime: 'text/x-properties', label: 'INI / Properties' };
    const info = CodeMirror.findModeByFileName(name);
    if (!info || !CodeMirror.modes[info.mode]) return { mime: 'text/plain', label: 'Teks Biasa' };
    // PHP files mix HTML and PHP, which only the httpd-php variant highlights.
    const mime = info.mode === 'php' ? 'application/x-httpd-php' : (info.mime || info.mimes[0]);
    const known = LANGUAGES.find((language) => language[0] === mime);
    return { mime, label: known ? known[1] : info.name };
  }

  // Same highlighter as CodeMirror's search add-on: marks every match on the visible lines.
  function searchOverlay(regex) {
    const pattern = new RegExp(regex.source, regex.flags);
    return {
      token(stream) {
        pattern.lastIndex = stream.pos;
        const match = pattern.exec(stream.string);
        if (match && match.index === stream.pos) {
          stream.pos += match[0].length || 1;
          return 'searching';
        }
        if (match) stream.pos = match.index;
        else stream.skipToEnd();
        return null;
      },
    };
  }

  Alpine.data('editor', () => {
    // CodeMirror keeps its own state; wrapping it in Alpine's reactive proxy would break it.
    let cm = null;
    let focusWhenVisible = false;
    let cleanGeneration = 0;
    let overlay = null;
    let currentMark = null;
    let matchStarts = [];
    // Line requested in the URL (a content search result); applied once the editor is visible.
    let pendingLine = Number(new URLSearchParams(location.search).get('line')) || 0;

    return {
      path: new URLSearchParams(location.search).get('path') || '',
      phase: 'loading',
      hash: '',
      entry: null,
      reason: '',
      errorMessage: '',
      conflict: '',
      saving: false,
      revision: 0,
      lines: 0,
      eol: 'LF',
      savedEol: 'LF',
      indent: 'spaces-4',
      language: 'text/plain',
      languages: LANGUAGES.slice(),
      prefs: readPrefs(),
      themes: THEMES,
      fontSizes: FONT_SIZES,
      cursor: { line: 1, col: 1 },
      selectionText: '',
      bar: '',
      find: { query: '', replacement: '', caseSensitive: false, wholeWord: false, regex: false },
      findTotal: 0,
      findIndex: 0,
      findCapped: false,
      findError: '',
      gotoValue: '',
      gotoError: '',
      shortcutsOpen: false,
      shortcutsOpener: null,

      get dirty() {
        this.revision;
        return this.phase === 'ready' && cm !== null && (!cm.isClean(cleanGeneration) || this.eol !== this.savedEol);
      },

      init() {
        window.addEventListener('beforeunload', (event) => {
          if (this.dirty) { event.preventDefault(); event.returnValue = ''; }
        });
        this.findDebounced = FM.debounce(() => this.runFind(true), 300);
        this.recountDebounced = FM.debounce(() => this.runFind(false), 300);
        this.load();
      },
      name() { return this.path.split('/').pop(); },
      folder() { return this.path.slice(0, this.path.lastIndexOf('/')) || '/'; },
      backUrl() { return `?r=explorer&path=${encodeURIComponent(this.folder())}`; },
      downloadUrl() { return FM.downloadUrl('api/files/download', { path: this.path }); },
      separator() { return this.eol === 'CRLF' ? '\r\n' : '\n'; },

      async load() {
        this.phase = 'loading';
        this.conflict = '';
        this.closeBar(false);
        try {
          const payload = await FM.api('api/files/content', { query: { path: this.path } });
          const data = payload.data;
          this.entry = data.entry;
          this.path = data.path;
          document.title = `${this.name()} · Editor Teks`;
          if (!data.editable) {
            this.reason = data.reason;
            this.phase = 'readonly';
            return;
          }
          const language = detectLanguage(this.name());
          if (!this.languages.some((item) => item[0] === language.mime)) this.languages.push([language.mime, language.label]);
          this.language = language.mime;
          this.eol = detectEol(data.content);
          this.savedEol = this.eol;
          this.indent = detectIndent(data.content);
          this.hash = data.hash;
          this.phase = 'ready';
          this.$nextTick(() => this.mount(data.content));
        } catch (error) {
          this.errorMessage = error.message;
          this.phase = 'error';
        }
      },
      mount(text) {
        if (!cm) {
          const host = this.$refs.frame.querySelector('.editor-host');
          cm = CodeMirror(host, Object.assign({
            theme: this.prefs.theme,
            lineNumbers: true,
            lineWrapping: this.prefs.wrap,
            keyMap: 'sublime',
            tabSize: 4,
            styleActiveLine: true,
            matchBrackets: true,
            autoCloseBrackets: true,
            autoCloseTags: true,
            matchTags: { bothTags: true },
            highlightSelectionMatches: { minChars: 2 },
            foldGutter: true,
            gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
            spellcheck: false,
            autocorrect: false,
            autocapitalize: false,
            // Ctrl+Space always opens the list; completeSingle off keeps a lone match from being inserted unasked.
            hintOptions: { hint: smartHint, completeSingle: false, useGlobalScope: false },
          }, this.indentOptions()));
          cm.on('changes', () => {
            this.revision++;
            this.lines = cm.lineCount();
            if (this.bar === 'find' || this.bar === 'replace') this.recountDebounced();
          });
          cm.on('cursorActivity', () => this.updateCursor());
          cm.on('inputRead', (editor, change) => this.suggest(editor, change));
          // CodeMirror measures its box once and only re-measures on window resize. x-show reveals the
          // host in a later task and the sidebar toggle changes its width, so either change would leave
          // the editor blank or mis-sized until the next click without this observer.
          new ResizeObserver(() => {
            if (!host.offsetWidth || !host.offsetHeight) return;
            cm.refresh();
            if (pendingLine) { this.centerOn(pendingLine - 1, 0); pendingLine = 0; }
            if (focusWhenVisible) { focusWhenVisible = false; cm.focus(); }
          }).observe(host);
        }
        cm.setOption('mode', this.language);
        cm.setOption('screenReaderLabel', `Isi berkas ${this.name()}`);
        cm.setOption('extraKeys', this.extraKeys());
        Object.entries(this.indentOptions()).forEach(([key, value]) => cm.setOption(key, value));
        cm.setValue(text);
        cm.clearHistory();
        cleanGeneration = cm.changeGeneration(true);
        this.lines = cm.lineCount();
        this.revision++;
        cm.refresh();
        focusWhenVisible = true;
        this.updateCursor();
      },
      indentOptions() {
        const tabs = this.indent === 'tabs';
        return { indentWithTabs: tabs, indentUnit: tabs ? 4 : Number(this.indent.split('-')[1]) };
      },
      extraKeys() {
        const keys = {
          'Alt-Up': 'swapLineUp',
          'Alt-Down': 'swapLineDown',
          'Shift-Alt-Down': 'duplicateLine',
          'Ctrl-Q': (editor) => editor.foldCode(editor.getCursor()),
          'Ctrl-Space': 'autocomplete',
        };
        if (this.prefs.tabIndent) {
          // A selection over several lines indents those lines; otherwise Tab inserts one indentation step.
          keys.Tab = (editor) => {
            const multiline = editor.listSelections().some((range) => range.anchor.line !== range.head.line);
            if (multiline) editor.execCommand('indentMore');
            else editor.execCommand(editor.getOption('indentWithTabs') ? 'insertTab' : 'insertSoftTab');
          };
          keys['Shift-Tab'] = 'indentLess';
        } else {
          // false hands the key back to the browser, so Tab moves focus out of the editor.
          keys.Tab = false;
          keys['Shift-Tab'] = false;
        }
        return keys;
      },
      /* Opens the suggestion list while typing: after two word characters, or after "<" in HTML and XML. */
      suggest(editor, change) {
        if (!this.prefs.autocomplete || editor.state.completionActive || change.origin !== '+input') return;
        const typed = change.text.length === 1 ? change.text[0] : '';
        const cursor = editor.getCursor();
        const token = editor.getTokenAt(cursor);
        if (/\bcomment\b/.test(token.type || '')) return;
        const before = editor.getLine(cursor.line).slice(0, cursor.ch);
        const markup = typed === '<' && editor.getModeAt(cursor).name === 'xml';
        if (markup || (/^[\w$]$/.test(typed) && /[\w$]{2}$/.test(before))) editor.showHint();
      },
      updateCursor() {
        const head = cm.getCursor('head');
        const column = CodeMirror.countColumn(cm.getLine(head.line), head.ch, cm.getOption('tabSize'));
        this.cursor = { line: head.line + 1, col: column + 1 };
        const selections = cm.listSelections();
        if (selections.length > 1) {
          this.selectionText = `${FM.formatNumber(selections.length)} kursor`;
        } else {
          const length = cm.getSelection().length;
          this.selectionText = length ? `${FM.formatNumber(length)} karakter dipilih` : '';
        }
      },

      setPref(key, value) {
        this.prefs[key] = value;
        if (cm) {
          if (key === 'theme') cm.setOption('theme', value);
          if (key === 'wrap') cm.setOption('lineWrapping', value);
          if (key === 'tabIndent') cm.setOption('extraKeys', this.extraKeys());
          if (key === 'fontSize') this.$nextTick(() => cm.refresh());
        }
        try { localStorage.setItem(PREFS_KEY, JSON.stringify(this.prefs)); } catch (error) { /* this page keeps the choice until it is closed */ }
      },
      setLanguage(mime) {
        this.language = mime;
        if (cm) cm.setOption('mode', mime);
      },
      applyIndent() {
        if (cm) Object.entries(this.indentOptions()).forEach(([key, value]) => cm.setOption(key, value));
      },

      shortcut(event) {
        if (this.shortcutsOpen) return;
        const mod = (event.ctrlKey || event.metaKey) && !event.altKey;
        const key = event.key.toLowerCase();
        if (mod && key === 's') { event.preventDefault(); this.save(); return; }
        if (this.phase !== 'ready' || !cm) return;
        if (mod && key === 'f') { event.preventDefault(); this.openBar('find'); }
        else if (mod && key === 'h') { event.preventDefault(); this.openBar('replace'); }
        else if (mod && key === 'g') { event.preventDefault(); this.openBar('goto'); }
        else if (event.key === 'F3' && this.find.query) { event.preventDefault(); this.findNext(event.shiftKey ? -1 : 1); }
        else if (event.key === 'Escape' && this.bar) this.closeBar();
      },
      openBar(kind) {
        if (this.phase !== 'ready' || !cm) return;
        if (kind === 'goto') {
          this.clearFind();
          this.gotoValue = '';
          this.gotoError = '';
        } else {
          const selected = cm.getSelection();
          if (selected && !selected.includes('\n')) this.find.query = selected;
        }
        this.bar = kind;
        this.$nextTick(() => {
          const input = kind === 'goto' ? this.$refs.gotoInput : (kind === 'replace' && this.find.query ? this.$refs.replaceInput : this.$refs.findInput);
          input.focus();
          input.select();
          if (kind !== 'goto') this.runFind(false);
        });
      },
      toggleReplace() {
        this.bar = this.bar === 'replace' ? 'find' : 'replace';
        if (this.bar === 'replace') this.$nextTick(() => this.$refs.replaceInput.focus());
      },
      closeBar(focusEditor = true) {
        this.bar = '';
        this.clearFind();
        if (cm && focusEditor) cm.focus();
      },
      clearFind() {
        if (overlay && cm) cm.removeOverlay(overlay);
        overlay = null;
        if (currentMark) currentMark.clear();
        currentMark = null;
        matchStarts = [];
        this.findTotal = 0;
        this.findIndex = 0;
        this.findCapped = false;
      },
      findRegex() {
        this.findError = '';
        const query = this.find.query;
        if (!query) return null;
        let source = this.find.regex ? query : query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        if (this.find.wholeWord) source = `\\b(?:${source})\\b`;
        let regex;
        try {
          regex = new RegExp(source, this.find.caseSensitive ? 'gm' : 'gim');
        } catch (error) {
          this.findError = 'Pola ekspresi reguler tidak valid.';
          return null;
        }
        if (regex.test('')) {
          this.findError = 'Pola harus cocok dengan minimal satu karakter.';
          return null;
        }
        regex.lastIndex = 0;
        return regex;
      },
      runFind(moveSelection) {
        if (!cm) return;
        this.clearFind();
        const regex = this.findRegex();
        if (!regex) return;
        overlay = searchOverlay(regex);
        cm.addOverlay(overlay);
        const cursor = cm.getSearchCursor(regex, CodeMirror.Pos(cm.firstLine(), 0));
        while (cursor.findNext()) {
          if (matchStarts.length >= MAX_COUNTED_MATCHES) { this.findCapped = true; break; }
          matchStarts.push(cursor.from());
        }
        this.findTotal = matchStarts.length;
        if (moveSelection) this.findNext(1, true);
        else this.syncFindIndex();
      },
      findInputChanged() {
        this.findError = '';
        this.findDebounced();
      },
      toggleFindOption(key) {
        this.find[key] = !this.find[key];
        this.runFind(true);
      },
      syncFindIndex() {
        const from = cm.getCursor('from');
        let low = 0;
        let high = matchStarts.length - 1;
        this.findIndex = 0;
        while (low <= high) {
          const mid = (low + high) >> 1;
          const order = CodeMirror.cmpPos(matchStarts[mid], from);
          if (order === 0) { this.findIndex = mid + 1; return; }
          if (order < 0) low = mid + 1;
          else high = mid - 1;
        }
      },
      findNext(direction, fromSelectionStart = false) {
        const regex = this.findRegex();
        if (!regex || !cm) return;
        const start = direction > 0 && !fromSelectionStart ? cm.getCursor('to') : cm.getCursor('from');
        let cursor = cm.getSearchCursor(regex, start);
        let found = direction > 0 ? cursor.findNext() : cursor.findPrevious();
        if (!found) {
          cursor = cm.getSearchCursor(regex, direction > 0 ? CodeMirror.Pos(cm.firstLine(), 0) : CodeMirror.Pos(cm.lastLine()));
          found = direction > 0 ? cursor.findNext() : cursor.findPrevious();
        }
        if (!found) { this.syncFindIndex(); return; }
        this.selectMatch(cursor.from(), cursor.to());
      },
      selectMatch(from, to) {
        cm.setSelection(from, to);
        cm.scrollIntoView({ from, to }, 80);
        if (currentMark) currentMark.clear();
        currentMark = cm.markText(from, to, { className: 'cm-search-current' });
        this.syncFindIndex();
      },
      findStatus() {
        if (this.findError) return this.findError;
        if (!this.find.query) return '';
        if (!this.findTotal) return 'Tidak ditemukan';
        const total = FM.formatNumber(this.findTotal) + (this.findCapped ? '+' : '');
        return this.findIndex ? `${FM.formatNumber(this.findIndex)} dari ${total}` : `${total} kecocokan`;
      },
      // In regex mode $1 to $9 insert a capture group, $& the whole match, and $$ a dollar sign.
      replacementFor(match) {
        if (!this.find.regex || !Array.isArray(match)) return this.find.replacement;
        return this.find.replacement.replace(/\$(\$|&|\d)/g, (all, token) => {
          if (token === '$') return '$';
          if (token === '&') return match[0];
          return match[Number(token)] !== undefined ? match[Number(token)] : '';
        });
      },
      replaceOne() {
        const regex = this.findRegex();
        if (!regex || !cm) return;
        const from = cm.getCursor('from');
        const to = cm.getCursor('to');
        const cursor = cm.getSearchCursor(regex, from);
        const match = cursor.findNext();
        if (match && CodeMirror.cmpPos(cursor.from(), from) === 0 && CodeMirror.cmpPos(cursor.to(), to) === 0) {
          cursor.replace(this.replacementFor(match));
          cm.setCursor(cursor.to());
        }
        this.findNext(1, true);
      },
      replaceAll() {
        const regex = this.findRegex();
        if (!regex || !cm) return;
        let count = 0;
        cm.operation(() => {
          const cursor = cm.getSearchCursor(regex, CodeMirror.Pos(cm.firstLine(), 0));
          let match = cursor.findNext();
          while (match) {
            cursor.replace(this.replacementFor(match));
            count++;
            match = cursor.findNext();
          }
        });
        this.runFind(false);
        // The replace buttons turn disabled once nothing matches, which would drop focus to the page.
        this.$refs.replaceInput.focus();
        if (count) FM.toast('success', `${FM.formatNumber(count)} kecocokan diganti.`);
        else FM.toast('info', 'Tidak ada kecocokan yang dapat diganti.');
      },
      goToLine() {
        const parts = /^\s*(\d+)(?:\s*[:,]\s*(\d+))?\s*$/.exec(this.gotoValue);
        if (!parts) {
          this.gotoError = 'Masukkan nomor baris, misalnya 120 atau 120:8.';
          return;
        }
        this.centerOn(Number(parts[1]) - 1, parts[2] ? Math.max(Number(parts[2]) - 1, 0) : 0);
        this.closeBar();
      },
      /* Puts the cursor on a line (0-based, clamped to the file) and scrolls it to the middle. */
      centerOn(line, ch) {
        const target = Math.min(Math.max(line, 0), cm.lineCount() - 1);
        cm.setCursor({ line: target, ch });
        const top = cm.charCoords({ line: target, ch: 0 }, 'local').top;
        cm.scrollTo(null, Math.max(0, top - cm.getScrollInfo().clientHeight / 2));
      },

      openShortcuts() {
        this.shortcutsOpener = document.activeElement;
        this.shortcutsOpen = true;
        this.$nextTick(() => FM.focusFirst(this.$refs.shortcutsModal));
      },
      closeShortcuts() {
        this.shortcutsOpen = false;
        const opener = this.shortcutsOpener;
        this.$nextTick(() => FM.restoreFocus(opener));
      },

      reloadContent(force) {
        if (this.dirty && !force) {
          this.conflict = 'Perubahan yang belum disimpan akan hilang bila isi berkas dimuat ulang. Pilih "Muat Versi Server" untuk melanjutkan.';
          return;
        }
        this.load();
      },
      async save() {
        if (this.phase !== 'ready' || this.saving || !this.dirty) return;
        this.saving = true;
        // Edits typed while the request runs stay unsaved: the clean point is the generation sent.
        const generation = cm.changeGeneration(true);
        const eol = this.eol;
        const content = cm.getValue(this.separator());
        try {
          await FM.apply('save', { path: this.path, content, expected_hash: this.hash });
          cleanGeneration = generation;
          this.savedEol = eol;
          this.revision++;
          this.conflict = '';
          FM.toast('success', `${this.name()} disimpan.`);
          // The server's hash of what is now on disk guards the next save against concurrent edits.
          try {
            const fresh = await FM.api('api/files/content', { query: { path: this.path } });
            this.hash = fresh.data.hash || '';
            this.entry = fresh.data.entry || this.entry;
          } catch (error) {
            this.hash = '';
          }
        } catch (error) {
          if (error.status === 409) this.conflict = error.message;
          else FM.toast('error', 'Berkas gagal disimpan', (error.details || []).join(' ') || error.message);
        } finally {
          this.saving = false;
        }
      },
      async copyToClipboard() {
        try {
          await navigator.clipboard.writeText(cm ? cm.getValue(this.separator()) : '');
          FM.toast('success', 'Isi editor disalin ke clipboard.');
        } catch (error) {
          FM.toast('error', 'Clipboard tidak dapat diakses oleh browser ini.');
        }
      },
    };
  });
});
