/** @author Ertha Dwi Setiyawan */
/* Loaded without defer in <head> so the theme is set before the first paint. A choice saved by
   the theme button wins; without one the page follows the system setting. core.js wires the button. */
(function () {
  'use strict';

  let saved = null;
  try { saved = localStorage.getItem('fm-theme'); } catch (error) { /* storage blocked: follow the system */ }
  const dark = saved === 'dark' || (saved !== 'light' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
})();
