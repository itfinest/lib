/** @author Ertha Dwi Setiyawan */
document.addEventListener('alpine:init', () => {
  Alpine.data('trashPage', () => Object.assign(FM.listPage({
    route: 'api/trash',
    sort: ['deleted_at', 'desc'],
    loaded() { this.selected = this.selected.filter((id) => this.items.some((item) => item.id === id)); },
    init() { window.addEventListener('fm:op-done', () => { this.selected = []; this.load(); }); },
  }), {
    selected: [],
    toggle(id) { this.selected = this.selected.includes(id) ? this.selected.filter((x) => x !== id) : [...this.selected, id]; },
    allSelected() { return this.items.length > 0 && this.items.every((item) => this.selected.includes(item.id)); },
    toggleAll() {
      const ids = this.items.map((item) => item.id);
      this.selected = this.allSelected() ? this.selected.filter((id) => !ids.includes(id)) : [...new Set([...this.selected, ...ids])];
    },
    label(ids) {
      if (ids.length !== 1) return `${ids.length} item`;
      const item = this.items.find((i) => i.id === ids[0]);
      return item ? item.name : '1 item';
    },
    restore(ids) {
      // A quarantined file goes back into a folder the web server serves, so it needs a typed confirmation.
      const quarantined = this.items.some((item) => ids.includes(item.id) && item.quarantine);
      FM.operate('restore', { ids: [...ids] }, { title: `Pulihkan ${this.label(ids)}`, confirmLabel: 'Pulihkan', typedConfirm: quarantined ? 'PULIHKAN' : '' });
    },
    purge(ids) {
      FM.operate('trash_purge', { ids: [...ids] }, { title: `Hapus permanen ${this.label(ids)}`, confirmLabel: 'Hapus Permanen', typedConfirm: 'HAPUS' });
    },
    purgeAll() {
      FM.operate('trash_purge', { all: true }, { title: 'Kosongkan tempat sampah', confirmLabel: 'Kosongkan', typedConfirm: 'HAPUS' });
    },
  }));
});
