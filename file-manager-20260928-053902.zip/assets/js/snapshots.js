/** @author Ertha Dwi Setiyawan */
document.addEventListener('alpine:init', () => {
  Alpine.data('snapshotList', () => Object.assign(FM.listPage({
    route: 'api/snapshots',
    sort: ['created_at', 'desc'],
    filters: { kind: '' },
    init() { window.addEventListener('fm:op-done', () => this.load()); },
  }), {
    deleting: null,
    busy: false,
    compare(item) {
      window.dispatchEvent(new CustomEvent('fm:compare', { detail: item }));
    },
    rollback(item) {
      FM.operate('rollback', { snapshot_id: item.id }, { title: `Kembalikan izin dari "${item.label}"`, confirmLabel: 'Kembalikan Izin' });
    },
    askDelete(item) {
      this.deleting = item;
      this.$nextTick(() => FM.focusFirst(this.$refs.modal));
    },
    async confirmDelete() {
      this.busy = true;
      try {
        const payload = await FM.api('api/snapshots/delete', { method: 'POST', body: { id: this.deleting.id } });
        FM.toast('success', payload.message);
        this.deleting = null;
        if (this.items.length === 1 && this.state.page > 1) this.state.page -= 1;
        this.load();
        window.dispatchEvent(new CustomEvent('fm:snapshots-changed'));
      } catch (error) {
        FM.toast('error', error.message);
        if (error.status === 404) { this.deleting = null; this.load(); }
      } finally {
        this.busy = false;
      }
    },
  }));

  Alpine.data('snapshotCompare', () => Object.assign(FM.listPage({
    route: 'api/snapshots/compare',
    prefix: 'c_',
    sort: ['path', 'asc'],
    keep: ['a', 'b'],
    filters: { a: '', b: 'live', change: '' },
    autoload: false,
    init() {
      if (this.state.a) { this.load(); this.loadOthers(); }
      window.addEventListener('fm:compare', (event) => {
        this.state.a = event.detail.id;
        this.state.b = 'live';
        this.state.change = '';
        this.state.search = '';
        this.state.page = 1;
        this.load();
        this.loadOthers();
        this.$nextTick(() => document.getElementById('compare')?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
      });
      window.addEventListener('fm:snapshots-changed', () => this.loadOthers());
    },
  }), {
    others: [],
    async loadOthers() {
      try {
        const payload = await FM.api('api/snapshots', { query: { per_page: 'all', sort_by: 'created_at', sort_dir: 'desc' } });
        this.others = payload.data.items.filter((s) => s.id !== this.state.a);
      } catch (error) {
        this.others = [];
      }
    },
    closeCompare() {
      this.state.a = '';
      this.state.b = 'live';
      this.state.change = '';
      this.state.search = '';
      this.writeUrl();
    },
  }));
});
