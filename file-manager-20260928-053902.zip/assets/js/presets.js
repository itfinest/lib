/** @author Ertha Dwi Setiyawan */
document.addEventListener('alpine:init', () => {
  Alpine.data('presetsPage', () => Object.assign(FM.listPage({
    route: 'api/presets',
    sort: ['name', 'asc'],
  }), FM.crudMixin({
    saveRoute: 'api/presets/save',
    deleteRoute: 'api/presets/delete',
    blank: { id: '', name: '', description: '', dir_mode: '', file_mode: '', owner: '', group: '' },
  })));
});
