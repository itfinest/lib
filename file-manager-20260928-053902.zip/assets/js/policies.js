/** @author Ertha Dwi Setiyawan */
document.addEventListener('alpine:init', () => {
  Alpine.data('policiesPage', () => Object.assign(FM.listPage({
    route: 'api/policies',
    sort: ['name', 'asc'],
    filters: { status: '' },
  }), FM.crudMixin({
    saveRoute: 'api/policies/save',
    deleteRoute: 'api/policies/delete',
    blank: { id: '', name: '', pattern: '', applies_to: 'any', max_mode: '', owner: '', group: '', severity: 'medium', enabled: true },
  }), {
    toggling: null,
    rules(item) {
      const parts = [];
      if (item.max_mode) parts.push(`maks ${item.max_mode}`);
      if (item.owner) parts.push(`pemilik ${item.owner}`);
      if (item.group) parts.push(`grup ${item.group}`);
      return parts.join(', ');
    },
    async toggle(item, event) {
      const button = event.currentTarget;
      this.toggling = item.id;
      try {
        const payload = await FM.api('api/policies/toggle', { method: 'POST', body: { id: item.id, enabled: !item.enabled } });
        item.enabled = payload.data.enabled;
        FM.toast('success', payload.message);
        if (this.state.status) this.load();
      } catch (error) {
        FM.toast('error', error.message);
        if (error.status === 404) this.load();
      } finally {
        this.toggling = null;
        this.$nextTick(() => button?.focus());
      }
    },
  }));
});
