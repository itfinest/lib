/** @author Ertha Dwi Setiyawan */
(function () {
  'use strict';
  const form = document.getElementById('login-form');
  if (!form) return;
  const button = form.querySelector('button[type="submit"]');
  const banner = document.getElementById('login-error');
  const csrf = document.querySelector('meta[name="csrf-token"]').content;

  const showFieldErrors = (errors) => {
    form.querySelectorAll('[data-error-for]').forEach((node) => {
      const message = errors[node.dataset.errorFor] || '';
      node.textContent = message;
      node.classList.toggle('hidden', !message);
      document.getElementById(node.dataset.errorFor).setAttribute('aria-invalid', message ? 'true' : 'false');
    });
  };

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    banner.classList.add('hidden');
    const username = form.username.value.trim();
    const password = form.password.value;
    const errors = {};
    if (!username) errors.username = 'Nama pengguna wajib diisi.';
    if (!password) errors.password = 'Kata sandi wajib diisi.';
    showFieldErrors(errors);
    if (Object.keys(errors).length) {
      form.querySelector('[aria-invalid="true"]').focus();
      return;
    }

    button.disabled = true;
    button.textContent = 'Memeriksa...';
    try {
      const response = await fetch('?r=api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'X-CSRF-Token': csrf },
        body: JSON.stringify({ username, password, next: form.elements.next.value }),
        credentials: 'same-origin',
      });
      let payload = null;
      try { payload = await response.json(); } catch (error) { payload = null; }
      if (response.ok && payload && payload.status === 'success') {
        window.location.href = payload.data.redirect || '?r=explorer';
        return;
      }
      showFieldErrors((payload && payload.data && payload.data.errors) || {});
      banner.textContent = (payload && payload.message) || 'Gagal masuk. Muat ulang halaman, lalu coba lagi.';
      banner.classList.remove('hidden');
      form.password.value = '';
      form.password.focus();
    } catch (error) {
      banner.textContent = 'Tidak dapat terhubung ke server. Periksa koneksi, lalu coba lagi.';
      banner.classList.remove('hidden');
    } finally {
      button.disabled = false;
      button.textContent = 'Masuk';
    }
  });
})();
