/** @author Ertha Dwi Setiyawan */
/* Download worker. A page asks for a download by opening api/files/download with a "dl" id; this
   worker fetches the file, hands the stream to the browser's download manager, and reports the
   progress to every open page of the application over a BroadcastChannel. The download therefore
   keeps going, and stays visible, while the user moves between pages, which are full page loads.
   It lives at the application root because a service worker only covers its own folder and below. */
'use strict';

const CHANNEL = 'fm-downloads';
const REPORT_MS = 250;
const jobs = new Map();
const channel = new BroadcastChannel(CHANNEL);

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => event.waitUntil(self.clients.claim()));

function publish(job) {
  channel.postMessage({ type: 'job', job: { id: job.id, path: job.path, name: job.name, loaded: job.loaded, total: job.total, state: job.state, error: job.error } });
}

function finish(job, state, error) {
  if (job.state !== 'running') return;
  job.state = state;
  job.error = error || '';
  publish(job);
  jobs.delete(job.id);
}

// A page that loads while downloads run asks for them, so its progress card shows them at once.
channel.onmessage = (event) => {
  const message = event.data || {};
  if (message.type === 'list') jobs.forEach(publish);
  if (message.type === 'cancel' && jobs.has(message.id)) jobs.get(message.id).controller.abort();
};

// Open pages ping while a download runs; each ping keeps the worker alive a little longer.
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'keepalive' && jobs.size) {
    event.waitUntil(new Promise((resolve) => setTimeout(resolve, 20000)));
  }
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  const id = url.searchParams.get('dl');
  if (!id || url.origin !== self.location.origin || url.searchParams.get('r') !== 'api/files/download') return;
  event.respondWith(start(url, id));
});

async function start(url, id) {
  url.searchParams.delete('dl');
  const path = url.searchParams.get('path') || '';
  const job = { id, path, name: path.split('/').pop() || 'berkas', loaded: 0, total: 0, state: 'running', error: '', controller: new AbortController() };
  jobs.set(id, job);
  publish(job);
  // 204 answers the page's request without navigating it, so a failed download leaves the page as it was.
  const stay = () => new Response(null, { status: 204 });

  let upstream;
  try {
    upstream = await fetch(url.toString(), { credentials: 'same-origin', signal: job.controller.signal });
  } catch (error) {
    finish(job, job.controller.signal.aborted ? 'cancelled' : 'error', 'Koneksi terputus. Periksa koneksi, lalu coba lagi.');
    return stay();
  }
  if (!upstream.ok) {
    let message = '';
    try { message = (await upstream.json()).message || ''; } catch (error) { message = ''; }
    finish(job, 'error', upstream.status === 401 ? 'Sesi berakhir. Silakan masuk kembali.' : (message || `Permintaan gagal diproses (kode ${upstream.status}). Coba lagi.`));
    return stay();
  }

  job.total = Number(upstream.headers.get('Content-Length')) || 0;
  publish(job);
  const reader = upstream.body.getReader();
  let reported = 0;
  const body = new ReadableStream({
    async pull(controller) {
      try {
        const { done, value } = await reader.read();
        if (done) {
          controller.close();
          finish(job, 'done');
          return;
        }
        job.loaded += value.byteLength;
        if (Date.now() - reported > REPORT_MS) {
          reported = Date.now();
          publish(job);
        }
        controller.enqueue(value);
      } catch (error) {
        controller.error(error);
        finish(job, job.controller.signal.aborted ? 'cancelled' : 'error', 'Unduhan terputus. Periksa koneksi, lalu coba lagi.');
      }
    },
    // The user cancelled in the browser's own download list.
    cancel() {
      job.controller.abort();
      finish(job, 'cancelled');
    },
  });
  return new Response(body, { status: 200, headers: upstream.headers });
}
