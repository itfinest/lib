<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?><!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= $e($title) ?></title>
  <link rel="icon" href="<?= $e($asset('favicon.svg')) ?>" type="image/svg+xml">
  <link rel="stylesheet" href="<?= $e($asset('app.css')) ?>">
  <script src="<?= $e($asset('js/theme.js')) ?>"></script>
</head>
<body class="grid min-h-screen place-items-center px-4 antialiased">
  <main class="panel w-full max-w-md p-6">
    <p class="font-mono text-xs text-muted">Kode <?= (int) $status ?></p>
    <h1 class="mt-1 font-display text-base font-semibold"><?= $e($title) ?></h1>
    <p class="mt-2 text-sm text-body"><?= $e($message) ?></p>
    <?php if (!empty($detail['trace']) || !empty($detail['file'])): ?>
      <p class="mt-4 font-mono text-xs text-muted">Kode referensi <?= $e($detail['reference']) ?></p>
      <pre class="code-block mt-1 max-h-[50vh] overflow-auto"><?= $e($detail['file'] . "
" . implode("
", $detail['trace'])) ?></pre>
    <?php endif; ?>
    <div class="mt-5 flex flex-wrap gap-2">
      <a href="?r=explorer" class="btn-primary">Ke Pengelola Berkas</a>
      <a href="?r=login" class="btn-secondary">Halaman Masuk</a>
    </div>
  </main>
</body>
</html>
