<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
// Progress card for downloads (core.js, downloads store). It sits in the layout so a download started
// on one page stays visible on the next.
?>
<section x-data class="pointer-events-none fixed inset-x-3 top-20 z-[65] flex flex-col gap-2 sm:inset-x-auto sm:right-4 sm:w-80 max-h-[50dvh] overflow-y-auto overscroll-contain" aria-label="Unduhan berjalan" x-show="$store.downloads.items.length" x-cloak>
  <template x-for="job in $store.downloads.items" :key="job.id">
    <div class="toast pointer-events-auto rounded-card border border-line bg-surface p-3 text-sm shadow-[0_8px_24px_-12px_rgba(17,24,39,0.35)]">
      <div class="flex items-start gap-3">
        <svg class="icon-lg mt-px" :class="job.state === 'done' ? 'text-success-700' : 'text-primary-700'" aria-hidden="true"><use :href="FM.icons + (job.state === 'done' ? '#circle-check' : '#download')"></use></svg>
        <div class="min-w-0 flex-1">
          <p class="truncate font-medium text-ink" x-text="job.name" :title="job.name"></p>
          <p class="font-mono text-xs text-muted" x-text="$store.downloads.text(job)" aria-live="polite"></p>
        </div>
        <button type="button" class="-m-1 grid h-8 w-8 shrink-0 place-items-center rounded-control text-muted hover:bg-surface-2" x-show="job.state === 'running'" @click="$store.downloads.cancel(job)" :aria-label="'Batalkan unduhan ' + job.name" title="Batalkan unduhan"><?= $icon('x') ?></button>
      </div>
      <div class="mt-2 h-2 overflow-hidden rounded-chip bg-surface-2" :class="job.total ? '' : 'skeleton'" role="progressbar" aria-valuemin="0" aria-valuemax="100"
           :aria-valuenow="job.total ? $store.downloads.percent(job) : null" :aria-valuetext="$store.downloads.text(job)" :aria-label="'Kemajuan unduhan ' + job.name">
        <div class="h-full transition-[width] duration-150" :class="job.state === 'done' ? 'bg-success-600' : 'bg-primary-600'" x-show="job.total" :style="`width: ${$store.downloads.percent(job)}%`"></div>
      </div>
    </div>
  </template>
</section>
