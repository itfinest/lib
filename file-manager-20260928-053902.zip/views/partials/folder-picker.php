<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;

// Folder picker used by the explorer dialogs and the settings page. The surrounding Alpine scope
// provides picker, loadPicker(path), and pickFolder(path); $choose runs on "Pilih Folder Ini".
$folderPicker = function ($choose = 'form.dest = picker.path') use ($icon) { ?>
  <div class="rounded-control border border-line">
    <div class="flex items-center gap-2 border-b border-line px-2 py-1.5">
      <button type="button" class="btn-ghost btn-icon" @click="picker.parent && loadPicker(picker.parent)" :disabled="!picker.parent" aria-label="Naik satu level"><?= $icon('arrow-up') ?></button>
      <p class="min-w-0 flex-1 truncate font-mono text-xs text-ink" x-text="picker.path" :title="picker.path"></p>
      <button type="button" class="btn-secondary" @click="<?= $choose ?>">Pilih Folder Ini</button>
    </div>
    <p x-show="!picker.loading && picker.cwd_access && !picker.cwd_access.add" class="flex items-start gap-2 border-b border-line bg-warning-50 px-3 py-2 text-xs text-warning-700" role="status">
      <?= $icon('lock', 'icon mt-px') ?><span>Akun PHP tidak dapat menambah berkas atau folder di folder ini.</span>
    </p>
    <div class="max-h-56 overflow-y-auto">
      <template x-if="picker.loading"><div class="space-y-2 p-3"><div class="skeleton h-4 w-2/3"></div><div class="skeleton h-4 w-1/2"></div><div class="skeleton h-4 w-3/5"></div></div></template>
      <template x-if="!picker.loading && picker.error"><p class="p-3 text-sm text-danger-700" role="alert" x-text="picker.error"></p></template>
      <template x-if="!picker.loading && !picker.error && !picker.folders.length"><p class="p-3 text-sm text-muted">Tidak ada subfolder di lokasi ini.</p></template>
      <ul x-show="!picker.loading && !picker.error">
        <template x-for="folder in picker.folders" :key="folder.path">
          <li>
            <button type="button" class="flex min-h-10 w-full items-start gap-2 px-3 py-1.5 text-left text-sm hover:bg-surface-2 sm:items-center" @click="pickFolder(folder.path)">
              <svg class="icon mt-0.5 shrink-0 text-primary-700 sm:mt-0" aria-hidden="true"><use :href="FM.icons + '#' + (folder.link ? 'link' : 'folder')"></use></svg>
              <span class="min-w-0 flex-1 sm:flex sm:items-center sm:gap-2">
                <span class="block min-w-0 sm:flex-1">
                  <span class="block truncate" x-text="folder.name"></span>
                  <span class="block truncate font-mono text-xs text-muted" x-show="folder.octal" :title="folder.octal + ' ' + folder.perms + (folder.owner ? ' · ' + folder.owner + ':' + folder.group : '')" x-text="folder.octal + ' ' + folder.perms + (folder.owner ? ' · ' + folder.owner + ':' + folder.group : '')"></span>
                </span>
                <template x-if="folder.access">
                  <span class="mt-1 flex gap-1 sm:mt-0 sm:shrink-0">
                    <span :class="folder.access.read ? 'chip-success' : 'chip-neutral'" :title="folder.access.read ? 'Isi folder dapat ditampilkan' : 'Isi folder tidak dapat ditampilkan'">
                      <svg class="h-3 w-3" aria-hidden="true"><use :href="FM.icons + '#' + (folder.access.read ? 'check' : 'x')"></use></svg>Buka<span class="sr-only" x-text="folder.access.read ? ' diizinkan' : ' tidak diizinkan'"></span>
                    </span>
                    <span :class="folder.access.add ? 'chip-success' : 'chip-neutral'" :title="folder.access.add ? 'Dapat ditambah berkas atau folder' : 'Tidak dapat ditambah berkas atau folder'">
                      <svg class="h-3 w-3" aria-hidden="true"><use :href="FM.icons + '#' + (folder.access.add ? 'check' : 'x')"></use></svg>Tambah<span class="sr-only" x-text="folder.access.add ? ' diizinkan' : ' tidak diizinkan'"></span>
                    </span>
                  </span>
                </template>
              </span>
            </button>
          </li>
        </template>
      </ul>
    </div>
  </div>
<?php };
?>
