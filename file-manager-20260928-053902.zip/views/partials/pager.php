<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
// Pagination row for any listPage scope: result range on the left, numbered pages on the right.
?>
<div class="flex flex-col gap-3 border-t border-line px-3 py-2 sm:flex-row sm:items-center sm:justify-between" x-show="phase === 'content'">
  <p class="text-sm text-muted" x-text="rangeText()"></p>
  <nav class="flex flex-wrap items-center gap-1" aria-label="Navigasi halaman">
    <button type="button" class="pager-btn" @click="goTo(pagination.current_page - 1)" :disabled="pagination.current_page <= 1" aria-label="Halaman sebelumnya">
      <svg class="icon" aria-hidden="true"><use :href="FM.icons + '#chevron-left'"></use></svg>
    </button>
    <template x-for="p in pages()" :key="p">
      <span>
        <template x-if="typeof p === 'number'">
          <button type="button" class="pager-btn font-mono" @click="goTo(p)" :aria-current="p === pagination.current_page ? 'page' : null" x-text="p" :aria-label="'Halaman ' + p"></button>
        </template>
        <template x-if="typeof p !== 'number'">
          <span class="px-1 text-muted" aria-hidden="true">...</span>
        </template>
      </span>
    </template>
    <button type="button" class="pager-btn" @click="goTo(pagination.current_page + 1)" :disabled="pagination.current_page >= pagination.last_page" aria-label="Halaman berikutnya">
      <svg class="icon" aria-hidden="true"><use :href="FM.icons + '#chevron-right'"></use></svg>
    </button>
  </nav>
</div>
