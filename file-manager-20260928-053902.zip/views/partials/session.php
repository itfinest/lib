<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data="sessionWatch" x-cloak>
  <div x-show="$store.session.warning" class="fixed inset-x-3 top-3 z-[65] mx-auto flex max-w-lg flex-col gap-3 rounded-card border border-warning-600/40 bg-surface p-3 text-sm shadow-[0_8px_24px_-12px_rgba(17,24,39,0.35)] sm:flex-row sm:items-center" role="alert">
    <svg class="icon-lg shrink-0 text-warning-700" aria-hidden="true"><use :href="FM.icons + '#triangle-alert'"></use></svg>
    <p class="flex-1 text-ink">Sesi akan berakhir dalam <span class="font-semibold" x-text="remaining"></span> menit karena tidak ada aktivitas.</p>
    <button type="button" class="btn-primary" @click="extend()">Perpanjang Sesi</button>
  </div>
</div>
