<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
// Skeleton rows for a listPage table body. Expects $cols.
?>
<template x-if="phase === 'loading'">
  <template x-for="n in 6" :key="n">
    <tr>
      <?php for ($i = 0; $i < $cols; $i++): ?>
        <td><span class="skeleton block h-4 <?= $i === 0 ? 'w-6' : ($i === 1 ? 'w-48' : 'w-20') ?>"></span></td>
      <?php endfor; ?>
    </tr>
  </template>
</template>
