<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;

// Folder picker shared by copy, move, extract, and compress.
require APP_ROOT . '/views/partials/folder-picker.php';
?>
<div x-show="modalOpen" x-cloak class="modal-backdrop" @mousedown.self.prevent x-transition:enter="modal-in" x-transition:leave="modal-out" @keydown.escape="closeModal()">

  <template x-if="modal === 'mkdir'">
    <form class="modal sm:max-w-md" role="dialog" aria-modal="true" aria-labelledby="mkdir-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitMkdir()">
      <div class="modal-head"><h2 id="mkdir-title" class="font-display text-sm font-semibold">Folder Baru</h2></div>
      <div class="modal-body">
        <p class="mb-3 break-all font-mono text-xs text-muted" x-text="'Di dalam ' + cwd"></p>
        <label for="mkdir-name" class="field-label">Nama folder</label>
        <input id="mkdir-name" type="text" class="input" x-model="form.name" data-autofocus required maxlength="255" placeholder="uploads" autocomplete="off" @input="errors.name = ''">
        <p class="field-error" x-show="fieldError('name')" x-text="fieldError('name')"></p>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()" :disabled="busy">Batal</button>
        <button type="submit" class="btn-primary" :disabled="busy"><span x-text="busy ? 'Membuat...' : 'Buat Folder'"></span></button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'createFile'">
    <form class="modal sm:max-w-3xl" role="dialog" aria-modal="true" aria-labelledby="touch-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitCreateFile()">
      <div class="modal-head"><h2 id="touch-title" class="font-display text-sm font-semibold">Berkas Baru</h2></div>
      <div class="modal-body space-y-3">
        <p class="break-all font-mono text-xs text-muted" x-text="'Di dalam ' + cwd"></p>
        <div>
          <label for="touch-name" class="field-label">Nama berkas</label>
          <input id="touch-name" type="text" class="input" x-model="form.name" data-autofocus required maxlength="255" placeholder="index.php" autocomplete="off" @input="errors.name = ''">
          <p class="field-error" x-show="fieldError('name')" x-text="fieldError('name')"></p>
        </div>
        <div>
          <label for="touch-content" class="field-label">Isi berkas (opsional)</label>
          <textarea id="touch-content" class="input h-72 resize-y font-mono text-xs leading-5" x-model="form.content" spellcheck="false" wrap="off"></textarea>
          <p class="field-error" x-show="fieldError('content')" x-text="fieldError('content')"></p>
        </div>
        <div x-show="form.confirmDiscard" class="flex flex-col gap-2 rounded-control border border-warning-600/40 bg-warning-50 p-3 text-sm text-warning-700 sm:flex-row sm:items-center" role="alert">
          <p class="flex-1">Isi berkas belum disimpan. Tutup dan buang isi ini?</p>
          <div class="flex gap-2">
            <button type="button" class="btn-secondary" @click="form.confirmDiscard = false">Lanjut Menulis</button>
            <button type="button" class="btn-danger" @click="closeModal(true)">Buang Isi</button>
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()" :disabled="busy">Batal</button>
        <button type="submit" class="btn-primary" :disabled="busy"><span x-text="busy ? 'Menyimpan...' : 'Buat Berkas'"></span></button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'rename'">
    <form class="modal sm:max-w-md" role="dialog" aria-modal="true" aria-labelledby="rename-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitRename()">
      <div class="modal-head"><h2 id="rename-title" class="font-display text-sm font-semibold">Ganti Nama</h2></div>
      <div class="modal-body">
        <p class="mb-3 break-all font-mono text-xs text-muted" x-text="form.item.path"></p>
        <label for="rename-name" class="field-label">Nama baru</label>
        <input id="rename-name" type="text" class="input" x-model="form.name" data-autofocus required maxlength="255" autocomplete="off" @input="errors.name = ''">
        <p class="field-error" x-show="fieldError('name')" x-text="fieldError('name')"></p>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()" :disabled="busy">Batal</button>
        <button type="submit" class="btn-primary" :disabled="busy"><span x-text="busy ? 'Menyimpan...' : 'Ganti Nama'"></span></button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'transfer'">
    <form class="modal sm:max-w-lg" role="dialog" aria-modal="true" aria-labelledby="transfer-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitTransfer()">
      <div class="modal-head"><h2 id="transfer-title" class="font-display text-sm font-semibold" x-text="(form.kind === 'move' ? 'Pindahkan ' : 'Salin ') + describe(form.paths)"></h2></div>
      <div class="modal-body space-y-3">
        <div>
          <label for="transfer-dest" class="field-label">Folder tujuan</label>
          <input id="transfer-dest" type="text" class="input-mono" x-model="form.dest" data-autofocus required spellcheck="false" autocomplete="off">
          <p class="field-error" x-show="fieldError('dest')" x-text="fieldError('dest')"></p>
        </div>
        <?php $folderPicker(); ?>
        <label class="flex min-h-control items-center gap-2 text-sm"><input type="checkbox" class="check" x-model="form.overwrite">Timpa item dengan nama yang sama di folder tujuan</label>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()">Batal</button>
        <button type="submit" class="btn-primary">Lanjut ke Pratinjau</button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'delete'">
    <form class="modal sm:max-w-md" role="dialog" aria-modal="true" aria-labelledby="delete-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitDelete()">
      <div class="modal-head"><h2 id="delete-title" class="font-display text-sm font-semibold" x-text="'Hapus ' + describe(form.paths) + '?'"></h2></div>
      <div class="modal-body space-y-3 text-sm">
        <ul class="max-h-40 overflow-y-auto rounded-control border border-line bg-surface-2 p-2 font-mono text-xs">
          <template x-for="path in form.paths" :key="path"><li class="break-all py-0.5" x-text="path"></li></template>
        </ul>
        <p x-show="!form.permanent">Item dipindahkan ke Tempat Sampah dan dapat dipulihkan ke lokasi asalnya.</p>
        <label class="flex items-start gap-2 rounded-control border border-line p-3">
          <input type="checkbox" class="check mt-0.5" x-model="form.permanent" data-autofocus>
          <span><span class="font-medium text-danger-700">Hapus permanen</span><span class="block text-muted">Lewati tempat sampah. Item tidak dapat dipulihkan.</span></span>
        </label>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()">Batal</button>
        <button type="submit" class="btn-danger" x-text="form.permanent ? 'Lanjut Hapus Permanen' : 'Pindahkan ke Tempat Sampah'"></button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'chmod'">
    <form class="modal sm:max-w-2xl" role="dialog" aria-modal="true" aria-labelledby="chmod-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitChmod()">
      <div class="modal-head"><h2 id="chmod-title" class="font-display text-sm font-semibold" x-text="'Ubah izin ' + describe(form.paths)"></h2></div>
      <div class="modal-body space-y-4">
        <label class="flex items-start gap-2 text-sm" x-show="form.hasDirs">
          <input type="checkbox" class="check mt-0.5" x-model="form.recursive" data-autofocus>
          <span>Terapkan ke seluruh isi folder (rekursif)<span class="block text-muted">Izin folder dan izin berkas diatur terpisah supaya berkas tidak ikut mendapat bit eksekusi.</span></span>
        </label>
        <p class="text-sm text-warning-700" x-show="form.links">Symlink dilewati karena izinnya mengikuti berkas tujuan.</p>

        <template x-for="grid in [{ key: 'dirMode', apply: 'applyDirs', label: 'Folder', isDir: true, error: 'dir_mode', show: showDirGrid() }, { key: 'fileMode', apply: 'applyFiles', label: 'Berkas', isDir: false, error: 'file_mode', show: showFileGrid() }]" :key="grid.key">
          <section x-show="grid.show" class="rounded-control border border-line p-3" :aria-label="'Izin ' + grid.label">
            <div class="mb-3 flex flex-wrap items-center justify-between gap-2">
              <h3 class="font-display text-sm font-semibold text-ink" x-text="'Izin ' + grid.label"></h3>
              <label class="flex items-center gap-2 text-sm" x-show="form.recursive">
                <input type="checkbox" class="check" x-model="form[grid.apply]">
                <span x-text="'Ubah izin ' + grid.label.toLowerCase()"></span>
              </label>
            </div>
            <fieldset class="grid gap-4 disabled:opacity-60 sm:grid-cols-[minmax(0,1fr)_10rem]" :disabled="form.recursive && !form[grid.apply]">
              <legend class="sr-only" x-text="'Pengaturan izin ' + grid.label.toLowerCase()"></legend>
              <table class="w-full text-sm">
                <thead><tr><th class="w-24"></th><template x-for="col in PERM_COLS" :key="col.bit"><th scope="col" class="pb-1 text-center text-xs font-medium text-muted" x-text="col.label"></th></template></tr></thead>
                <tbody>
                  <template x-for="row in PERM_ROWS" :key="row.shift">
                    <tr>
                      <th scope="row" class="py-1 text-left font-normal text-body" x-text="row.label"></th>
                      <template x-for="col in PERM_COLS" :key="col.bit">
                        <td class="text-center"><label class="inline-grid h-11 w-11 place-items-center lg:h-9 lg:w-9"><input type="checkbox" class="check" :checked="hasBit(grid.key, col.bit << row.shift)" @change="flipBit(grid.key, col.bit << row.shift)" :aria-label="row.label + ' ' + col.label.toLowerCase() + ' ' + grid.label.toLowerCase()"></label></td>
                      </template>
                    </tr>
                  </template>
                </tbody>
              </table>
              <div class="space-y-3">
                <div>
                  <label class="field-label" :for="'mode-' + grid.key">Mode oktal</label>
                  <input :id="'mode-' + grid.key" type="text" inputmode="numeric" class="input-mono" maxlength="5" x-model="form[grid.key]" @input="errors[grid.error] = ''">
                  <p class="field-error" x-show="fieldError(grid.error)" x-text="fieldError(grid.error)"></p>
                </div>
                <p class="font-mono text-xs text-muted" x-text="symbolic(grid.key, grid.isDir)"></p>
                <div class="flex flex-wrap gap-x-3 gap-y-1 text-xs">
                  <template x-for="special in SPECIAL" :key="special.bit">
                    <label class="flex min-h-8 items-center gap-1.5"><input type="checkbox" class="check" :checked="hasBit(grid.key, special.bit)" @change="flipBit(grid.key, special.bit)"><span x-text="special.label"></span></label>
                  </template>
                </div>
              </div>
            </fieldset>
          </section>
        </template>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()">Batal</button>
        <button type="submit" class="btn-primary">Lanjut ke Pratinjau</button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'chown'">
    <form class="modal sm:max-w-md" role="dialog" aria-modal="true" aria-labelledby="chown-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitChown()">
      <div class="modal-head"><h2 id="chown-title" class="font-display text-sm font-semibold" x-text="'Ubah pemilik ' + describe(form.paths)"></h2></div>
      <div class="modal-body space-y-3">
        <div>
          <label for="chown-owner" class="field-label">Pemilik</label>
          <input id="chown-owner" type="text" class="input-mono" x-model="form.owner" list="principal-users" data-autofocus autocomplete="off" spellcheck="false" placeholder="Kosongkan bila tidak diubah" @input="errors.owner = ''">
          <p class="field-error" x-show="fieldError('owner')" x-text="fieldError('owner')"></p>
        </div>
        <div>
          <label for="chown-group" class="field-label">Grup</label>
          <input id="chown-group" type="text" class="input-mono" x-model="form.group" list="principal-groups" autocomplete="off" spellcheck="false" placeholder="Kosongkan bila tidak diubah" @input="errors.group = ''">
          <p class="field-error" x-show="fieldError('group')" x-text="fieldError('group')"></p>
        </div>
        <label class="flex items-center gap-2 text-sm" x-show="form.hasDirs"><input type="checkbox" class="check" x-model="form.recursive">Terapkan ke seluruh isi folder (rekursif)</label>
        <p class="text-xs text-muted">Mengubah pemilik umumnya membutuhkan hak root. Bila server menolak, aktifkan opsi sudo di config/app.php.</p>
        <datalist id="principal-users"><template x-for="u in (principals ? principals.users : [])" :key="u.name"><option :value="u.name" x-text="'UID ' + u.id"></option></template></datalist>
        <datalist id="principal-groups"><template x-for="g in (principals ? principals.groups : [])" :key="g.name"><option :value="g.name" x-text="'GID ' + g.id"></option></template></datalist>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()">Batal</button>
        <button type="submit" class="btn-primary">Lanjut ke Pratinjau</button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'preset'">
    <form class="modal sm:max-w-md" role="dialog" aria-modal="true" aria-labelledby="preset-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitPreset()">
      <div class="modal-head"><h2 id="preset-title" class="font-display text-sm font-semibold" x-text="'Terapkan preset pada ' + describe(form.paths)"></h2></div>
      <div class="modal-body space-y-3">
        <div>
          <label for="preset-id" class="field-label">Preset</label>
          <select id="preset-id" class="input" x-model="form.preset_id" data-autofocus>
            <template x-for="p in presets" :key="p.id"><option :value="p.id" x-text="p.name"></option></template>
          </select>
          <p class="field-error" x-show="fieldError('preset_id')" x-text="fieldError('preset_id')"></p>
        </div>
        <template x-if="presetById(form.preset_id)">
          <dl class="grid grid-cols-[7rem_minmax(0,1fr)] gap-y-1 rounded-control border border-line bg-surface-2 p-3 text-sm">
            <dt class="text-muted">Izin folder</dt><dd class="font-mono" x-text="presetById(form.preset_id).dir_mode || '(tetap)'"></dd>
            <dt class="text-muted">Izin berkas</dt><dd class="font-mono" x-text="presetById(form.preset_id).file_mode || '(tetap)'"></dd>
            <dt class="text-muted">Pemilik</dt><dd class="font-mono" x-text="(presetById(form.preset_id).owner || '(tetap)') + ':' + (presetById(form.preset_id).group || '(tetap)')"></dd>
            <dd class="col-span-2 mt-1 text-muted" x-show="presetById(form.preset_id).description" x-text="presetById(form.preset_id).description"></dd>
          </dl>
        </template>
        <label class="flex items-center gap-2 text-sm" x-show="form.hasDirs"><input type="checkbox" class="check" x-model="form.recursive">Terapkan ke seluruh isi folder (rekursif)</label>
        <a href="?r=presets" class="inline-flex min-h-control items-center text-sm font-medium text-primary-700 hover:underline">Kelola preset</a>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()">Batal</button>
        <button type="submit" class="btn-primary" :disabled="!presets.length">Lanjut ke Pratinjau</button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'acl'">
    <form class="modal sm:max-w-xl" role="dialog" aria-modal="true" aria-labelledby="acl-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitAcl()">
      <div class="modal-head"><h2 id="acl-title" class="font-display text-sm font-semibold" x-text="'Kelola ACL ' + describe(form.paths)"></h2></div>
      <div class="modal-body space-y-4">
        <section x-show="form.paths.length === 1">
          <h3 class="panel-title mb-2">ACL saat ini</h3>
          <template x-if="form.loadingCurrent"><div class="skeleton h-16 w-full"></div></template>
          <template x-if="!form.loadingCurrent && form.current">
            <ul class="rounded-control border border-line bg-surface-2 p-2 font-mono text-xs">
              <template x-for="row in form.current.entries.concat(form.current.default.map((r) => Object.assign({}, r, { tag: 'default:' + r.tag })))" :key="row.tag + row.qualifier">
                <li class="py-0.5"><span x-text="row.tag + ':' + row.qualifier + ':' + row.perms"></span><span class="text-warning-700" x-show="row.effective" x-text="'  (efektif ' + row.effective + ')'"></span></li>
              </template>
            </ul>
          </template>
        </section>
        <div>
          <label for="acl-action" class="field-label">Tindakan</label>
          <select id="acl-action" class="input" x-model="form.action" data-autofocus>
            <option value="modify">Tambah atau ubah entri</option>
            <option value="remove">Hapus entri pengguna atau grup</option>
            <option value="clear">Hapus seluruh ACL tambahan</option>
          </select>
        </div>
        <div class="grid gap-3 sm:grid-cols-2" x-show="form.action !== 'clear'">
          <div>
            <label for="acl-tag" class="field-label">Jenis entri</label>
            <select id="acl-tag" class="input" x-model="form.tag">
              <option value="user">Pengguna</option>
              <option value="group">Grup</option>
              <option value="mask" x-show="form.action === 'modify'">Mask</option>
              <option value="other" x-show="form.action === 'modify'">Lainnya</option>
            </select>
          </div>
          <div x-show="['user', 'group'].includes(form.tag)">
            <label for="acl-name" class="field-label">Nama</label>
            <input id="acl-name" type="text" class="input-mono" x-model="form.qualifier" :list="form.tag === 'user' ? 'principal-users' : 'principal-groups'" autocomplete="off" spellcheck="false" placeholder="deploy" @input="errors.spec = ''">
          </div>
        </div>
        <fieldset x-show="form.action === 'modify'" class="flex flex-wrap gap-4 text-sm">
          <legend class="field-label">Izin</legend>
          <label class="flex min-h-control items-center gap-2"><input type="checkbox" class="check" x-model="form.r">Baca</label>
          <label class="flex min-h-control items-center gap-2"><input type="checkbox" class="check" x-model="form.w">Tulis</label>
          <label class="flex min-h-control items-center gap-2"><input type="checkbox" class="check" x-model="form.x">Eksekusi</label>
        </fieldset>
        <div class="space-y-2 text-sm" x-show="form.hasDirs">
          <label class="flex items-start gap-2" x-show="form.action !== 'clear'"><input type="checkbox" class="check mt-0.5" x-model="form.isDefault"><span>ACL default<span class="block text-muted">Diwariskan ke berkas dan folder baru di dalam folder. Hanya berlaku untuk folder.</span></span></label>
          <label class="flex items-center gap-2"><input type="checkbox" class="check" x-model="form.recursive">Terapkan ke seluruh isi folder (rekursif)</label>
        </div>
        <p class="font-mono text-xs text-muted" x-show="form.action !== 'clear'" x-text="'Entri: ' + aclSpec()"></p>
        <p class="field-error" x-show="fieldError('spec')" x-text="fieldError('spec')"></p>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()">Batal</button>
        <button type="submit" class="btn-primary">Lanjut ke Pratinjau</button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'compress'">
    <form class="modal sm:max-w-3xl" role="dialog" aria-modal="true" aria-labelledby="compress-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitCompress()">
      <div class="modal-head"><h2 id="compress-title" class="font-display text-sm font-semibold" x-text="'Kompres ' + describe(form.paths)"></h2></div>
      <div class="modal-body space-y-3">
        <div class="grid gap-3 sm:grid-cols-[minmax(0,1fr)_10rem]">
          <div>
            <label for="compress-name" class="field-label">Nama arsip</label>
            <input id="compress-name" type="text" class="input" x-model="form.name" data-autofocus required maxlength="240" autocomplete="off">
          </div>
          <div>
            <label for="compress-format" class="field-label">Format</label>
            <select id="compress-format" class="input" x-model="form.format">
              <template x-if="system.tools.tar"><option value="tar.gz">.tar.gz</option></template>
              <option value="zip" :disabled="!system.tools.zip" x-text="system.tools.zip ? '.zip' : (system.shell ? '.zip (perintah zip tidak tersedia)' : '.zip (ekstensi PHP zip tidak aktif)')"></option>
            </select>
          </div>
        </div>
        <div>
          <label for="compress-exclude" class="field-label">Kecualikan (opsional)</label>
          <textarea id="compress-exclude" rows="6" class="input-mono" x-model="form.exclude" spellcheck="false" placeholder="node_modules&#10;*.log" :aria-invalid="fieldError('exclude') ? 'true' : null" aria-describedby="compress-exclude-hint"></textarea>
          <p id="compress-exclude-hint" class="mt-1 text-xs text-muted">Kolom ini terisi daftar bawaan dari halaman Pengaturan. Daftar ini dapat diubah atau dihapus. Satu pola per baris, boleh memakai * dan ?. Pola tanpa "/" berlaku untuk nama berkas atau folder di semua subfolder, misalnya node_modules atau *.log. Pola dengan "/" adalah path relatif terhadap folder yang berisi item yang dipilih, misalnya <span class="font-mono" x-text="(form.paths[0] || '').split('/').pop() + '/storage/logs'"></span>. Folder yang cocok dikecualikan beserta seluruh isinya.</p>
          <p class="field-error" x-show="fieldError('exclude')" x-text="fieldError('exclude')"></p>
        </div>
        <div>
          <label for="compress-dest" class="field-label">Folder tujuan</label>
          <input id="compress-dest" type="text" class="input-mono" x-model="form.dest" required spellcheck="false" autocomplete="off">
          <p class="field-error" x-show="fieldError('dest')" x-text="fieldError('dest')"></p>
        </div>
        <?php $folderPicker(); ?>
        <p class="text-xs text-muted">Arsip disimpan di folder tujuan. Nilai bawaannya diambil dari Folder tujuan kompres di halaman Pengaturan. Bila pengaturan tersebut kosong, arsip disimpan di folder yang berisi item yang dipilih.</p>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()">Batal</button>
        <button type="submit" class="btn-primary">Lanjut ke Pratinjau</button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'search'">
    <div class="modal sm:max-w-4xl" role="dialog" aria-modal="true" aria-labelledby="search-title" x-ref="modal" @keydown.tab="trapModal($event)">
      <div class="modal-head">
        <div class="min-w-0">
          <h2 id="search-title" class="font-display text-sm font-semibold">Cari Isi Berkas</h2>
          <p class="break-all font-mono text-xs text-muted" x-text="'Di dalam ' + cwd + ' dan semua subfoldernya'"></p>
        </div>
        <button type="button" class="btn-ghost btn-icon -mr-2 -mt-1" @click="closeModal(true)" aria-label="Tutup pencarian"><?= $icon('x') ?></button>
      </div>
      <div class="modal-body space-y-4">
        <form class="space-y-3" @submit.prevent="runSearch()">
          <div>
            <label for="search-q" class="field-label">Teks yang dicari</label>
            <div class="flex gap-2">
              <input id="search-q" type="text" class="input-mono min-w-0 flex-1" x-model="textSearch.q" data-autofocus maxlength="200" autocomplete="off" spellcheck="false" placeholder="DB_PASSWORD" @input="textSearch.errors.q = ''" :aria-invalid="textSearch.errors.q ? 'true' : null">
              <button type="submit" class="btn-primary" :aria-busy="textSearch.phase === 'loading' ? 'true' : 'false'"><?= $icon('search') ?>Cari</button>
            </div>
            <p class="field-error" x-show="textSearch.errors.q" x-text="textSearch.errors.q"></p>
            <div class="mt-1 flex flex-wrap gap-x-5 text-sm">
              <label class="flex min-h-control items-center gap-2"><input type="checkbox" class="check" x-model="textSearch.caseSensitive">Bedakan huruf besar dan kecil</label>
              <label class="flex min-h-control items-center gap-2"><input type="checkbox" class="check" x-model="textSearch.regex">Ekspresi reguler</label>
            </div>
          </div>
          <div class="grid gap-3 sm:grid-cols-2">
            <div>
              <label for="search-names" class="field-label">Nama berkas (opsional)</label>
              <input id="search-names" type="text" class="input-mono" x-model="textSearch.names" autocomplete="off" spellcheck="false" placeholder="*.php, .env" aria-describedby="search-names-hint" @input="textSearch.errors.names = ''" :aria-invalid="textSearch.errors.names ? 'true' : null">
              <p id="search-names-hint" class="mt-1 text-xs text-muted">Pisahkan dengan koma. Kosongkan untuk mencari di semua berkas.</p>
              <p class="field-error" x-show="textSearch.errors.names" x-text="textSearch.errors.names"></p>
            </div>
            <div>
              <label for="search-skip" class="field-label">Folder yang dilewati</label>
              <input id="search-skip" type="text" class="input-mono" x-model="textSearch.skip" autocomplete="off" spellcheck="false" placeholder="node_modules, vendor, .git, .svn" aria-describedby="search-skip-hint" @input="textSearch.errors.skip = ''" :aria-invalid="textSearch.errors.skip ? 'true' : null">
              <p id="search-skip-hint" class="mt-1 text-xs text-muted">Nama folder, atau path relatif seperti storage/logs. Kosongkan untuk memakai daftar bawaan.</p>
              <p class="field-error" x-show="textSearch.errors.skip" x-text="textSearch.errors.skip"></p>
            </div>
          </div>
          <p class="text-xs text-muted">Berkas biner dan berkas di atas 5 MB tidak diperiksa. Pencarian berhenti setelah 1.000 baris yang cocok.</p>
        </form>

        <section aria-live="polite" aria-label="Hasil pencarian">
          <template x-if="textSearch.phase === 'loading'">
            <div class="space-y-3">
              <div class="flex items-center justify-between gap-3">
                <p class="text-sm text-muted">Mencari di dalam berkas. Folder besar membutuhkan waktu lebih lama.</p>
                <button type="button" class="btn-secondary" @click="cancelSearch(); $nextTick(() => document.getElementById('search-q')?.focus())">Batalkan</button>
              </div>
              <div class="space-y-2"><div class="skeleton h-4 w-2/3"></div><div class="skeleton h-4 w-full"></div><div class="skeleton h-4 w-5/6"></div><div class="skeleton h-4 w-1/2"></div></div>
            </div>
          </template>
          <template x-if="textSearch.phase !== 'loading' && textSearch.error">
            <p class="text-sm text-danger-700" role="alert" x-text="textSearch.error"></p>
          </template>
          <template x-if="textSearch.phase === 'done' && textSearch.result">
            <div class="space-y-3">
              <p class="text-sm text-ink" x-text="textSearch.result.matched_lines
                ? FM.formatNumber(textSearch.result.matched_lines) + ' baris cocok di ' + FM.formatNumber(textSearch.result.matched_files) + ' berkas. ' + FM.formatNumber(textSearch.result.searched) + ' berkas diperiksa.'
                : 'Tidak ada baris yang cocok. ' + FM.formatNumber(textSearch.result.searched) + ' berkas diperiksa.'"></p>
              <ul class="space-y-1 text-xs text-warning-700" x-show="textSearch.result.limit_lines || textSearch.result.limit_files || textSearch.result.skipped_large || textSearch.result.unreadable || textSearch.result.warnings.length">
                <li x-show="textSearch.result.limit_lines">Pencarian berhenti setelah 1.000 baris yang cocok. Persempit teks, nama berkas, atau folder yang dicari.</li>
                <li x-show="textSearch.result.limit_files">Jumlah berkas di folder ini melebihi batas pemindaian, sehingga sebagian berkas tidak diperiksa.</li>
                <li x-show="textSearch.result.skipped_large" x-text="FM.formatNumber(textSearch.result.skipped_large) + ' berkas di atas 5 MB tidak diperiksa.'"></li>
                <li x-show="textSearch.result.unreadable" x-text="FM.formatNumber(textSearch.result.unreadable) + ' berkas tidak dapat dibaca oleh akun PHP.'"></li>
                <template x-for="warning in textSearch.result.warnings" :key="warning"><li x-text="warning"></li></template>
              </ul>
              <p class="text-xs text-muted" x-text="'Folder yang dilewati: ' + textSearch.result.skip.join(', ')"></p>
              <ul class="divide-y divide-line rounded-control border border-line" x-show="textSearch.result.files.length">
                <template x-for="file in textSearch.result.files" :key="file.path">
                  <li class="py-2">
                    <div class="flex flex-wrap items-center gap-2 px-3">
                      <svg class="icon shrink-0 text-muted" aria-hidden="true"><use :href="FM.icons + '#file-text'"></use></svg>
                      <span class="min-w-0 flex-1 break-all font-mono text-xs font-semibold text-ink" x-text="file.rel"></span>
                      <button type="button" class="btn-ghost" @click="revealFromSearch(file.path)">Lihat Lokasi</button>
                    </div>
                    <ul class="mt-1">
                      <template x-for="match in file.matches" :key="match.line">
                        <li>
                          <a :href="editorUrl(file.path, match.line)" class="flex min-h-10 items-start gap-3 px-3 py-1.5 hover:bg-surface-2" :title="'Buka baris ' + match.line + ' di editor'">
                            <span class="w-12 shrink-0 text-right font-mono text-xs text-muted" x-text="match.line"></span>
                            <span class="min-w-0 break-all font-mono text-xs text-body"><span x-show="match.cut_start">...</span><span x-text="match.before"></span><mark class="rounded-sm bg-warning-50 font-semibold text-warning-700" x-text="match.match"></mark><span x-text="match.after"></span><span x-show="match.cut_end">...</span></span>
                          </a>
                        </li>
                      </template>
                    </ul>
                    <p class="px-3 pt-1 text-xs text-muted" x-show="file.more">Baris lain yang cocok di berkas ini tidak ditampilkan. Buka berkas lalu gunakan Cari (Ctrl+F) di editor.</p>
                  </li>
                </template>
              </ul>
            </div>
          </template>
        </section>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal(true)">Tutup</button>
      </div>
    </div>
  </template>

  <template x-if="modal === 'shortcuts'">
    <div class="modal sm:max-w-lg" role="dialog" aria-modal="true" aria-labelledby="explorer-shortcuts-title" x-ref="modal" @keydown.tab="trapModal($event)">
      <div class="modal-head">
        <h2 id="explorer-shortcuts-title" class="font-display text-sm font-semibold">Pintasan Keyboard</h2>
        <button type="button" class="btn-ghost btn-icon -my-1" @click="closeModal(true)" aria-label="Tutup"><?= $icon('x') ?></button>
      </div>
      <div class="modal-body">
        <?php
        $shortcuts = [
            'Item yang dipilih' => [
                ['Enter', 'Buka item'],
                ['F2', 'Ganti nama'],
                ['Delete', 'Hapus ke tempat sampah'],
                ['Ctrl+C / Ctrl+X', 'Salin / potong'],
                ['Ctrl+V', 'Tempel di folder yang dibuka'],
                ['Ctrl+A', 'Pilih semua item di halaman ini'],
            ],
            'Navigasi' => [
                ['Backspace atau Alt+↑', 'Naik satu level'],
                ['Klik kanan pada item', 'Buka menu aksi item'],
                ['?', 'Tampilkan daftar pintasan ini'],
            ],
        ];
        ?>
        <?php foreach ($shortcuts as $group => $rows): ?>
          <h3 class="mb-1.5 mt-4 text-xs font-medium text-muted first:mt-0"><?= $e($group) ?></h3>
          <dl class="divide-y divide-line text-sm">
            <?php foreach ($rows as $row): ?>
              <div class="flex items-start justify-between gap-4 py-1.5">
                <dt class="text-body"><?= $e($row[1]) ?></dt>
                <dd class="shrink-0 text-right"><kbd class="rounded-chip border border-line bg-surface-2 px-1.5 py-0.5 text-xs text-ink"><?= $e($row[0]) ?></kbd></dd>
              </div>
            <?php endforeach; ?>
          </dl>
        <?php endforeach; ?>
        <p class="mt-4 text-xs text-muted">Pintasan tidak berlaku saat sedang mengetik di kolom isian atau saat dialog terbuka. Di macOS, gunakan Cmd sebagai pengganti Ctrl.</p>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal(true)" data-autofocus>Tutup</button>
      </div>
    </div>
  </template>

  <template x-if="modal === 'extract'">
    <form class="modal sm:max-w-lg" role="dialog" aria-modal="true" aria-labelledby="extract-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitExtract()">
      <div class="modal-head"><h2 id="extract-title" class="font-display text-sm font-semibold" x-text="'Ekstrak ' + form.item.name"></h2></div>
      <div class="modal-body space-y-3">
        <div>
          <label for="extract-dest" class="field-label">Folder tujuan</label>
          <input id="extract-dest" type="text" class="input-mono" x-model="form.dest" data-autofocus required spellcheck="false" autocomplete="off">
        </div>
        <?php $folderPicker(); ?>
        <p class="text-xs text-muted">Berkas yang sudah ada di folder tujuan tidak ditimpa. Pemilik dan izin dari arsip tidak dipakai.</p>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()">Batal</button>
        <button type="submit" class="btn-primary">Lanjut ke Pratinjau</button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'snapshot'">
    <form class="modal sm:max-w-md" role="dialog" aria-modal="true" aria-labelledby="snapshot-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitSnapshot()">
      <div class="modal-head"><h2 id="snapshot-title" class="font-display text-sm font-semibold">Snapshot Izin</h2></div>
      <div class="modal-body space-y-3">
        <p class="text-sm text-body">Snapshot menyimpan izin, pemilik, dan grup saat ini sehingga dapat dibandingkan atau dikembalikan nanti.</p>
        <div>
          <label for="snapshot-label" class="field-label">Label</label>
          <input id="snapshot-label" type="text" class="input" x-model="form.label" data-autofocus maxlength="120" autocomplete="off" @input="errors.label = ''">
          <p class="field-error" x-show="fieldError('label')" x-text="fieldError('label')"></p>
        </div>
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" class="check" x-model="form.recursive">Sertakan seluruh isi folder</label>
        <label class="flex items-center gap-2 text-sm" x-show="system.acl"><input type="checkbox" class="check" x-model="form.acl">Sertakan ACL</label>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()" :disabled="busy">Batal</button>
        <button type="submit" class="btn-primary" :disabled="busy"><span x-text="busy ? 'Menyimpan...' : 'Buat Snapshot'"></span></button>
      </div>
    </form>
  </template>

  <template x-if="modal === 'preview'">
    <div class="modal sm:max-w-none lg:w-[75vw]" role="dialog" aria-modal="true" aria-labelledby="preview-title" x-ref="modal" @keydown.tab="trapModal($event)">
      <div class="modal-head">
        <div class="min-w-0">
          <h2 id="preview-title" class="truncate font-display text-sm font-semibold" :title="form.item.path" x-text="form.item.name"></h2>
          <p class="font-mono text-xs text-muted" x-text="sizeText(form.item)"></p>
        </div>
        <button type="button" class="btn-ghost btn-icon -mr-2 -mt-1" @click="closeModal()" aria-label="Tutup pratinjau"><?= $icon('x') ?></button>
      </div>
      <div class="modal-body relative flex min-h-[16rem] items-center justify-center bg-surface-2" :class="previewKind(form.item) === 'pdf' ? 'p-0' : ''">
        <div class="skeleton absolute inset-4" x-show="previewStatus === 'loading' && previewKind(form.item) !== 'pdf' && previewKind(form.item) !== 'audio'" aria-hidden="true"></div>
        <template x-if="previewKind(form.item) === 'image'">
          <img :src="previewUrl(form.item)" :alt="form.item.name" class="relative max-h-[70vh] max-w-full object-contain" x-show="previewStatus !== 'error'" @load="previewStatus = 'ready'" @error="previewStatus = 'error'">
        </template>
        <template x-if="previewKind(form.item) === 'video'">
          <video :src="previewUrl(form.item)" controls preload="metadata" class="relative max-h-[70vh] w-full bg-black" x-show="previewStatus !== 'error'" @loadedmetadata="previewStatus = 'ready'" @error="previewStatus = 'error'"></video>
        </template>
        <template x-if="previewKind(form.item) === 'audio'">
          <audio :src="previewUrl(form.item)" controls preload="metadata" class="w-full" x-show="previewStatus !== 'error'" @loadedmetadata="previewStatus = 'ready'" @error="previewStatus = 'error'"></audio>
        </template>
        <template x-if="previewKind(form.item) === 'pdf'">
          <iframe :src="previewUrl(form.item)" :title="'Pratinjau ' + form.item.name" class="block h-[75vh] w-full border-0 bg-surface"></iframe>
        </template>
        <div class="flex max-w-sm flex-col items-center gap-2 py-8 text-center text-sm" x-show="previewStatus === 'error'" role="alert">
          <svg class="icon-lg text-danger-700" aria-hidden="true"><use :href="FM.icons + '#circle-alert'"></use></svg>
          <p class="font-medium text-ink">Pratinjau tidak dapat dimuat</p>
          <p class="text-muted">Berkas mungkin rusak atau formatnya tidak didukung browser ini. Unduh berkas untuk membukanya di aplikasi lain.</p>
        </div>
      </div>
      <div class="modal-foot">
        <a class="btn-secondary" :href="previewUrl(form.item)" target="_blank" rel="noopener" x-show="previewKind(form.item) === 'pdf'"><?= $icon('external-link') ?>Buka di Tab Baru</a>
        <button type="button" class="btn-secondary" @click="download(form.item)"><?= $icon('download') ?>Unduh</button>
        <button type="button" class="btn-primary" @click="closeModal()" data-autofocus>Tutup</button>
      </div>
    </div>
  </template>

  <template x-if="modal === 'upload'">
    <form class="modal sm:max-w-3xl" role="dialog" aria-modal="true" aria-labelledby="upload-title" x-ref="modal" @keydown.tab="trapModal($event)" @submit.prevent="submitUpload()" @dragover.window.prevent="$event.dataTransfer.dropEffect = 'none'" @drop.window.prevent>
      <div class="modal-head"><h2 id="upload-title" class="font-display text-sm font-semibold">Unggah Berkas</h2></div>
      <div class="modal-body space-y-3">
        <p class="break-all font-mono text-xs text-muted" x-text="'Ke folder ' + cwd"></p>
        <div>
          <p class="field-label" id="upload-files-label">Berkas</p>
          <label for="upload-files" class="flex cursor-pointer flex-col items-center gap-1 rounded-control border border-dashed px-4 py-6 text-center text-sm transition-colors duration-150 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-primary-600"
                 :class="upload.dragging ? 'border-primary-600 bg-surface-2' : 'border-primary-200 hover:bg-surface-2'"
                 @dragover.prevent.stop="dragOverUpload($event)" @dragleave="upload.dragging = false" @drop.prevent.stop="dropFiles($event)">
            <svg class="icon-lg pointer-events-none text-muted" aria-hidden="true"><use :href="FM.icons + '#upload'"></use></svg>
            <span class="pointer-events-none font-medium text-ink" x-text="upload.reading ? 'Membaca isi folder...' : 'Tarik dan lepas berkas atau folder ke sini'"></span>
            <span class="pointer-events-none text-muted">atau klik untuk memilih berkas</span>
            <input id="upload-files" type="file" multiple class="sr-only" aria-labelledby="upload-files-label" @change="pickFiles($event)" :disabled="busy || upload.reading" data-autofocus>
          </label>
          <label for="upload-folder" class="btn-secondary mt-2 cursor-pointer has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-primary-600" :class="busy || upload.reading ? 'pointer-events-none opacity-60' : ''">
            <?= $icon('folder-open') ?>Pilih Folder
            <input id="upload-folder" type="file" webkitdirectory class="sr-only" @change="pickFiles($event)" :disabled="busy || upload.reading">
          </label>
          <p class="mt-2 text-xs text-muted" x-text="'Batas ukuran per berkas ' + FM.formatBytes(system.limits.upload_bytes) + '. Folder diunggah beserta subfoldernya, dan folder yang belum ada di tujuan dibuat otomatis.'"></p>
          <p class="mt-1 text-xs text-muted" x-show="system.blocks_scripts">Berkas skrip server (misalnya .php) dan berkas konfigurasi server web (misalnya .htaccess) ditolak demi keamanan.</p>
          <p class="field-error" x-show="fieldError('files')" x-text="fieldError('files')"></p>
        </div>
        <div x-show="upload.files.length">
          <p class="mb-1 text-xs text-muted" x-text="uploadSummary()"></p>
          <ul class="max-h-40 divide-y divide-line overflow-y-auto rounded-control border border-line text-sm">
            <template x-for="entry in upload.files" :key="entry.path">
              <li class="flex items-center justify-between gap-3 px-3 py-1.5">
                <span class="truncate" :title="entry.path" x-text="entry.path"></span>
                <span class="shrink-0 font-mono text-xs" :class="system.limits.upload_bytes && entry.file.size > system.limits.upload_bytes ? 'text-danger-700' : 'text-muted'" x-text="FM.formatBytes(entry.file.size)"></span>
              </li>
            </template>
          </ul>
        </div>
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" class="check" x-model="form.overwrite" :disabled="busy">Timpa berkas dengan nama yang sama</label>
        <div x-show="busy" class="space-y-1">
          <div class="h-2 overflow-hidden rounded-chip bg-surface-2" role="progressbar" :aria-valuenow="upload.progress" aria-valuemin="0" aria-valuemax="100" aria-label="Kemajuan unggahan">
            <div class="h-full bg-primary-600 transition-[width] duration-150" :style="`width: ${upload.progress}%`"></div>
          </div>
          <p class="text-xs text-muted" x-text="upload.progress < 100 ? 'Mengunggah ' + upload.progress + '%' : 'Memproses di server...'"></p>
        </div>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeModal()" :disabled="busy">Batal</button>
        <button type="submit" class="btn-primary" :disabled="busy || upload.reading"><span x-text="busy ? 'Mengunggah...' : 'Unggah'"></span></button>
      </div>
    </form>
  </template>
</div>
