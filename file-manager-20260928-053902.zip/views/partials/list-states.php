<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
// Empty, filtered-empty, and error blocks shared by the desktop table and the mobile card list.
// Expects $emptyTitle, $emptyText, and optionally $emptyAction [Alpine expression, label].
$emptyAction = (isset($emptyAction) ? $emptyAction : null);
?>
<template x-if="phase === 'empty'">
    <div class="flex flex-col items-center gap-2 py-10 text-center">
      <svg class="icon-lg text-muted" aria-hidden="true"><use :href="FM.icons + '#inbox'"></use></svg>
      <p class="font-medium text-ink"><?= $e($emptyTitle) ?></p>
      <p class="max-w-md text-sm text-muted"><?= $e($emptyText) ?></p>
      <?php if ($emptyAction): ?>
        <button type="button" class="btn-secondary mt-2" @click="<?= $e($emptyAction[0]) ?>"><?= $e($emptyAction[1]) ?></button>
      <?php endif; ?>
    </div>
</template>
<template x-if="phase === 'filtered'">
    <div class="flex flex-col items-center gap-2 py-10 text-center">
      <svg class="icon-lg text-muted" aria-hidden="true"><use :href="FM.icons + '#search'"></use></svg>
      <p class="font-medium text-ink">Tidak ada data yang cocok dengan pencarian atau filter ini</p>
      <button type="button" class="btn-secondary mt-2" @click="resetFilters()">Reset Filter</button>
    </div>
</template>
<template x-if="phase === 'error'">
    <div class="flex flex-col items-center gap-2 py-10 text-center" role="alert">
      <svg class="icon-lg text-danger-700" aria-hidden="true"><use :href="FM.icons + '#circle-alert'"></use></svg>
      <p class="font-medium text-ink">Data gagal dimuat</p>
      <p class="max-w-md text-sm text-muted" x-text="errorMessage"></p>
      <button type="button" class="btn-secondary mt-2" @click="reload()">Muat Ulang</button>
    </div>
</template>
