<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
// Page length and free-text search, always the last row directly above the table.
$searchLabel = (isset($searchLabel) ? $searchLabel : 'Cari');
$searchId = (isset($searchId) ? $searchId : 'list-search');
?>
<div class="flex flex-wrap items-center gap-3 border-b border-line px-3 py-3">
  <label class="flex items-center gap-2 text-sm text-muted">
    Tampilkan
    <select class="input w-auto" x-model="state.per_page" @change="setFilter()">
      <option value="10">10</option>
      <option value="25">25</option>
      <option value="50">50</option>
      <option value="100">100</option>
      <option value="all">Semua</option>
    </select>
  </label>
  <div class="relative w-full sm:w-72">
    <label for="<?= $e($searchId) ?>" class="sr-only"><?= $e($searchLabel) ?></label>
    <svg class="icon pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted" aria-hidden="true"><use href="<?= $e($asset('icons.svg')) ?>#search"></use></svg>
    <input id="<?= $e($searchId) ?>" type="search" class="input pl-9" placeholder="<?= $e($searchLabel) ?>" x-model="state.search" @input="searchDebounced()" @keydown.enter.prevent="setFilter()">
  </div>
  <p class="text-sm text-muted sm:ml-auto" x-show="notice" x-text="notice"></p>
</div>
