<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data class="pointer-events-none fixed inset-x-3 bottom-3 z-[70] flex flex-col items-end gap-2 sm:inset-x-auto sm:right-4 sm:w-96" aria-live="polite">
  <template x-for="toast in $store.toasts.items" :key="toast.id">
    <div class="toast pointer-events-auto flex w-full items-start gap-3 rounded-card border bg-surface p-3 text-sm shadow-[0_8px_24px_-12px_rgba(17,24,39,0.35)]"
         :class="{ 'toast-leave': toast.leaving, 'border-success-600/40': toast.type === 'success', 'border-danger-600/40': toast.type === 'error', 'border-warning-600/40': toast.type === 'warning', 'border-line': toast.type === 'info' }"
         :role="toast.type === 'error' ? 'alert' : 'status'">
      <svg class="icon-lg mt-px" aria-hidden="true"
           :class="{ 'text-success-700': toast.type === 'success', 'text-danger-700': toast.type === 'error', 'text-warning-700': toast.type === 'warning', 'text-primary-700': toast.type === 'info' }">
        <use :href="$store.toasts.icon(toast.type)"></use>
      </svg>
      <div class="min-w-0 flex-1">
        <p class="font-medium text-ink" x-text="toast.title"></p>
        <p class="mt-0.5 break-words text-body" x-show="toast.message" x-text="toast.message"></p>
        <button type="button" class="btn-secondary mt-2" x-show="toast.action" x-text="toast.action?.label" @click="$store.toasts.runAction(toast)"></button>
      </div>
      <button type="button" class="-m-1 grid h-8 w-8 shrink-0 place-items-center rounded-control text-muted hover:bg-surface-2" @click="$store.toasts.dismiss(toast.id)" aria-label="Tutup notifikasi">
        <svg class="icon" aria-hidden="true"><use :href="$store.toasts.iconUrl + '#x'"></use></svg>
      </button>
    </div>
  </template>
</div>
