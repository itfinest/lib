<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
// Unsaved-changes prompt inside a crudMixin form modal.
?>
<div x-show="confirmDiscard" class="flex flex-col gap-2 rounded-control border border-warning-600/40 bg-warning-50 p-3 text-sm text-warning-700 sm:flex-row sm:items-center" role="alert">
  <p class="flex-1">Perubahan belum disimpan. Tutup dan buang perubahan?</p>
  <div class="flex gap-2">
    <button type="button" class="btn-secondary" @click="confirmDiscard = false">Lanjut Mengisi</button>
    <button type="button" class="btn-danger" @click="closeForm(true)">Buang Perubahan</button>
  </div>
</div>
