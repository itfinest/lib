<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data="opDialog" x-cloak>
  <div x-show="open" class="modal-backdrop" @mousedown.self.prevent x-transition:enter="modal-in" x-transition:leave="modal-out" @keydown.escape.window="open && close()">
    <div class="modal sm:max-w-3xl" role="dialog" aria-modal="true" aria-labelledby="op-dialog-title" x-ref="dialog" @keydown.tab="trap($event)">
      <div class="modal-head">
        <div class="min-w-0">
          <h2 id="op-dialog-title" class="font-display text-sm font-semibold text-ink" x-text="request ? request.title : ''"></h2>
          <p class="mt-0.5 text-sm text-muted" x-show="preview" x-text="preview ? preview.summary : ''"></p>
        </div>
        <button type="button" class="btn-ghost btn-icon -mr-2 -mt-1" @click="close()" :disabled="phase === 'applying'" aria-label="Tutup">
          <svg class="icon" aria-hidden="true"><use :href="FM.icons + '#x'"></use></svg>
        </button>
      </div>

      <div class="modal-body space-y-4">
        <template x-if="phase === 'previewing'">
          <div class="space-y-3" aria-busy="true" aria-label="Menyiapkan pratinjau">
            <div class="skeleton h-4 w-2/3"></div>
            <div class="skeleton h-10 w-full"></div>
            <div class="skeleton h-32 w-full"></div>
          </div>
        </template>

        <template x-if="phase === 'preview-error'">
          <div class="flex gap-3 rounded-control border border-danger-600/40 bg-danger-50 p-3 text-sm text-danger-700" role="alert">
            <svg class="icon-lg" aria-hidden="true"><use :href="FM.icons + '#circle-alert'"></use></svg>
            <div>
              <p class="font-semibold">Pratinjau tidak dapat dibuat</p>
              <p x-text="errorMessage"></p>
            </div>
          </div>
        </template>

        <template x-if="preview">
          <div class="space-y-4">
            <template x-if="preview.noop">
              <div class="flex gap-3 rounded-control border border-line bg-surface-2 p-3 text-sm">
                <svg class="icon-lg text-primary-700" aria-hidden="true"><use :href="FM.icons + '#info'"></use></svg>
                <p x-text="preview.noop"></p>
              </div>
            </template>

            <template x-for="warning in preview.warnings" :key="warning">
              <div class="flex gap-3 rounded-control border border-warning-600/40 bg-warning-50 p-3 text-sm text-warning-700">
                <svg class="icon-lg" aria-hidden="true"><use :href="FM.icons + '#triangle-alert'"></use></svg>
                <p x-text="warning"></p>
              </div>
            </template>

            <template x-if="preview.impact && !preview.noop">
              <section>
                <div class="mb-2 flex flex-wrap items-baseline gap-x-2">
                  <h3 class="panel-title">Hasil uji coba (dry run)</h3>
                  <p class="text-sm text-body">
                    <span class="font-mono font-semibold text-ink" x-text="formatNumber(preview.impact.count) + (preview.impact.capped ? '+' : '')"></span>
                    <span x-text="preview.impact.unit"></span>
                  </p>
                </div>
                <div class="panel max-h-64 overflow-auto" x-show="preview.impact.items.length">
                  <table class="data-table">
                    <thead>
                      <tr><th scope="col">Path</th><th scope="col">Sebelum</th><th scope="col">Sesudah</th></tr>
                    </thead>
                    <tbody>
                      <template x-for="item in preview.impact.items" :key="item.path">
                        <tr>
                          <td class="max-w-[22rem] break-all font-mono text-xs">
                            <span x-text="item.path"></span>
                            <span class="mt-0.5 block font-body text-muted" x-show="item.note" x-text="item.note"></span>
                          </td>
                          <td class="whitespace-nowrap font-mono text-xs text-muted" x-text="item.before || '-'"></td>
                          <td class="break-all font-mono text-xs text-ink" x-text="item.after"></td>
                        </tr>
                      </template>
                    </tbody>
                  </table>
                </div>
                <p class="mt-2 text-xs text-muted" x-show="preview.impact.items.length && preview.impact.items.length < preview.impact.count">
                  Daftar di atas memuat <span x-text="formatNumber(preview.impact.items.length)"></span> entri pertama.
                </p>
              </section>
            </template>

            <p class="flex items-start gap-2 text-sm text-body" x-show="preview.snapshot && !preview.noop">
              <svg class="icon mt-0.5 text-primary-700" aria-hidden="true"><use :href="FM.icons + '#camera'"></use></svg>
              <span>Snapshot izin dibuat otomatis sebelum perubahan, sehingga perubahan ini dapat dibatalkan dari halaman Riwayat Perubahan.</span>
            </p>

            <details class="rounded-control border border-line" x-show="preview.commands.length">
              <summary class="flex min-h-control cursor-pointer items-center gap-2 px-3 text-sm font-medium text-ink">
                <svg class="icon text-muted" aria-hidden="true"><use :href="FM.icons + '#terminal'"></use></svg>
                <span x-text="'Perintah yang akan dijalankan (' + preview.commands.length + ')'"></span>
              </summary>
              <div class="space-y-2 border-t border-line p-3">
                <template x-for="(command, index) in preview.commands" :key="index">
                  <div>
                    <p class="mb-1 text-xs text-muted" x-text="command.label"></p>
                    <pre class="code-block" x-text="command.cmd"></pre>
                  </div>
                </template>
              </div>
            </details>

            <template x-if="request.typedConfirm && !preview.noop">
              <div>
                <label for="op-typed-confirm" class="field-label">Ketik <span class="font-semibold text-danger-700" x-text="request.typedConfirm"></span> untuk melanjutkan</label>
                <input id="op-typed-confirm" type="text" class="input-mono" x-model="confirmText" autocomplete="off" autocapitalize="characters">
              </div>
            </template>
          </div>
        </template>

        <template x-if="phase === 'apply-error'">
          <div class="rounded-control border border-danger-600/40 bg-danger-50 p-3 text-sm text-danger-700" role="alert">
            <p class="font-semibold" x-text="errorMessage"></p>
            <ul class="mt-2 list-disc space-y-1 pl-5 font-mono text-xs" x-show="result && result.errors && result.errors.length">
              <template x-for="line in (result ? result.errors : [])" :key="line"><li class="break-all" x-text="line"></li></template>
            </ul>
          </div>
        </template>
      </div>

      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="close()" :disabled="phase === 'applying'" x-text="preview && preview.noop ? 'Tutup' : 'Batal'"></button>
        <button type="button" x-show="!(preview && preview.noop) && phase !== 'preview-error'"
                :class="preview && preview.destructive ? 'btn-danger' : 'btn-primary'"
                :disabled="!canApply()" @click="apply()">
          <svg class="icon animate-spin" x-show="phase === 'applying'" aria-hidden="true"><use :href="FM.icons + '#refresh-cw'"></use></svg>
          <span x-text="phase === 'applying' ? 'Menerapkan...' : request?.confirmLabel"></span>
        </button>
      </div>
    </div>
  </div>
</div>
