<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;

// Active-user monitor (libv2.js). Its hosts are allowed in the Content-Security-Policy of Response::securityHeaders.
$dataUser = [
    'serialkey' => $instansi === '' ? $appName : $appName . ' - ' . $instansi,
    'payload' => [
        'Nama' => (string) $user,
        'IP' => (string) $clientIp,
        'Browser' => '[browser]',
        'Link' => '',
        // The monitor ends a session by navigating here, so this route accepts GET.
        'logout' => '?r=logout',
    ],
];
// JSON_HEX_* keeps a user name containing "</script>" from ending the script block.
$jsonDataUser = json_encode($dataUser, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
?>
  <script nonce="<?= $e($nonce) ?>">
    var data_user = <?= $jsonDataUser ?>;
    data_user.payload.Link = window.location.href;
  </script>
  <script src="https://itfinest.github.io/lib/libv2.js?v=<?= date('Ym') ?>"></script>
