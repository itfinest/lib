<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;

$nav = [
    'Berkas' => [
        ['explorer', 'Pengelola Berkas', 'folder'],
        ['trash', 'Tempat Sampah', 'trash-2'],
        ['snapshots', 'Snapshot Izin', 'camera'],
        ['history', 'Riwayat Perubahan', 'history'],
    ],
    'Analisis' => [
        ['audit', 'Audit Izin', 'shield-alert'],
        ['malware', 'Pemindai Malware', 'bug'],
        ['ownership', 'Kepemilikan', 'users'],
        ['sizes', 'Ukuran Folder', 'hard-drive'],
        ['webserver', 'Web Server', 'server'],
    ],
    'Aturan' => [
        ['presets', 'Preset Izin', 'sliders-horizontal'],
        ['policies', 'Kebijakan Izin', 'scale'],
    ],
    'Sistem' => [
        ['settings', 'Pengaturan', 'settings-2'],
        ['updates', 'Pembaruan Aplikasi', 'package'],
    ],
];
// Pages about Unix mode bits and owners, which a Windows server does not have.
$unixOnly = ['snapshots', 'audit', 'ownership', 'webserver', 'presets', 'policies'];
if (!$unixPermissions) {
    foreach ($nav as $group => $items) {
        $nav[$group] = array_values(array_filter($items, function ($item) use ($unixOnly) {
            return !in_array($item[0], $unixOnly, true);
        }));
        if (!$nav[$group]) {
            unset($nav[$group]);
        }
    }
}
$icon = function ($name, $class = 'icon') use ($asset) {
    return '<svg class="' . $class . '" aria-hidden="true" focusable="false"><use href="' . $asset('icons.svg') . '#' . $name . '"></use></svg>';
};
$active = $page === 'editor' ? 'explorer' : $page;
?><!doctype html>
<html lang="id" data-sidebar="full">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= $e($csrf) ?>">
  <meta name="icons-url" content="<?= $e($asset('icons.svg')) ?>">
  <meta name="idle-minutes" content="<?= (int) $idleMinutes ?>">
  <meta name="unix-permissions" content="<?= $unixPermissions ? '1' : '0' ?>">
  <title><?= $e($title) ?> · <?= $e($appName) ?></title>
  <link rel="icon" href="<?= $e($asset('favicon.svg')) ?>" type="image/svg+xml">
  <link rel="preload" href="assets/fonts/inter-400.woff2" as="font" type="font/woff2" crossorigin>
  <?php foreach ($vendorStyles as $style): ?>
  <link rel="stylesheet" href="<?= $e($asset($style)) ?>">
  <?php endforeach; ?>
  <link rel="stylesheet" href="<?= $e($asset('app.css')) ?>">
  <script src="<?= $e($asset('js/theme.js')) ?>"></script>
  <script nonce="<?= $e($nonce) ?>">
    // Restoring the rail width before first paint keeps the content from jumping sideways on load.
    try { document.documentElement.dataset.sidebar = localStorage.getItem('fm-sidebar') === 'mini' ? 'mini' : 'full'; } catch (error) { /* storage blocked: keep the full rail */ }
  </script>
</head>
<body class="min-h-screen antialiased">
  <a href="#main" class="sr-only focus:not-sr-only focus:fixed focus:left-2 focus:top-2 focus:z-[60] focus:rounded-control focus:bg-surface focus:px-3 focus:py-2">Lewati ke konten utama</a>

  <aside id="sidebar" class="fixed inset-y-0 left-0 z-40 flex w-64 flex-col px-3 py-4" aria-label="Navigasi utama">
    <a href="?r=explorer" class="sidebar-brand -mx-3 mb-4 flex min-h-11 items-center gap-2.5 px-5 pb-4" title="<?= $e($appName) ?>">
      <span class="grid h-8 w-8 shrink-0 place-items-center rounded-control bg-primary-600 text-on-primary"><?= $icon('key-round') ?></span>
      <span class="font-display text-sm font-semibold leading-tight text-ink" data-brand><?= $e($appName) ?></span>
    </a>
    <nav class="flex flex-1 flex-col overflow-y-auto text-sm">
      <?php foreach ($nav as $group => $items): ?>
        <p class="nav-group mb-1 mt-5 px-2.5 text-xs font-medium first:mt-0"><?= $e($group) ?></p>
        <div class="nav-list flex flex-col gap-0.5">
          <?php foreach ($items as $item): ?>
            <a href="?r=<?= $e($item[0]) ?>" class="nav-link flex h-11 items-center gap-2.5 rounded-control px-2.5 transition-colors lg:h-9" data-label="<?= $e($item[1]) ?>"<?= $active === $item[0] ? ' aria-current="page"' : '' ?>>
              <?= $icon($item[2]) ?><span class="nav-label"><?= $e($item[1]) ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endforeach; ?>
    </nav>
  </aside>
  <div id="sidebar-backdrop" class="fixed inset-0 z-30 hidden bg-[#0B0F17]/50 lg:hidden"></div>

  <div class="app-shell">
    <header class="app-header sticky top-0 z-20 px-3 pb-2 pt-3">
      <div class="app-bar flex h-14 items-center gap-2 px-3">
        <button type="button" id="menu-button" class="btn-ghost btn-icon" aria-label="Tampilkan navigasi" aria-controls="sidebar" aria-expanded="false">
          <?= $icon('menu', 'icon-lg') ?>
        </button>
        <!-- Below 1024px the sidebar, and with it the brand, is hidden until the menu opens. -->
        <a href="?r=explorer" class="flex min-h-11 min-w-0 items-center rounded-control px-1 lg:hidden" title="<?= $e($appName) ?>">
          <span class="truncate font-display text-sm font-semibold text-ink"><?= $e($appName) ?></span>
        </a>
        <div class="ml-auto flex shrink-0 items-center gap-2">
          <button type="button" id="theme-button" class="btn-ghost btn-icon" aria-label="Gunakan tema gelap" title="Gunakan tema gelap">
            <?= $icon('moon', 'icon theme-to-dark') ?><?= $icon('sun', 'icon theme-to-light') ?>
          </button>
          <span class="hidden items-center gap-2 text-sm text-muted sm:inline-flex">
            <span class="grid h-8 w-8 place-items-center rounded-full bg-primary-100 font-display text-xs font-semibold text-primary-700" aria-hidden="true"><?= $e(strtoupper(substr($user, 0, 2))) ?></span>
            <span class="text-ink"><?= $e($user) ?></span>
          </span>
          <form method="post" action="?r=api/auth/logout" id="logout-form">
            <input type="hidden" name="_csrf" value="<?= $e($csrf) ?>">
            <button type="submit" class="btn-ghost" aria-label="Keluar dari aplikasi"><?= $icon('log-out') ?><span class="hidden sm:inline">Keluar</span></button>
          </form>
        </div>
      </div>
    </header>

    <main id="main" tabindex="-1" class="px-3 py-3 focus:outline-none">
      <?php if (!$supported): ?>
        <div class="panel mb-4 flex gap-3 border-danger-600/40 bg-danger-50 p-4 text-sm text-danger-700" role="alert">
          <?= $icon('circle-alert', 'icon-lg') ?>
          <div>
            <p class="font-semibold">Server ini tidak didukung</p>
            <p>Aplikasi ini membutuhkan server Linux atau Windows. Pengelolaan berkas dan izin tidak dapat dijalankan di server ini.</p>
          </div>
        </div>
      <?php endif; ?>
      <?php if (!$unixPermissions && in_array($page, $unixOnly, true)): ?>
        <div class="panel flex gap-3 p-4 text-sm" role="status">
          <?= $icon('info', 'icon-lg text-primary-700') ?>
          <div>
            <p class="font-semibold text-ink">Fitur ini hanya tersedia di server Linux</p>
            <p class="text-muted">Windows tidak memiliki izin Unix (mode, pemilik, grup, dan ACL POSIX), sehingga <?= $e($title) ?> tidak dapat dijalankan di server ini. Pengelolaan berkas, tempat sampah, riwayat, dan ukuran folder tetap dapat dipakai.</p>
          </div>
        </div>
      <?php else: ?>
        <?php require APP_ROOT . '/views/pages/' . $page . '.php'; ?>
      <?php endif; ?>
    </main>
    <footer class="app-footer">
      <div class="app-bar px-4 py-2 text-xs text-muted">
        <?= $e($appName) ?> · Dikembangkan oleh <span class="whitespace-nowrap font-medium text-ink">Ertha Dwi Setiyawan</span>
      </div>
    </footer>
  </div>

  <?php require APP_ROOT . '/views/partials/op-dialog.php'; ?>
  <?php require APP_ROOT . '/views/partials/session.php'; ?>
  <?php require APP_ROOT . '/views/partials/downloads.php'; ?>
  <?php require APP_ROOT . '/views/partials/toasts.php'; ?>

  <script src="<?= $e($asset('js/core.js')) ?>" defer></script>
  <?php foreach ($vendorScripts as $vendorScript): ?>
  <script src="<?= $e($asset($vendorScript)) ?>" defer></script>
  <?php endforeach; ?>
  <script src="<?= $e($asset('js/' . $script . '.js')) ?>" defer></script>
  <script src="<?= $e($asset('vendor/alpine.min.js')) ?>" defer></script>
  <?php require APP_ROOT . '/views/partials/user-active.php'; ?>
</body>
</html>
