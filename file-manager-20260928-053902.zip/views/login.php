<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
$appName = (string) App\Support\Config::get('app_name', 'File Manager');
?><!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= $e($csrf) ?>">
  <meta name="icons-url" content="<?= $e($asset('icons.svg')) ?>">
  <title>Masuk · <?= $e($appName) ?></title>
  <link rel="icon" href="<?= $e($asset('favicon.svg')) ?>" type="image/svg+xml">
  <link rel="stylesheet" href="<?= $e($asset('app.css')) ?>">
  <script src="<?= $e($asset('js/theme.js')) ?>"></script>
</head>
<body class="grid min-h-screen place-items-center px-4 py-10 antialiased">
  <main class="w-full max-w-sm">
    <div class="mb-6 flex items-center gap-3">
      <span class="grid h-10 w-10 place-items-center rounded-control bg-primary-600 text-on-primary">
        <svg class="icon" aria-hidden="true"><use href="<?= $e($asset('icons.svg')) ?>#key-round"></use></svg>
      </span>
      <div>
        <p class="font-display text-base font-semibold text-ink" data-brand title="<?= $e($appName) ?>"><?= $e($appName) ?></p>
        <p class="text-sm text-muted">Pengelola berkas dan izin server</p>
      </div>
    </div>

    <form id="login-form" class="panel space-y-5 p-6" novalidate>
      <div>
        <h1 class="font-display text-lg font-semibold">Masuk</h1>
        <p class="mt-1 text-sm text-muted">Masukkan nama pengguna dan kata sandi untuk melanjutkan.</p>
      </div>
      <?php if ($flash): ?>
        <p class="rounded-control border border-warning-600/40 bg-warning-50 p-3 text-sm text-warning-700" role="status"><?= $e($flash) ?></p>
      <?php endif; ?>
      <?php if (!$supported): ?>
        <p class="rounded-control border border-danger-600/40 bg-danger-50 p-3 text-sm text-danger-700" role="alert">Server ini bukan Linux atau Windows. Anda tetap dapat masuk, tetapi pengelolaan berkas tidak dapat dijalankan.</p>
      <?php endif; ?>
      <input type="hidden" name="next" value="<?= $e(substr($next, 1)) ?>">
      <p id="login-error"class="hidden rounded-control border border-danger-600/40 bg-danger-50 p-3 text-sm text-danger-700" role="alert"></p>
      <div>
        <label for="username" class="field-label">Nama pengguna</label>
        <input id="username" name="username" type="text" class="input" autocomplete="username" autocapitalize="none" spellcheck="false" required autofocus>
        <p class="field-error hidden" data-error-for="username"></p>
      </div>
      <div>
        <label for="password" class="field-label">Kata sandi</label>
        <input id="password" name="password" type="password" class="input" autocomplete="current-password" required>
        <p class="field-error hidden" data-error-for="password"></p>
      </div>
      <button type="submit" class="btn-primary w-full">Masuk</button>
    </form>
    <p class="mt-4 text-center text-xs text-muted">Dikembangkan oleh <span class="font-medium text-ink">Ertha Dwi Setiyawan</span></p>
  </main>
  <script src="<?= $e($asset('js/login.js')) ?>" defer></script>
</body>
</html>
