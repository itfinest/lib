<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data="presetsPage" class="flex flex-col gap-4">
  <div class="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
    <div>
      <h1 class="font-display text-lg font-semibold">Preset Izin</h1>
      <p class="mt-1 text-sm text-muted">Kombinasi izin folder, izin berkas, pemilik, dan grup yang dapat diterapkan sekaligus dari Pengelola Berkas.</p>
    </div>
    <button type="button" class="btn-primary" @click="openForm(null)"><?= $icon('plus') ?>Tambah Preset</button>
  </div>

  <section class="panel min-w-0">
    <?php $searchLabel = 'Cari nama, keterangan, atau pemilik'; $searchId = 'preset-search'; require APP_ROOT . '/views/partials/list-toolbar.php'; ?>
    <div class="table-scroll hidden md:block" x-show="phase === 'loading' || phase === 'content'">
      <table class="data-table">
        <thead>
          <tr>
            <th scope="col" class="w-12 text-right">No</th>
            <th scope="col" :aria-sort="ariaSort('name')"><button type="button" class="sort-btn" @click="sortBy('name')">Nama<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('name')"></use></svg></button></th>
            <th scope="col" :aria-sort="ariaSort('dir_mode')"><button type="button" class="sort-btn" @click="sortBy('dir_mode')">Folder<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('dir_mode')"></use></svg></button></th>
            <th scope="col" :aria-sort="ariaSort('file_mode')"><button type="button" class="sort-btn" @click="sortBy('file_mode')">Berkas<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('file_mode')"></use></svg></button></th>
            <th scope="col">Pemilik:Grup</th>
            <th scope="col" :aria-sort="ariaSort('updated_at')"><button type="button" class="sort-btn" @click="sortBy('updated_at')">Diubah<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('updated_at')"></use></svg></button></th>
            <th scope="col" class="text-right">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $cols = 7; require APP_ROOT . '/views/partials/skeleton-rows.php'; ?>
          <template x-if="phase === 'content'">
            <template x-for="(item, index) in items" :key="item.id">
              <tr>
                <td class="text-right font-mono text-xs text-muted" x-text="rowNumber(index)"></td>
                <td class="max-w-[24rem]"><p class="font-medium text-ink" x-text="item.name"></p><p class="text-xs text-muted" x-text="item.description"></p></td>
                <td class="font-mono text-xs" x-text="item.dir_mode || '(tetap)'"></td>
                <td class="font-mono text-xs" x-text="item.file_mode || '(tetap)'"></td>
                <td class="font-mono text-xs" x-text="(item.owner || '(tetap)') + ':' + (item.group || '(tetap)')"></td>
                <td class="whitespace-nowrap text-xs"><span x-text="FM.formatDate(item.updated_at)"></span><span class="block text-muted" x-text="'oleh ' + item.updated_by"></span></td>
                <td class="whitespace-nowrap text-right">
                  <button type="button" class="btn-ghost" @click="openForm(item)">Ubah</button>
                  <button type="button" class="btn-ghost text-danger-700 hover:bg-danger-50" @click="askDelete(item)">Hapus</button>
                </td>
              </tr>
            </template>
          </template>
        </tbody>
      </table>
    </div>
    <ul class="divide-y divide-line md:hidden" x-show="phase === 'loading' || phase === 'content'">
      <template x-if="phase === 'loading'"><template x-for="n in 4" :key="n"><li class="space-y-2 p-3"><span class="skeleton block h-4 w-2/3"></span><span class="skeleton block h-3 w-full"></span></li></template></template>
      <template x-if="phase === 'content'">
        <template x-for="(item, index) in items" :key="item.id">
          <li class="p-3">
            <p class="font-medium text-ink"><span class="font-mono text-xs text-muted" x-text="rowNumber(index) + '. '"></span><span x-text="item.name"></span></p>
            <p class="font-mono text-xs text-muted" x-text="'Folder ' + (item.dir_mode || 'tetap') + ' · Berkas ' + (item.file_mode || 'tetap') + ' · ' + (item.owner || 'tetap') + ':' + (item.group || 'tetap')"></p>
            <div class="mt-2 flex gap-2">
              <button type="button" class="btn-secondary btn-sm" @click="openForm(item)">Ubah</button>
              <button type="button" class="btn-danger-ghost btn-sm" @click="askDelete(item)">Hapus</button>
            </div>
          </li>
        </template>
      </template>
    </ul>
    <?php $emptyTitle = 'Belum ada preset'; $emptyText = 'Buat preset untuk menerapkan kombinasi izin yang sering dipakai dengan sekali pilih.'; $emptyAction = ['openForm(null)', 'Tambah Preset']; require APP_ROOT . '/views/partials/list-states.php'; ?>
    <?php require APP_ROOT . '/views/partials/pager.php'; ?>
  </section>

  <div x-show="formOpen" x-cloak class="modal-backdrop" @mousedown.self.prevent x-transition:enter="modal-in" x-transition:leave="modal-out" @keydown.escape="closeForm()">
    <form class="modal sm:max-w-lg" role="dialog" aria-modal="true" aria-labelledby="preset-form-title" x-ref="formModal" @keydown.tab="FM.trapFocus($event, $refs.formModal)" @submit.prevent="save()">
      <div class="modal-head"><h2 id="preset-form-title" class="font-display text-sm font-semibold" x-text="form.id ? 'Ubah Preset' : 'Tambah Preset'"></h2></div>
      <div class="modal-body space-y-3">
        <div>
          <label for="p-name" class="field-label">Nama <span class="text-danger-700" aria-hidden="true">*</span></label>
          <input id="p-name" type="text" class="input" x-model="form.name" maxlength="80" required data-autofocus autocomplete="off" @input="errors.name = ''">
          <p class="field-error" x-show="errors.name" x-text="errors.name"></p>
        </div>
        <div>
          <label for="p-desc" class="field-label">Keterangan</label>
          <textarea id="p-desc" class="input" rows="2" maxlength="200" x-model="form.description" @input="errors.description = ''"></textarea>
          <p class="field-error" x-show="errors.description" x-text="errors.description"></p>
        </div>
        <div class="grid gap-3 sm:grid-cols-2">
          <div>
            <label for="p-dir" class="field-label">Izin folder</label>
            <input id="p-dir" type="text" inputmode="numeric" class="input-mono" maxlength="5" placeholder="0755" x-model="form.dir_mode" @input="errors.dir_mode = ''">
            <p class="field-error" x-show="errors.dir_mode" x-text="errors.dir_mode"></p>
          </div>
          <div>
            <label for="p-file" class="field-label">Izin berkas</label>
            <input id="p-file" type="text" inputmode="numeric" class="input-mono" maxlength="5" placeholder="0644" x-model="form.file_mode" @input="errors.file_mode = ''">
            <p class="field-error" x-show="errors.file_mode" x-text="errors.file_mode"></p>
          </div>
          <div>
            <label for="p-owner" class="field-label">Pemilik</label>
            <input id="p-owner" type="text" class="input-mono" placeholder="deploy" x-model="form.owner" autocomplete="off" spellcheck="false" @input="errors.owner = ''">
            <p class="field-error" x-show="errors.owner" x-text="errors.owner"></p>
          </div>
          <div>
            <label for="p-group" class="field-label">Grup</label>
            <input id="p-group" type="text" class="input-mono" placeholder="www-data" x-model="form.group" autocomplete="off" spellcheck="false" @input="errors.group = ''">
            <p class="field-error" x-show="errors.group" x-text="errors.group"></p>
          </div>
        </div>
        <p class="text-xs text-muted">Kosongkan nilai yang tidak ingin diubah saat preset diterapkan. Isi minimal satu nilai.</p>
        <?php require APP_ROOT . '/views/partials/discard-confirm.php'; ?>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeForm()" :disabled="busy">Batal</button>
        <button type="submit" class="btn-primary" :disabled="busy" x-text="busy ? 'Menyimpan...' : 'Simpan'"></button>
      </div>
    </form>
  </div>

  <div x-show="deleting" x-cloak class="modal-backdrop" @mousedown.self.prevent x-transition:enter="modal-in" x-transition:leave="modal-out" @keydown.escape="!busy && (deleting = null)">
    <div class="modal sm:max-w-md" role="dialog" aria-modal="true" aria-labelledby="preset-del-title" x-ref="delModal" @keydown.tab="FM.trapFocus($event, $refs.delModal)">
      <div class="modal-head"><h2 id="preset-del-title" class="font-display text-sm font-semibold">Hapus preset?</h2></div>
      <div class="modal-body text-sm"><p>Preset "<span class="font-semibold" x-text="deleting ? deleting.name : ''"></span>" akan dihapus. Izin yang sudah diterapkan dengan preset ini tidak berubah.</p></div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="deleting = null" :disabled="busy" data-autofocus>Batal</button>
        <button type="button" class="btn-danger" @click="confirmDelete()" :disabled="busy" x-text="busy ? 'Menghapus...' : 'Hapus Preset'"></button>
      </div>
    </div>
  </div>
</div>
