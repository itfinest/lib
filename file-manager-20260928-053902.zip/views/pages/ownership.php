<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data="ownershipPage" class="flex flex-col gap-4">
  <div>
    <h1 class="font-display text-lg font-semibold">Analisis Kepemilikan</h1>
    <p class="mt-1 text-sm text-muted">Sebaran pemilik dan grup di dalam folder, akun yang tidak dikenal, serta item yang tidak sesuai pemilik yang diharapkan.</p>
  </div>

  <form class="panel grid grid-cols-1 items-end gap-3 p-3 md:grid-cols-[minmax(0,1fr)_12rem_12rem_auto]" @submit.prevent="analyze()">
    <div>
      <label for="own-path" class="field-label">Folder</label>
      <input id="own-path" type="text" class="input-mono" x-model="form.path" required spellcheck="false" autocomplete="off" placeholder="/var/www/html">
    </div>
    <div>
      <label for="own-owner" class="field-label">Pemilik diharapkan</label>
      <input id="own-owner" type="text" class="input-mono" x-model="form.expected_owner" spellcheck="false" autocomplete="off" placeholder="deploy">
    </div>
    <div>
      <label for="own-group" class="field-label">Grup diharapkan</label>
      <input id="own-group" type="text" class="input-mono" x-model="form.expected_group" spellcheck="false" autocomplete="off" placeholder="www-data">
    </div>
    <button type="submit" class="btn-primary" :disabled="phase === 'loading'"><?= $icon('users') ?><span x-text="phase === 'loading' ? 'Menganalisis...' : 'Analisis'"></span></button>
  </form>

  <template x-if="phase === 'loading'">
    <div class="grid gap-4 lg:grid-cols-2"><div class="panel space-y-3 p-4"><div class="skeleton h-4 w-40"></div><div class="skeleton h-32 w-full"></div></div><div class="panel space-y-3 p-4"><div class="skeleton h-4 w-40"></div><div class="skeleton h-32 w-full"></div></div></div>
  </template>
  <template x-if="phase === 'error'">
    <div class="panel flex flex-col items-center gap-2 px-4 py-10 text-center" role="alert">
      <svg class="icon-lg text-danger-700" aria-hidden="true"><use :href="FM.icons + '#circle-alert'"></use></svg>
      <p class="font-medium text-ink">Analisis gagal</p>
      <p class="max-w-md text-sm text-muted" x-text="errorMessage"></p>
      <button type="button" class="btn-secondary mt-2" @click="analyze()">Coba Lagi</button>
    </div>
  </template>
  <template x-if="phase === 'idle'">
    <div class="panel flex flex-col items-center gap-2 px-4 py-10 text-center">
      <svg class="icon-lg text-muted" aria-hidden="true"><use :href="FM.icons + '#users'"></use></svg>
      <p class="font-medium text-ink">Pilih folder yang akan dianalisis</p>
      <p class="max-w-md text-sm text-muted">Isi pemilik atau grup yang diharapkan untuk menemukan item yang menyimpang.</p>
    </div>
  </template>

  <template x-if="phase === 'content'">
    <div class="flex flex-col gap-4">
      <p class="text-sm text-muted"><span class="font-mono text-ink" x-text="FM.formatNumber(data.scanned)"></span> entri diperiksa di <span class="font-mono text-ink" x-text="data.path"></span><span x-show="data.truncated" class="text-warning-700">, hasil terpotong karena melebihi batas pemindaian</span>.</p>
      <template x-for="w in data.warnings" :key="w"><p class="rounded-control border border-warning-600/40 bg-warning-50 p-3 text-sm text-warning-700" x-text="w"></p></template>

      <div class="grid gap-4 xl:grid-cols-2">
        <template x-for="block in [{ title: 'Pemilik', rows: data.owners, id: 'UID' }, { title: 'Grup', rows: data.groups, id: 'GID' }]" :key="block.title">
          <section class="panel min-w-0">
            <h2 class="panel-title border-b border-line px-4 py-3" x-text="'Sebaran ' + block.title.toLowerCase()"></h2>
            <div class="table-scroll">
              <table class="data-table">
                <thead><tr><th scope="col" class="w-12 text-right">No</th><th scope="col" x-text="block.title"></th><th scope="col" class="text-right">Berkas</th><th scope="col" class="text-right">Folder</th><th scope="col" class="text-right">Ukuran</th><th scope="col" class="w-1/3">Porsi</th></tr></thead>
                <tbody>
                  <template x-for="(row, i) in block.rows" :key="row.name">
                    <tr>
                      <td class="text-right font-mono text-xs text-muted" x-text="i + 1"></td>
                      <td class="font-mono text-xs"><span class="text-ink" x-text="row.name"></span> <span class="text-muted" x-text="block.id + ' ' + row.id"></span></td>
                      <td class="text-right font-mono text-xs" x-text="FM.formatNumber(row.files)"></td>
                      <td class="text-right font-mono text-xs" x-text="FM.formatNumber(row.dirs)"></td>
                      <td class="whitespace-nowrap text-right font-mono text-xs" x-text="FM.formatBytes(row.bytes)"></td>
                      <td><div class="flex items-center gap-2"><div class="h-2 flex-1 overflow-hidden rounded-chip bg-surface-2"><div class="h-full bg-primary-600" :style="`width: ${share(row)}%`"></div></div><span class="w-10 text-right font-mono text-xs" x-text="share(row) + '%'"></span></div></td>
                    </tr>
                  </template>
                </tbody>
              </table>
            </div>
          </section>
        </template>
      </div>

      <template x-for="block in issueBlocks()" :key="block.key">
        <section class="panel min-w-0">
          <div class="flex flex-wrap items-baseline gap-2 border-b border-line px-4 py-3">
            <h2 class="panel-title" x-text="block.title"></h2>
            <span :class="block.count ? 'chip-warning' : 'chip-success'" x-text="FM.formatNumber(block.count) + ' item'"></span>
          </div>
          <p class="px-4 py-6 text-sm text-muted" x-show="!block.count" x-text="block.empty"></p>
          <div class="table-scroll" x-show="block.count">
            <table class="data-table">
              <thead><tr><th scope="col" class="w-12 text-right">No</th><th scope="col">Path</th><th scope="col">Pemilik:Grup</th><th scope="col">Izin</th></tr></thead>
              <tbody>
                <template x-for="(row, i) in block.items" :key="row.path">
                  <tr>
                    <td class="text-right font-mono text-xs text-muted" x-text="i + 1"></td>
                    <td class="break-all font-mono text-xs" x-text="row.path"></td>
                    <td class="whitespace-nowrap font-mono text-xs" x-text="row.owner + ':' + row.group + ' (' + row.uid + ':' + row.gid + ')'"></td>
                    <td class="font-mono text-xs" x-text="row.octal"></td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
          <p class="border-t border-line px-4 py-2 text-xs text-muted" x-show="block.count > block.items.length" x-text="'Menampilkan ' + block.items.length + ' item pertama dari ' + FM.formatNumber(block.count) + '.'"></p>
        </section>
      </template>
    </div>
  </template>
</div>
