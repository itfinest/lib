<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data="policiesPage" class="flex flex-col gap-4">
  <div class="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
    <div>
      <h1 class="font-display text-lg font-semibold">Kebijakan Izin</h1>
      <p class="mt-1 text-sm text-muted">Aturan izin yang diperiksa setiap audit. Pelanggaran dapat diperbaiki otomatis dari halaman Audit Izin.</p>
    </div>
    <button type="button" class="btn-primary" @click="openForm(null)"><?= $icon('plus') ?>Tambah Kebijakan</button>
  </div>

  <section class="panel min-w-0">
    <div class="grid grid-cols-1 items-end gap-3 border-b border-line p-3 sm:grid-cols-[14rem_auto]">
      <div>
        <label for="pol-status" class="field-label">Status</label>
        <select id="pol-status" class="input" x-model="state.status" @change="setFilter()">
          <option value="">Semua status</option>
          <option value="active">Aktif</option>
          <option value="inactive">Nonaktif</option>
        </select>
      </div>
      <div><button type="button" class="btn-secondary" @click="resetFilters()" :disabled="!isFiltered()">Reset Filter</button></div>
    </div>
    <?php $searchLabel = 'Cari nama, pola, atau pemilik'; $searchId = 'policy-search'; require APP_ROOT . '/views/partials/list-toolbar.php'; ?>
    <div class="table-scroll hidden md:block" x-show="phase === 'loading' || phase === 'content'">
      <table class="data-table">
        <thead>
          <tr>
            <th scope="col" class="w-12 text-right">No</th>
            <th scope="col" :aria-sort="ariaSort('name')"><button type="button" class="sort-btn" @click="sortBy('name')">Nama<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('name')"></use></svg></button></th>
            <th scope="col" :aria-sort="ariaSort('pattern')"><button type="button" class="sort-btn" @click="sortBy('pattern')">Pola<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('pattern')"></use></svg></button></th>
            <th scope="col">Syarat</th>
            <th scope="col" :aria-sort="ariaSort('severity')"><button type="button" class="sort-btn" @click="sortBy('severity')">Tingkat<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('severity')"></use></svg></button></th>
            <th scope="col">Status</th>
            <th scope="col" class="text-right">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $cols = 7; require APP_ROOT . '/views/partials/skeleton-rows.php'; ?>
          <template x-if="phase === 'content'">
            <template x-for="(item, index) in items" :key="item.id">
              <tr>
                <td class="text-right font-mono text-xs text-muted" x-text="rowNumber(index)"></td>
                <td class="max-w-[20rem] font-medium text-ink" x-text="item.name"></td>
                <td class="font-mono text-xs"><span x-text="item.pattern"></span><span class="block font-body text-muted" x-text="{ any: 'Berkas dan folder', file: 'Berkas saja', dir: 'Folder saja' }[item.applies_to]"></span></td>
                <td class="font-mono text-xs" x-text="rules(item)"></td>
                <td><span :class="FM.SEVERITY[item.severity].chip" x-text="FM.SEVERITY[item.severity].label"></span></td>
                <td>
                  <button type="button" role="switch" class="inline-flex min-h-8 items-center gap-2 rounded-chip px-1 text-xs hover:bg-surface-2" :aria-checked="item.enabled ? 'true' : 'false'" @click="toggle(item, $event)" :disabled="toggling === item.id" :aria-label="(item.enabled ? 'Nonaktifkan ' : 'Aktifkan ') + item.name">
                    <span class="relative h-4 w-7 rounded-full transition-colors duration-150" :class="item.enabled ? 'bg-primary-600' : 'bg-[#8B93A1]'"><span class="absolute top-0.5 h-3 w-3 rounded-full bg-surface transition-transform duration-150" :class="item.enabled ? 'translate-x-3.5' : 'translate-x-0.5'"></span></span>
                    <span x-text="toggling === item.id ? 'Memproses...' : (item.enabled ? 'Aktif' : 'Nonaktif')"></span>
                  </button>
                </td>
                <td class="whitespace-nowrap text-right">
                  <button type="button" class="btn-ghost" @click="openForm(item)">Ubah</button>
                  <button type="button" class="btn-ghost text-danger-700 hover:bg-danger-50" @click="askDelete(item)">Hapus</button>
                </td>
              </tr>
            </template>
          </template>
        </tbody>
      </table>
    </div>
    <ul class="divide-y divide-line md:hidden" x-show="phase === 'loading' || phase === 'content'">
      <template x-if="phase === 'loading'"><template x-for="n in 4" :key="n"><li class="space-y-2 p-3"><span class="skeleton block h-4 w-2/3"></span><span class="skeleton block h-3 w-full"></span></li></template></template>
      <template x-if="phase === 'content'">
        <template x-for="(item, index) in items" :key="item.id">
          <li class="p-3">
            <div class="flex flex-wrap items-center gap-2"><span class="font-mono text-xs text-muted" x-text="rowNumber(index) + '.'"></span><span class="font-medium text-ink" x-text="item.name"></span><span :class="FM.SEVERITY[item.severity].chip" x-text="FM.SEVERITY[item.severity].label"></span><span :class="item.enabled ? 'chip-success' : 'chip-neutral'" x-text="item.enabled ? 'Aktif' : 'Nonaktif'"></span></div>
            <p class="mt-1 font-mono text-xs text-muted" x-text="item.pattern + ' · ' + rules(item)"></p>
            <div class="mt-2 flex flex-wrap gap-2">
              <button type="button" class="btn-secondary btn-sm" @click="toggle(item, $event)" :disabled="toggling === item.id" x-text="toggling === item.id ? 'Memproses...' : (item.enabled ? 'Nonaktifkan' : 'Aktifkan')"></button>
              <button type="button" class="btn-secondary btn-sm" @click="openForm(item)">Ubah</button>
              <button type="button" class="btn-danger-ghost btn-sm" @click="askDelete(item)">Hapus</button>
            </div>
          </li>
        </template>
      </template>
    </ul>
    <?php $emptyTitle = 'Belum ada kebijakan'; $emptyText = 'Tambahkan kebijakan, misalnya berkas .env maksimal 0640, agar audit dapat menandai pelanggarannya.'; $emptyAction = ['openForm(null)', 'Tambah Kebijakan']; require APP_ROOT . '/views/partials/list-states.php'; ?>
    <?php require APP_ROOT . '/views/partials/pager.php'; ?>
  </section>

  <div x-show="formOpen" x-cloak class="modal-backdrop" @mousedown.self.prevent x-transition:enter="modal-in" x-transition:leave="modal-out" @keydown.escape="closeForm()">
    <form class="modal sm:max-w-lg" role="dialog" aria-modal="true" aria-labelledby="policy-form-title" x-ref="formModal" @keydown.tab="FM.trapFocus($event, $refs.formModal)" @submit.prevent="save()">
      <div class="modal-head"><h2 id="policy-form-title" class="font-display text-sm font-semibold" x-text="form.id ? 'Ubah Kebijakan' : 'Tambah Kebijakan'"></h2></div>
      <div class="modal-body space-y-3">
        <div>
          <label for="k-name" class="field-label">Nama <span class="text-danger-700" aria-hidden="true">*</span></label>
          <input id="k-name" type="text" class="input" x-model="form.name" maxlength="120" required data-autofocus autocomplete="off" @input="errors.name = ''">
          <p class="field-error" x-show="errors.name" x-text="errors.name"></p>
        </div>
        <div class="grid gap-3 sm:grid-cols-[minmax(0,1fr)_10rem]">
          <div>
            <label for="k-pattern" class="field-label">Pola path <span class="text-danger-700" aria-hidden="true">*</span></label>
            <input id="k-pattern" type="text" class="input-mono" x-model="form.pattern" maxlength="300" required placeholder="*/storage/*" spellcheck="false" autocomplete="off" @input="errors.pattern = ''">
            <p class="field-error" x-show="errors.pattern" x-text="errors.pattern"></p>
          </div>
          <div>
            <label for="k-applies" class="field-label">Berlaku untuk</label>
            <select id="k-applies" class="input" x-model="form.applies_to">
              <option value="any">Berkas dan folder</option>
              <option value="file">Berkas saja</option>
              <option value="dir">Folder saja</option>
            </select>
          </div>
        </div>
        <p class="text-xs text-muted">Pola dicocokkan dengan path lengkap. Gunakan * untuk bagian apa pun, misalnya */.env atau /var/www/*/storage/*.</p>
        <div class="grid gap-3 sm:grid-cols-3">
          <div>
            <label for="k-max" class="field-label">Batas izin</label>
            <input id="k-max" type="text" inputmode="numeric" class="input-mono" maxlength="5" placeholder="0640" x-model="form.max_mode" @input="errors.max_mode = ''">
            <p class="field-error" x-show="errors.max_mode" x-text="errors.max_mode"></p>
          </div>
          <div>
            <label for="k-owner" class="field-label">Pemilik</label>
            <input id="k-owner" type="text" class="input-mono" placeholder="deploy" x-model="form.owner" autocomplete="off" spellcheck="false" @input="errors.owner = ''">
            <p class="field-error" x-show="errors.owner" x-text="errors.owner"></p>
          </div>
          <div>
            <label for="k-group" class="field-label">Grup</label>
            <input id="k-group" type="text" class="input-mono" placeholder="www-data" x-model="form.group" autocomplete="off" spellcheck="false" @input="errors.group = ''">
            <p class="field-error" x-show="errors.group" x-text="errors.group"></p>
          </div>
        </div>
        <p class="text-xs text-muted">Batas izin berarti izin tidak boleh lebih longgar dari nilai ini. Kosongkan syarat yang tidak diperiksa.</p>
        <div class="grid gap-3 sm:grid-cols-2">
          <div>
            <label for="k-sev" class="field-label">Tingkat</label>
            <select id="k-sev" class="input" x-model="form.severity">
              <option value="low">Rendah</option>
              <option value="medium">Sedang</option>
              <option value="high">Tinggi</option>
              <option value="critical">Kritis</option>
            </select>
          </div>
          <label class="flex min-h-control items-center gap-2 self-end text-sm"><input type="checkbox" class="check" x-model="form.enabled">Aktif</label>
        </div>
        <?php require APP_ROOT . '/views/partials/discard-confirm.php'; ?>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeForm()" :disabled="busy">Batal</button>
        <button type="submit" class="btn-primary" :disabled="busy" x-text="busy ? 'Menyimpan...' : 'Simpan'"></button>
      </div>
    </form>
  </div>

  <div x-show="deleting" x-cloak class="modal-backdrop" @mousedown.self.prevent x-transition:enter="modal-in" x-transition:leave="modal-out" @keydown.escape="!busy && (deleting = null)">
    <div class="modal sm:max-w-md" role="dialog" aria-modal="true" aria-labelledby="policy-del-title" x-ref="delModal" @keydown.tab="FM.trapFocus($event, $refs.delModal)">
      <div class="modal-head"><h2 id="policy-del-title" class="font-display text-sm font-semibold">Hapus kebijakan?</h2></div>
      <div class="modal-body text-sm"><p>Kebijakan "<span class="font-semibold" x-text="deleting ? deleting.name : ''"></span>" akan dihapus dan tidak lagi diperiksa pada audit berikutnya.</p></div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="deleting = null" :disabled="busy" data-autofocus>Batal</button>
        <button type="button" class="btn-danger" @click="confirmDelete()" :disabled="busy" x-text="busy ? 'Menghapus...' : 'Hapus Kebijakan'"></button>
      </div>
    </div>
  </div>
</div>
