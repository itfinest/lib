<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data="editor" class="flex flex-col gap-3" @keydown.window="shortcut($event)">
  <div class="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
    <div class="min-w-0">
      <a :href="backUrl()" class="inline-flex min-h-11 items-center gap-1 text-sm text-muted hover:text-ink lg:min-h-8"><?= $icon('chevron-left') ?>Kembali ke folder</a>
      <h1 class="mt-1 flex items-center gap-2 font-display text-lg font-semibold">
        <span class="truncate" x-text="name() || 'Editor Teks'"></span>
        <span class="chip-warning" x-show="dirty" x-cloak>Belum disimpan</span>
      </h1>
      <p class="break-all font-mono text-xs text-muted" x-text="path"></p>
    </div>
    <div class="flex flex-wrap items-center gap-2">
      <label class="relative flex items-center" x-show="phase === 'ready'" x-cloak title="Tema editor">
        <span class="sr-only">Tema editor</span>
        <svg class="icon pointer-events-none absolute left-3 text-muted" aria-hidden="true"><use :href="FM.icons + '#palette'"></use></svg>
        <select class="input w-auto pl-9 max-sm:h-8 max-sm:text-xs" @change="setPref('theme', $event.target.value)">
          <template x-for="group in themes" :key="group.group">
            <optgroup :label="group.group">
              <template x-for="theme in group.items" :key="theme[0]">
                <option :value="theme[0]" x-text="theme[1]" :selected="theme[0] === prefs.theme"></option>
              </template>
            </optgroup>
          </template>
        </select>
      </label>
      <button type="button" class="btn-secondary btn-sm" @click="openBar('find')" x-show="phase === 'ready'" x-cloak title="Cari (Ctrl+F)"><?= $icon('search') ?>Cari</button>
      <a class="btn-secondary btn-sm" :href="downloadUrl()" x-show="phase === 'ready' || phase === 'readonly'"><?= $icon('download') ?>Unduh</a>
      <button type="button" class="btn-secondary btn-sm" @click="reloadContent()" :disabled="phase === 'loading' || saving"><?= $icon('refresh-cw') ?>Muat Ulang</button>
      <button type="button" class="btn-primary btn-sm" @click="save()" :disabled="phase !== 'ready' || saving || !dirty" title="Simpan (Ctrl+S)">
        <?= $icon('save') ?><span x-text="saving ? 'Menyimpan...' : 'Simpan'"></span>
      </button>
    </div>
  </div>

  <div class="flex flex-wrap gap-x-4 gap-y-1 font-mono text-xs text-muted" x-show="entry" x-cloak>
    <span x-text="entry ? entry.octal + ' ' + entry.perms : ''"></span>
    <span x-text="entry ? entry.owner + ':' + entry.group : ''"></span>
    <span x-text="entry ? FM.formatBytes(entry.size) : ''"></span>
    <span x-show="phase === 'ready'" x-text="FM.formatNumber(lines) + ' baris'"></span>
  </div>

  <template x-if="conflict">
    <div class="flex flex-col gap-3 rounded-control border border-warning-600/40 bg-warning-50 p-3 text-sm text-warning-700 sm:flex-row sm:items-center" role="alert">
      <p class="flex-1" x-text="conflict"></p>
      <button type="button" class="btn-secondary" @click="copyToClipboard()">Salin Isi Saya</button>
      <button type="button" class="btn-secondary" @click="reloadContent(true)">Muat Versi Server</button>
    </div>
  </template>

  <div class="panel editor-panel overflow-hidden" :class="phase === 'ready' || phase === 'loading' ? 'flex h-[calc(100vh-17.5rem)] min-h-[22rem] flex-col' : ''">
    <template x-if="phase === 'loading'">
      <div class="space-y-2 p-4" aria-busy="true" aria-label="Memuat isi berkas">
        <template x-for="n in 14" :key="n"><div class="skeleton h-4" :style="`width: ${30 + ((n * 37) % 60)}%`"></div></template>
      </div>
    </template>
    <template x-if="phase === 'error'">
      <div class="flex flex-col items-center gap-2 px-4 py-12 text-center" role="alert">
        <svg class="icon-lg text-danger-700" aria-hidden="true"><use :href="FM.icons + '#circle-alert'"></use></svg>
        <p class="font-medium text-ink">Berkas gagal dibuka</p>
        <p class="max-w-md text-sm text-muted" x-text="errorMessage"></p>
        <button type="button" class="btn-secondary mt-2" @click="reloadContent(true)">Muat Ulang</button>
      </div>
    </template>
    <template x-if="phase === 'readonly'">
      <div class="flex flex-col items-center gap-2 px-4 py-12 text-center">
        <svg class="icon-lg text-muted" aria-hidden="true"><use :href="FM.icons + '#lock'"></use></svg>
        <p class="font-medium text-ink">Berkas tidak dapat diedit di sini</p>
        <p class="max-w-md text-sm text-muted" x-text="reason"></p>
      </div>
    </template>

    <div class="flex flex-col gap-2 border-b border-line bg-surface-2 p-2" role="search" aria-label="Cari di berkas"
         x-show="phase === 'ready' && (bar === 'find' || bar === 'replace')" x-cloak @keydown.escape.prevent.stop="closeBar()">
      <div class="flex flex-wrap items-center gap-1.5">
        <button type="button" class="btn-ghost btn-icon" @click="toggleReplace()" :aria-expanded="(bar === 'replace').toString()" aria-controls="replace-row"
                :aria-label="bar === 'replace' ? 'Sembunyikan kolom ganti' : 'Tampilkan kolom ganti'" :title="bar === 'replace' ? 'Sembunyikan kolom ganti' : 'Ganti (Ctrl+H)'">
          <svg class="icon" aria-hidden="true"><use :href="FM.icons + (bar === 'replace' ? '#chevron-down' : '#chevron-right')"></use></svg>
        </button>
        <label for="find-input" class="sr-only">Cari</label>
        <input id="find-input" type="text" class="input-mono min-w-[10rem] flex-1" placeholder="Cari" x-ref="findInput" x-model="find.query"
               @input="findInputChanged()" @keydown.enter.prevent="findNext($event.shiftKey ? -1 : 1)"
               :aria-invalid="findError ? 'true' : 'false'" aria-describedby="find-status" autocomplete="off" spellcheck="false">
        <div class="flex items-center gap-0.5">
          <button type="button" class="btn-ghost btn-icon aria-pressed:bg-primary-100" :aria-pressed="find.caseSensitive.toString()" @click="toggleFindOption('caseSensitive')"
                  aria-label="Bedakan huruf besar dan kecil" title="Bedakan huruf besar dan kecil"><?= $icon('case-sensitive') ?></button>
          <button type="button" class="btn-ghost btn-icon aria-pressed:bg-primary-100" :aria-pressed="find.wholeWord.toString()" @click="toggleFindOption('wholeWord')"
                  aria-label="Cocokkan kata utuh" title="Cocokkan kata utuh"><?= $icon('whole-word') ?></button>
          <button type="button" class="btn-ghost btn-icon aria-pressed:bg-primary-100" :aria-pressed="find.regex.toString()" @click="toggleFindOption('regex')"
                  aria-label="Gunakan ekspresi reguler" title="Gunakan ekspresi reguler"><?= $icon('regex') ?></button>
        </div>
        <span id="find-status" class="min-w-[6rem] px-1 text-xs" :class="findError ? 'text-danger-700' : 'text-muted'" x-text="findStatus()" aria-live="polite"></span>
        <div class="flex items-center gap-0.5">
          <button type="button" class="btn-ghost btn-icon" @click="findNext(-1)" :disabled="!findTotal" aria-label="Kecocokan sebelumnya" title="Kecocokan sebelumnya (Shift+Enter)"><?= $icon('chevron-up') ?></button>
          <button type="button" class="btn-ghost btn-icon" @click="findNext(1)" :disabled="!findTotal" aria-label="Kecocokan berikutnya" title="Kecocokan berikutnya (Enter)"><?= $icon('chevron-down') ?></button>
          <button type="button" class="btn-ghost btn-icon" @click="closeBar()" aria-label="Tutup pencarian" title="Tutup pencarian (Esc)"><?= $icon('x') ?></button>
        </div>
      </div>
      <div id="replace-row" class="flex flex-wrap items-center gap-1.5 sm:pl-[calc(var(--control-h)+0.375rem)]" x-show="bar === 'replace'">
        <label for="replace-input" class="sr-only">Ganti dengan</label>
        <input id="replace-input" type="text" class="input-mono min-w-[10rem] flex-1" placeholder="Ganti dengan" x-ref="replaceInput" x-model="find.replacement"
               @keydown.enter.prevent="replaceOne()" autocomplete="off" spellcheck="false">
        <button type="button" class="btn-secondary" @click="replaceOne()" :disabled="!findTotal"><?= $icon('replace') ?>Ganti</button>
        <button type="button" class="btn-secondary" @click="replaceAll()" :disabled="!findTotal"><?= $icon('replace-all') ?>Ganti Semua</button>
      </div>
    </div>

    <form class="flex flex-wrap items-center gap-2 border-b border-line bg-surface-2 p-2" x-show="phase === 'ready' && bar === 'goto'" x-cloak
          @submit.prevent="goToLine()" @keydown.escape.prevent.stop="closeBar()">
      <label for="goto-input" class="text-sm text-body">Lompat ke baris</label>
      <input id="goto-input" type="text" inputmode="numeric" class="input-mono w-40" x-ref="gotoInput" x-model="gotoValue" @input="gotoError = ''"
             :placeholder="'1 sampai ' + lines" :aria-invalid="gotoError ? 'true' : 'false'" aria-describedby="goto-hint" autocomplete="off">
      <button type="submit" class="btn-secondary"><?= $icon('arrow-down-to-line') ?>Lompat</button>
      <button type="button" class="btn-ghost btn-icon" @click="closeBar()" aria-label="Tutup" title="Tutup (Esc)"><?= $icon('x') ?></button>
      <p id="goto-hint" class="w-full text-xs" :class="gotoError ? 'text-danger-700' : 'text-muted'" x-text="gotoError || 'Format: baris atau baris:kolom, misalnya 120:8.'"></p>
    </form>

    <div class="relative min-h-0 flex-1" x-ref="frame" x-show="phase === 'ready'" :style="`--editor-font: ${prefs.fontSize}px`">
      <div class="editor-host absolute inset-0" x-ignore></div>
    </div>

    <div class="flex flex-wrap items-center gap-x-1 border-t border-line bg-surface-2 px-1.5 text-xs text-muted" x-show="phase === 'ready'" x-cloak>
      <button type="button" class="status-item font-mono" @click="openBar('goto')" title="Lompat ke baris (Ctrl+G)" x-text="`Baris ${FM.formatNumber(cursor.line)}, Kolom ${FM.formatNumber(cursor.col)}`"></button>
      <span class="px-1.5" x-show="selectionText" x-text="selectionText"></span>
      <div class="ml-auto flex flex-wrap items-center gap-x-1">
        <select class="status-item" aria-label="Bahasa" title="Bahasa" @change="setLanguage($event.target.value)">
          <template x-for="item in languages" :key="item[0]">
            <option :value="item[0]" x-text="item[1]" :selected="item[0] === language"></option>
          </template>
        </select>
        <select class="status-item" aria-label="Indentasi" title="Indentasi" x-model="indent" @change="applyIndent()">
          <option value="spaces-2">Spasi: 2</option>
          <option value="spaces-4">Spasi: 4</option>
          <option value="spaces-8">Spasi: 8</option>
          <option value="tabs">Tab</option>
        </select>
        <select class="status-item" aria-label="Akhir baris" title="Akhir baris" x-model="eol">
          <option value="LF">LF</option>
          <option value="CRLF">CRLF</option>
        </select>
        <span class="px-1.5" title="Enkode">UTF-8</span>
        <select class="status-item" aria-label="Ukuran huruf" title="Ukuran huruf" @change="setPref('fontSize', Number($event.target.value))">
          <template x-for="size in fontSizes" :key="size">
            <option :value="size" x-text="size + ' px'" :selected="size === prefs.fontSize"></option>
          </template>
        </select>
        <label class="status-item gap-1.5"><input type="checkbox" class="check" :checked="prefs.wrap" @change="setPref('wrap', $event.target.checked)">Bungkus baris</label>
        <label class="status-item gap-1.5"><input type="checkbox" class="check" :checked="prefs.tabIndent" @change="setPref('tabIndent', $event.target.checked)">Tab untuk indentasi</label>
        <label class="status-item gap-1.5" title="Tampilkan saran kode saat mengetik. Ctrl+Space tetap menampilkan saran."><input type="checkbox" class="check" :checked="prefs.autocomplete" @change="setPref('autocomplete', $event.target.checked)">Saran otomatis</label>
        <button type="button" class="status-item gap-1.5" @click="openShortcuts()"><?= $icon('keyboard') ?>Pintasan</button>
      </div>
    </div>
  </div>

  <div x-show="shortcutsOpen" x-cloak class="modal-backdrop" @mousedown.self.prevent x-transition:enter="modal-in" x-transition:leave="modal-out" @keydown.escape="closeShortcuts()">
    <div class="modal sm:max-w-lg" role="dialog" aria-modal="true" aria-labelledby="shortcuts-title" x-ref="shortcutsModal" @keydown.tab="FM.trapFocus($event, $refs.shortcutsModal)">
      <div class="modal-head">
        <h2 id="shortcuts-title" class="font-display text-sm font-semibold">Pintasan Keyboard</h2>
        <button type="button" class="btn-ghost btn-icon -my-1" @click="closeShortcuts()" aria-label="Tutup"><?= $icon('x') ?></button>
      </div>
      <div class="modal-body">
        <?php
        $shortcuts = [
            'Berkas dan pencarian' => [
                ['Ctrl+S', 'Simpan berkas'],
                ['Ctrl+F', 'Cari'],
                ['Ctrl+H', 'Cari dan ganti'],
                ['Enter / Shift+Enter', 'Kecocokan berikutnya / sebelumnya'],
                ['Ctrl+G', 'Lompat ke baris'],
                ['Ctrl+D', 'Pilih kemunculan berikutnya dari kata yang sama'],
            ],
            'Penyuntingan' => [
                ['Tab / Shift+Tab', 'Tambah / kurangi indentasi'],
                ['Ctrl+/', 'Jadikan komentar atau batalkan'],
                ['Alt+↑ / Alt+↓', 'Pindahkan baris ke atas / bawah'],
                ['Shift+Alt+↓ atau Ctrl+Shift+D', 'Gandakan baris'],
                ['Ctrl+Shift+K', 'Hapus baris'],
                ['Ctrl+Enter', 'Sisipkan baris baru di bawah'],
                ['Ctrl+J', 'Gabungkan baris'],
                ['Ctrl+Z / Ctrl+Y', 'Urungkan / ulangi'],
            ],
            'Saran kode' => [
                ['Ctrl+Space', 'Tampilkan saran kode'],
                ['↑ / ↓', 'Pilih saran'],
                ['Enter atau Tab', 'Sisipkan saran yang dipilih'],
                ['Esc', 'Tutup daftar saran'],
            ],
            'Kursor dan blok' => [
                ['Ctrl+Klik', 'Tambah kursor'],
                ['Ctrl+Alt+↑ / Ctrl+Alt+↓', 'Tambah kursor di baris atas / bawah'],
                ['Ctrl+L', 'Pilih baris'],
                ['Ctrl+M', 'Lompat ke pasangan kurung'],
                ['Ctrl+Q', 'Lipat atau buka blok'],
                ['Esc', 'Kembali ke satu kursor'],
            ],
        ];
        ?>
        <?php foreach ($shortcuts as $group => $rows): ?>
          <h3 class="mb-1.5 mt-4 text-xs font-medium text-muted first:mt-0"><?= $e($group) ?></h3>
          <dl class="divide-y divide-line text-sm">
            <?php foreach ($rows as $row): ?>
              <div class="flex items-start justify-between gap-4 py-1.5">
                <dt class="text-body"><?= $e($row[1]) ?></dt>
                <dd class="shrink-0 text-right"><kbd class="rounded-chip border border-line bg-surface-2 px-1.5 py-0.5 text-xs text-ink"><?= $e($row[0]) ?></kbd></dd>
              </div>
            <?php endforeach; ?>
          </dl>
        <?php endforeach; ?>
        <p class="mt-4 text-xs text-muted">Di macOS, sebagian besar pintasan memakai Cmd sebagai pengganti Ctrl.</p>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="closeShortcuts()" data-autofocus>Tutup</button>
      </div>
    </div>
  </div>
</div>
