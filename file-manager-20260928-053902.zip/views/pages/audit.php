<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data="auditPage" class="flex flex-col gap-4">
  <div>
    <h1 class="font-display text-lg font-semibold">Audit Izin</h1>
    <p class="mt-1 text-sm text-muted">Memindai folder untuk izin berbahaya, symlink bermasalah, pemilik tak dikenal, dan pelanggaran kebijakan.</p>
  </div>

  <form class="panel grid grid-cols-1 items-end gap-3 p-3 md:grid-cols-[minmax(0,1fr)_auto_auto]" @submit.prevent="run()">
    <div>
      <label for="audit-path" class="field-label">Folder yang diaudit</label>
      <input id="audit-path" type="text" class="input-mono" x-model="runPath" required spellcheck="false" autocomplete="off" placeholder="/var/www/html" @input="runError = ''">
      <p class="field-error" x-show="runError" x-text="runError"></p>
    </div>
    <label class="flex min-h-control items-center gap-2 text-sm"><input type="checkbox" class="check" x-model="usePolicies">Terapkan kebijakan aktif</label>
    <button type="submit" class="btn-primary" :disabled="running"><?= $icon('shield-alert') ?><span x-text="running ? 'Mengaudit...' : 'Jalankan Audit'"></span></button>
  </form>

  <template x-if="!runs.length && !runsLoading">
    <div class="panel flex flex-col items-center gap-2 px-4 py-12 text-center">
      <svg class="icon-lg text-muted" aria-hidden="true"><use :href="FM.icons + '#shield'"></use></svg>
      <p class="font-medium text-ink">Belum ada hasil audit</p>
      <p class="max-w-md text-sm text-muted">Isi folder yang ingin diperiksa, lalu pilih Jalankan Audit. Hasil setiap audit disimpan untuk diekspor dan diperbaiki.</p>
    </div>
  </template>

  <template x-if="runs.length">
    <div class="flex flex-col gap-4">
      <div class="grid grid-cols-1 items-end gap-3 sm:grid-cols-[minmax(0,1fr)_auto]">
        <div>
          <label for="audit-run" class="field-label">Hasil audit</label>
          <select id="audit-run" class="input" x-model="state.id" @change="setFilter()">
            <template x-for="r in runs" :key="r.id"><option :value="r.id" x-text="FM.formatDate(r.created_at) + ' · ' + r.path + ' · ' + FM.formatNumber(r.total) + ' temuan'"></option></template>
          </select>
        </div>
        <div class="flex flex-wrap gap-2">
          <a class="btn-secondary btn-sm" :href="exportUrl('csv')"><?= $icon('download') ?>Ekspor CSV</a>
          <a class="btn-secondary btn-sm" :href="exportUrl('json')"><?= $icon('download') ?>Ekspor JSON</a>
          <button type="button" class="btn-secondary btn-sm" @click="openFix()" :disabled="!fixableRules().length"><?= $icon('shield-check') ?>Perbaiki Otomatis</button>
        </div>
      </div>

      <div class="grid grid-cols-2 gap-px overflow-hidden rounded-card border border-line bg-line sm:grid-cols-5" data-kpi-row>
        <template x-for="(k, i) in kpis()" :key="k.key">
          <div class="min-w-0 bg-surface p-4" data-widget data-kpi :class="i === 4 ? 'col-span-2 sm:col-span-1' : ''">
            <p class="text-xs font-medium text-muted" x-text="k.label"></p>
            <p class="mt-2 font-mono text-2xl font-semibold" :class="k.tone" x-text="meta ? FM.formatNumber(k.value) : '-'"></p>
            <p class="mt-1 truncate text-xs text-muted" data-support x-show="k.caption" x-text="k.caption" :title="k.caption"></p>
          </div>
        </template>
      </div>

      <section class="panel min-w-0" aria-label="Temuan audit">
        <div class="grid grid-cols-1 items-end gap-3 border-b border-line p-3 sm:grid-cols-[12rem_minmax(0,20rem)_auto]">
          <div>
            <label for="audit-severity" class="field-label">Tingkat</label>
            <select id="audit-severity" class="input" x-model="state.severity" @change="setFilter()">
              <option value="">Semua tingkat</option>
              <option value="critical">Kritis</option>
              <option value="high">Tinggi</option>
              <option value="medium">Sedang</option>
              <option value="low">Rendah</option>
            </select>
          </div>
          <div>
            <label for="audit-rule" class="field-label">Jenis temuan</label>
            <select id="audit-rule" class="input" x-model="state.rule" @change="setFilter()">
              <option value="">Semua jenis</option>
              <template x-for="r in rulesInRun()" :key="r.id"><option :value="r.id" x-text="r.label + ' (' + r.count + ')'"></option></template>
            </select>
          </div>
          <div><button type="button" class="btn-secondary" @click="resetFilters()" :disabled="!isFiltered()">Reset Filter</button></div>
        </div>
        <?php $searchLabel = 'Cari path, temuan, atau pemilik'; $searchId = 'audit-search'; require APP_ROOT . '/views/partials/list-toolbar.php'; ?>
        <div x-show="meta && (meta.truncated || meta.warnings.length)" class="space-y-1 border-b border-line bg-warning-50 px-3 py-2 text-sm text-warning-700">
          <p x-show="meta && meta.truncated">Folder berisi lebih banyak entri dari batas pemindaian, sehingga hanya sebagian yang diperiksa.</p>
          <template x-for="w in (meta ? meta.warnings : [])" :key="w"><p x-text="w"></p></template>
        </div>

        <div class="table-scroll hidden md:block" x-show="phase === 'loading' || phase === 'content'">
          <table class="data-table">
            <thead>
              <tr>
                <th scope="col" class="w-12 text-right">No</th>
                <th scope="col" :aria-sort="ariaSort('severity_rank')"><button type="button" class="sort-btn" @click="sortBy('severity_rank')">Tingkat<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('severity_rank')"></use></svg></button></th>
                <th scope="col" :aria-sort="ariaSort('label')"><button type="button" class="sort-btn" @click="sortBy('label')">Temuan<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('label')"></use></svg></button></th>
                <th scope="col" :aria-sort="ariaSort('path')"><button type="button" class="sort-btn" @click="sortBy('path')">Path<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('path')"></use></svg></button></th>
                <th scope="col" :aria-sort="ariaSort('octal')"><button type="button" class="sort-btn" @click="sortBy('octal')">Izin<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('octal')"></use></svg></button></th>
                <th scope="col" :aria-sort="ariaSort('owner')"><button type="button" class="sort-btn" @click="sortBy('owner')">Pemilik<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('owner')"></use></svg></button></th>
              </tr>
            </thead>
            <tbody>
              <?php $cols = 6; require APP_ROOT . '/views/partials/skeleton-rows.php'; ?>
              <template x-if="phase === 'content'">
                <template x-for="(f, index) in items" :key="f.rule + f.path">
                  <tr>
                    <td class="text-right font-mono text-xs text-muted" x-text="rowNumber(index)"></td>
                    <td><span :class="FM.SEVERITY[f.severity].chip" x-text="FM.SEVERITY[f.severity].label"></span></td>
                    <td class="max-w-[18rem]"><p class="font-medium text-ink" x-text="f.label"></p><p class="text-xs text-muted" x-text="f.detail"></p></td>
                    <td class="max-w-[24rem] break-all font-mono text-xs"><a class="hover:underline" :href="'?r=explorer&path=' + encodeURIComponent(f.type === 'dir' ? f.path : f.path.slice(0, f.path.lastIndexOf('/')) || '/')" x-text="f.path"></a><span class="block text-muted" x-show="f.link" x-text="'→ ' + f.link"></span></td>
                    <td class="whitespace-nowrap font-mono text-xs"><span class="font-semibold text-ink" x-text="f.octal"></span> <span class="text-muted" x-text="f.perms"></span></td>
                    <td class="whitespace-nowrap font-mono text-xs" x-text="f.owner + ':' + f.group"></td>
                  </tr>
                </template>
              </template>
            </tbody>
          </table>
        </div>
        <ul class="divide-y divide-line md:hidden" x-show="phase === 'loading' || phase === 'content'">
          <template x-if="phase === 'loading'"><template x-for="n in 5" :key="n"><li class="space-y-2 p-3"><span class="skeleton block h-4 w-2/3"></span><span class="skeleton block h-3 w-full"></span></li></template></template>
          <template x-if="phase === 'content'">
            <template x-for="(f, index) in items" :key="f.rule + f.path">
              <li class="p-3">
                <div class="flex items-center gap-2"><span class="font-mono text-xs text-muted" x-text="rowNumber(index) + '.'"></span><span :class="FM.SEVERITY[f.severity].chip" x-text="FM.SEVERITY[f.severity].label"></span><span class="font-medium text-ink" x-text="f.label"></span></div>
                <p class="mt-1 break-all font-mono text-xs" x-text="f.path"></p>
                <p class="font-mono text-xs text-muted" x-text="f.octal + ' ' + f.perms + ' · ' + f.owner + ':' + f.group"></p>
              </li>
            </template>
          </template>
        </ul>
        <?php $emptyTitle = 'Tidak ada temuan'; $emptyText = 'Audit ini tidak menemukan izin berbahaya atau pelanggaran kebijakan.'; require APP_ROOT . '/views/partials/list-states.php'; ?>
        <?php require APP_ROOT . '/views/partials/pager.php'; ?>
      </section>
    </div>
  </template>

  <div x-show="fixOpen" x-cloak class="modal-backdrop" @mousedown.self.prevent x-transition:enter="modal-in" x-transition:leave="modal-out" @keydown.escape="fixOpen = false">
    <form class="modal sm:max-w-lg" role="dialog" aria-modal="true" aria-labelledby="fix-title" x-ref="modal" @keydown.tab="FM.trapFocus($event, $refs.modal)" @submit.prevent="submitFix()">
      <div class="modal-head"><h2 id="fix-title" class="font-display text-sm font-semibold">Perbaiki Otomatis</h2></div>
      <div class="modal-body space-y-3 text-sm">
        <p>Pilih jenis temuan yang diperbaiki. Setiap entri diperiksa ulang terhadap kondisi saat ini sebelum diubah, dan snapshot dibuat otomatis.</p>
        <fieldset class="space-y-1">
          <legend class="sr-only">Jenis temuan</legend>
          <template x-for="r in fixableRules()" :key="r.id">
            <label class="flex items-start gap-2 rounded-control border border-line p-2">
              <input type="checkbox" class="check mt-0.5" :value="r.id" x-model="fixRules">
              <span><span class="font-medium text-ink" x-text="r.label + ' (' + r.count + ')'"></span><span class="block text-xs text-muted" x-text="r.fix ? 'Perbaikan: chmod ' + r.fix : 'Perbaikan mengikuti batas izin, pemilik, dan grup pada kebijakan'"></span></span>
            </label>
          </template>
        </fieldset>
        <p class="text-xs text-muted">Setuid, setgid, pemilik tak dikenal, dan symlink tidak diperbaiki otomatis karena membutuhkan keputusan manual.</p>
        <p class="field-error" x-show="fixError" x-text="fixError"></p>
      </div>
      <div class="modal-foot">
        <button type="button" class="btn-secondary" @click="fixOpen = false">Batal</button>
        <button type="submit" class="btn-primary">Lanjut ke Pratinjau</button>
      </div>
    </form>
  </div>
</div>
