<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data="webserverPage" class="flex flex-col gap-4">
  <div>
    <h1 class="font-display text-lg font-semibold">Pemeriksaan Web Server</h1>
    <p class="mt-1 text-sm text-muted">Mendeteksi akun Apache, Nginx, dan PHP-FPM, lalu memeriksa apakah folder situs dapat dibaca akun tersebut tanpa memberi akses tulis berlebih.</p>
  </div>

  <section class="panel min-w-0" aria-labelledby="ws-detect-title">
    <div class="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
      <h2 id="ws-detect-title" class="panel-title">Akun terdeteksi</h2>
      <button type="button" class="btn-secondary btn-icon" @click="detect()" aria-label="Deteksi ulang" title="Deteksi ulang"><?= $icon('refresh-cw') ?></button>
    </div>
    <template x-if="detectPhase === 'loading'"><div class="space-y-2 p-4"><div class="skeleton h-4 w-1/2"></div><div class="skeleton h-4 w-2/3"></div><div class="skeleton h-4 w-1/3"></div></div></template>
    <template x-if="detectPhase === 'error'"><p class="p-4 text-sm text-danger-700" role="alert" x-text="detectError"></p></template>
    <template x-if="detectPhase === 'content'">
      <div class="grid gap-0 divide-y divide-line lg:grid-cols-2 lg:divide-x lg:divide-y-0">
        <div class="p-4">
          <h3 class="field-label">Konfigurasi</h3>
          <p class="text-sm text-muted" x-show="!info.config.length">Tidak ditemukan konfigurasi Apache, Nginx, atau PHP-FPM di lokasi standar.</p>
          <ul class="space-y-2 text-sm">
            <template x-for="row in info.config" :key="row.service + row.source">
              <li><p class="font-medium text-ink" x-text="row.service"></p><p class="font-mono text-xs text-muted" x-text="row.user + (row.group ? ':' + row.group : '') + ' · ' + row.source"></p></li>
            </template>
          </ul>
          <h3 class="field-label mt-4">Proses berjalan</h3>
          <p class="text-sm text-muted" x-show="!info.processes.length">Tidak ada proses web server yang terdeteksi.</p>
          <ul class="flex flex-wrap gap-1"><template x-for="p in info.processes" :key="p.process + p.user"><li class="chip-neutral font-mono" x-text="p.process + ' (' + p.user + ', ' + p.count + ')'"></li></template></ul>
        </div>
        <div class="p-4">
          <h3 class="field-label">Akun dan grup</h3>
          <ul class="space-y-2 text-sm">
            <template x-for="a in info.accounts" :key="a.name"><li><span class="font-mono font-medium text-ink" x-text="a.name + ' (UID ' + a.uid + ')'"></span><span class="block font-mono text-xs text-muted" x-text="'Grup: ' + a.groups.join(', ')"></span></li></template>
          </ul>
          <p class="mt-3 text-xs text-muted" x-show="info.php_user" x-text="'Aplikasi ini berjalan sebagai ' + (info.php_user ? info.php_user.name : '-') + (info.sudo ? ' dengan sudo aktif.' : '.')"></p>
          <template x-if="info.sockets.length">
            <div class="mt-4">
              <h3 class="field-label">Socket PHP-FPM</h3>
              <ul class="space-y-2 text-sm">
                <template x-for="s in info.sockets" :key="s.socket">
                  <li>
                    <p class="break-all font-mono text-xs text-ink" x-text="s.socket + ' (' + s.pool + ')'"></p>
                    <p class="font-mono text-xs text-muted" x-show="s.exists" x-text="s.octal + ' ' + s.owner + ':' + s.group"></p>
                    <p class="text-xs text-warning-700" x-show="!s.exists">Socket tidak ditemukan. PHP-FPM mungkin sedang berhenti.</p>
                    <div class="mt-1 flex flex-wrap gap-1"><template x-for="a in s.access" :key="a.user"><span :class="a.ok ? 'chip-success' : 'chip-danger'" x-text="a.user + (a.ok ? ' dapat terhubung' : ' tidak dapat terhubung')"></span></template></div>
                  </li>
                </template>
              </ul>
            </div>
          </template>
        </div>
      </div>
    </template>
  </section>

  <form class="panel grid grid-cols-1 items-end gap-3 p-3 md:grid-cols-[minmax(0,1fr)_14rem_auto]" @submit.prevent="check()">
    <div>
      <label for="ws-path" class="field-label">Folder situs</label>
      <input id="ws-path" type="text" class="input-mono" x-model="form.path" required spellcheck="false" autocomplete="off" placeholder="/var/www/html/situs">
    </div>
    <div>
      <label for="ws-user" class="field-label">Akun web server</label>
      <input id="ws-user" type="text" class="input-mono" x-model="form.user" list="ws-users" required spellcheck="false" autocomplete="off" placeholder="www-data">
      <datalist id="ws-users"><template x-for="a in (info ? info.accounts : [])" :key="a.name"><option :value="a.name"></option></template></datalist>
      <p class="field-error" x-show="errors.user" x-text="errors.user"></p>
    </div>
    <button type="submit" class="btn-primary" :disabled="checkPhase === 'loading'"><?= $icon('server') ?><span x-text="checkPhase === 'loading' ? 'Memeriksa...' : 'Periksa Akses'"></span></button>
  </form>

  <template x-if="checkPhase === 'loading'"><div class="panel space-y-3 p-4"><div class="skeleton h-4 w-1/3"></div><div class="skeleton h-24 w-full"></div></div></template>
  <template x-if="checkPhase === 'error'">
    <div class="panel flex flex-col items-center gap-2 px-4 py-10 text-center" role="alert">
      <p class="font-medium text-ink">Pemeriksaan gagal</p>
      <p class="max-w-md text-sm text-muted" x-text="checkError"></p>
    </div>
  </template>
  <template x-if="checkPhase === 'content'">
    <div class="flex flex-col gap-4">
      <p class="text-sm text-muted"><span class="font-mono text-ink" x-text="FM.formatNumber(result.scanned)"></span> entri diperiksa sebagai <span class="font-mono text-ink" x-text="result.user.name"></span>. Pola folder tulis: <span class="font-mono" x-text="result.patterns.join(', ')"></span>. ACL tidak diperhitungkan.</p>
      <template x-for="block in blocks()" :key="block.key">
        <section class="panel min-w-0">
          <div class="flex flex-wrap items-baseline gap-2 border-b border-line px-4 py-3">
            <h2 class="panel-title" x-text="block.title"></h2>
            <span :class="block.count ? block.tone : 'chip-success'" x-text="block.count ? FM.formatNumber(block.count) + ' item' : 'Aman'"></span>
          </div>
          <p class="px-4 pt-3 text-sm text-body" x-text="block.help"></p>
          <p class="px-4 py-3 text-sm text-muted" x-show="!block.count" x-text="block.empty"></p>
          <div class="table-scroll mt-3" x-show="block.count">
            <table class="data-table">
              <thead><tr><th scope="col" class="w-12 text-right">No</th><th scope="col">Path</th><th scope="col">Izin</th><th scope="col">Pemilik:Grup</th><th scope="col">Keterangan</th></tr></thead>
              <tbody>
                <template x-for="(row, i) in block.items" :key="row.path">
                  <tr>
                    <td class="text-right font-mono text-xs text-muted" x-text="i + 1"></td>
                    <td class="break-all font-mono text-xs" x-text="row.path"></td>
                    <td class="font-mono text-xs" x-text="row.octal"></td>
                    <td class="whitespace-nowrap font-mono text-xs" x-text="row.owner + ':' + row.group"></td>
                    <td class="text-xs text-muted" x-text="row.reason"></td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
          <p class="border-t border-line px-4 py-2 text-xs text-muted" x-show="block.count > block.items.length" x-text="'Menampilkan ' + block.items.length + ' item pertama dari ' + FM.formatNumber(block.count) + '.'"></p>
        </section>
      </template>
    </div>
  </template>
</div>
