<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
$changed = function ($key) {
    return '<span class="chip-primary" x-show="changed(\'' . $key . '\')" title="Nilai ini diubah dari halaman Pengaturan">Diubah</span>';
};
require APP_ROOT . '/views/partials/folder-picker.php';
?>
<div x-data="settingsPage" class="flex flex-col gap-4">
  <div>
    <h1 class="font-display text-lg font-semibold">Pengaturan</h1>
    <p class="mt-1 text-sm text-muted">Nilai di halaman ini disimpan di <code>storage/settings.php</code> dan menggantikan nilai yang sama di <code>config/app.php</code>. Perubahan berlaku mulai permintaan berikutnya.</p>
  </div>

  <template x-if="phase === 'loading'">
    <div class="grid gap-4 lg:grid-cols-2" aria-busy="true">
      <template x-for="n in 4" :key="n">
        <div class="panel space-y-3 p-4"><span class="skeleton block h-3 w-40"></span><span class="skeleton block h-10 w-full"></span><span class="skeleton block h-10 w-full"></span><span class="skeleton block h-3 w-2/3"></span></div>
      </template>
    </div>
  </template>

  <template x-if="phase === 'error'">
    <div class="panel flex flex-col items-center gap-2 px-4 py-12 text-center" role="alert">
      <?= $icon('circle-alert', 'icon-lg text-danger-700') ?>
      <p class="font-medium text-ink">Pengaturan gagal dimuat</p>
      <p class="max-w-md text-sm text-muted" x-text="errorMessage"></p>
      <button type="button" class="btn-secondary mt-2" @click="load()"><?= $icon('refresh-cw') ?>Muat Ulang</button>
    </div>
  </template>

  <form x-show="phase === 'content'" x-cloak class="flex flex-col gap-4" @submit.prevent="save()" novalidate>
    <div class="grid gap-4 lg:grid-cols-2">
      <section class="panel min-w-0 space-y-3 p-4" aria-labelledby="set-general">
        <h2 id="set-general" class="panel-title">Umum</h2>
        <div>
          <label for="set-app-name" class="field-label">Nama aplikasi <?= $changed('app_name') ?></label>
          <input id="set-app-name" type="text" class="input" x-model="form.app_name" maxlength="60" required autocomplete="off" @input="clear('app_name')" :aria-invalid="fieldError('app_name') ? 'true' : null">
          <p class="field-error" x-show="fieldError('app_name')" x-text="fieldError('app_name')"></p>
        </div>
        <div>
          <p id="set-roots-label" class="field-label">Folder root <?= $changed('roots') ?></p>
          <ul class="space-y-2" aria-labelledby="set-roots-label">
            <template x-for="(root, index) in form.roots" :key="index">
              <li>
                <div class="flex gap-2">
                  <input type="text" class="input-mono min-w-0 flex-1" :id="'set-root-' + index" x-model="form.roots[index]" spellcheck="false" autocomplete="off" :placeholder="unix ? '/var/www/html' : 'D:/laragon/www'"
                         :aria-label="'Folder root ' + (index + 1)" @input="clear('roots')" :aria-invalid="fieldError('roots') ? 'true' : null" aria-describedby="set-roots-hint">
                  <button type="button" class="btn-secondary" @click="togglePicker('roots.' + index)" :aria-expanded="pickerField === 'roots.' + index ? 'true' : 'false'"><?= $icon('folder-open') ?>Telusuri</button>
                  <button type="button" class="btn-ghost btn-icon" @click="removeRoot(index)" :disabled="form.roots.length === 1" :aria-label="'Hapus folder root ' + (index + 1)" title="Hapus folder root"><?= $icon('trash-2') ?></button>
                </div>
                <div class="mt-2" x-show="pickerField === 'roots.' + index"><?php $folderPicker('pickFolder(picker.path)'); ?></div>
              </li>
            </template>
          </ul>
          <button type="button" class="btn-secondary mt-2" @click="addRoot()" :disabled="form.roots.length >= 20"><?= $icon('plus') ?>Tambah Folder Root</button>
          <p id="set-roots-hint" class="mt-1 text-xs text-muted">Hanya berkas di dalam folder ini yang dapat dibuka dan diubah, maksimal 20 folder. Telusuri hanya menampilkan folder di dalam folder root yang sedang berlaku; folder di luar itu diketik langsung sebagai path absolut.</p>
          <p class="field-error" x-show="fieldError('roots')" x-text="fieldError('roots')"></p>
        </div>
        <div>
          <label for="set-default" class="field-label">Folder awal <?= $changed('default_path') ?></label>
          <div class="flex gap-2">
            <input id="set-default" type="text" class="input-mono min-w-0 flex-1" x-model="form.default_path" spellcheck="false" autocomplete="off" :placeholder="unix ? '/var/www/html/situs' : 'D:/laragon/www/situs'" @input="clear('default_path')" :aria-invalid="fieldError('default_path') ? 'true' : null" aria-describedby="set-default-hint">
            <button type="button" class="btn-secondary" @click="togglePicker('default_path')" :aria-expanded="pickerField === 'default_path' ? 'true' : 'false'" aria-controls="set-default-picker"><?= $icon('folder-open') ?>Telusuri</button>
          </div>
          <div id="set-default-picker" class="mt-2" x-show="pickerField === 'default_path'"><?php $folderPicker('pickFolder(picker.path)'); ?></div>
          <p id="set-default-hint" class="mt-1 text-xs text-muted">Folder yang dibuka pertama kali di Pengelola Berkas dan halaman analisis. Kosongkan untuk memakai folder root pertama.</p>
          <p class="field-error" x-show="fieldError('default_path')" x-text="fieldError('default_path')"></p>
        </div>
        <div>
          <label for="set-compress" class="field-label">Folder tujuan kompres <?= $changed('compress_path') ?></label>
          <div class="flex gap-2">
            <input id="set-compress" type="text" class="input-mono min-w-0 flex-1" x-model="form.compress_path" spellcheck="false" autocomplete="off" :placeholder="unix ? '/var/www/html/arsip' : 'D:/laragon/www/arsip'" @input="clear('compress_path')" :aria-invalid="fieldError('compress_path') ? 'true' : null" aria-describedby="set-compress-hint">
            <button type="button" class="btn-secondary" @click="togglePicker('compress_path')" :aria-expanded="pickerField === 'compress_path' ? 'true' : 'false'" aria-controls="set-compress-picker"><?= $icon('folder-open') ?>Telusuri</button>
          </div>
          <div id="set-compress-picker" class="mt-2" x-show="pickerField === 'compress_path'"><?php $folderPicker('pickFolder(picker.path)'); ?></div>
          <p id="set-compress-hint" class="mt-1 text-xs text-muted">Folder tujuan yang terisi otomatis di dialog Kompres. Nilainya masih dapat diubah untuk setiap arsip. Kosongkan agar arsip disimpan di folder yang berisi item yang dipilih.</p>
          <p class="field-error" x-show="fieldError('compress_path')" x-text="fieldError('compress_path')"></p>
        </div>
        <div>
          <label for="set-compress-exclude" class="field-label">Pengecualian kompres bawaan <?= $changed('compress_exclude') ?></label>
          <textarea id="set-compress-exclude" rows="6" class="input-mono" x-model="form.compress_exclude" spellcheck="false" placeholder="node_modules&#10;*.log" @input="clear('compress_exclude')" :aria-invalid="fieldError('compress_exclude') ? 'true' : null" aria-describedby="set-compress-exclude-hint"></textarea>
          <p id="set-compress-exclude-hint" class="mt-1 text-xs text-muted">Pola berkas atau folder yang terisi otomatis di kolom Kecualikan pada dialog Kompres. Daftar ini masih dapat diubah untuk setiap arsip. Satu pola per baris, boleh memakai * dan ?, maksimal 50 baris. Pola tanpa "/" berlaku untuk nama di semua subfolder, misalnya node_modules atau *.log. Pola dengan "/" adalah path relatif terhadap folder yang berisi item yang dikompres. Kosongkan agar tidak ada pengecualian bawaan.</p>
          <p class="field-error" x-show="fieldError('compress_exclude')" x-text="fieldError('compress_exclude')"></p>
        </div>
        <div>
          <label for="set-hidden-names" class="field-label">Nama yang disembunyikan <?= $changed('hidden_names') ?></label>
          <textarea id="set-hidden-names" rows="4" class="input-mono" x-model="form.hidden_names" spellcheck="false" placeholder="node_modules&#10;Thumbs.db" @input="clear('hidden_names')" :aria-invalid="fieldError('hidden_names') ? 'true' : null" aria-describedby="set-hidden-names-hint"></textarea>
          <p id="set-hidden-names-hint" class="mt-1 text-xs text-muted">Nama berkas atau folder yang tidak ditampilkan di Pengelola Berkas dan pohon folder, seperti berkas berawalan titik, sampai pilihan Tampilkan tersembunyi dicentang. Satu nama per baris, maksimal 100, huruf besar dan kecil tidak dibedakan. Isi folder yang disembunyikan juga tidak ikut dicari. Kosongkan agar hanya berkas berawalan titik yang disembunyikan.</p>
          <p class="field-error" x-show="fieldError('hidden_names')" x-text="fieldError('hidden_names')"></p>
        </div>
      </section>

      <section class="panel space-y-3 p-4" aria-labelledby="set-session">
        <h2 id="set-session" class="panel-title">Sesi dan akses</h2>
        <div class="grid gap-3 sm:grid-cols-2">
          <div>
            <label for="set-idle" class="field-label">Sesi tanpa aktivitas (menit) <?= $changed('session_idle_minutes') ?></label>
            <input id="set-idle" type="number" inputmode="numeric" min="5" max="480" class="input" x-model="form.session_idle_minutes" @input="clear('session_idle_minutes')" :aria-invalid="fieldError('session_idle_minutes') ? 'true' : null">
            <p class="field-error" x-show="fieldError('session_idle_minutes')" x-text="fieldError('session_idle_minutes')"></p>
          </div>
          <div>
            <label for="set-max" class="field-label">Umur sesi maksimal (jam) <?= $changed('session_max_hours') ?></label>
            <input id="set-max" type="number" inputmode="numeric" min="1" max="72" class="input" x-model="form.session_max_hours" @input="clear('session_max_hours')" :aria-invalid="fieldError('session_max_hours') ? 'true' : null">
            <p class="field-error" x-show="fieldError('session_max_hours')" x-text="fieldError('session_max_hours')"></p>
          </div>
        </div>
        <label class="flex min-h-control items-center gap-2 text-sm"><input type="checkbox" class="check" x-model="form.session_bind_ip">Akhiri sesi bila alamat IP berubah <?= $changed('session_bind_ip') ?></label>
        <div>
          <label for="set-ips" class="field-label">Alamat IP yang diizinkan <?= $changed('allowed_ips') ?></label>
          <textarea id="set-ips" rows="3" class="input-mono" x-model="form.allowed_ips" spellcheck="false" placeholder="192.168.1.0/24" @input="clear('allowed_ips')" :aria-invalid="fieldError('allowed_ips') ? 'true' : null" aria-describedby="set-ips-hint"></textarea>
          <p id="set-ips-hint" class="mt-1 text-xs text-muted">Satu alamat IP atau rentang CIDR per baris. Kosongkan untuk mengizinkan semua alamat. Alamat IP Anda saat ini: <span class="font-mono" x-text="clientIp"></span>.</p>
          <p class="field-error" x-show="fieldError('allowed_ips')" x-text="fieldError('allowed_ips')"></p>
        </div>
      </section>

      <section class="panel space-y-3 p-4" aria-labelledby="set-files">
        <h2 id="set-files" class="panel-title">Keamanan berkas</h2>
        <div>
          <label for="set-ext" class="field-label">Ekstensi yang diblokir <?= $changed('blocked_extensions') ?></label>
          <textarea id="set-ext" rows="3" class="input-mono" x-model="form.blocked_extensions" spellcheck="false" @input="clear('blocked_extensions')" :aria-invalid="fieldError('blocked_extensions') ? 'true' : null"></textarea>
          <p class="field-error" x-show="fieldError('blocked_extensions')" x-text="fieldError('blocked_extensions')"></p>
        </div>
        <div>
          <label for="set-names" class="field-label">Nama berkas yang diblokir <?= $changed('blocked_names') ?></label>
          <textarea id="set-names" rows="2" class="input-mono" x-model="form.blocked_names" spellcheck="false" @input="clear('blocked_names')" :aria-invalid="fieldError('blocked_names') ? 'true' : null"></textarea>
          <p class="field-error" x-show="fieldError('blocked_names')" x-text="fieldError('blocked_names')"></p>
        </div>
        <p class="text-xs text-muted">Pisahkan dengan koma atau baris baru. Berkas dan folder baru (unggah, buat, ganti nama, ekstrak arsip) tidak dapat memakai ekstensi atau nama ini. Bila daftar dikosongkan, skrip server seperti .php dapat diunggah kembali.</p>
        <div>
          <label class="flex min-h-control items-center gap-2 text-sm"><input type="checkbox" class="check" x-model="form.protect_app_folder" aria-describedby="set-protect-hint">Lindungi folder aplikasi <?= $changed('protect_app_folder') ?></label>
          <p id="set-protect-hint" class="text-xs text-muted">Bila aktif, folder aplikasi File Manager tidak dapat dibuka atau diubah, dan folder induknya tidak dapat dihapus, dipindahkan, atau diganti namanya.</p>
          <p class="mt-1 text-xs text-warning-700" x-show="!form.protect_app_folder">Folder aplikasi dapat dibuka dan diubah seperti folder lain, termasuk konfigurasi login dan riwayat perubahan. Kesalahan di folder ini dapat membuat aplikasi tidak dapat dibuka.</p>
        </div>
      </section>

      <section class="panel space-y-3 p-4" aria-labelledby="set-limits">
        <h2 id="set-limits" class="panel-title">Batas</h2>
        <div class="grid gap-3 sm:grid-cols-2">
          <div>
            <label for="set-list" class="field-label">Item per daftar folder <?= $changed('limit_list') ?></label>
            <input id="set-list" type="number" inputmode="numeric" min="100" max="50000" class="input" x-model="form.limit_list" @input="clear('limit_list')" :aria-invalid="fieldError('limit_list') ? 'true' : null">
            <p class="field-error" x-show="fieldError('limit_list')" x-text="fieldError('limit_list')"></p>
          </div>
          <div>
            <label for="set-scan" class="field-label">Entri per pemindaian <?= $changed('limit_scan') ?></label>
            <input id="set-scan" type="number" inputmode="numeric" min="1000" max="1000000" class="input" x-model="form.limit_scan" @input="clear('limit_scan')" :aria-invalid="fieldError('limit_scan') ? 'true' : null">
            <p class="field-error" x-show="fieldError('limit_scan')" x-text="fieldError('limit_scan')"></p>
          </div>
          <div>
            <label for="set-edit" class="field-label">Ukuran editor (MB) <?= $changed('edit_mb') ?></label>
            <input id="set-edit" type="number" inputmode="numeric" min="1" max="20" class="input" x-model="form.edit_mb" @input="clear('edit_mb')" :aria-invalid="fieldError('edit_mb') ? 'true' : null">
            <p class="field-error" x-show="fieldError('edit_mb')" x-text="fieldError('edit_mb')"></p>
          </div>
          <div>
            <label for="set-upload" class="field-label">Ukuran unggahan (MB) <?= $changed('upload_mb') ?></label>
            <input id="set-upload" type="number" inputmode="numeric" min="1" max="2048" class="input" x-model="form.upload_mb" @input="clear('upload_mb')" :aria-invalid="fieldError('upload_mb') ? 'true' : null">
            <p class="field-error" x-show="fieldError('upload_mb')" x-text="fieldError('upload_mb')"></p>
          </div>
          <div>
            <label for="set-preview" class="field-label">Item pratinjau <?= $changed('preview_items') ?></label>
            <input id="set-preview" type="number" inputmode="numeric" min="10" max="1000" class="input" x-model="form.preview_items" @input="clear('preview_items')" :aria-invalid="fieldError('preview_items') ? 'true' : null">
            <p class="field-error" x-show="fieldError('preview_items')" x-text="fieldError('preview_items')"></p>
          </div>
          <div x-show="unix">
            <label for="set-timeout" class="field-label">Batas waktu perintah (detik) <?= $changed('command_timeout') ?></label>
            <input id="set-timeout" type="number" inputmode="numeric" min="10" max="3600" class="input" x-model="form.command_timeout" @input="clear('command_timeout')" :aria-invalid="fieldError('command_timeout') ? 'true' : null" aria-describedby="set-timeout-hint">
            <p class="field-error" x-show="fieldError('command_timeout')" x-text="fieldError('command_timeout')"></p>
            <p id="set-timeout-hint" class="mt-1 text-xs text-muted" x-show="form.no_time_limit">Tidak berlaku selama pilihan Proses tanpa batas waktu aktif.</p>
          </div>
        </div>
        <p class="text-xs text-muted">Ukuran unggahan tetap dibatasi upload_max_filesize dan post_max_size di php.ini.</p>
        <div>
          <label class="flex min-h-control items-center gap-2 text-sm"><input type="checkbox" class="check" x-model="form.no_time_limit" aria-describedby="set-notimelimit-hint">Proses tanpa batas waktu <?= $changed('no_time_limit') ?></label>
          <p id="set-notimelimit-hint" class="text-xs text-muted">Bila aktif, proses panjang seperti kompres, ekstrak, salin, pindah, hapus, unggah, dan simpan berjalan sampai selesai tanpa dihentikan oleh max_execution_time PHP dan tetap diselesaikan bila browser terputus. Batas waktu web server (Timeout Apache, fastcgi_read_timeout Nginx, request_terminate_timeout PHP-FPM) tetap berlaku dan perlu dinaikkan di konfigurasi server.</p>
        </div>
      </section>
    </div>

    <section class="panel space-y-3 p-4" aria-labelledby="set-account">
      <h2 id="set-account" class="panel-title">Akun masuk</h2>
      <div class="grid gap-3 sm:grid-cols-3">
        <div>
          <label for="set-user" class="field-label">Nama pengguna <?= $changed('username') ?></label>
          <input id="set-user" type="text" class="input" x-model="form.username" maxlength="64" autocomplete="username" autocapitalize="none" spellcheck="false" @input="clear('username')" :aria-invalid="fieldError('username') ? 'true' : null">
          <p class="field-error" x-show="fieldError('username')" x-text="fieldError('username')"></p>
        </div>
        <div>
          <label for="set-pass" class="field-label">Kata sandi baru <?= $changed('password') ?></label>
          <input id="set-pass" type="password" class="input" x-model="form.new_password" maxlength="72" autocomplete="new-password" @input="clear('new_password')" :aria-invalid="fieldError('new_password') ? 'true' : null">
          <p class="field-error" x-show="fieldError('new_password')" x-text="fieldError('new_password')"></p>
        </div>
        <div>
          <label for="set-pass2" class="field-label">Ulangi kata sandi baru</label>
          <input id="set-pass2" type="password" class="input" x-model="form.new_password_confirm" maxlength="72" autocomplete="new-password" @input="clear('new_password_confirm')" :aria-invalid="fieldError('new_password_confirm') ? 'true' : null">
          <p class="field-error" x-show="fieldError('new_password_confirm')" x-text="fieldError('new_password_confirm')"></p>
        </div>
      </div>
      <p class="text-xs text-muted">Kosongkan kata sandi baru bila tidak ingin mengubahnya. Kata sandi disimpan sebagai hash bcrypt.</p>
      <p class="flex items-start gap-2 text-xs" :class="recovery ? 'text-muted' : 'text-warning-700'">
        <?= $icon('shield-check', 'icon mt-px') ?>
        <span x-text="recovery ? 'Kata sandi cadangan aktif. Kata sandi ini diatur di config/app.php (auth.recovery_password_hash), tidak dapat diubah dari halaman ini, dan tetap dapat dipakai untuk masuk bila kata sandi utama diganti orang lain.' : 'Kata sandi cadangan belum diatur. Isi auth.recovery_password_hash di config/app.php agar tetap dapat masuk bila kata sandi utama diganti orang lain.'"></span>
      </p>
    </section>

    <section class="panel space-y-3 p-4" aria-labelledby="set-confirm">
      <h2 id="set-confirm" class="panel-title">Konfirmasi</h2>
      <div class="flex flex-col gap-3 xl:flex-row xl:items-end xl:justify-between">
        <div class="xl:w-96">
          <label for="set-current" class="field-label">Kata sandi saat ini <span class="text-danger-700" aria-hidden="true">*</span></label>
          <input id="set-current" type="password" class="input" x-model="form.current_password" autocomplete="current-password" required @input="clear('current_password')" :aria-invalid="fieldError('current_password') ? 'true' : null">
          <p class="field-error" x-show="fieldError('current_password')" x-text="fieldError('current_password')"></p>
        </div>
        <div class="flex flex-wrap gap-2">
          <button type="button" class="btn-danger-ghost" @click="confirmReset = true" :disabled="busy || !overridden.length"><?= $icon('rotate-ccw') ?>Kembalikan ke config/app.php</button>
          <button type="submit" class="btn-primary" :disabled="busy"><?= $icon('save') ?><span x-text="busy ? 'Menyimpan...' : 'Simpan Pengaturan'"></span></button>
        </div>
      </div>
      <div x-show="confirmReset" class="flex flex-col gap-2 rounded-control border border-warning-600/40 bg-warning-50 p-3 text-sm text-warning-700 sm:flex-row sm:items-center" role="alert">
        <p class="flex-1">Semua nilai yang diubah dari halaman ini akan dihapus, termasuk nama pengguna dan kata sandi. Setelah itu aplikasi kembali memakai config/app.php.</p>
        <div class="flex gap-2">
          <button type="button" class="btn-secondary" @click="confirmReset = false">Batal</button>
          <button type="button" class="btn-danger" @click="reset()" :disabled="busy">Kembalikan</button>
        </div>
      </div>
    </section>
  </form>
</div>
