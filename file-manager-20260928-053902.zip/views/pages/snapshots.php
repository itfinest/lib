<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div class="flex flex-col gap-4">
  <div>
    <h1 class="font-display text-lg font-semibold">Snapshot Izin</h1>
    <p class="mt-1 text-sm text-muted">Rekaman izin, pemilik, dan grup. Snapshot otomatis dibuat sebelum setiap perubahan izin. Buat snapshot manual dari menu aksi di Pengelola Berkas.</p>
  </div>

  <section x-data="snapshotList" class="panel min-w-0" aria-label="Daftar snapshot">
    <div class="grid grid-cols-1 items-end gap-3 border-b border-line p-3 sm:grid-cols-[14rem_auto]">
      <div>
        <label for="snap-kind" class="field-label">Jenis</label>
        <select id="snap-kind" class="input" x-model="state.kind" @change="setFilter()">
          <option value="">Semua jenis</option>
          <option value="auto">Otomatis</option>
          <option value="manual">Manual</option>
        </select>
      </div>
      <div><button type="button" class="btn-secondary" @click="resetFilters()" :disabled="!isFiltered()">Reset Filter</button></div>
    </div>
    <?php $searchLabel = 'Cari label, path, atau pengguna'; $searchId = 'snap-search'; require APP_ROOT . '/views/partials/list-toolbar.php'; ?>

    <div class="table-scroll hidden md:block" x-show="phase === 'loading' || phase === 'content'">
      <table class="data-table">
        <thead>
          <tr>
            <th scope="col" class="w-12 text-right">No</th>
            <th scope="col" :aria-sort="ariaSort('label')"><button type="button" class="sort-btn" @click="sortBy('label')">Label<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('label')"></use></svg></button></th>
            <th scope="col">Cakupan</th>
            <th scope="col" class="text-right" :aria-sort="ariaSort('count')"><button type="button" class="sort-btn" @click="sortBy('count')">Entri<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('count')"></use></svg></button></th>
            <th scope="col" :aria-sort="ariaSort('created_at')"><button type="button" class="sort-btn" @click="sortBy('created_at')">Dibuat<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('created_at')"></use></svg></button></th>
            <th scope="col" class="text-right">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $cols = 6; require APP_ROOT . '/views/partials/skeleton-rows.php'; ?>
          <template x-if="phase === 'content'">
            <template x-for="(item, index) in items" :key="item.id">
              <tr>
                <td class="text-right font-mono text-xs text-muted" x-text="rowNumber(index)"></td>
                <td class="max-w-[22rem]">
                  <p class="font-medium text-ink" x-text="item.label"></p>
                  <span :class="item.kind === 'auto' ? 'chip-neutral' : 'chip-primary'" x-text="item.kind === 'auto' ? 'Otomatis' : 'Manual'"></span>
                  <span class="chip-neutral" x-show="item.has_acl">Dengan ACL</span>
                </td>
                <td class="max-w-[20rem] break-all font-mono text-xs text-muted"><span x-text="item.paths.slice(0, 3).join(', ')"></span><span x-show="item.paths.length > 3" x-text="' dan ' + (item.paths.length - 3) + ' lainnya'"></span><span class="block font-body" x-text="item.recursive ? 'Termasuk isi folder' : 'Tanpa isi folder'"></span></td>
                <td class="text-right font-mono text-xs" x-text="FM.formatNumber(item.count)"></td>
                <td class="whitespace-nowrap text-xs"><span x-text="FM.formatDate(item.created_at)"></span><span class="block text-muted" x-text="'oleh ' + item.created_by"></span></td>
                <td class="whitespace-nowrap text-right">
                  <button type="button" class="btn-ghost" @click="compare(item)">Bandingkan</button>
                  <button type="button" class="btn-ghost" @click="rollback(item)">Kembalikan</button>
                  <button type="button" class="btn-ghost text-danger-700 hover:bg-danger-50" @click="askDelete(item)">Hapus</button>
                </td>
              </tr>
            </template>
          </template>
        </tbody>
      </table>
    </div>
    <ul class="divide-y divide-line md:hidden" x-show="phase === 'loading' || phase === 'content'">
      <template x-if="phase === 'loading'"><template x-for="n in 5" :key="n"><li class="space-y-2 p-3"><span class="skeleton block h-4 w-2/3"></span><span class="skeleton block h-3 w-full"></span></li></template></template>
      <template x-if="phase === 'content'">
        <template x-for="(item, index) in items" :key="item.id">
          <li class="p-3">
            <p class="font-medium text-ink"><span class="font-mono text-xs text-muted" x-text="rowNumber(index) + '. '"></span><span x-text="item.label"></span></p>
            <p class="break-all font-mono text-xs text-muted" x-text="item.paths.join(', ')"></p>
            <p class="text-xs text-muted" x-text="FM.formatDate(item.created_at) + ' · ' + FM.formatNumber(item.count) + ' entri · ' + (item.kind === 'auto' ? 'Otomatis' : 'Manual')"></p>
            <div class="mt-2 flex flex-wrap gap-2">
              <button type="button" class="btn-secondary btn-sm" @click="compare(item)">Bandingkan</button>
              <button type="button" class="btn-secondary btn-sm" @click="rollback(item)">Kembalikan</button>
              <button type="button" class="btn-danger-ghost btn-sm" @click="askDelete(item)">Hapus</button>
            </div>
          </li>
        </template>
      </template>
    </ul>
    <?php $emptyTitle = 'Belum ada snapshot'; $emptyText = 'Snapshot otomatis dibuat setiap kali izin atau pemilik diubah. Snapshot manual dapat dibuat dari menu aksi di Pengelola Berkas.'; require APP_ROOT . '/views/partials/list-states.php'; ?>
    <?php require APP_ROOT . '/views/partials/pager.php'; ?>

    <div x-show="deleting" x-cloak class="modal-backdrop" @mousedown.self.prevent x-transition:enter="modal-in" x-transition:leave="modal-out" @keydown.escape="!busy && (deleting = null)">
      <div class="modal sm:max-w-md" role="dialog" aria-modal="true" aria-labelledby="snap-delete-title" x-ref="modal" @keydown.tab="FM.trapFocus($event, $refs.modal)">
        <div class="modal-head"><h2 id="snap-delete-title" class="font-display text-sm font-semibold">Hapus snapshot?</h2></div>
        <div class="modal-body text-sm">
          <p>Snapshot "<span class="font-semibold" x-text="deleting ? deleting.label : ''"></span>" akan dihapus. Perubahan yang dicatat dengan snapshot ini tidak dapat dibatalkan lagi dari Riwayat Perubahan.</p>
        </div>
        <div class="modal-foot">
          <button type="button" class="btn-secondary" @click="deleting = null" :disabled="busy" data-autofocus>Batal</button>
          <button type="button" class="btn-danger" @click="confirmDelete()" :disabled="busy" x-text="busy ? 'Menghapus...' : 'Hapus Snapshot'"></button>
        </div>
      </div>
    </div>
  </section>

  <section x-data="snapshotCompare" x-show="state.a" x-cloak class="panel min-w-0" id="compare" aria-labelledby="compare-title">
    <div class="flex flex-col gap-3 border-b border-line p-3 lg:flex-row lg:items-end">
      <div class="min-w-0 flex-1">
        <h2 id="compare-title" class="panel-title">Perbandingan Snapshot</h2>
        <p class="mt-1 text-sm text-body"><span class="font-medium" x-text="extra.left || '-'"></span> <span class="text-muted">dibandingkan dengan</span> <span class="font-medium" x-text="extra.right || '-'"></span></p>
      </div>
      <div class="grid grid-cols-1 gap-3 sm:grid-cols-[16rem_12rem_auto] sm:items-end">
        <div>
          <label for="cmp-b" class="field-label">Pembanding</label>
          <select id="cmp-b" class="input" x-model="state.b" @change="setFilter()">
            <option value="live">Kondisi saat ini</option>
            <template x-for="s in others" :key="s.id"><option :value="s.id" x-text="s.label + ' (' + FM.formatDate(s.created_at) + ')'"></option></template>
          </select>
        </div>
        <div>
          <label for="cmp-change" class="field-label">Perubahan</label>
          <select id="cmp-change" class="input" x-model="state.change" @change="setFilter()">
            <option value="">Semua perubahan</option>
            <option value="changed" x-text="'Berubah (' + (extra.counts ? extra.counts.changed : 0) + ')'"></option>
            <option value="added" x-text="'Baru (' + (extra.counts ? extra.counts.added : 0) + ')'"></option>
            <option value="removed" x-text="'Hilang (' + (extra.counts ? extra.counts.removed : 0) + ')'"></option>
          </select>
        </div>
        <button type="button" class="btn-secondary" @click="closeCompare()">Tutup</button>
      </div>
    </div>
    <?php $searchLabel = 'Cari path'; $searchId = 'cmp-search'; require APP_ROOT . '/views/partials/list-toolbar.php'; ?>
    <div class="table-scroll" x-show="phase === 'loading' || phase === 'content'">
      <table class="data-table">
        <thead><tr><th scope="col" class="w-12 text-right">No</th><th scope="col">Path</th><th scope="col">Perubahan</th><th scope="col">Sebelum</th><th scope="col">Sesudah</th></tr></thead>
        <tbody>
          <?php $cols = 5; require APP_ROOT . '/views/partials/skeleton-rows.php'; ?>
          <template x-if="phase === 'content'">
            <template x-for="(row, index) in items" :key="row.path">
              <tr>
                <td class="text-right font-mono text-xs text-muted" x-text="rowNumber(index)"></td>
                <td class="max-w-[28rem] break-all font-mono text-xs" x-text="row.path"></td>
                <td><span :class="{ changed: 'chip-warning', added: 'chip-success', removed: 'chip-danger' }[row.change]" x-text="{ changed: 'Berubah', added: 'Baru', removed: 'Hilang' }[row.change]"></span></td>
                <td class="whitespace-nowrap font-mono text-xs text-muted" x-text="row.before || '-'"></td>
                <td class="whitespace-nowrap font-mono text-xs text-ink" x-text="row.after || '-'"></td>
              </tr>
            </template>
          </template>
        </tbody>
      </table>
    </div>
    <?php $emptyTitle = 'Tidak ada perbedaan'; $emptyText = 'Izin, pemilik, dan grup pada kedua sisi sama persis.'; require APP_ROOT . '/views/partials/list-states.php'; ?>
    <?php require APP_ROOT . '/views/partials/pager.php'; ?>
  </section>
</div>
