<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
$ops = [
    'mkdir' => 'Buat folder', 'create_file' => 'Buat berkas', 'save' => 'Simpan berkas', 'upload' => 'Unggah', 'rename' => 'Ganti nama',
    'copy' => 'Salin', 'duplicate' => 'Duplikat', 'move' => 'Pindah', 'trash' => 'Ke tempat sampah', 'restore' => 'Pulihkan', 'delete' => 'Hapus permanen',
    'trash_purge' => 'Kosongkan sampah', 'compress' => 'Kompres', 'extract' => 'Ekstrak', 'chmod' => 'Ubah izin', 'chown' => 'Ubah pemilik',
    'preset' => 'Preset', 'acl' => 'ACL', 'rollback' => 'Kembalikan izin', 'audit_fix' => 'Perbaikan audit', 'audit' => 'Audit',
    'malware_scan' => 'Pindai malware', 'quarantine' => 'Karantina', 'malware_cloaking' => 'Buang cloaking', 'malware_lock' => 'Kunci folder unggahan',
    'snapshot' => 'Snapshot manual', 'snapshot_delete' => 'Hapus snapshot', 'preset_save' => 'Simpan preset', 'preset_delete' => 'Hapus preset',
    'favorite_save' => 'Tambah favorit', 'favorite_delete' => 'Hapus favorit', 'policy_save' => 'Simpan kebijakan', 'policy_toggle' => 'Status kebijakan', 'policy_delete' => 'Hapus kebijakan', 'login' => 'Masuk', 'logout' => 'Keluar',
    'session_rejected' => 'Sesi ditolak', 'settings_save' => 'Ubah pengaturan', 'settings_reset' => 'Reset pengaturan',
];
?>
<div x-data="historyPage" data-ops='<?= $e(json_encode($ops, JSON_UNESCAPED_UNICODE)) ?>' class="flex flex-col gap-4">
  <div class="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
    <div>
      <h1 class="font-display text-lg font-semibold">Riwayat Perubahan</h1>
      <p class="mt-1 text-sm text-muted">Catatan setiap perubahan beserta perintah yang dijalankan. Perubahan izin dapat dibatalkan dari snapshot otomatisnya.</p>
    </div>
    <a class="btn-secondary" :href="exportUrl()"><?= $icon('download') ?>Ekspor CSV</a>
  </div>

  <section class="panel min-w-0">
    <div class="grid grid-cols-1 items-end gap-3 border-b border-line p-3 sm:grid-cols-2 lg:grid-cols-[14rem_12rem_12rem_auto]">
      <div>
        <label for="h-op" class="field-label">Operasi</label>
        <select id="h-op" class="input" x-model="state.op" @change="setFilter()">
          <option value="">Semua operasi</option>
          <template x-for="(label, key) in ops" :key="key"><option :value="key" x-text="label"></option></template>
        </select>
      </div>
      <div>
        <label for="h-status" class="field-label">Status</label>
        <select id="h-status" class="input" x-model="state.status" @change="setFilter()">
          <option value="">Semua status</option>
          <option value="ok">Berhasil</option>
          <option value="failed">Gagal</option>
        </select>
      </div>
      <div>
        <label for="h-category" class="field-label">Kategori</label>
        <select id="h-category" class="input" x-model="state.category" @change="setFilter()">
          <option value="">Semua kategori</option>
          <option value="operation">Perubahan berkas</option>
          <option value="event">Aktivitas lain</option>
        </select>
      </div>
      <div><button type="button" class="btn-secondary" @click="resetFilters()" :disabled="!isFiltered()">Reset Filter</button></div>
    </div>
    <?php $searchLabel = 'Cari ringkasan, path, atau pengguna'; $searchId = 'history-search'; require APP_ROOT . '/views/partials/list-toolbar.php'; ?>

    <div class="table-scroll hidden md:block" x-show="phase === 'loading' || phase === 'content'">
      <table class="data-table">
        <thead>
          <tr>
            <th scope="col" class="w-12 text-right">No</th>
            <th scope="col" :aria-sort="ariaSort('at')"><button type="button" class="sort-btn" @click="sortBy('at')">Waktu<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('at')"></use></svg></button></th>
            <th scope="col" :aria-sort="ariaSort('user')"><button type="button" class="sort-btn" @click="sortBy('user')">Pengguna<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('user')"></use></svg></button></th>
            <th scope="col" :aria-sort="ariaSort('op')"><button type="button" class="sort-btn" @click="sortBy('op')">Operasi<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('op')"></use></svg></button></th>
            <th scope="col">Ringkasan</th>
            <th scope="col">Status</th>
            <th scope="col" class="text-right">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $cols = 7; require APP_ROOT . '/views/partials/skeleton-rows.php'; ?>
          <template x-if="phase === 'content'">
            <template x-for="(item, index) in items" :key="item.id">
              <tr>
                <td class="text-right font-mono text-xs text-muted" x-text="rowNumber(index)"></td>
                <td class="whitespace-nowrap text-xs" x-text="FM.formatDate(item.at)"></td>
                <td class="font-mono text-xs" x-text="item.user"></td>
                <td><span class="chip-neutral" x-text="opLabel(item.op)"></span></td>
                <td class="max-w-[30rem]"><p class="text-ink" x-text="item.summary"></p><p class="text-xs text-muted" x-show="item.target_count" x-text="FM.formatNumber(item.target_count) + ' target'"></p></td>
                <td><span :class="item.ok ? 'chip-success' : 'chip-danger'"><svg class="h-3 w-3" aria-hidden="true"><use :href="FM.icons + '#' + (item.ok ? 'check' : 'x')"></use></svg><span x-text="item.ok ? 'Berhasil' : 'Gagal'"></span></span></td>
                <td class="whitespace-nowrap text-right">
                  <button type="button" class="btn-ghost" @click="show(item)">Detail</button>
                  <button type="button" class="btn-ghost" x-show="canUndo(item)" @click="undo(item)">Batalkan</button>
                </td>
              </tr>
            </template>
          </template>
        </tbody>
      </table>
    </div>
    <ul class="divide-y divide-line md:hidden" x-show="phase === 'loading' || phase === 'content'">
      <template x-if="phase === 'loading'"><template x-for="n in 5" :key="n"><li class="space-y-2 p-3"><span class="skeleton block h-4 w-2/3"></span><span class="skeleton block h-3 w-full"></span></li></template></template>
      <template x-if="phase === 'content'">
        <template x-for="(item, index) in items" :key="item.id">
          <li class="p-3">
            <div class="flex flex-wrap items-center gap-2">
              <span class="font-mono text-xs text-muted" x-text="rowNumber(index) + '.'"></span>
              <span class="chip-neutral" x-text="opLabel(item.op)"></span>
              <span :class="item.ok ? 'chip-success' : 'chip-danger'" x-text="item.ok ? 'Berhasil' : 'Gagal'"></span>
            </div>
            <p class="mt-1 text-ink" x-text="item.summary"></p>
            <p class="text-xs text-muted" x-text="FM.formatDate(item.at) + ' · ' + item.user"></p>
            <div class="mt-2 flex gap-2">
              <button type="button" class="btn-secondary btn-sm" @click="show(item)">Detail</button>
              <button type="button" class="btn-secondary btn-sm" x-show="canUndo(item)" @click="undo(item)">Batalkan</button>
            </div>
          </li>
        </template>
      </template>
    </ul>
    <?php $emptyTitle = 'Belum ada riwayat'; $emptyText = 'Setiap perubahan berkas, izin, dan pengaturan akan tercatat di sini.'; require APP_ROOT . '/views/partials/list-states.php'; ?>
    <?php require APP_ROOT . '/views/partials/pager.php'; ?>
  </section>

  <div x-show="detailOpen" x-cloak class="modal-backdrop" @mousedown.self.prevent x-transition:enter="modal-in" x-transition:leave="modal-out" @keydown.escape="closeDetail()">
    <div class="modal sm:max-w-2xl" role="dialog" aria-modal="true" aria-labelledby="h-detail-title" x-ref="modal" @keydown.tab="FM.trapFocus($event, $refs.modal)">
      <template x-if="detail">
        <div class="contents">
          <div class="modal-head">
            <div class="min-w-0">
              <h2 id="h-detail-title" class="font-display text-sm font-semibold" x-text="detail.summary"></h2>
              <p class="text-xs text-muted" x-text="FM.formatDate(detail.at) + ' · ' + detail.user + (detail.ip ? ' · ' + detail.ip : '')"></p>
            </div>
            <button type="button" class="btn-ghost btn-icon -mr-2" @click="closeDetail()" aria-label="Tutup"><?= $icon('x') ?></button>
          </div>
          <div class="modal-body space-y-4 text-sm">
            <section x-show="detail.errors && detail.errors.length" class="rounded-control border border-danger-600/40 bg-danger-50 p-3 text-danger-700">
              <h3 class="font-semibold">Kesalahan</h3>
              <ul class="mt-1 list-disc space-y-1 pl-5 font-mono text-xs"><template x-for="line in detail.errors" :key="line"><li class="break-all" x-text="line"></li></template></ul>
            </section>
            <section x-show="detail.targets && detail.targets.length">
              <h3 class="panel-title mb-2" x-text="'Target (' + FM.formatNumber(detail.target_count) + ')'"></h3>
              <ul class="max-h-40 overflow-y-auto rounded-control border border-line bg-surface-2 p-2 font-mono text-xs"><template x-for="t in detail.targets" :key="t"><li class="break-all py-0.5" x-text="t"></li></template></ul>
              <p class="mt-1 text-xs text-muted" x-show="detail.target_count > detail.targets.length" x-text="'Menampilkan ' + detail.targets.length + ' target pertama.'"></p>
            </section>
            <section x-show="detail.commands && detail.commands.length">
              <h3 class="panel-title mb-2">Perintah yang dijalankan</h3>
              <div class="space-y-2"><template x-for="(c, i) in detail.commands" :key="i"><div><p class="mb-1 text-xs text-muted" x-text="c.label"></p><pre class="code-block" x-text="c.cmd"></pre></div></template></div>
            </section>
            <p x-show="detail.snapshot_id" class="text-xs text-muted" x-text="'Snapshot: ' + detail.snapshot_id"></p>
          </div>
          <div class="modal-foot">
            <button type="button" class="btn-secondary" @click="closeDetail()" data-autofocus>Tutup</button>
            <button type="button" class="btn-primary" x-show="canUndo(detail)" @click="undoDetail()">Batalkan Perubahan Ini</button>
          </div>
        </div>
      </template>
    </div>
  </div>
</div>
