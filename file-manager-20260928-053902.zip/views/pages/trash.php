<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data="trashPage" class="flex flex-col gap-4">
  <div class="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
    <div>
      <h1 class="font-display text-lg font-semibold">Tempat Sampah</h1>
      <p class="mt-1 text-sm text-muted">Item yang dihapus dari Pengelola Berkas dan berkas yang dikarantina dari Pemindai Malware. Pulihkan ke lokasi asal atau hapus permanen.</p>
    </div>
    <button type="button" class="btn-danger-ghost" @click="purgeAll()" :disabled="phase === 'loading' || (phase === 'empty')"><?= $icon('trash-2') ?>Kosongkan Tempat Sampah</button>
  </div>

  <section class="panel min-w-0">
    <div x-show="selected.length" x-cloak class="flex flex-wrap items-center gap-2 border-b border-line bg-primary-50 px-3 py-2">
      <p class="mr-1 text-sm font-medium text-primary-700"><span class="font-mono" x-text="selected.length"></span> item dipilih</p>
      <button type="button" class="btn-secondary btn-sm" @click="restore(selected)"><?= $icon('undo-2') ?>Pulihkan</button>
      <button type="button" class="btn-danger-ghost btn-sm" @click="purge(selected)"><?= $icon('trash-2') ?>Hapus Permanen</button>
      <button type="button" class="btn-ghost btn-sm sm:ml-auto" @click="selected = []">Batal Pilih</button>
    </div>
    <?php $searchLabel = 'Cari nama atau lokasi asal'; $searchId = 'trash-search'; require APP_ROOT . '/views/partials/list-toolbar.php'; ?>

    <div class="table-scroll hidden md:block" x-show="phase === 'loading' || phase === 'content'">
      <table class="data-table">
        <thead>
          <tr>
            <th scope="col" class="w-10"><input type="checkbox" class="check" :checked="allSelected()" @change="toggleAll()" :disabled="phase !== 'content'" aria-label="Pilih semua item di halaman ini"></th>
            <th scope="col" class="w-12 text-right">No</th>
            <th scope="col" :aria-sort="ariaSort('name')"><button type="button" class="sort-btn" @click="sortBy('name')">Nama<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('name')"></use></svg></button></th>
            <th scope="col" :aria-sort="ariaSort('original')"><button type="button" class="sort-btn" @click="sortBy('original')">Lokasi Asal<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('original')"></use></svg></button></th>
            <th scope="col" class="text-right" :aria-sort="ariaSort('size')"><button type="button" class="sort-btn" @click="sortBy('size')">Ukuran<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('size')"></use></svg></button></th>
            <th scope="col" :aria-sort="ariaSort('deleted_at')"><button type="button" class="sort-btn" @click="sortBy('deleted_at')">Dihapus<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('deleted_at')"></use></svg></button></th>
            <th scope="col" class="text-right">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $cols = 7; require APP_ROOT . '/views/partials/skeleton-rows.php'; ?>
          <template x-if="phase === 'content'">
            <template x-for="(item, index) in items" :key="item.id">
              <tr :aria-selected="selected.includes(item.id) ? 'true' : 'false'">
                <td><input type="checkbox" class="check" :checked="selected.includes(item.id)" @change="toggle(item.id)" :aria-label="'Pilih ' + item.name"></td>
                <td class="text-right font-mono text-xs text-muted" x-text="rowNumber(index)"></td>
                <td><span class="flex items-center gap-2 font-medium text-ink"><svg class="icon text-muted" aria-hidden="true"><use :href="FM.icons + '#' + (item.type === 'd' ? 'folder' : 'file-text')"></use></svg><span x-text="item.name"></span><span class="chip-danger" x-show="item.quarantine">Karantina</span></span></td>
                <td class="max-w-[24rem] break-all font-mono text-xs text-muted" x-text="item.original"></td>
                <td class="whitespace-nowrap text-right font-mono text-xs" x-text="FM.formatBytes(item.size)"></td>
                <td class="whitespace-nowrap text-xs"><span x-text="FM.formatDate(item.deleted_at)"></span><span class="block text-muted" x-text="'oleh ' + item.deleted_by"></span></td>
                <td class="whitespace-nowrap text-right">
                  <button type="button" class="btn-ghost" @click="restore([item.id])">Pulihkan</button>
                  <button type="button" class="btn-ghost text-danger-700 hover:bg-danger-50" @click="purge([item.id])">Hapus</button>
                </td>
              </tr>
            </template>
          </template>
        </tbody>
      </table>
    </div>

    <ul class="divide-y divide-line md:hidden" x-show="phase === 'loading' || phase === 'content'">
      <template x-if="phase === 'loading'"><template x-for="n in 5" :key="n"><li class="space-y-2 p-3"><span class="skeleton block h-4 w-2/3"></span><span class="skeleton block h-3 w-full"></span></li></template></template>
      <template x-if="phase === 'content'">
        <template x-for="(item, index) in items" :key="item.id">
          <li class="flex gap-3 p-3">
            <label class="grid h-11 w-8 shrink-0 place-items-center"><input type="checkbox" class="check" :checked="selected.includes(item.id)" @change="toggle(item.id)" :aria-label="'Pilih ' + item.name"></label>
            <div class="min-w-0 flex-1">
              <p class="font-medium text-ink"><span class="font-mono text-xs text-muted" x-text="rowNumber(index) + '. '"></span><span x-text="item.name"></span> <span class="chip-danger" x-show="item.quarantine">Karantina</span></p>
              <p class="break-all font-mono text-xs text-muted" x-text="item.original"></p>
              <p class="text-xs text-muted" x-text="FM.formatDate(item.deleted_at) + ' · ' + FM.formatBytes(item.size)"></p>
              <div class="mt-2 flex gap-2">
                <button type="button" class="btn-secondary btn-sm" @click="restore([item.id])">Pulihkan</button>
                <button type="button" class="btn-danger-ghost btn-sm" @click="purge([item.id])">Hapus</button>
              </div>
            </div>
          </li>
        </template>
      </template>
    </ul>

    <?php $emptyTitle = 'Tempat sampah kosong'; $emptyText = 'Item yang dihapus dari Pengelola Berkas akan muncul di sini dan dapat dipulihkan.'; $emptyAction = null; require APP_ROOT . '/views/partials/list-states.php'; ?>
    <?php require APP_ROOT . '/views/partials/pager.php'; ?>
  </section>
</div>
