<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data="sizesPage" class="flex flex-col gap-4">
  <div>
    <h1 class="font-display text-lg font-semibold">Ukuran Folder</h1>
    <p class="mt-1 text-sm text-muted">Pemakaian disk per subfolder dan berkas, diurutkan dari yang terbesar. Pilih folder untuk menelusuri isinya.</p>
  </div>

  <form class="panel grid grid-cols-1 items-end gap-3 p-3 md:grid-cols-[minmax(0,1fr)_auto_auto]" @submit.prevent="analyze(form.path)">
    <div>
      <label for="size-path" class="field-label">Folder</label>
      <input id="size-path" type="text" class="input-mono" x-model="form.path" required spellcheck="false" autocomplete="off" placeholder="/var/www/html">
    </div>
    <label class="flex min-h-control items-center gap-2 text-sm"><input type="checkbox" class="check" x-model="form.hidden" @change="data && analyze(data.path)">Tampilkan tersembunyi</label>
    <button type="submit" class="btn-primary" :disabled="phase === 'loading'"><?= $icon('hard-drive') ?><span x-text="phase === 'loading' ? 'Menghitung...' : 'Hitung Ukuran'"></span></button>
  </form>

  <section class="panel min-w-0">
    <div class="flex flex-wrap items-center gap-3 border-b border-line px-4 py-3">
      <button type="button" class="btn-secondary" x-show="data && data.parent" @click="analyze(data.parent)"><?= $icon('arrow-up') ?>Naik Satu Level</button>
      <div class="min-w-0">
        <h2 class="panel-title">Isi folder</h2>
        <p class="break-all font-mono text-xs text-muted" x-text="data ? data.path : '-'"></p>
      </div>
      <p class="ml-auto font-mono text-lg font-semibold text-ink" x-show="phase === 'content' || phase === 'empty'" x-text="data ? FM.formatBytes(data.total) : ''"></p>
    </div>

    <template x-if="phase === 'loading'">
      <ul class="divide-y divide-line"><template x-for="n in 8" :key="n"><li class="flex items-center gap-3 px-4 py-3"><span class="skeleton h-4 w-40"></span><span class="skeleton h-2 flex-1"></span><span class="skeleton h-4 w-16"></span></li></template></ul>
    </template>
    <template x-if="phase === 'idle'">
      <p class="px-4 py-10 text-center text-sm text-muted">Isi path folder, lalu pilih Hitung Ukuran. Perhitungan folder besar dapat memerlukan beberapa detik.</p>
    </template>
    <template x-if="phase === 'empty'">
      <p class="px-4 py-10 text-center text-sm text-muted">Folder ini kosong.</p>
    </template>
    <template x-if="phase === 'error'">
      <div class="flex flex-col items-center gap-2 px-4 py-10 text-center" role="alert">
        <svg class="icon-lg text-danger-700" aria-hidden="true"><use :href="FM.icons + '#circle-alert'"></use></svg>
        <p class="font-medium text-ink">Ukuran folder gagal dihitung</p>
        <p class="max-w-md text-sm text-muted" x-text="errorMessage"></p>
        <button type="button" class="btn-secondary mt-2" @click="analyze(form.path)">Coba Lagi</button>
      </div>
    </template>
    <template x-if="phase === 'content'">
      <div>
        <template x-for="w in data.warnings" :key="w"><p class="border-b border-line bg-warning-50 px-4 py-2 text-sm text-warning-700" x-text="w"></p></template>
        <ol class="max-h-[65vh] divide-y divide-line overflow-y-auto">
          <template x-for="(item, index) in data.items" :key="item.path">
            <li class="grid grid-cols-[2rem_minmax(0,1fr)_auto] items-center gap-x-3 gap-y-1 px-4 py-2 sm:grid-cols-[2rem_minmax(0,16rem)_minmax(0,1fr)_7rem]">
              <span class="text-right font-mono text-xs text-muted" x-text="index + 1"></span>
              <button type="button" class="flex min-h-9 min-w-0 items-center gap-2 text-left" :class="item.type === 'dir' ? 'hover:underline' : 'cursor-default'" @click="item.type === 'dir' && analyze(item.path)" :disabled="item.type !== 'dir'" :aria-label="item.type === 'dir' ? 'Telusuri ' + item.name : item.name">
                <svg class="icon shrink-0" :class="item.type === 'dir' ? 'text-primary-700' : 'text-muted'" aria-hidden="true"><use :href="FM.icons + '#' + (item.type === 'dir' ? 'folder' : 'file-text')"></use></svg>
                <span class="truncate font-medium text-ink" x-text="item.name" :title="item.path"></span>
              </button>
              <span class="text-right font-mono text-xs text-ink sm:col-start-4 sm:row-start-1" x-text="FM.formatBytes(item.bytes)"></span>
              <div class="col-span-2 col-start-2 flex items-center gap-2 sm:col-span-1 sm:col-start-3 sm:row-start-1" role="img" :aria-label="item.percent + ' persen dari total'">
                <div class="h-2 flex-1 overflow-hidden rounded-chip bg-surface-2"><div class="h-full bg-primary-600" :style="`width: ${Math.max(item.percent, 0.5)}%`"></div></div>
                <span class="w-12 text-right font-mono text-xs text-muted" x-text="item.percent + '%'"></span>
              </div>
            </li>
          </template>
        </ol>
      </div>
    </template>
  </section>
</div>
