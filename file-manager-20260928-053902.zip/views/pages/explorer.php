<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;

// Favorite folder list, shown in the tree panel on large screens and in a panel of its own below that.
$favoriteList = function ($rowClass) use ($icon) { ?>
  <p x-show="!favorites.length" class="px-2 py-1.5 text-xs text-muted">Belum ada folder favorit. Buka folder, lalu pilih Tambah ke Favorit.</p>
  <ul class="text-sm" x-show="favorites.length">
    <template x-for="fav in favorites" :key="fav.id">
      <li class="flex items-center gap-1">
        <button type="button" class="flex min-w-0 flex-1 items-center gap-1.5 rounded-chip px-1.5 text-left hover:bg-surface-2 <?= $rowClass ?>"
                :class="fav.path === cwd ? 'bg-primary-50 font-medium text-primary-700' : (fav.available ? 'text-body' : 'text-muted')" @click="openFavorite(fav)" :title="fav.available ? fav.path : fav.path + ' (tidak tersedia)'">
          <svg class="icon shrink-0" :class="fav.available ? '' : 'text-warning-700'" aria-hidden="true"><use :href="FM.icons + '#' + (fav.available ? 'star' : 'triangle-alert')"></use></svg>
          <span class="truncate" x-text="fav.label"></span><span class="sr-only" x-show="!fav.available">, tidak tersedia</span>
        </button>
        <button type="button" class="grid shrink-0 place-items-center rounded-chip text-muted hover:bg-surface-2 hover:text-danger-700 <?= $rowClass ?> w-8" @click="removeFavorite(fav)" :aria-label="'Hapus ' + fav.label + ' dari favorit'" title="Hapus dari favorit"><?= $icon('x') ?></button>
      </li>
    </template>
  </ul>
<?php };
?>
<div x-data="explorer" class="flex flex-col gap-4" @keydown.escape.window="menuFor ? closeMenu(true) : (detail.open ? closeDetail() : null)">
  <div class="flex flex-col gap-3 xl:flex-row xl:items-end xl:justify-between">
    <div class="min-w-0">
      <h1 class="font-display text-lg font-semibold">Pengelola Berkas</h1>
      <nav aria-label="Lokasi folder" class="mt-1">
        <ol class="flex flex-wrap items-center gap-x-1 gap-y-0.5 font-mono text-xs text-muted">
          <template x-for="(crumb, index) in breadcrumbs" :key="crumb.path">
            <li class="flex items-center gap-1">
              <svg class="h-3 w-3" aria-hidden="true" x-show="index > 0"><use :href="FM.icons + '#chevron-right'"></use></svg>
              <button type="button" class="inline-flex min-h-11 items-center rounded-chip px-1 hover:bg-surface hover:text-ink lg:min-h-8" @click="navigate(crumb.path)"
                      :aria-current="index === breadcrumbs.length - 1 ? 'location' : null"
                      :class="index === breadcrumbs.length - 1 ? 'font-semibold text-ink' : ''" x-text="crumb.name"></button>
            </li>
          </template>
          <li x-show="!breadcrumbs.length"><span class="skeleton inline-block h-3 w-48 align-middle"></span></li>
        </ol>
      </nav>
    </div>
    <form class="flex w-full gap-2 xl:w-96" @submit.prevent="goToTyped()">
      <label for="jump-path" class="sr-only">Buka path</label>
      <input id="jump-path" type="text" class="input-mono" :placeholder="unix ? '/var/www/html/situs' : 'D:/laragon/www/situs'" x-model="form.jump" autocomplete="off" spellcheck="false">
      <button type="submit" class="btn-secondary">Buka</button>
    </form>
  </div>

  <div class="flex flex-wrap items-center gap-2">
    <button type="button" class="btn-primary btn-sm" @click="openUpload()" :disabled="!cwd"><?= $icon('upload') ?>Unggah</button>
    <button type="button" class="btn-secondary btn-sm" @click="newFolder()" :disabled="!cwd"><?= $icon('folder-plus') ?>Folder Baru</button>
    <button type="button" class="btn-secondary btn-sm" @click="newFile()" :disabled="!cwd"><?= $icon('file-plus') ?>Berkas Baru</button>
    <button type="button" class="btn-secondary btn-sm" @click="openSearch()" :disabled="!cwd"><?= $icon('text-search') ?>Cari Isi Berkas</button>
    <span class="hidden h-6 w-px bg-line sm:block" aria-hidden="true"></span>
    <button type="button" class="btn-secondary btn-sm" @click="goUp()" :disabled="!parent"><?= $icon('arrow-up') ?>Naik Satu Level</button>
    <button type="button" class="btn-secondary btn-sm btn-icon" @click="reload(); refreshTreeNode(cwd)" aria-label="Muat ulang daftar" title="Muat ulang daftar"><?= $icon('refresh-cw') ?></button>
    <button type="button" class="btn-secondary btn-sm" @click="toggleFavorite()" :disabled="!cwd"><svg class="icon" :class="favoriteOf(cwd) ? 'text-primary-700' : ''" aria-hidden="true"><use :href="FM.icons + '#star'"></use></svg><span x-text="favoriteOf(cwd) ? 'Hapus dari Favorit' : 'Tambah ke Favorit'"></span></button>
    <button type="button" class="btn-secondary btn-sm lg:hidden" @click="favoritesOpen = !favoritesOpen" :aria-expanded="favoritesOpen ? 'true' : 'false'" aria-controls="favorites-mobile"><?= $icon('folder-open') ?><span x-text="'Favorit (' + favorites.length + ')'"></span></button>
    <button type="button" class="btn-secondary btn-sm btn-icon hidden md:inline-flex" @click="openModal('shortcuts', {})" aria-label="Pintasan keyboard" title="Pintasan keyboard (?)"><?= $icon('keyboard') ?></button>
  </div>
  <nav id="favorites-mobile" x-show="favoritesOpen" x-cloak class="panel p-2 lg:hidden" aria-label="Folder favorit">
    <?php $favoriteList('min-h-11'); ?>
  </nav>
  <p x-show="cwd && phase !== 'loading' && !cwdAccess.add" x-cloak class="flex items-start gap-2 text-sm text-warning-700" role="status">
    <?= $icon('lock', 'icon mt-0.5') ?><span>Akun PHP tidak dapat menambah berkas atau folder di folder ini, sehingga unggahan dan pembuatan item baru akan ditolak.</span>
  </p>

  <div x-show="clipboard" x-cloak class="panel flex flex-col gap-2 px-3 py-2 lg:flex-row lg:items-center" role="region" aria-label="Item yang siap ditempel">
    <p class="flex min-w-0 flex-1 items-start gap-2 text-sm">
      <?= $icon('clipboard-paste', 'icon mt-0.5 shrink-0 text-primary-700') ?>
      <span class="min-w-0">
        <span class="font-medium text-ink" x-text="clipboard ? describe(clipboard.paths) + (clipboard.kind === 'move' ? ' siap dipindahkan' : ' siap disalin') : ''"></span>
        <span class="block truncate font-mono text-xs text-muted" :title="clipboard ? clipboard.from : ''" x-text="clipboard ? 'Dari ' + clipboard.from : ''"></span>
        <span class="block text-xs text-muted" x-show="clipboard && clipboard.from === cwd">Buka folder tujuan terlebih dahulu. Item tidak dapat ditempel di folder asalnya.</span>
      </span>
    </p>
    <div class="flex flex-wrap items-center gap-2">
      <label class="flex min-h-control items-center gap-2 text-sm"><input type="checkbox" class="check" x-model="pasteOverwrite">Timpa item dengan nama yang sama</label>
      <button type="button" class="btn-primary" @click="paste()" :disabled="pasteBlocked()"><?= $icon('clipboard-paste') ?>Tempel di Sini</button>
      <button type="button" class="btn-ghost" @click="clearClipboard()">Batalkan</button>
    </div>
  </div>

  <div class="grid gap-4 lg:grid-cols-[15rem_minmax(0,1fr)]">
    <aside class="panel hidden max-h-[calc(100vh-13rem)] min-w-0 overflow-auto p-2 lg:block" aria-label="Pohon folder">
      <nav aria-label="Folder favorit" class="mb-3 border-b border-line pb-3">
        <p class="panel-title px-2 pb-1 pt-1">Favorit</p>
        <?php $favoriteList('min-h-7'); ?>
      </nav>
      <p class="panel-title px-2 pb-2 pt-1">Folder</p>
      <ul role="tree" class="text-sm">
        <template x-for="node in treeRows()" :key="node.path">
          <li role="treeitem" :aria-expanded="node.open ? 'true' : 'false'" class="flex items-center" :style="`padding-left: ${node.depth * 12}px`">
            <button type="button" class="grid h-7 w-6 shrink-0 place-items-center rounded-chip text-muted hover:bg-surface-2" @click="toggleNode(node.path)" :aria-label="(node.open ? 'Ciutkan ' : 'Luaskan ') + node.name">
              <svg class="h-3.5 w-3.5 transition-transform duration-150" :class="node.open ? 'rotate-90' : ''" aria-hidden="true" x-show="!node.loading"><use :href="FM.icons + '#chevron-right'"></use></svg>
              <span class="skeleton h-3 w-3" x-show="node.loading"></span>
            </button>
            <button type="button" class="flex min-h-7 min-w-0 flex-1 items-center gap-1.5 rounded-chip px-1.5 text-left hover:bg-surface-2"
                    :class="node.path === cwd ? 'bg-primary-50 font-medium text-primary-700' : 'text-body'" @click="navigate(node.path)" :title="node.path">
              <svg class="icon shrink-0" aria-hidden="true"><use :href="FM.icons + '#' + (node.open ? 'folder-open' : 'folder')"></use></svg>
              <span class="truncate" :class="node.depth === 0 ? 'font-mono text-xs' : ''" x-text="node.name"></span>
            </button>
          </li>
        </template>
      </ul>
    </aside>

    <section class="panel min-w-0" aria-label="Daftar berkas">
      <div class="flex items-center justify-between gap-2 border-b border-line px-3 py-2 sm:hidden">
        <button type="button" class="btn-secondary" @click="filtersOpen = !filtersOpen" :aria-expanded="filtersOpen ? 'true' : 'false'" aria-controls="explorer-filters">
          <?= $icon('filter') ?><span x-text="'Filter' + (activeFilterCount() ? ' (' + activeFilterCount() + ')' : '')"></span>
        </button>
        <button type="button" class="btn-ghost" x-show="isFiltered()" @click="resetFilters()">Reset Filter</button>
      </div>
      <div id="explorer-filters" class="items-end gap-3 border-b border-line p-3 sm:flex sm:flex-wrap" :class="filtersOpen ? 'grid grid-cols-1' : 'hidden'">
        <div class="sm:w-44">
          <label for="filter-type" class="field-label">Jenis</label>
          <select id="filter-type" class="input" x-model="state.type" @change="setFilter()">
            <option value="">Semua jenis</option>
            <option value="dir">Folder</option>
            <option value="file">Berkas</option>
            <option value="link">Symlink</option>
          </select>
        </div>
        <div class="sm:w-44" x-show="unix">
          <label for="filter-owner" class="field-label">Pemilik</label>
          <input id="filter-owner" type="text" class="input-mono" placeholder="www-data" x-model="state.owner" @input="searchDebounced()" autocomplete="off" spellcheck="false">
        </div>
        <div class="sm:w-44" x-show="unix">
          <label for="filter-group" class="field-label">Grup</label>
          <input id="filter-group" type="text" class="input-mono" placeholder="www-data" x-model="state.group" @input="searchDebounced()" autocomplete="off" spellcheck="false">
        </div>
        <fieldset class="flex flex-wrap gap-x-5 gap-y-1 text-sm">
          <legend class="sr-only">Opsi tampilan</legend>
          <label class="flex min-h-control items-center gap-2"><input type="checkbox" class="check" :checked="state.hidden === '1'" @change="state.hidden = $event.target.checked ? '1' : '0'; setFilter()">Tampilkan tersembunyi</label>
          <label class="flex min-h-control items-center gap-2" x-show="unix"><input type="checkbox" class="check" :checked="state.danger === '1'" @change="state.danger = $event.target.checked ? '1' : '0'; setFilter()">Hanya izin berbahaya</label>
          <label class="flex min-h-control items-center gap-2"><input type="checkbox" class="check" :checked="state.recursive === '1'" @change="state.recursive = $event.target.checked ? '1' : '0'; setFilter()">Cari di subfolder</label>
        </fieldset>
        <button type="button" class="btn-secondary" @click="resetFilters()" :disabled="!isFiltered()"><?= $icon('rotate-ccw') ?>Reset Filter</button>
      </div>

      <div x-show="selected.length" x-cloak class="flex flex-wrap items-center gap-2 border-b border-line bg-primary-50 px-3 py-2">
        <p class="mr-1 text-sm font-medium text-primary-700"><span class="font-mono" x-text="FM.formatNumber(selected.length)"></span> item dipilih</p>
        <button type="button" class="btn-secondary btn-sm" @click="downloadSelected()"><?= $icon('download') ?>Unduh</button>
        <button type="button" class="btn-secondary btn-sm" @click="copyToClipboard()"><?= $icon('copy') ?>Salin</button>
        <button type="button" class="btn-secondary btn-sm" @click="cutToClipboard()"><?= $icon('scissors') ?>Potong</button>
        <button type="button" class="btn-secondary btn-sm" @click="transfer('copy')"><?= $icon('copy') ?>Salin ke Folder</button>
        <button type="button" class="btn-secondary btn-sm" @click="transfer('move')"><?= $icon('folder-input') ?>Pindahkan ke Folder</button>
        <button type="button" class="btn-secondary btn-sm" @click="duplicate()"><?= $icon('copy-plus') ?>Duplikat</button>
        <button type="button" class="btn-secondary btn-sm" @click="chmod()" x-show="unix"><?= $icon('key-round') ?>Izin</button>
        <button type="button" class="btn-secondary btn-sm" @click="chown()" x-show="unix"><?= $icon('users') ?>Pemilik</button>
        <button type="button" class="btn-secondary btn-sm" @click="preset()" x-show="unix"><?= $icon('sliders-horizontal') ?>Preset</button>
        <button type="button" class="btn-secondary btn-sm" @click="acl()" x-show="system.acl"><?= $icon('list-checks') ?>ACL</button>
        <button type="button" class="btn-secondary btn-sm" @click="compress()"><?= $icon('archive') ?>Kompres</button>
        <button type="button" class="btn-secondary btn-sm" @click="snapshot()" x-show="unix"><?= $icon('camera') ?>Snapshot</button>
        <button type="button" class="btn-danger-ghost btn-sm" @click="remove()"><?= $icon('trash-2') ?>Hapus</button>
        <button type="button" class="btn-ghost btn-sm sm:ml-auto" @click="clearSelection()">Batal Pilih</button>
      </div>

      <?php $searchLabel = 'Cari nama berkas atau folder'; $searchId = 'file-search'; require APP_ROOT . '/views/partials/list-toolbar.php'; ?>

      <template x-if="truncated || warnings.length">
        <div class="space-y-1 border-b border-line bg-warning-50 px-3 py-2 text-sm text-warning-700" role="status">
          <p x-show="truncated" class="flex items-start gap-2"><svg class="icon mt-0.5" aria-hidden="true"><use :href="FM.icons + '#triangle-alert'"></use></svg>Folder berisi lebih banyak item dari batas tampilan. Gunakan pencarian atau filter untuk menemukan item lainnya.</p>
          <template x-for="warning in warnings" :key="warning"><p class="flex items-start gap-2"><svg class="icon mt-0.5" aria-hidden="true"><use :href="FM.icons + '#triangle-alert'"></use></svg><span x-text="warning"></span></p></template>
        </div>
      </template>

      <div class="table-scroll hidden md:block">
        <table class="data-table">
          <thead>
            <tr>
              <th scope="col" class="w-10"><input type="checkbox" class="check" :checked="allSelected()" @change="toggleAll()" :disabled="phase !== 'content'" aria-label="Pilih semua item di halaman ini"></th>
              <th scope="col" class="w-12 text-right">No</th>
              <th scope="col" :aria-sort="ariaSort('name')"><button type="button" class="sort-btn" @click="sortBy('name')">Nama<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('name')"></use></svg></button></th>
              <th scope="col" class="text-right" :aria-sort="ariaSort('size')"><button type="button" class="sort-btn" @click="sortBy('size')">Ukuran<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('size')"></use></svg></button></th>
              <th scope="col" :aria-sort="ariaSort('mtime')"><button type="button" class="sort-btn" @click="sortBy('mtime')">Diubah<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('mtime')"></use></svg></button></th>
              <th scope="col" x-show="unix" :aria-sort="ariaSort('mode')"><button type="button" class="sort-btn" @click="sortBy('mode')">Izin<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('mode')"></use></svg></button></th>
              <th scope="col" x-show="unix" :aria-sort="ariaSort('owner')"><button type="button" class="sort-btn" @click="sortBy('owner')">Pemilik:Grup<svg class="h-3 w-3" aria-hidden="true"><use :href="sortIcon('owner')"></use></svg></button></th>
              <th scope="col" title="Tindakan yang dapat dilakukan akun PHP pada item ini">Hak Akses</th>
              <th scope="col" class="w-14 text-right">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <template x-if="phase === 'loading'">
              <template x-for="n in 8" :key="n">
                <tr>
                  <td><span class="skeleton block h-4 w-4"></span></td>
                  <td><span class="skeleton ml-auto block h-3 w-5"></span></td>
                  <td><span class="skeleton block h-4 w-56"></span></td>
                  <td><span class="skeleton ml-auto block h-3 w-14"></span></td>
                  <td><span class="skeleton block h-3 w-28"></span></td>
                  <td x-show="unix"><span class="skeleton block h-3 w-24"></span></td>
                  <td x-show="unix"><span class="skeleton block h-3 w-28"></span></td>
                  <td><span class="skeleton block h-3 w-28"></span></td>
                  <td><span class="skeleton ml-auto block h-8 w-8"></span></td>
                </tr>
              </template>
            </template>
            <template x-if="phase === 'content'">
              <template x-for="(item, index) in items" :key="item.path">
                <tr :data-path="item.path" :aria-selected="isSelected(item.path) ? 'true' : 'false'" @dblclick="open(item)" @contextmenu.prevent="openMenu(item, $event)">
                  <td><input type="checkbox" class="check" :checked="isSelected(item.path)" @change="toggle(item.path)" :aria-label="'Pilih ' + item.name"></td>
                  <td class="text-right font-mono text-xs text-muted" x-text="rowNumber(index)"></td>
                  <td class="max-w-[28rem]">
                    <div class="flex min-w-0 items-center gap-2">
                      <svg class="icon shrink-0" :class="item.target_type === 'dir' ? 'text-primary-700' : (item.broken ? 'text-danger-700' : 'text-muted')" aria-hidden="true"><use :href="FM.icons + '#' + iconFor(item)"></use></svg>
                      <button type="button" class="min-w-0 truncate text-left font-medium text-ink hover:underline" @click="open(item)" :title="item.path" x-text="displayName(item)"></button>
                      <template x-for="rule in item.danger" :key="rule"><span class="chip-danger shrink-0" x-text="dangerLabel(rule)"></span></template>
                    </div>
                    <p class="ml-6 truncate font-mono text-xs text-muted" x-show="item.type === 'link'" :title="item.link" x-text="'→ ' + item.link"></p>
                  </td>
                  <td class="whitespace-nowrap text-right font-mono text-xs" x-text="sizeText(item)"></td>
                  <td class="whitespace-nowrap text-xs text-muted" x-text="dateText(item)"></td>
                  <td class="whitespace-nowrap" x-show="unix">
                    <button type="button" class="rounded-chip px-1 font-mono text-xs hover:bg-surface-2" @click="chmod(item)" :disabled="item.type === 'link'" :title="item.type === 'link' ? 'Izin symlink mengikuti berkas tujuannya' : 'Ubah izin'">
                      <span class="font-semibold text-ink" x-text="item.octal"></span> <span class="text-muted" x-text="item.perms"></span>
                    </button>
                  </td>
                  <td class="whitespace-nowrap font-mono text-xs" x-show="unix"><button type="button" class="rounded-chip px-1 hover:bg-surface-2" @click="chown(item)" title="Ubah pemilik" x-text="item.owner + ':' + item.group"></button></td>
                  <td class="whitespace-nowrap">
                    <div class="flex gap-1">
                      <template x-for="right in accessList(item.type, item.access)" :key="right.key">
                        <span :class="right.ok ? 'chip-success' : 'chip-neutral'" :title="right.title">
                          <svg class="h-3 w-3" aria-hidden="true"><use :href="FM.icons + '#' + (right.ok ? 'check' : 'x')"></use></svg><span x-text="right.label"></span><span class="sr-only" x-text="right.ok ? ' diizinkan' : ' tidak diizinkan'"></span>
                        </span>
                      </template>
                    </div>
                  </td>
                  <td class="text-right">
                    <button type="button" class="btn-ghost btn-icon" @click="openMenu(item, $event)" :aria-label="'Aksi untuk ' + item.name" aria-haspopup="menu" :aria-expanded="menuFor && menuFor.item.path === item.path ? 'true' : 'false'"><?= $icon('ellipsis') ?></button>
                  </td>
                </tr>
              </template>
            </template>
          </tbody>
        </table>
      </div>

      <ul class="divide-y divide-line md:hidden" x-show="phase === 'loading' || phase === 'content'">
        <template x-if="phase === 'loading'">
          <template x-for="n in 6" :key="n">
            <li class="flex items-center gap-3 px-3 py-3"><span class="skeleton h-5 w-5"></span><div class="flex-1 space-y-2"><span class="skeleton block h-4 w-2/3"></span><span class="skeleton block h-3 w-1/2"></span></div></li>
          </template>
        </template>
        <template x-if="phase === 'content'">
          <template x-for="(item, index) in items" :key="item.path">
            <li class="flex items-start gap-3 px-3 py-2" :data-path="item.path" :class="isSelected(item.path) ? 'bg-primary-50' : ''" @contextmenu.prevent="openMenu(item, $event)">
              <label class="grid h-11 w-8 shrink-0 place-items-center"><input type="checkbox" class="check" :checked="isSelected(item.path)" @change="toggle(item.path)" :aria-label="'Pilih ' + item.name"></label>
              <button type="button" class="flex min-h-11 min-w-0 flex-1 flex-col items-start justify-center text-left" @click="open(item)">
                <span class="flex max-w-full items-center gap-2">
                  <span class="font-mono text-xs text-muted" x-text="rowNumber(index) + '.'"></span>
                  <svg class="icon shrink-0" :class="item.target_type === 'dir' ? 'text-primary-700' : 'text-muted'" aria-hidden="true"><use :href="FM.icons + '#' + iconFor(item)"></use></svg>
                  <span class="truncate font-medium text-ink" x-text="displayName(item)"></span>
                </span>
                <span class="mt-0.5 font-mono text-xs text-muted" x-text="unix ? item.octal + ' ' + item.perms + ' · ' + item.owner + ':' + item.group + ' · ' + sizeText(item) : item.perms + ' · ' + sizeText(item)"></span>
                <span class="mt-1 flex flex-wrap gap-1">
                      <template x-for="right in accessList(item.type, item.access)" :key="right.key">
                        <span :class="right.ok ? 'chip-success' : 'chip-neutral'" :title="right.title">
                          <svg class="h-3 w-3" aria-hidden="true"><use :href="FM.icons + '#' + (right.ok ? 'check' : 'x')"></use></svg><span x-text="right.label"></span><span class="sr-only" x-text="right.ok ? ' diizinkan' : ' tidak diizinkan'"></span>
                        </span>
                      </template>
                </span>
                <span class="mt-1 flex flex-wrap gap-1" x-show="item.danger.length"><template x-for="rule in item.danger" :key="rule"><span class="chip-danger" x-text="dangerLabel(rule)"></span></template></span>
              </button>
              <button type="button" class="btn-ghost btn-icon shrink-0" @click="openMenu(item, $event)" :aria-label="'Aksi untuk ' + item.name" aria-haspopup="menu"><?= $icon('ellipsis') ?></button>
            </li>
          </template>
        </template>
      </ul>

      <template x-if="phase === 'empty'">
        <div class="flex flex-col items-center gap-2 px-4 py-12 text-center">
          <svg class="icon-lg text-muted" aria-hidden="true"><use :href="FM.icons + '#folder-open'"></use></svg>
          <p class="font-medium text-ink">Folder ini kosong</p>
          <p class="text-sm text-muted">Unggah berkas atau buat folder baru di lokasi ini.</p>
          <div class="mt-2 flex flex-wrap justify-center gap-2">
            <button type="button" class="btn-secondary" @click="openUpload()"><?= $icon('upload') ?>Unggah</button>
            <button type="button" class="btn-secondary" @click="newFolder()"><?= $icon('folder-plus') ?>Folder Baru</button>
          </div>
        </div>
      </template>
      <template x-if="phase === 'filtered'">
        <div class="flex flex-col items-center gap-2 px-4 py-12 text-center">
          <svg class="icon-lg text-muted" aria-hidden="true"><use :href="FM.icons + '#search'"></use></svg>
          <p class="font-medium text-ink">Tidak ada item yang cocok dengan pencarian atau filter ini</p>
          <button type="button" class="btn-secondary mt-2" @click="resetFilters()"><?= $icon('rotate-ccw') ?>Reset Filter</button>
        </div>
      </template>
      <template x-if="phase === 'error'">
        <div class="flex flex-col items-center gap-2 px-4 py-12 text-center" role="alert">
          <svg class="icon-lg text-danger-700" aria-hidden="true"><use :href="FM.icons + '#circle-alert'"></use></svg>
          <p class="font-medium text-ink">Daftar berkas gagal dimuat</p>
          <p class="max-w-md text-sm text-muted" x-text="errorMessage"></p>
          <div class="mt-2 flex flex-wrap justify-center gap-2">
            <button type="button" class="btn-secondary" @click="reload()"><?= $icon('refresh-cw') ?>Muat Ulang</button>
            <button type="button" class="btn-secondary" x-show="roots.length || parent" @click="navigate(parent || roots[0])">Kembali ke Folder Sebelumnya</button>
          </div>
        </div>
      </template>

      <?php require APP_ROOT . '/views/partials/pager.php'; ?>
    </section>
  </div>

  <!-- Row action menu: a dropdown beside its button, or a bottom sheet below 640px -->
  <div x-show="menuFor && menuFor.sheet" x-cloak class="fixed inset-0 z-40 bg-[#0B0F17]/50" x-transition:enter="backdrop-in" x-transition:leave="backdrop-out" aria-hidden="true"></div>
  <div x-show="menuFor" x-cloak x-transition:enter="menu-in" x-transition:leave="menu-out" class="fixed z-40 overflow-y-auto overscroll-contain border border-line bg-surface shadow-[0_8px_24px_-12px_rgba(17,24,39,0.35)]"
       :class="menuView && menuView.sheet ? 'menu-sheet inset-x-0 bottom-0 max-h-[85dvh] rounded-t-card pb-[env(safe-area-inset-bottom)]' : 'w-56 rounded-card'"
       :style="menuView && !menuView.sheet ? `top:${menuView.top}px;left:${menuView.left}px;max-height:${menuView.maxHeight}px` : ''" role="menu" x-ref="rowMenu"
       :aria-label="menuView ? 'Aksi untuk ' + menuView.item.name : null"
       @click.outside="closeMenu(false)" @keydown.tab="closeMenu(false)">
    <template x-if="menuView && menuView.sheet">
      <div class="sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-line bg-surface py-1 pl-4 pr-2">
        <p class="min-w-0 truncate font-display text-sm font-semibold" x-text="menuView.item.name"></p>
        <button type="button" class="btn-ghost btn-icon shrink-0" @click="closeMenu(true)" aria-label="Tutup menu aksi"><?= $icon('x') ?></button>
      </div>
    </template>
    <template x-if="menuView">
      <div class="flex flex-col py-1 text-sm">
        <template x-if="menuView.item.target_type === 'dir'"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('open')"><?= $icon('folder-open') ?>Buka</button></template>
        <template x-if="previewKind(menuView.item)"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('preview')"><?= $icon('eye') ?>Pratinjau</button></template>
        <template x-if="menuView.item.type === 'file'"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('edit')"><?= $icon('file-pen') ?>Lihat atau Edit</button></template>
        <template x-if="menuView.item.type === 'file'"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('download')"><?= $icon('download') ?>Unduh</button></template>
        <template x-if="menuView.item.type === 'dir'"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('download')"><?= $icon('download') ?>Unduh sebagai Arsip</button></template>
        <button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('rename')"><?= $icon('text-cursor-input') ?>Ganti Nama</button>
        <button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('copyToClipboard')"><?= $icon('copy') ?>Salin</button>
        <button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('cutToClipboard')"><?= $icon('scissors') ?>Potong</button>
        <button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('copyItem')"><?= $icon('copy') ?>Salin ke Folder</button>
        <button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('moveItem')"><?= $icon('folder-input') ?>Pindahkan ke Folder</button>
        <button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('duplicate')"><?= $icon('copy-plus') ?>Duplikat</button>
        <button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('compress')"><?= $icon('archive') ?>Kompres</button>
        <template x-if="isArchive(menuView.item)"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('extract')"><?= $icon('package-open') ?>Ekstrak</button></template>
        <div class="my-1 border-t border-line" role="separator"></div>
        <template x-if="unix && menuView.item.type !== 'link'"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('chmod')"><?= $icon('key-round') ?>Ubah Izin</button></template>
        <template x-if="unix"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('chown')"><?= $icon('users') ?>Ubah Pemilik</button></template>
        <template x-if="unix && menuView.item.type !== 'link'"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('preset')"><?= $icon('sliders-horizontal') ?>Terapkan Preset</button></template>
        <template x-if="system.acl && menuView.item.type !== 'link'"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('acl')"><?= $icon('list-checks') ?>Kelola ACL</button></template>
        <template x-if="unix"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('snapshot')"><?= $icon('camera') ?>Snapshot Izin</button></template>
        <template x-if="menuView.item.url"><button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('copyItemLink')"><?= $icon('link') ?>Salin Link</button></template>
        <button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left hover:bg-surface-2" @click="menuAction('showDetail')"><?= $icon('info') ?>Detail</button>
        <div class="my-1 border-t border-line" role="separator"></div>
        <button type="button" role="menuitem" class="flex min-h-10 items-center gap-2 px-3 text-left text-danger-700 hover:bg-danger-50" @click="menuAction('remove')"><?= $icon('trash-2') ?>Hapus</button>
      </div>
    </template>
  </div>

  <?php require APP_ROOT . '/views/partials/explorer-modals.php'; ?>

  <!-- Detail drawer -->
  <div x-show="detail.open" x-cloak class="fixed inset-0 z-40 bg-[#0B0F17]/40" x-transition:enter="backdrop-in" x-transition:leave="backdrop-out" @click="closeDetail()" aria-hidden="true"></div>
  <aside x-show="detail.open" x-cloak class="fixed inset-y-0 right-0 z-50 flex w-full flex-col border-l border-line bg-surface sm:w-[28rem]" x-transition:enter="drawer-in" x-transition:leave="drawer-out"
         role="dialog" aria-modal="true" aria-labelledby="detail-title" x-ref="detailPanel" @keydown.tab="FM.trapFocus($event, $refs.detailPanel)">
    <div class="flex items-start justify-between gap-3 border-b border-line px-4 py-3">
      <div class="min-w-0">
        <h2 id="detail-title" class="truncate font-display text-sm font-semibold" x-text="detail.item ? detail.item.name : 'Detail'"></h2>
        <p class="break-all font-mono text-xs text-muted" x-text="detail.item ? detail.item.path : ''"></p>
      </div>
      <button type="button" class="btn-ghost btn-icon -mr-2" @click="closeDetail()" aria-label="Tutup detail" data-autofocus><?= $icon('x') ?></button>
    </div>
    <div class="flex-1 overflow-y-auto p-4 text-sm">
      <template x-if="detail.loading"><div class="space-y-3"><div class="skeleton h-4 w-2/3"></div><div class="skeleton h-4 w-1/2"></div><div class="skeleton h-24 w-full"></div></div></template>
      <template x-if="detail.error"><p class="text-danger-700" role="alert" x-text="detail.error"></p></template>
      <template x-if="detail.data && detail.data.entry">
        <div class="space-y-5">
          <dl class="grid grid-cols-[8rem_minmax(0,1fr)] gap-x-3 gap-y-2">
            <dt class="text-muted">Jenis</dt><dd x-text="{dir: 'Folder', file: 'Berkas', link: 'Symlink', other: 'Lainnya'}[detail.data.entry.type]"></dd>
            <dt class="text-muted" x-text="unix ? 'Izin' : 'Atribut'"></dt><dd class="font-mono"><span class="font-semibold text-ink" x-show="unix" x-text="detail.data.entry.octal + ' '"></span><span x-text="detail.data.entry.perms"></span></dd>
            <dt class="text-muted" x-show="unix">Pemilik</dt><dd class="font-mono" x-show="unix" x-text="detail.data.entry.owner + ' (UID ' + detail.data.entry.uid + ')'"></dd>
            <dt class="text-muted" x-show="unix">Grup</dt><dd class="font-mono" x-show="unix" x-text="detail.data.entry.group + ' (GID ' + detail.data.entry.gid + ')'"></dd>
            <dt class="text-muted">Ukuran</dt><dd class="font-mono" x-text="FM.formatBytes(detail.data.entry.size)"></dd>
            <dt class="text-muted">Diubah</dt><dd x-text="FM.formatDate(detail.data.entry.mtime)"></dd>
            <template x-if="detail.data.link_resolved">
              <dt class="text-muted">Tujuan</dt>
            </template>
            <template x-if="detail.data.link_resolved">
              <dd class="break-all font-mono">
                <span x-text="detail.data.entry.link"></span>
                <span class="mt-1 block" x-show="detail.data.link_resolved.path" :class="detail.data.link_resolved.inside_roots ? 'text-muted' : 'text-warning-700'"
                      x-text="(detail.data.link_resolved.inside_roots ? 'Berada di dalam root: ' : 'Berada di luar root: ') + detail.data.link_resolved.path"></span>
                <span class="mt-1 block text-danger-700" x-show="!detail.data.link_resolved.path">Tujuan tautan tidak ditemukan.</span>
              </dd>
            </template>
            <template x-if="detail.data.url">
              <dt class="text-muted">Link</dt>
            </template>
            <template x-if="detail.data.url">
              <dd class="min-w-0">
                <a class="break-all font-mono font-medium text-primary-700 hover:underline" :href="detail.data.url" target="_blank" rel="noopener noreferrer" x-text="detail.data.url"></a>
                <span class="mt-2 flex flex-wrap gap-2">
                  <button type="button" class="btn-secondary btn-sm" @click="copyLink(detail.data.url)"><?= $icon('link') ?>Salin Link</button>
                  <a class="btn-secondary btn-sm" :href="detail.data.url" target="_blank" rel="noopener noreferrer"><?= $icon('external-link') ?>Buka</a>
                </span>
              </dd>
            </template>
          </dl>
          <section x-show="detail.data.entry.type === 'file'">
            <h3 class="panel-title mb-2">Checksum</h3>
            <template x-if="!checksum.data">
              <div>
                <button type="button" class="btn-secondary" @click="computeChecksum()" :disabled="checksum.loading"><?= $icon('fingerprint') ?><span x-text="checksum.loading ? 'Menghitung...' : 'Hitung MD5 dan SHA-256'"></span></button>
                <p class="mt-1 text-xs text-muted">Bandingkan dengan checksum salinan di tempat lain untuk memastikan isinya sama. Berkas besar membutuhkan waktu lebih lama.</p>
                <p class="mt-1 text-danger-700" role="alert" x-show="checksum.error" x-text="checksum.error"></p>
              </div>
            </template>
            <template x-if="checksum.data">
              <dl class="space-y-2">
                <div><dt class="text-muted">MD5</dt><dd class="select-all break-all font-mono text-xs text-ink" x-text="checksum.data.md5"></dd></div>
                <div><dt class="text-muted">SHA-256</dt><dd class="select-all break-all font-mono text-xs text-ink" x-text="checksum.data.sha256"></dd></div>
              </dl>
            </template>
          </section>
          <section x-show="detail.data.access">
            <h3 class="panel-title mb-2">Hak akses</h3>
            <template x-if="detail.data.access">
              <div>
                <ul class="flex flex-wrap gap-1">
                  <template x-for="right in accessList(detail.data.entry.type, detail.data.access)" :key="right.key">
                    <li :class="right.ok ? 'chip-success' : 'chip-neutral'">
                      <svg class="h-3 w-3" aria-hidden="true"><use :href="FM.icons + '#' + (right.ok ? 'check' : 'x')"></use></svg><span x-text="right.text"></span>
                    </li>
                  </template>
                </ul>
                <p class="mt-2 text-muted" x-show="detail.data.access.note" x-text="detail.data.access.note"></p>
              </div>
            </template>
          </section>
          <section x-show="detail.data.entry.danger.length">
            <h3 class="panel-title mb-2">Peringatan izin</h3>
            <ul class="flex flex-wrap gap-1"><template x-for="rule in detail.data.entry.danger" :key="rule"><li class="chip-danger" x-text="dangerLabel(rule)"></li></template></ul>
          </section>
          <section x-show="detail.data.acl">
            <h3 class="panel-title mb-2">ACL</h3>
            <template x-if="detail.data.acl">
              <div>
                <p class="mb-2 text-muted" x-show="!detail.data.acl.extended">Tidak ada entri ACL tambahan. Akses mengikuti izin standar.</p>
                <table class="data-table rounded-control border border-line" x-show="detail.data.acl.entries.length">
                  <thead><tr><th scope="col">Jenis</th><th scope="col">Nama</th><th scope="col">Izin</th></tr></thead>
                  <tbody>
                    <template x-for="row in detail.data.acl.entries.concat(detail.data.acl.default.map((r) => Object.assign({}, r, { tag: 'default:' + r.tag })))" :key="row.tag + row.qualifier">
                      <tr><td class="font-mono text-xs" x-text="row.tag"></td><td class="font-mono text-xs" x-text="row.qualifier || '-'"></td><td class="font-mono text-xs"><span x-text="row.perms"></span> <span class="text-warning-700" x-show="row.effective" x-text="'(efektif ' + row.effective + ')'"></span></td></tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </template>
          </section>
        </div>
      </template>
    </div>
  </aside>
</div>
