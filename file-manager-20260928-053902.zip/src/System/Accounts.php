<?php
/** @author Ertha Dwi Setiyawan */

namespace App\System;

/**
 * User and group lookups on a Linux host without a shell. The posix extension
 * is asked first because it also sees accounts from LDAP or other NSS sources;
 * /etc/passwd and /etc/group are the fallback when the extension is missing.
 */
final class Accounts
{
    /** @var array|null */
    private static $passwd;

    /** @var array|null */
    private static $group;

    /** @var array<int,string|null> listings ask for the same few ids thousands of times */
    private static $userNames = [];

    /** @var array<int,string|null> */
    private static $groupNames = [];

    /**
     * False when neither the posix extension nor /etc/passwd is usable, so a missing
     * name cannot be taken as proof that the account does not exist.
     */
    public static function available()
    {
        return function_exists('posix_getpwuid') || self::passwd();
    }

    public static function userName($uid)
    {
        $uid = (int) $uid;
        if (!array_key_exists($uid, self::$userNames)) {
            self::$userNames[$uid] = null;
            if (function_exists('posix_getpwuid')) {
                $info = @posix_getpwuid($uid);
                self::$userNames[$uid] = is_array($info) ? $info['name'] : null;
            } else {
                foreach (self::passwd() as $row) {
                    if ($row['id'] === $uid) {
                        self::$userNames[$uid] = $row['name'];
                        break;
                    }
                }
            }
        }
        return self::$userNames[$uid];
    }

    public static function groupName($gid)
    {
        $gid = (int) $gid;
        if (!array_key_exists($gid, self::$groupNames)) {
            self::$groupNames[$gid] = null;
            if (function_exists('posix_getgrgid')) {
                $info = @posix_getgrgid($gid);
                self::$groupNames[$gid] = is_array($info) ? $info['name'] : null;
            } else {
                foreach (self::group() as $row) {
                    if ($row['id'] === $gid) {
                        self::$groupNames[$gid] = $row['name'];
                        break;
                    }
                }
            }
        }
        return self::$groupNames[$gid];
    }

    /**
     * @return array{name:string,uid:int,gid:int}|null
     */
    public static function user($name)
    {
        if (ctype_digit((string) $name)) {
            $resolved = self::userName((int) $name);
            return $resolved === null ? null : self::user($resolved);
        }
        if (function_exists('posix_getpwnam')) {
            $info = @posix_getpwnam((string) $name);
            return is_array($info) ? ['name' => $info['name'], 'uid' => (int) $info['uid'], 'gid' => (int) $info['gid']] : null;
        }
        foreach (self::passwd() as $row) {
            if ($row['name'] === (string) $name) {
                return ['name' => $row['name'], 'uid' => $row['id'], 'gid' => $row['gid']];
            }
        }
        return null;
    }

    public static function groupExists($name)
    {
        if (ctype_digit((string) $name)) {
            return self::groupName((int) $name) !== null;
        }
        if (function_exists('posix_getgrnam')) {
            return is_array(@posix_getgrnam((string) $name));
        }
        foreach (self::group() as $row) {
            if ($row['name'] === (string) $name) {
                return true;
            }
        }
        return false;
    }

    /**
     * Primary and supplementary groups of an account, like id -G and id -Gn.
     *
     * @return array{gids:int[],groups:string[]}
     */
    public static function membership(array $user)
    {
        $gids = [$user['gid']];
        foreach (self::group() as $row) {
            if (in_array($user['name'], $row['members'], true)) {
                $gids[] = $row['id'];
            }
        }
        $gids = array_values(array_unique($gids));
        $names = [];
        foreach ($gids as $gid) {
            $name = self::groupName($gid);
            $names[] = $name === null ? (string) $gid : $name;
        }
        return ['gids' => $gids, 'groups' => $names];
    }

    public static function current()
    {
        if (function_exists('posix_geteuid')) {
            $name = self::userName(posix_geteuid());
            if ($name !== null) {
                return $name;
            }
        }
        return (string) get_current_user();
    }

    /**
     * @return array{users:array[],groups:array[]} name and id of every local account and group
     */
    public static function all()
    {
        $users = [];
        foreach (self::passwd() as $row) {
            $users[] = ['name' => $row['name'], 'id' => $row['id']];
        }
        $groups = [];
        foreach (self::group() as $row) {
            $groups[] = ['name' => $row['name'], 'id' => $row['id']];
        }
        return ['users' => $users, 'groups' => $groups];
    }

    private static function passwd()
    {
        if (self::$passwd === null) {
            self::$passwd = [];
            foreach (self::lines('/etc/passwd') as $parts) {
                if (count($parts) >= 4) {
                    self::$passwd[] = ['name' => $parts[0], 'id' => (int) $parts[2], 'gid' => (int) $parts[3]];
                }
            }
        }
        return self::$passwd;
    }

    private static function group()
    {
        if (self::$group === null) {
            self::$group = [];
            foreach (self::lines('/etc/group') as $parts) {
                if (count($parts) >= 3) {
                    $members = isset($parts[3]) && $parts[3] !== '' ? explode(',', $parts[3]) : [];
                    self::$group[] = ['name' => $parts[0], 'id' => (int) $parts[2], 'members' => $members];
                }
            }
        }
        return self::$group;
    }

    /**
     * @return array[] colon-separated fields per line; empty when the file cannot be read (open_basedir, permissions)
     */
    private static function lines($file)
    {
        $content = @file_get_contents($file);
        if (!is_string($content)) {
            return [];
        }
        $out = [];
        foreach (explode("\n", $content) as $line) {
            $line = trim($line);
            if ($line !== '' && $line[0] !== '#') {
                $out[] = explode(':', $line);
            }
        }
        return $out;
    }
}
