<?php
/** @author Ertha Dwi Setiyawan */

namespace App\System;

final class Shell
{
    /**
     * POSIX single-quote escaping. PHP's escapeshellarg() follows the host OS
     * rules, so it is not used: commands always run under /bin/sh.
     */
    public static function quote($value)
    {
        return "'" . str_replace("'", "'\\''", $value) . "'";
    }

    /**
     * @param string[] $values
     */
    public static function quoteAll(array $values)
    {
        return implode(' ', array_map([self::class, 'quote'], $values));
    }

    /**
     * Splits paths into argument groups so no single command line grows past a safe length.
     *
     * @param string[] $paths
     * @return string[][]
     */
    public static function chunkArgs(array $paths, $maxBytes = 60000)
    {
        $chunks = [];
        $current = [];
        $size = 0;
        foreach ($paths as $path) {
            $len = strlen($path) + 4;
            if ($current && $size + $len > $maxBytes) {
                $chunks[] = $current;
                $current = [];
                $size = 0;
            }
            $current[] = $path;
            $size += $len;
        }
        if ($current) {
            $chunks[] = $current;
        }
        return $chunks;
    }

    /**
     * Escapes a term for find's -name/-iname glob so it matches literally.
     */
    public static function globLiteral($term)
    {
        return addcslashes($term, '\\*?[]');
    }
}
