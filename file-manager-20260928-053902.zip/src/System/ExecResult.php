<?php
/** @author Ertha Dwi Setiyawan */

namespace App\System;

final class ExecResult
{
    /** @var string */
    public $stdout;

    /** @var string */
    public $stderr;

    /** @var int */
    public $exitCode;

    /** @var bool */
    public $timedOut;

    public function __construct($stdout, $stderr, $exitCode, $timedOut)
    {
        $this->stdout = $stdout;
        $this->stderr = $stderr;
        $this->exitCode = $exitCode;
        $this->timedOut = $timedOut;
    }

    public function ok()
    {
        return $this->exitCode === 0 && !$this->timedOut;
    }

    /**
     * @return string[] non-empty stderr lines, capped
     */
    public function errorLines($max = 20)
    {
        $lines = array_values(array_filter(array_map('trim', explode("\n", $this->stderr)), 'strlen'));
        return array_slice($lines, 0, $max);
    }
}
