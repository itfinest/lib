<?php
/** @author Ertha Dwi Setiyawan */

namespace App\System;

use App\Http\HttpException;
use App\Support\Config;

/**
 * Runs shell commands on the local Linux host. Every command the tool
 * executes passes through here, so the command shown in a preview is exactly
 * the command that runs. Where no shell is available (Windows, or a Linux host
 * with proc_open disabled) the same work runs through native PHP functions in
 * App\Fs\NativeFs instead.
 */
final class Runner
{
    const MAX_OUTPUT = 67108864;
    const MAX_STDERR = 65536;

    public static function isWindows()
    {
        // PHP_OS rather than PHP_OS_FAMILY, which only exists from PHP 7.2.
        return strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
    }

    public static function supported()
    {
        return self::isWindows() || PHP_OS === 'Linux';
    }

    public static function assertSupported()
    {
        if (!self::supported()) {
            throw new HttpException(503, 'Aplikasi ini hanya berjalan di server Linux atau Windows.');
        }
    }

    /**
     * True on a Linux host where proc_open may run shell commands.
     */
    public static function shell()
    {
        static $shell = null;
        if ($shell === null) {
            $shell = !self::isWindows() && PHP_OS === 'Linux' && function_exists('proc_open') && self::functionEnabled('proc_open');
        }
        return $shell;
    }

    /**
     * True when file work runs through native PHP functions instead of shell commands.
     */
    public static function native()
    {
        return !self::shell();
    }

    /**
     * The sudo setting only takes effect through the shell; native PHP always acts as the PHP account.
     */
    public static function sudo()
    {
        return self::shell() && Config::get('sudo') === true;
    }

    /**
     * Mode bits, owners, groups, and POSIX ACLs only exist on the Linux host.
     */
    public static function unixPermissions()
    {
        return !self::isWindows();
    }

    public static function assertUnixPermissions()
    {
        if (!self::unixPermissions()) {
            throw new HttpException(501, 'Fitur izin Unix (chmod, chown, ACL, snapshot, audit, kepemilikan, dan pemeriksaan web server) hanya tersedia di server Linux.');
        }
    }

    /**
     * True when long work may run to the end: the PHP time limit is lifted for signed-in
     * requests and shell commands wait without the command_timeout deadline.
     */
    public static function noTimeLimit()
    {
        return Config::get('no_time_limit', true) !== false;
    }

    /**
     * Lifts max_execution_time for the current request. A change also keeps running when the
     * browser disconnects, so it is never left half done; a download still stops with its reader.
     */
    public static function liftTimeLimit($finishWhenAborted)
    {
        if (function_exists('set_time_limit') && self::functionEnabled('set_time_limit')) {
            @set_time_limit(0);
        }
        if ($finishWhenAborted && function_exists('ignore_user_abort') && self::functionEnabled('ignore_user_abort')) {
            ignore_user_abort(true);
        }
    }

    /**
     * Account the PHP process runs as.
     */
    public static function processUser()
    {
        if (self::isWindows()) {
            $name = getenv('USERNAME');
            return is_string($name) ? $name : '';
        }
        if (self::native()) {
            return Accounts::current();
        }
        return trim(self::run('id -un', null, 5)->stdout);
    }

    /**
     * The command as it is actually handed to /bin/sh, including the sudo wrapper when enabled.
     */
    public static function wrap($command)
    {
        if (Config::get('sudo') === true) {
            return 'sudo -n sh -c ' . Shell::quote($command);
        }
        return $command;
    }

    public static function run($command, $stdin = null, $timeout = null)
    {
        self::assertShell();
        // A timeout of 0 lets the command run until it ends; only calls without their own limit get it.
        $timeout = (isset($timeout) ? $timeout : (self::noTimeLimit() ? 0 : Config::int('command_timeout', 120)));
        $process = proc_open(self::wrap($command), [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ], $pipes, null, ['LC_ALL' => 'C', 'PATH' => '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin']);
        if (!is_resource($process)) {
            throw new HttpException(500, 'Perintah sistem tidak dapat dijalankan.');
        }

        if ($stdin !== null && $stdin !== '') {
            fwrite($pipes[0], $stdin);
        }
        fclose($pipes[0]);
        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);

        $stdout = '';
        $stderr = '';
        $timedOut = false;
        $deadline = $timeout > 0 ? microtime(true) + $timeout : null;
        $open = [1 => $pipes[1], 2 => $pipes[2]];

        while ($open) {
            $sec = null;
            $usec = 0;
            if ($deadline !== null) {
                $remaining = $deadline - microtime(true);
                if ($remaining <= 0) {
                    $timedOut = true;
                    break;
                }
                $sec = (int) floor($remaining);
                $usec = (int) (($remaining - $sec) * 1000000);
            }
            $read = array_values($open);
            $write = null;
            $except = null;
            if (@stream_select($read, $write, $except, $sec, $usec) === false) {
                break;
            }
            foreach ($open as $index => $pipe) {
                $chunk = fread($pipe, 65536);
                if ($chunk !== false && $chunk !== '') {
                    if ($index === 1) {
                        $stdout .= $chunk;
                    } elseif (strlen($stderr) < self::MAX_STDERR) {
                        $stderr .= $chunk;
                    }
                }
                if (feof($pipe)) {
                    fclose($pipe);
                    unset($open[$index]);
                }
            }
            if (strlen($stdout) > self::MAX_OUTPUT) {
                $stderr .= "\nOutput melebihi batas dan dihentikan.";
                $timedOut = true;
                break;
            }
        }

        foreach ($open as $pipe) {
            fclose($pipe);
        }
        if ($timedOut) {
            proc_terminate($process, 9);
        }
        $exit = proc_close($process);

        return new ExecResult($stdout, $stderr, $timedOut ? 124 : (int) $exit, $timedOut);
    }

    /**
     * Streams stdout straight to the client (downloads) without buffering the whole file.
     */
    public static function passthru($command)
    {
        self::assertShell();
        $process = proc_open(self::wrap($command), [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ], $pipes, null, ['LC_ALL' => 'C', 'PATH' => '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin']);
        if (!is_resource($process)) {
            throw new HttpException(500, 'Perintah sistem tidak dapat dijalankan.');
        }
        fclose($pipes[0]);
        while (!feof($pipes[1])) {
            $chunk = fread($pipes[1], 65536);
            if ($chunk === false) {
                break;
            }
            echo $chunk;
            flush();
        }
        fclose($pipes[1]);
        fclose($pipes[2]);
        return proc_close($process);
    }

    /**
     * Checks which optional tools exist on the host.
     *
     * @return array<string,bool>
     */
    public static function tools()
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        if (self::native()) {
            // Archives are handled by the zip extension; the Unix tools are never called.
            $zip = class_exists('ZipArchive');
            $cache = ['zip' => $zip, 'unzip' => $zip];
            return $cache;
        }
        $names = ['find', 'chmod', 'chown', 'du', 'realpath', 'getent', 'getfacl', 'setfacl', 'ps', 'id', 'tar', 'zip', 'unzip'];
        $script = '';
        foreach ($names as $name) {
            $script .= 'command -v ' . $name . ' >/dev/null 2>&1 && echo ' . $name . '; ';
        }
        $found = array_filter(explode("\n", self::run($script, null, 10)->stdout));
        $cache = [];
        foreach ($names as $name) {
            $cache[$name] = in_array($name, $found, true);
        }
        return $cache;
    }

    public static function hasTool($name)
    {
        $tools = self::tools();
        return !empty($tools[$name]);
    }

    /**
     * Shell commands are POSIX sh; a call without a usable shell is a programming error, never user input.
     */
    private static function assertShell()
    {
        self::assertSupported();
        if (!self::shell()) {
            throw new \LogicException('Perintah shell tidak dipakai tanpa proc_open.');
        }
    }

    private static function functionEnabled($name)
    {
        $disabled = array_map('trim', explode(',', (string) ini_get('disable_functions')));
        return !in_array($name, $disabled, true);
    }
}
