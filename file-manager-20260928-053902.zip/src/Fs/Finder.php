<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Fs;

use App\System\ExecResult;
use App\System\Runner;
use App\System\Shell;

/**
 * Reads file metadata through GNU find -printf. One shell call returns every
 * field the UI needs, NUL-separated so any file name is parsed safely. Without
 * a shell (Windows, or Linux with proc_open disabled) the same reads go through
 * NativeFs, which understands the "match" option instead of the raw find
 * "conditions", so a caller that filters passes both.
 */
final class Finder
{
    const FORMAT = '%y\0%Y\0%m\0%U\0%G\0%u\0%g\0%s\0%T@\0%l\0%p\0';
    const FIELDS = 11;

    /**
     * @param string[] $starts resolved start paths
     * @param array $opt mindepth, maxdepth, hidden (bool), conditions (raw find expression, already escaped), match (search, type, filter; native), xdev, prune (paths to skip), prune_names (folder names to skip at any depth, any case), hide_names (file or folder names to skip at any depth, any case), limit
     * @return array{entries:array[],truncated:bool,warnings:string[]}
     */
    public static function scan(array $starts, array $opt)
    {
        if (Runner::native()) {
            return NativeFs::scan($starts, $opt);
        }
        $limit = (int) (isset($opt['limit']) ? $opt['limit'] : 5000);
        // One record more than the limit tells us the result was cut off.
        $cmd = self::command($starts, $opt, '-printf ' . Shell::quote(self::FORMAT))
            . ' | head -z -n ' . (($limit + 1) * self::FIELDS);

        $result = Runner::run($cmd);
        $entries = self::parse($result->stdout);
        $truncated = count($entries) > $limit;
        if ($truncated) {
            $entries = array_slice($entries, 0, $limit);
        }
        return [
            'entries' => $entries,
            'truncated' => $truncated,
            'warnings' => self::warnings($result),
        ];
    }

    /**
     * Counts matching entries without transferring their metadata.
     *
     * @return array{count:int,capped:bool}
     */
    public static function count(array $starts, array $opt, $cap = 1000000)
    {
        if (Runner::native()) {
            return NativeFs::count($starts, $opt, $cap);
        }
        $cmd = self::command($starts, $opt, '-printf .') . ' | head -c ' . ($cap + 1) . ' | wc -c';
        $count = (int) trim(Runner::run($cmd)->stdout);
        return ['count' => min($count, $cap), 'capped' => $count > $cap];
    }

    /**
     * The find command without its output stage, reused by the operations that
     * act on exactly the entries a dry run reports.
     */
    public static function command(array $starts, array $opt, $action)
    {
        $cmd = 'find -P ' . Shell::quoteAll($starts);
        if (!empty($opt['xdev'])) {
            $cmd .= ' -xdev';
        }
        if (isset($opt['mindepth'])) {
            $cmd .= ' -mindepth ' . (int) $opt['mindepth'];
        }
        if (isset($opt['maxdepth'])) {
            $cmd .= ' -maxdepth ' . (int) $opt['maxdepth'];
        }
        $skip = [];
        foreach ((array) (isset($opt['prune']) ? $opt['prune'] : []) as $path) {
            $skip[] = '-path ' . Shell::quote($path);
        }
        $names = (array) (isset($opt['prune_names']) ? $opt['prune_names'] : []);
        if ($names) {
            $skip[] = self::nameSkip($names, $starts, '-type d ');
        }
        $hide = (array) (isset($opt['hide_names']) ? $opt['hide_names'] : []);
        if ($hide) {
            $skip[] = self::nameSkip($hide, $starts, '');
        }
        if (empty($opt['hidden'])) {
            $skip[] = '-name ' . Shell::quote('.*');
        }
        $conditions = trim((string) (isset($opt['conditions']) ? $opt['conditions'] : ''));
        $body = ($conditions !== '' ? '\( ' . $conditions . ' \) ' : '') . $action;
        if ($skip) {
            return $cmd . ' \( ' . implode(' -o ', $skip) . ' \) -prune -o \( ' . $body . ' \)';
        }
        return $cmd . ' ' . $body;
    }

    /**
     * find expression matching any of $names (any case), optionally narrowed by $type.
     * A start folder is never skipped by its own name, only the entries below it.
     */
    private static function nameSkip(array $names, array $starts, $type)
    {
        $alternatives = [];
        foreach ($names as $name) {
            $alternatives[] = '-iname ' . Shell::quote(Shell::globLiteral($name));
        }
        $notStart = '';
        foreach ($starts as $start) {
            $notStart .= ' ! -path ' . Shell::quote(Shell::globLiteral($start));
        }
        return '\( ' . $type . '\( ' . implode(' -o ', $alternatives) . ' \)' . $notStart . ' \)';
    }

    /**
     * Metadata for specific entries (depth 0), in input order.
     *
     * @param string[] $paths
     * @return array[] keyed by path
     */
    public static function stat(array $paths)
    {
        if (Runner::native()) {
            return NativeFs::stat($paths);
        }
        $out = [];
        foreach (Shell::chunkArgs($paths) as $chunk) {
            $res = self::scan($chunk, ['maxdepth' => 0, 'hidden' => true, 'limit' => count($chunk)]);
            foreach ($res['entries'] as $entry) {
                $out[$entry['path']] = $entry;
            }
        }
        return $out;
    }

    /**
     * Metadata for one entry, or null when it cannot be read.
     */
    public static function statOne($path)
    {
        $stats = self::stat([$path]);
        return isset($stats[$path]) ? $stats[$path] : null;
    }

    /**
     * @return array[]
     */
    public static function parse($raw)
    {
        if ($raw === '') {
            return [];
        }
        $fields = explode("\0", $raw);
        $entries = [];
        $count = (int) floor(count($fields) / self::FIELDS);
        for ($i = 0; $i < $count; $i++) {
            $f = array_slice($fields, $i * self::FIELDS, self::FIELDS);
            $type = Entry::type($f[0]);
            $mode = octdec($f[2]);
            $path = $f[10];
            $entry = [
                'path' => $path,
                'name' => $path === '/' ? '/' : basename($path),
                'type' => $type,
                'target_type' => $type === 'link' ? Entry::type($f[1]) : $type,
                'broken' => $type === 'link' && in_array($f[1], ['N', 'L', '?'], true),
                'mode' => (int) $mode,
                'octal' => Entry::octal((int) $mode),
                'perms' => Entry::symbolic((int) $mode, $type),
                'uid' => (int) $f[3],
                'gid' => (int) $f[4],
                'owner' => $f[5],
                'group' => $f[6],
                'size' => (int) $f[7],
                'mtime' => (int) floor((float) $f[8]),
                'link' => $f[9],
            ];
            // find prints the numeric id when no account exists for it.
            $entry['orphan'] = $entry['owner'] === (string) $entry['uid'] || $entry['group'] === (string) $entry['gid'];
            $entry['danger'] = Entry::dangers($entry);
            $entries[] = $entry;
        }
        return $entries;
    }

    /**
     * @return string[]
     */
    private static function warnings(ExecResult $result)
    {
        $lines = $result->errorLines(50);
        $denied = 0;
        $other = [];
        foreach ($lines as $line) {
            if (stripos($line, 'Permission denied') !== false) {
                $denied++;
            } else {
                $other[] = $line;
            }
        }
        $warnings = [];
        if ($denied > 0) {
            $warnings[] = 'Sebagian folder tidak dapat dibaca karena izin akses (' . $denied . ' lokasi). Hasil mungkin tidak lengkap.';
        }
        foreach (array_slice($other, 0, 3) as $line) {
            $warnings[] = $line;
        }
        return $warnings;
    }
}
