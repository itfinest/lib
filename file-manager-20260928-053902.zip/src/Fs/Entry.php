<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Fs;

final class Entry
{
    const SENSITIVE_PATTERNS = [
        '.env', '.env.*', '*.pem', '*.key', 'id_rsa', 'id_rsa*', 'id_ed25519*', 'id_ecdsa*',
        '.htpasswd', 'wp-config.php', '*.sql', '*.sql.gz', '*.bak', '*.p12', '*.pfx', '.git-credentials',
    ];

    const TYPES = ['d' => 'dir', 'f' => 'file', 'l' => 'link'];

    public static function type($findType)
    {
        $types = self::TYPES;
        return isset($types[$findType]) ? $types[$findType] : 'other';
    }

    public static function octal($mode)
    {
        return sprintf('%04o', $mode & 07777);
    }

    /**
     * ls-style permission string, e.g. drwxr-sr-x.
     */
    public static function symbolic($mode, $type)
    {
        $prefixes = ['dir' => 'd', 'link' => 'l', 'file' => '-'];
        $prefix = isset($prefixes[$type]) ? $prefixes[$type] : '?';
        $bits = '';
        $specials = [[04000, 's', 'S'], [02000, 's', 'S'], [01000, 't', 'T']];
        foreach ([6, 3, 0] as $i => $shift) {
            $triple = ($mode >> $shift) & 7;
            $bits .= ($triple & 4) ? 'r' : '-';
            $bits .= ($triple & 2) ? 'w' : '-';
            $exec = ($triple & 1) === 1;
            list($flag, $withExec, $withoutExec) = $specials[$i];
            if ($mode & $flag) {
                $bits .= $exec ? $withExec : $withoutExec;
            } else {
                $bits .= $exec ? 'x' : '-';
            }
        }
        return $prefix . $bits;
    }

    public static function isSensitiveName($name)
    {
        foreach (self::SENSITIVE_PATTERNS as $pattern) {
            if (fnmatch($pattern, $name)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Built-in dangerous-permission checks for a single entry.
     *
     * @return string[] rule ids from AuditService::RULES
     */
    public static function dangers(array $entry)
    {
        if ($entry['type'] === 'link') {
            return $entry['broken'] ? ['broken_symlink'] : [];
        }
        $mode = $entry['mode'];
        $found = [];
        $worldWritable = ($mode & 0002) !== 0;
        if (($mode & 0777) === 0777) {
            $found[] = 'mode_777';
        } elseif ($worldWritable && $entry['type'] === 'file') {
            $found[] = 'world_writable_file';
        }
        if ($worldWritable && $entry['type'] === 'dir' && ($mode & 01000) === 0 && ($mode & 0777) !== 0777) {
            $found[] = 'world_writable_dir';
        }
        if ($entry['type'] === 'file' && ($mode & 04000)) {
            $found[] = 'setuid';
        }
        if ($entry['type'] === 'file' && ($mode & 02000)) {
            $found[] = 'setgid';
        }
        if ($entry['type'] === 'file' && ($mode & 0004) && self::isSensitiveName($entry['name'])) {
            $found[] = 'sensitive_readable';
        }
        if ($entry['orphan']) {
            $found[] = 'orphan_owner';
        }
        return $found;
    }
}
