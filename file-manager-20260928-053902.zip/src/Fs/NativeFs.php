<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Fs;

use App\System\Accounts;
use App\System\Runner;
use RuntimeException;
use ZipArchive;

/**
 * Filesystem layer built on native PHP functions. A Linux host with proc_open
 * reads metadata through find and changes files through shell commands; on
 * Windows, and on Linux without proc_open, the same work runs here, so no
 * command line is ever built from input.
 *
 * Windows paths use forward slashes and an upper-case drive letter
 * ("D:/www/site") and compare case-insensitively; Linux paths compare exactly.
 * Links (and Windows junctions) are never followed while walking, copying,
 * compressing, or deleting a tree, so a link that points outside the roots
 * cannot be used to read or remove what lies behind it.
 */
final class NativeFs
{
    const CHUNK = 65536;
    const MAX_DEPTH = 1000;

    public static function normalize($path)
    {
        if (!Runner::isWindows()) {
            // A backslash is an ordinary character in a Linux file name.
            $path = (string) $path;
            return strlen($path) > 1 ? rtrim($path, '/') : $path;
        }
        $path = str_replace('\\', '/', (string) $path);
        // realpath() and readlink() may return the extended-length form.
        if (strncmp($path, '//?/', 4) === 0 || strncmp($path, '/??/', 4) === 0) {
            $path = substr($path, 4);
        }
        if (preg_match('#^[a-zA-Z]:#', $path)) {
            $path = strtoupper($path[0]) . substr($path, 1);
        }
        if (strlen($path) > 3) {
            $path = rtrim($path, '/');
        }
        return $path;
    }

    /**
     * A drive root on Windows ("D:/"), "/" on Linux.
     */
    public static function isFsRoot($path)
    {
        return Runner::isWindows() ? (bool) preg_match('#^[A-Z]:/$#', $path) : $path === '/';
    }

    public static function parent($path)
    {
        if (self::isFsRoot($path)) {
            return $path;
        }
        $slash = strrpos($path, '/');
        if ($slash === false) {
            return $path;
        }
        if ($slash === 0) {
            return '/';
        }
        $parent = substr($path, 0, $slash);
        return preg_match('#^[A-Z]:$#', $parent) ? $parent . '/' : $parent;
    }

    public static function base($path)
    {
        if (self::isFsRoot($path)) {
            return $path;
        }
        $slash = strrpos($path, '/');
        return $slash === false ? $path : substr($path, $slash + 1);
    }

    public static function join($dir, $name)
    {
        return rtrim($dir, '/') . '/' . $name;
    }

    /**
     * Windows paths are case-insensitive, so containment is compared that way there.
     */
    public static function inside($path, $base)
    {
        $path = self::key($path);
        $base = self::key($base);
        $prefix = substr($base, -1) === '/' ? $base : $base . '/';
        return $path === $base || strncmp($path, $prefix, strlen($prefix)) === 0;
    }

    public static function realpath($path)
    {
        $real = @realpath($path);
        return $real === false ? '' : self::normalize($real);
    }

    /**
     * l (symbolic link or junction), d, f, or n (does not exist). The parent
     * part of $path must already be resolved, which every caller guarantees.
     */
    public static function kind($path)
    {
        // filetype() reads the entry itself (lstat): "link" for a symbolic link,
        // "unknown" for a junction. is_link() and is_dir() are not used for this,
        // because they report junctions differently between PHP 7 and PHP 8.
        $type = @filetype($path);
        if ($type === false) {
            return 'n';
        }
        if ($type === 'link' || $type === 'unknown') {
            return 'l';
        }
        if ($type !== 'dir') {
            return 'f';
        }
        // A folder whose real path differs from its own path is a reparse point
        // that filetype() did not recognize.
        $real = self::realpath($path);
        return $real !== '' && self::key($real) !== self::key(self::normalize($path)) ? 'l' : 'd';
    }

    /**
     * Same result shape as Finder::scan. $opt: mindepth, maxdepth, hidden,
     * prune (paths to skip), prune_names (folder names to skip below the starts),
     * hide_names (file or folder names to skip below the starts), limit, match (search, type).
     */
    public static function scan(array $starts, array $opt)
    {
        $limit = (int) (isset($opt['limit']) ? $opt['limit'] : 5000);
        $entries = [];
        $warnings = self::walk($starts, $opt, function ($entry) use (&$entries, $limit) {
            $entries[] = $entry;
            // One record more than the limit tells the caller the result was cut off.
            return count($entries) <= $limit;
        });
        $truncated = count($entries) > $limit;
        if ($truncated) {
            $entries = array_slice($entries, 0, $limit);
        }
        return ['entries' => $entries, 'truncated' => $truncated, 'warnings' => $warnings];
    }

    /**
     * Visits every entry without a limit, for operations that act on a whole tree.
     *
     * @param callable $visit receives an entry; returning false stops the walk
     * @return string[] warnings
     */
    public static function each(array $starts, array $opt, $visit)
    {
        return self::walk($starts, $opt, $visit);
    }

    public static function count(array $starts, array $opt, $cap)
    {
        $count = 0;
        self::walk($starts, $opt, function () use (&$count, $cap) {
            $count++;
            return $count <= $cap;
        });
        return ['count' => min($count, $cap), 'capped' => $count > $cap];
    }

    /**
     * @param string[] $paths
     * @return array[] keyed by path
     */
    public static function stat(array $paths)
    {
        $out = [];
        foreach ($paths as $path) {
            $kind = self::kind($path);
            if ($kind !== 'n') {
                $out[$path] = self::entry($path, $kind);
            }
        }
        return $out;
    }

    /**
     * @param string[] $paths already cleaned
     * @return array<int,array{path:string,type:string}|null> null when the parent folder is missing
     */
    public static function inspect(array $paths)
    {
        $out = [];
        foreach ($paths as $path) {
            if (self::isFsRoot($path)) {
                $real = self::realpath($path);
                $out[] = $real === '' ? null : ['path' => $real, 'type' => 'd'];
                continue;
            }
            $parent = self::realpath(self::parent($path));
            if ($parent === '' || !@is_dir($parent)) {
                $out[] = null;
                continue;
            }
            $full = self::join($parent, self::base($path));
            $out[] = ['path' => $full, 'type' => self::kind($full)];
        }
        return $out;
    }

    public static function makeDir($path, $mode = 0777)
    {
        self::clearError();
        if (!@mkdir($path, $mode)) {
            throw self::failure('Folder tidak dapat dibuat', $path);
        }
    }

    /**
     * Creates a new file; fails instead of overwriting a file created in the meantime.
     */
    public static function createFile($path, $content)
    {
        self::clearError();
        $handle = @fopen($path, 'xb');
        if ($handle === false) {
            throw self::failure('Berkas tidak dapat dibuat', $path);
        }
        $written = fwrite($handle, $content);
        fclose($handle);
        if ($written !== strlen($content)) {
            throw new RuntimeException('Isi berkas tidak tersimpan utuh: ' . $path);
        }
    }

    /**
     * Overwrites the content of an existing file in place, so its ACL stays as it was.
     */
    public static function writeFile($path, $content)
    {
        self::clearError();
        if (@file_put_contents($path, $content, LOCK_EX) !== strlen($content)) {
            throw self::failure('Isi berkas tidak dapat disimpan', $path);
        }
    }

    public static function copyUpload($source, $target, $overwrite)
    {
        self::clearError();
        $in = @fopen($source, 'rb');
        if ($in === false) {
            throw self::failure('Berkas unggahan tidak dapat dibaca', self::base($target));
        }
        $out = @fopen($target, $overwrite ? 'wb' : 'xb');
        if ($out === false) {
            fclose($in);
            throw self::failure('Berkas tidak dapat ditulis', $target);
        }
        stream_copy_to_stream($in, $out);
        fclose($in);
        fclose($out);
    }

    /**
     * Copies one file to a new name; fails instead of overwriting an existing target.
     */
    public static function copyFile($source, $target)
    {
        if (self::kind($target) !== 'n') {
            throw new RuntimeException('Sudah ada berkas atau folder bernama ' . self::base($target) . '.');
        }
        self::clearError();
        if (!@copy($source, $target)) {
            throw self::failure('Berkas tidak dapat disalin', $source);
        }
    }

    public static function rename($from, $to)
    {
        // A change of letter case only is a valid rename on a case-insensitive filesystem.
        if (self::key($from) !== self::key($to) && self::kind($to) !== 'n') {
            throw new RuntimeException('Sudah ada berkas atau folder bernama ' . self::base($to) . '.');
        }
        self::clearError();
        if (!@rename($from, $to)) {
            throw self::failure('Nama tidak dapat diganti', $from);
        }
    }

    /**
     * Copies or moves one entry into a folder under the same name.
     */
    public static function transfer($source, $destDir, $overwrite, $move)
    {
        $target = self::join($destDir, self::base($source));
        if (self::kind($target) !== 'n') {
            if (!$overwrite) {
                throw new RuntimeException('Sudah ada item bernama ' . self::base($source) . ' di folder tujuan.');
            }
            self::remove($target);
        }
        if (!$move) {
            self::copyTree($source, $target);
            return;
        }
        self::clearError();
        if (@rename($source, $target)) {
            return;
        }
        // rename() cannot move a folder to another drive or filesystem; only then is copy plus delete used.
        if (!self::otherDevice($source, $destDir)) {
            throw self::failure('Item tidak dapat dipindahkan', $source);
        }
        self::copyTree($source, $target);
        self::remove($source);
    }

    /**
     * Copies an entry to a new path the way transfer() copies, failing when the target exists.
     */
    public static function copyAs($source, $target)
    {
        if (self::kind($target) !== 'n') {
            throw new RuntimeException('Sudah ada berkas atau folder bernama ' . self::base($target) . '.');
        }
        self::copyTree($source, $target);
    }

    /**
     * Deletes an entry and, for a folder, everything inside it. A symbolic link
     * or junction is removed as a link; the folder it points to is left alone.
     */
    public static function remove($path)
    {
        $kind = self::kind($path);
        if ($kind === 'n') {
            return;
        }
        self::clearError();
        if ($kind === 'l') {
            if (!@unlink($path) && !@rmdir($path)) {
                throw self::failure('Tautan tidak dapat dihapus', $path);
            }
            return;
        }
        if ($kind === 'f') {
            if (!@unlink($path)) {
                // Windows refuses to delete a file with the read-only attribute. On Linux the
                // folder's rights decide, so the file's mode is left as it was.
                if (!Runner::isWindows()) {
                    throw self::failure('Berkas tidak dapat dihapus', $path);
                }
                @chmod($path, 0666);
                if (!@unlink($path)) {
                    throw self::failure('Berkas tidak dapat dihapus', $path);
                }
            }
            return;
        }
        foreach (self::children($path) as $name) {
            self::remove(self::join($path, $name));
        }
        if (!@rmdir($path)) {
            throw self::failure('Folder tidak dapat dihapus', $path);
        }
    }

    /**
     * Total bytes of the files under a path, without following reparse points.
     *
     * @param int $budget entries left to visit; the walk stops at zero
     * @return array{0:int,1:bool} bytes and whether every entry was counted
     */
    public static function size($path, &$budget)
    {
        $kind = self::kind($path);
        $budget--;
        if ($kind === 'f') {
            $bytes = @filesize($path);
            return [$bytes === false ? 0 : (int) $bytes, true];
        }
        if ($kind !== 'd') {
            return [0, true];
        }
        $handle = @opendir($path);
        if ($handle === false) {
            return [0, false];
        }
        $total = 0;
        $complete = true;
        while (($name = readdir($handle)) !== false) {
            if ($name === '.' || $name === '..') {
                continue;
            }
            if ($budget <= 0) {
                $complete = false;
                break;
            }
            list($bytes, $done) = self::size(self::join($path, $name), $budget);
            $total += $bytes;
            $complete = $complete && $done;
        }
        closedir($handle);
        return [$total, $complete];
    }

    public static function readBytes($path, $limit)
    {
        self::clearError();
        $content = @file_get_contents($path, false, null, 0, $limit);
        if ($content === false) {
            throw self::failure('Berkas tidak dapat dibaca', $path);
        }
        return $content;
    }

    /**
     * Streams a file to the client without loading it into memory.
     */
    /**
     * @param int|null $length bytes to send from $offset; null sends the rest of the file
     */
    public static function output($path, $offset = 0, $length = null)
    {
        $handle = @fopen($path, 'rb');
        if ($handle === false) {
            return;
        }
        if ($offset > 0) {
            fseek($handle, $offset);
        }
        $left = $length;
        while (!feof($handle) && ($left === null || $left > 0)) {
            $chunk = fread($handle, $left === null ? self::CHUNK : min(self::CHUNK, $left));
            if ($chunk === false || $chunk === '') {
                break;
            }
            echo $chunk;
            flush();
            if ($left !== null) {
                $left -= strlen($chunk);
            }
        }
        fclose($handle);
    }

    /**
     * Whether a path inside an archive, relative to the folder that holds the
     * compressed items, matches an exclusion pattern. Name patterns test the
     * last segment, path patterns test the whole relative path; "*" crosses "/"
     * in both, as it does in tar and zip.
     *
     * @param array{names:string[],paths:string[]} $patterns
     */
    public static function patternExcluded($local, array $patterns)
    {
        $flags = Runner::isWindows() ? FNM_NOESCAPE | FNM_CASEFOLD : 0;
        $base = self::base($local);
        foreach ($patterns['names'] as $pattern) {
            if (fnmatch($pattern, $base, $flags)) {
                return true;
            }
        }
        foreach ($patterns['paths'] as $pattern) {
            if (fnmatch($pattern, $local, $flags)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param string[] $names entries inside $parent to add
     * @param string[] $exclude paths left out of the archive
     * @param array{names:string[],paths:string[]} $patterns see patternExcluded()
     */
    public static function zipCreate($dest, $parent, array $names, array $exclude, array $patterns)
    {
        $zip = new ZipArchive();
        if ($zip->open($dest, ZipArchive::CREATE | ZipArchive::EXCL) !== true) {
            throw new RuntimeException('Arsip tidak dapat dibuat: ' . $dest);
        }
        $skipped = [];
        try {
            foreach ($names as $name) {
                self::zipAdd($zip, self::join($parent, $name), $name, array_map([self::class, 'key'], $exclude), $patterns, $skipped);
            }
        } catch (RuntimeException $e) {
            @$zip->close();
            @unlink($dest);
            throw $e;
        }
        if (!@$zip->close()) {
            @unlink($dest);
            throw new RuntimeException('Arsip tidak dapat ditulis: ' . $dest);
        }
        if ($skipped) {
            throw new RuntimeException('Arsip dibuat, tetapi symlink atau junction berikut tidak ikut dikompres: ' . self::listSample($skipped));
        }
    }

    /**
     * @return string[] member names, at most $max
     */
    public static function zipList($archive, $max)
    {
        $zip = new ZipArchive();
        if ($zip->open($archive) !== true) {
            throw new RuntimeException('Arsip zip tidak dapat dibuka. Berkas mungkin rusak.');
        }
        $names = [];
        for ($i = 0; $i < $zip->numFiles && count($names) < $max; $i++) {
            $name = $zip->getNameIndex($i);
            if (is_string($name)) {
                $names[] = $name;
            }
        }
        $zip->close();
        return $names;
    }

    /**
     * Extracts member by member. Unsafe paths and blocked names are skipped,
     * existing files are never overwritten, and nothing is written through a
     * reparse point that leads outside the destination.
     *
     * @param callable $blocked receives a file name, returns true when the security policy refuses it
     */
    public static function zipExtract($archive, $dest, $blocked)
    {
        $zip = new ZipArchive();
        if ($zip->open($archive) !== true) {
            throw new RuntimeException('Arsip zip tidak dapat dibuka. Berkas mungkin rusak.');
        }
        $destReal = self::realpath($dest);
        $skipped = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if (!is_string($name)) {
                continue;
            }
            $normalized = str_replace('\\', '/', $name);
            $isDir = substr($normalized, -1) === '/';
            $relative = trim($normalized, '/');
            if (!self::safeMember($normalized)) {
                $skipped[] = $name . ' (path tidak aman)';
                continue;
            }
            if (call_user_func($blocked, self::base($relative))) {
                $skipped[] = $name . ' (diblokir kebijakan keamanan)';
                continue;
            }
            $target = self::join($destReal, $relative);
            $folder = $isDir ? $target : self::parent($target);
            if (!@is_dir($folder) && !@mkdir($folder, 0777, true)) {
                $skipped[] = $name . ' (folder tidak dapat dibuat)';
                continue;
            }
            if (!self::inside(self::realpath($folder), $destReal)) {
                $skipped[] = $name . ' (melewati tautan ke luar folder tujuan)';
                continue;
            }
            if ($isDir || self::kind($target) !== 'n') {
                continue;
            }
            $in = $zip->getStream($name);
            $out = @fopen($target, 'xb');
            if ($in === false || $out === false) {
                $skipped[] = $name . ' (tidak dapat ditulis)';
                if ($in !== false) {
                    fclose($in);
                }
                if ($out !== false) {
                    fclose($out);
                }
                continue;
            }
            stream_copy_to_stream($in, $out);
            fclose($in);
            fclose($out);
        }
        $zip->close();
        if ($skipped) {
            throw new RuntimeException('Sebagian isi arsip dilewati: ' . self::listSample($skipped));
        }
    }

    /**
     * Archive member names must stay inside the destination, and on Windows be valid Windows names.
     */
    public static function safeMember($name)
    {
        if ($name === '' || $name[0] === '/' || preg_match('#^[A-Za-z]:#', $name)) {
            return false;
        }
        foreach (explode('/', trim($name, '/')) as $segment) {
            if ($segment === '' || $segment === '.' || $segment === '..') {
                return false;
            }
            if (Runner::isWindows() && PathGuard::windowsNameProblem($segment) !== null) {
                return false;
            }
        }
        return true;
    }

    /**
     * Runs $change for every path and reports all failures at the end, as chmod does
     * with many arguments: one entry that cannot be changed does not stop the rest.
     *
     * @param callable $change receives a path, throws RuntimeException on failure
     */
    public static function changeEach(array $paths, $change)
    {
        $errors = [];
        foreach ($paths as $path) {
            try {
                call_user_func($change, $path);
            } catch (RuntimeException $e) {
                $errors[] = $e->getMessage();
            }
        }
        if ($errors) {
            $more = count($errors) > 5 ? ' Ada ' . (count($errors) - 5) . ' entri lain yang juga gagal.' : '';
            throw new RuntimeException(implode(' ', array_slice($errors, 0, 5)) . $more);
        }
    }

    /**
     * chmod for one entry; a link is never passed here, since its mode follows its target.
     */
    public static function setMode($path, $mode)
    {
        self::clearError();
        if (!@chmod($path, $mode)) {
            throw self::failure('Izin tidak dapat diubah', $path);
        }
    }

    /**
     * chown and chgrp for one entry, acting on a link itself like chown -h. Without
     * root, PHP may only move a file to another group the account belongs to.
     *
     * @param string|null $owner user name or numeric id; null keeps the owner
     * @param string|null $group group name or numeric id; null keeps the group
     */
    public static function setOwner($path, $owner, $group)
    {
        $link = self::kind($path) === 'l';
        self::clearError();
        if ($owner !== null) {
            $user = ctype_digit($owner) ? (int) $owner : $owner;
            if (!($link ? @lchown($path, $user) : @chown($path, $user))) {
                throw self::failure('Pemilik tidak dapat diubah', $path);
            }
        }
        if ($group !== null) {
            $id = ctype_digit($group) ? (int) $group : $group;
            if (!($link ? @lchgrp($path, $id) : @chgrp($path, $id))) {
                throw self::failure('Grup tidak dapat diubah', $path);
            }
        }
    }

    /**
     * @return string[] warnings in the same wording as the Linux scan
     */
    private static function walk(array $starts, array $opt, $visit)
    {
        $min = isset($opt['mindepth']) ? (int) $opt['mindepth'] : 0;
        $max = isset($opt['maxdepth']) ? (int) $opt['maxdepth'] : self::MAX_DEPTH;
        $hidden = !empty($opt['hidden']);
        $prune = array_map([self::class, 'key'], (array) (isset($opt['prune']) ? $opt['prune'] : []));
        $pruneNames = array_map('strtolower', (array) (isset($opt['prune_names']) ? $opt['prune_names'] : []));
        $hideNames = array_map('strtolower', (array) (isset($opt['hide_names']) ? $opt['hide_names'] : []));
        $match = isset($opt['match']) ? (array) $opt['match'] : [];
        // Like find -xdev: entries on another filesystem are listed but not entered.
        $xdev = !empty($opt['xdev']) && !Runner::isWindows();
        $denied = 0;
        $stack = [];
        foreach (array_reverse($starts) as $start) {
            $stack[] = [$start, 0, null];
        }
        while ($stack) {
            list($path, $depth, $device) = array_pop($stack);
            if (in_array(self::key($path), $prune, true)) {
                continue;
            }
            $kind = self::kind($path);
            if ($kind === 'n') {
                continue;
            }
            if ($depth > 0 && $kind === 'd' && $pruneNames && in_array(strtolower(self::base($path)), $pruneNames, true)) {
                continue;
            }
            if ($depth > 0 && $hideNames && in_array(strtolower(self::base($path)), $hideNames, true)) {
                continue;
            }
            if ($depth >= $min) {
                $entry = self::entry($path, $kind);
                if (self::matches($entry, $match) && call_user_func($visit, $entry) === false) {
                    break;
                }
            }
            if ($kind !== 'd' || $depth >= $max) {
                continue;
            }
            if ($xdev) {
                $stat = @stat($path);
                $here = is_array($stat) ? $stat['dev'] : null;
                if ($device === null) {
                    $device = $here;
                } elseif ($here !== $device) {
                    continue;
                }
            }
            $handle = @opendir($path);
            if ($handle === false) {
                $denied++;
                continue;
            }
            $names = [];
            while (($name = readdir($handle)) !== false) {
                if ($name === '.' || $name === '..' || (!$hidden && $name[0] === '.')) {
                    continue;
                }
                $names[] = $name;
            }
            closedir($handle);
            for ($i = count($names) - 1; $i >= 0; $i--) {
                $stack[] = [self::join($path, $names[$i]), $depth + 1, $device];
            }
        }
        return $denied > 0
            ? ['Sebagian folder tidak dapat dibaca karena izin akses (' . $denied . ' lokasi). Hasil mungkin tidak lengkap.']
            : [];
    }

    /**
     * $match: search (name contains, any case), type (file, dir, link, or folder for a
     * folder or a link to one), and filter (callable taking the entry), the native
     * counterpart of the find conditions a caller passes to the shell.
     */
    private static function matches(array $entry, array $match)
    {
        if (isset($match['filter']) && !call_user_func($match['filter'], $entry)) {
            return false;
        }
        $search = isset($match['search']) ? (string) $match['search'] : '';
        if ($search !== '' && stripos($entry['name'], $search) === false) {
            return false;
        }
        $type = isset($match['type']) ? (string) $match['type'] : '';
        if ($type === 'folder') {
            return $entry['target_type'] === 'dir';
        }
        return $type === '' || $entry['type'] === $type;
    }

    /**
     * One entry in the shape Finder::parse produces. Windows has no Unix mode
     * bits or owners: the mode only reflects the read-only attribute, so the
     * Unix danger rules are not applied.
     */
    private static function entry($path, $kind)
    {
        if (!Runner::isWindows()) {
            return self::unixEntry($path, $kind);
        }
        $type = $kind === 'l' ? 'link' : ($kind === 'd' ? 'dir' : 'file');
        $link = '';
        $broken = false;
        $targetType = $type;
        $statPath = $path;
        if ($type === 'link') {
            $target = @readlink($path);
            $real = self::realpath($path);
            $link = is_string($target) && $target !== '' ? self::normalize($target) : $real;
            $broken = $real === '';
            // PHP 8 returns an empty stat for a junction itself, so its target is read instead.
            $statPath = $real;
            $targetType = $broken ? 'other' : (@is_dir($real) ? 'dir' : 'file');
        }
        $stat = $statPath === '' ? false : @stat($statPath);
        $mode = is_array($stat) ? $stat['mode'] & 07777 : 0;
        $name = self::base($path);
        return [
            'path' => $path,
            'name' => $name,
            'type' => $type,
            'target_type' => $targetType,
            'broken' => $broken,
            'mode' => $mode,
            'octal' => Entry::octal($mode),
            'perms' => ($mode & 0200) ? 'baca-tulis' : 'hanya baca',
            'uid' => 0,
            'gid' => 0,
            'owner' => '',
            'group' => '',
            'size' => $type === 'file' && is_array($stat) ? (int) $stat['size'] : 0,
            'mtime' => is_array($stat) ? (int) $stat['mtime'] : 0,
            'link' => $link,
            'orphan' => false,
            'danger' => $broken ? ['broken_symlink'] : [],
        ];
    }

    /**
     * Linux entry read with lstat, so a link reports its own mode and owner like find -P.
     */
    private static function unixEntry($path, $kind)
    {
        $stat = @lstat($path);
        $type = $kind === 'l' ? 'link' : ($kind === 'd' ? 'dir' : 'file');
        if ($type === 'file' && @filetype($path) !== 'file') {
            $type = 'other';
        }
        $link = '';
        $broken = false;
        $targetType = $type;
        if ($type === 'link') {
            $target = @readlink($path);
            $link = is_string($target) ? $target : '';
            $real = self::realpath($path);
            $broken = $real === '';
            $targetType = $broken ? 'other' : (@is_dir($real) ? 'dir' : 'file');
        }
        $mode = is_array($stat) ? $stat['mode'] & 07777 : 0;
        $uid = is_array($stat) ? (int) $stat['uid'] : 0;
        $gid = is_array($stat) ? (int) $stat['gid'] : 0;
        $owner = Accounts::userName($uid);
        $group = Accounts::groupName($gid);
        $entry = [
            'path' => $path,
            'name' => $path === '/' ? '/' : self::base($path),
            'type' => $type,
            'target_type' => $targetType,
            'broken' => $broken,
            'mode' => $mode,
            'octal' => Entry::octal($mode),
            'perms' => Entry::symbolic($mode, $type),
            'uid' => $uid,
            'gid' => $gid,
            // Like find, a numeric id stands in for an account that does not exist.
            'owner' => $owner === null ? (string) $uid : $owner,
            'group' => $group === null ? (string) $gid : $group,
            'size' => is_array($stat) && $type !== 'dir' ? (int) $stat['size'] : 0,
            'mtime' => is_array($stat) ? (int) $stat['mtime'] : 0,
            'link' => $link,
            'orphan' => Accounts::available() && ($owner === null || $group === null),
        ];
        $entry['danger'] = Entry::dangers($entry);
        return $entry;
    }

    /**
     * Comparison key: Windows paths ignore letter case, Linux paths do not.
     */
    private static function key($path)
    {
        return Runner::isWindows() ? strtolower($path) : $path;
    }

    private static function otherDevice($source, $destDir)
    {
        if (Runner::isWindows()) {
            return strcasecmp(substr($source, 0, 2), substr($destDir, 0, 2)) !== 0;
        }
        $a = @lstat($source);
        $b = @stat($destDir);
        return is_array($a) && is_array($b) && $a['dev'] !== $b['dev'];
    }

    /**
     * @return string[] every name inside a folder, hidden ones included
     */
    private static function children($dir)
    {
        self::clearError();
        $handle = @opendir($dir);
        if ($handle === false) {
            throw self::failure('Folder tidak dapat dibaca', $dir);
        }
        $names = [];
        while (($name = readdir($handle)) !== false) {
            if ($name !== '.' && $name !== '..') {
                $names[] = $name;
            }
        }
        closedir($handle);
        return $names;
    }

    private static function copyTree($source, $target)
    {
        $skipped = [];
        self::copyNode($source, $target, $skipped);
        if ($skipped) {
            throw new RuntimeException('Symlink atau junction berikut tidak ikut disalin: ' . self::listSample($skipped));
        }
    }

    private static function copyNode($source, $target, array &$skipped)
    {
        $kind = self::kind($source);
        if ($kind === 'l') {
            // Copying the target of a link could pull content from outside the roots. On Linux the
            // link itself is recreated, as cp -a does; a Windows junction is left out.
            $linkTarget = Runner::isWindows() ? false : @readlink($source);
            if (!is_string($linkTarget) || !@symlink($linkTarget, $target)) {
                $skipped[] = $source;
            }
            return;
        }
        self::clearError();
        if ($kind === 'f') {
            if (!@copy($source, $target)) {
                throw self::failure('Berkas tidak dapat disalin', $source);
            }
            $mtime = @filemtime($source);
            if ($mtime !== false) {
                @touch($target, $mtime);
            }
            self::keepMode($source, $target);
            return;
        }
        if ($kind !== 'd') {
            return;
        }
        if (!@mkdir($target) && !@is_dir($target)) {
            throw self::failure('Folder tidak dapat dibuat', $target);
        }
        self::keepMode($source, $target);
        foreach (self::children($source) as $name) {
            self::copyNode(self::join($source, $name), self::join($target, $name), $skipped);
        }
    }

    /**
     * Linux copies keep the source mode, as cp -a does; the owner stays the PHP account's.
     */
    private static function keepMode($source, $target)
    {
        if (!Runner::isWindows()) {
            $perms = @fileperms($source);
            if ($perms !== false) {
                @chmod($target, $perms & 07777);
            }
        }
    }

    private static function zipAdd(ZipArchive $zip, $path, $local, array $exclude, array $patterns, array &$skipped)
    {
        if (in_array(self::key($path), $exclude, true) || self::patternExcluded($local, $patterns)) {
            return;
        }
        $kind = self::kind($path);
        if ($kind === 'l') {
            $skipped[] = $local;
            return;
        }
        if ($kind === 'f') {
            if (!$zip->addFile($path, $local)) {
                throw new RuntimeException('Berkas tidak dapat ditambahkan ke arsip: ' . $path);
            }
            return;
        }
        if ($kind !== 'd') {
            return;
        }
        $zip->addEmptyDir($local);
        foreach (self::children($path) as $name) {
            self::zipAdd($zip, self::join($path, $name), $local . '/' . $name, $exclude, $patterns, $skipped);
        }
    }

    private static function listSample(array $items)
    {
        return implode(', ', array_slice($items, 0, 5)) . (count($items) > 5 ? ', dan ' . (count($items) - 5) . ' lainnya' : '') . '.';
    }

    private static function clearError()
    {
        if (function_exists('error_clear_last')) {
            error_clear_last();
        }
    }

    private static function failure($message, $path)
    {
        $error = error_get_last();
        $detail = is_array($error) && isset($error['message']) ? preg_replace('/^[a-z_]+\([^)]*\):\s*/i', '', $error['message']) : '';
        return new RuntimeException($message . ': ' . $path . ($detail !== '' ? ' (' . $detail . ')' : '') . '.');
    }
}
