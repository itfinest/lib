<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Fs;

use App\Http\HttpException;
use App\Support\Config;
use App\System\Runner;
use App\System\Shell;

/**
 * Keeps every path the tool touches inside the configured roots, and keeps
 * the application's own folder out of reach unless protect_app_folder is off.
 *
 * Linux paths start with "/". Windows paths start with a drive letter and use
 * forward slashes ("D:/www/site"); they are compared case-insensitively,
 * because "D:/WWW" and "d:/www" are the same folder there.
 */
final class PathGuard
{
    const READ = 'read';
    const CONTENT = 'content';
    const STRUCTURE = 'structure';

    // Names a web server may run as code or read as configuration. A new file or
    // folder may not get one of these names, which closes the usual route for
    // planting a web shell (for example uploading shell.txt, then renaming it to shell.php).
    const DEFAULT_BLOCKED_EXTENSIONS = [
        'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'pht', 'phar', 'phps',
        'shtml', 'cgi', 'pl', 'asp', 'aspx', 'ashx', 'asmx', 'jsp', 'jspx', 'cfm',
    ];
    const DEFAULT_BLOCKED_NAMES = ['.htaccess', '.htpasswd', '.user.ini', 'php.ini', 'web.config'];

    /** @var string[]|null */
    private static $roots;

    /**
     * Validates and lexically normalizes a client-supplied path.
     */
    public static function clean($path, $field = 'path')
    {
        $path = (string) $path;
        if (preg_match('/[\x00-\x1F\x7F]/', $path)) {
            throw HttpException::validation([$field => 'Path mengandung karakter kontrol yang tidak diizinkan.']);
        }
        if (Runner::isWindows()) {
            return self::cleanWindows($path, $field);
        }
        if ($path === '' || $path[0] !== '/') {
            throw HttpException::validation([$field => 'Path harus berupa path absolut yang diawali "/".']);
        }
        $parts = [];
        foreach (explode('/', $path) as $segment) {
            if ($segment === '' || $segment === '.') {
                continue;
            }
            if ($segment === '..') {
                array_pop($parts);
                continue;
            }
            $parts[] = $segment;
        }
        return '/' . implode('/', $parts);
    }

    /**
     * Validates a single new file or folder name (no separators, no "." or "..").
     */
    public static function name($name, $field = 'name')
    {
        $name = trim($name);
        if ($name === '' || $name === '.' || $name === '..') {
            throw HttpException::validation([$field => 'Nama wajib diisi dan tidak boleh "." atau "..".']);
        }
        if (strpos($name, '/') !== false || preg_match('/[\x00-\x1F\x7F]/', $name)) {
            throw HttpException::validation([$field => 'Nama tidak boleh mengandung "/" atau karakter kontrol.']);
        }
        if (strlen($name) > 255) {
            throw HttpException::validation([$field => 'Nama maksimal 255 byte.']);
        }
        if (Runner::isWindows()) {
            $problem = self::windowsNameProblem($name);
            if ($problem !== null) {
                throw HttpException::validation([$field => $problem]);
            }
        }
        if (self::blockedName($name)) {
            throw HttpException::validation([$field => 'Nama "' . $name . '" diblokir oleh kebijakan keamanan karena dapat dijalankan atau dibaca sebagai konfigurasi oleh server web. Ubah daftar ini di halaman Pengaturan bila memang diperlukan.']);
        }
        return $name;
    }

    /**
     * Windows rejects these characters and names, and a colon opens an NTFS
     * alternate data stream ("shell.php::$DATA" writes to shell.php).
     *
     * @return string|null the reason the name is invalid, or null when it is valid
     */
    public static function windowsNameProblem($name)
    {
        if (preg_match('/[<>:"\/\\\\|?*\x00-\x1F]/', $name)) {
            return 'Nama tidak boleh mengandung karakter < > : " / \\ | ? * atau karakter kontrol.';
        }
        if (preg_match('/[. ]$/', $name)) {
            return 'Nama tidak boleh diakhiri titik atau spasi.';
        }
        if (preg_match('/^(con|prn|aux|nul|com[0-9]|lpt[0-9])(\..*)?$/i', $name)) {
            return 'Nama "' . $name . '" dicadangkan oleh Windows.';
        }
        return null;
    }

    /**
     * True when the name, or any extension in it ("shell.php.jpg"), is on the block list.
     */
    public static function blockedName($name)
    {
        $lower = strtolower($name);
        if (in_array(rtrim($lower, ' .'), self::lowerList('blocked_names', self::DEFAULT_BLOCKED_NAMES, " \t"), true)) {
            return true;
        }
        $extensions = self::lowerList('blocked_extensions', self::DEFAULT_BLOCKED_EXTENSIONS, " .\t");
        $segments = explode('.', $lower);
        array_shift($segments);
        foreach ($segments as $segment) {
            if (in_array(rtrim($segment, ' .'), $extensions, true)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Glob patterns for the block list, used to skip archive members on extraction.
     *
     * @return string[]
     */
    public static function blockedPatterns()
    {
        $patterns = [];
        foreach (self::lowerList('blocked_names', self::DEFAULT_BLOCKED_NAMES, " \t") as $name) {
            $patterns[] = $name;
            $patterns[] = '*/' . $name;
        }
        foreach (self::lowerList('blocked_extensions', self::DEFAULT_BLOCKED_EXTENSIONS, " .\t") as $ext) {
            $patterns[] = '*.' . $ext;
            $patterns[] = '*.' . $ext . '.*';
        }
        return $patterns;
    }

    /**
     * @return string[] configured roots, fully resolved
     */
    public static function roots()
    {
        if (self::$roots === null) {
            $configured = [];
            foreach ((array) Config::get('roots', []) as $root) {
                if (is_string($root) && $root !== '') {
                    $configured[] = self::clean($root, 'roots');
                }
            }
            self::$roots = array_values(array_unique(array_filter(self::realpaths($configured))));
            if (!self::$roots) {
                throw new HttpException(500, 'Tidak ada folder root yang valid. Periksa nilai roots di config/app.php.');
            }
        }
        return self::$roots;
    }

    /**
     * The folder opened first (setting default_path). Falls back to the first
     * root when the setting is empty, missing, or outside the roots.
     */
    public static function defaultPath()
    {
        $roots = self::roots();
        $configured = Config::get('default_path', '');
        if (!is_string($configured) || trim($configured) === '') {
            return $roots[0];
        }
        try {
            $real = self::realpaths([self::clean($configured, 'default_path')])[0];
        } catch (HttpException $e) {
            return $roots[0];
        }
        return $real !== '' && @is_dir($real) && self::allows($real, self::READ) ? $real : $roots[0];
    }

    /**
     * The folder filled in as the compress destination (setting compress_path).
     * Empty when the setting is empty, missing, outside the roots, or not a
     * folder, so the archive lands next to the compressed items.
     */
    public static function compressPath()
    {
        $configured = Config::get('compress_path', '');
        if (!is_string($configured) || trim($configured) === '') {
            return '';
        }
        try {
            $real = self::realpaths([self::clean($configured, 'compress_path')])[0];
        } catch (HttpException $e) {
            return '';
        }
        return $real !== '' && @is_dir($real) && self::allows($real, self::CONTENT) ? $real : '';
    }

    public static function appRoot()
    {
        $real = realpath(APP_ROOT);
        $path = $real === false ? APP_ROOT : $real;
        return Runner::isWindows() ? NativeFs::normalize($path) : str_replace('\\', '/', $path);
    }

    /**
     * True while the application's own folder is protected (setting protect_app_folder).
     */
    public static function protectsApp()
    {
        return Config::get('protect_app_folder', true) !== false;
    }

    /**
     * True when the path is the protected application folder or sits inside it.
     */
    public static function inApp($path)
    {
        return self::protectsApp() && self::within($path, self::appRoot());
    }

    public static function within($path, $base)
    {
        if (Runner::isWindows()) {
            return NativeFs::inside($path, $base);
        }
        if ($base === '/') {
            return true;
        }
        return $path === $base || strncmp($path, $base . '/', strlen($base) + 1) === 0;
    }

    public static function inRoots($path)
    {
        foreach (self::roots() as $root) {
            if (self::within($path, $root)) {
                return true;
            }
        }
        return false;
    }

    public static function isRoot($path)
    {
        foreach (self::roots() as $root) {
            if (Runner::isWindows() ? strcasecmp($path, $root) === 0 : $path === $root) {
                return true;
            }
        }
        return false;
    }

    public static function same($a, $b)
    {
        return Runner::isWindows() ? strcasecmp($a, $b) === 0 : $a === $b;
    }

    /**
     * Parent folder of a cleaned path. dirname() is not used on Windows, where
     * it switches to backslashes for some inputs.
     */
    public static function parent($path)
    {
        return Runner::isWindows() ? NativeFs::parent($path) : dirname($path);
    }

    public static function base($path)
    {
        return Runner::isWindows() ? NativeFs::base($path) : basename($path);
    }

    /**
     * Resolves a folder to browse. Symlinked folders are followed, but the
     * final location must still sit inside a root.
     */
    public static function resolveDir($path)
    {
        $clean = self::clean($path);
        $real = self::realpaths([$clean])[0];
        if ($real === '') {
            throw new HttpException(404, 'Folder tidak ditemukan: ' . $clean);
        }
        self::assertAllowed($real, self::READ);
        return $real;
    }

    /**
     * Resolves existing entries without following the final component, so a
     * symlink is treated as the link itself.
     *
     * @param string[] $paths
     * @return array<int,array{path:string,type:string}> type: d, f, l
     */
    public static function resolveEntries(array $paths, $level = self::CONTENT)
    {
        if (!$paths) {
            throw HttpException::validation(['paths' => 'Pilih minimal satu berkas atau folder.']);
        }
        $cleaned = array_values(array_unique(array_map(function ($p) {
            return self::clean($p, 'paths');
        }, $paths)));
        $inspected = self::inspect($cleaned);
        $out = [];
        foreach ($cleaned as $i => $original) {
            $info = $inspected[$i];
            if ($info === null || $info['type'] === 'n') {
                throw new HttpException(404, 'Berkas atau folder tidak ditemukan: ' . $original);
            }
            self::assertAllowed($info['path'], $level);
            $out[] = $info;
        }
        return $out;
    }

    /**
     * Resolves a path that must not exist yet (create, rename, copy destination).
     *
     * @return array{path:string,type:string}
     */
    public static function resolveNew($path, $field = 'name')
    {
        $info = self::inspect([self::clean($path, $field)])[0];
        if ($info === null) {
            throw new HttpException(404, 'Folder tujuan tidak ditemukan.');
        }
        self::assertAllowed($info['path'], self::STRUCTURE);
        return $info;
    }

    /**
     * READ: inside a root. CONTENT: may change metadata or contents, so it must
     * not be the app folder or inside it (recursive work prunes the app folder
     * out). STRUCTURE: may be deleted, moved, or renamed, so it must also not be
     * a root or a folder that contains the app.
     */
    public static function assertAllowed($path, $level)
    {
        if (!self::inRoots($path)) {
            throw new HttpException(403, 'Path berada di luar root yang diizinkan: ' . $path);
        }
        // The app folder holds the login hash and the change history, so it is neither shown nor changed.
        if (self::inApp($path)) {
            throw new HttpException(403, 'Folder aplikasi File Manager tidak dapat dibuka atau diubah dari aplikasi ini.');
        }
        if ($level === self::READ) {
            return;
        }
        if ($level === self::STRUCTURE) {
            if (self::isRoot($path)) {
                throw new HttpException(403, 'Folder root tidak dapat dihapus, dipindahkan, atau diganti namanya: ' . $path);
            }
            if (self::protectsApp() && self::within(self::appRoot(), $path)) {
                throw new HttpException(403, 'Folder ini berisi aplikasi File Manager sehingga tidak dapat dihapus, dipindahkan, atau diganti namanya: ' . $path);
            }
        }
    }

    public static function allows($path, $level)
    {
        try {
            self::assertAllowed($path, $level);
            return true;
        } catch (HttpException $e) {
            return false;
        }
    }

    /**
     * find expression fragment that skips the app folder when it lies under the given starts.
     *
     * @param string[] $starts
     * @return string[] paths to prune
     */
    public static function pruneFor(array $starts)
    {
        if (!self::protectsApp()) {
            return [];
        }
        $app = self::appRoot();
        foreach ($starts as $start) {
            if (self::within($app, $start)) {
                return [$app];
            }
        }
        return [];
    }

    /**
     * @param string[] $paths
     * @return string[] resolved path, or '' when it does not exist
     */
    public static function realpaths(array $paths)
    {
        if (!$paths) {
            return [];
        }
        if (Runner::native()) {
            return array_map([NativeFs::class, 'realpath'], array_values($paths));
        }
        $cmd = 'set -- ' . Shell::quoteAll($paths) . '; for p; do realpath -e -- "$p" 2>/dev/null || echo; done';
        $lines = explode("\n", Runner::run($cmd, null, 30)->stdout);
        $out = [];
        foreach (array_keys($paths) as $i) {
            $out[] = isset($lines[$i]) ? $lines[$i] : '';
        }
        return $out;
    }

    /**
     * Resolves the parent folder of each path and reports what the final component is.
     *
     * @param string[] $paths already cleaned
     * @return array<int,array{path:string,type:string}|null> type: d, f, l, or n (does not exist); null when the parent is missing
     */
    public static function inspect(array $paths)
    {
        if (Runner::native()) {
            return NativeFs::inspect(array_values($paths));
        }
        $args = [];
        foreach ($paths as $path) {
            if ($path === '/') {
                $args[] = '/';
                $args[] = '.';
                continue;
            }
            $args[] = dirname($path);
            $args[] = basename($path);
        }
        $cmd = 'set -- ' . Shell::quoteAll($args) . '; '
            . 'while [ $# -gt 0 ]; do d=$1; b=$2; shift 2; '
            . 'r=$(realpath -e -- "$d" 2>/dev/null) || { echo X; continue; }; '
            . 'if [ "$b" = . ]; then f=$r; elif [ "$r" = / ]; then f=/$b; else f=$r/$b; fi; '
            . 'if [ -L "$f" ]; then t=l; elif [ -d "$f" ]; then t=d; elif [ -e "$f" ]; then t=f; else t=n; fi; '
            . 'printf "%s\t%s\n" "$t" "$f"; done';
        $lines = explode("\n", Runner::run($cmd, null, 30)->stdout);
        $out = [];
        foreach (array_keys($paths) as $i) {
            $line = isset($lines[$i]) ? $lines[$i] : 'X';
            if ($line === 'X' || strpos($line, "\t") === false) {
                $out[] = null;
                continue;
            }
            list($type, $full) = explode("\t", $line, 2);
            $out[] = ['path' => $full, 'type' => $type];
        }
        return $out;
    }

    private static function cleanWindows($path, $field)
    {
        $path = str_replace('\\', '/', $path);
        if (!preg_match('#^([A-Za-z]):/#', $path, $m)) {
            throw HttpException::validation([$field => 'Path harus berupa path absolut yang diawali huruf drive, misalnya D:/www.']);
        }
        $parts = [];
        foreach (explode('/', substr($path, 3)) as $segment) {
            if ($segment === '' || $segment === '.') {
                continue;
            }
            if ($segment === '..') {
                array_pop($parts);
                continue;
            }
            $problem = self::windowsNameProblem($segment);
            if ($problem !== null) {
                throw HttpException::validation([$field => 'Path tidak valid. ' . $problem]);
            }
            $parts[] = $segment;
        }
        return strtoupper($m[1]) . ':/' . implode('/', $parts);
    }

    /**
     * @return string[]
     */
    private static function lowerList($key, array $default, $trim)
    {
        $out = [];
        foreach ((array) Config::get($key, $default) as $value) {
            if (is_string($value) && trim($value) !== '') {
                $out[] = strtolower(trim($value, $trim));
            }
        }
        return $out;
    }
}
