<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Storage;

use App\Support\Config;
use App\Http\HttpException;
use RuntimeException;

/**
 * File-based persistence. Every file is written as .php with an exit guard on
 * the first line, so a server that ignores .htaccess (nginx) still executes it
 * instead of serving the contents.
 */
final class DataStore
{
    const GUARD = "<?php exit; ?>\n";

    public static function path($name)
    {
        return rtrim((string) Config::get('storage_path'), '/\\') . '/' . $name;
    }

    public static function ensureReady()
    {
        $base = self::path('');
        foreach (['', 'snapshots', 'audits', 'malware', 'sessions', 'downloads', 'uploads'] as $dir) {
            $full = $base . $dir;
            // Session files grant a login, so that folder is private to the PHP account.
            $mode = $dir === 'sessions' ? 0700 : 0770;
            if (!is_dir($full) && !@mkdir($full, $mode, true) && !is_dir($full)) {
                throw new HttpException(500, 'Folder penyimpanan tidak dapat dibuat: ' . $full . '. Pastikan folder storage dapat ditulisi oleh PHP.');
            }
            if (!is_writable($full)) {
                throw new HttpException(500, 'Folder penyimpanan tidak dapat ditulisi oleh PHP: ' . $full . '. Ubah pemilik atau izin folder storage.');
            }
        }
        $htaccess = $base . '.htaccess';
        if (!is_file($htaccess)) {
            file_put_contents($htaccess, "Require all denied\nDeny from all\n");
        }
        $index = $base . 'index.php';
        if (!is_file($index)) {
            file_put_contents($index, self::GUARD);
        }
    }

    public static function readJson($name, array $default = [])
    {
        $raw = self::readRaw(self::path($name));
        if ($raw === null) {
            return $default;
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $default;
    }

    /**
     * Read-modify-write under an exclusive lock, so two requests never overwrite each other.
     *
     * @return mixed whatever the mutator returns
     */
    public static function mutateJson($name, callable $mutator)
    {
        $file = self::path($name);
        $handle = fopen($file, 'c+');
        if ($handle === false) {
            throw new RuntimeException('Berkas data tidak dapat dibuka: ' . $name);
        }
        try {
            flock($handle, LOCK_EX);
            $raw = stream_get_contents($handle);
            $data = [];
            if (is_string($raw) && strncmp($raw, self::GUARD, strlen(self::GUARD)) === 0) {
                $decoded = json_decode(substr($raw, strlen(self::GUARD)), true);
                $data = is_array($decoded) ? $decoded : [];
            }
            $result = $mutator($data);
            $encoded = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
            ftruncate($handle, 0);
            rewind($handle);
            fwrite($handle, self::GUARD . $encoded);
            fflush($handle);
            return $result;
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }

    public static function appendLine($name, array $record)
    {
        $file = self::path($name);
        $line = json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE) . "\n";
        $handle = fopen($file, 'a');
        if ($handle === false) {
            throw new RuntimeException('Log tidak dapat ditulis: ' . $name);
        }
        try {
            flock($handle, LOCK_EX);
            clearstatcache(true, $file);
            if (filesize($file) === 0) {
                fwrite($handle, self::GUARD);
            }
            fwrite($handle, $line);
            fflush($handle);
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }

    /**
     * @return array[] every record, oldest first
     */
    public static function readLines($name)
    {
        $raw = self::readRaw(self::path($name));
        if ($raw === null) {
            return [];
        }
        $records = [];
        foreach (explode("\n", $raw) as $line) {
            if ($line === '') {
                continue;
            }
            $record = json_decode($line, true);
            if (is_array($record)) {
                $records[] = $record;
            }
        }
        return $records;
    }

    public static function writeBlob($name, array $data)
    {
        $payload = gzencode(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE), 6);
        $file = self::path($name);
        if (file_put_contents($file, self::GUARD . $payload, LOCK_EX) === false) {
            throw new RuntimeException('Data tidak dapat disimpan: ' . $name);
        }
        return (int) filesize($file);
    }

    public static function readBlob($name)
    {
        $raw = self::readRaw(self::path($name));
        if ($raw === null) {
            return null;
        }
        $json = @gzdecode($raw);
        $data = $json === false ? null : json_decode($json, true);
        return is_array($data) ? $data : null;
    }

    public static function delete($name)
    {
        $file = self::path($name);
        if (is_file($file)) {
            unlink($file);
        }
    }

    private static function readRaw($file)
    {
        if (!is_file($file)) {
            return null;
        }
        $raw = file_get_contents($file);
        if ($raw === false || strncmp($raw, self::GUARD, strlen(self::GUARD)) !== 0) {
            return null;
        }
        return substr($raw, strlen(self::GUARD));
    }
}
