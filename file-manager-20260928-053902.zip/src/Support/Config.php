<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Support;

final class Config
{
    /** @var array */
    private static $values = [];

    /** @var array config/app.php as loaded, before the settings page overrides */
    private static $file = [];

    public static function load(array $values)
    {
        self::$values = $values;
        self::$file = $values;
    }

    /**
     * Applies settings saved from the settings page over config/app.php. Groups
     * (auth, limits) merge key by key; every other value, lists included, is replaced.
     */
    public static function merge(array $overrides)
    {
        foreach ($overrides as $key => $value) {
            if (in_array($key, ['auth', 'limits'], true) && is_array($value) && isset(self::$values[$key]) && is_array(self::$values[$key])) {
                self::$values[$key] = array_replace(self::$values[$key], $value);
                continue;
            }
            self::$values[$key] = $value;
        }
    }

    /**
     * Reads a value by dot path, e.g. "limits.list".
     *
     * @return mixed
     */
    public static function get($key, $default = null)
    {
        return self::lookup(self::$values, $key, $default);
    }

    /**
     * Reads a value from config/app.php alone, ignoring anything saved from the settings page.
     *
     * @return mixed
     */
    public static function fileValue($key, $default = null)
    {
        return self::lookup(self::$file, $key, $default);
    }

    /**
     * True only when config/app.php sets 'environment' => 'local'. Without the key the
     * application counts as production, so a server never shows developer tools by accident.
     */
    public static function local()
    {
        return self::fileValue('environment', 'production') === 'local';
    }

    public static function int($key, $default)
    {
        $value = self::get($key, $default);
        return is_numeric($value) ? (int) $value : $default;
    }

    private static function lookup(array $value, $key, $default)
    {
        foreach (explode('.', $key) as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                return $default;
            }
            $value = $value[$segment];
        }
        return $value;
    }
}
