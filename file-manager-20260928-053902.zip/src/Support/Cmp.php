<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Support;

/**
 * Three-way comparison for usort callbacks. Stands in for the <=> operator,
 * which only exists from PHP 7.0.
 */
final class Cmp
{
    public static function values($a, $b)
    {
        if ($a == $b) {
            return 0;
        }
        return $a < $b ? -1 : 1;
    }
}
