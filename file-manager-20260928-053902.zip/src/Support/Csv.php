<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Support;

use App\Http\Response;

final class Csv
{
    /**
     * Streams a CSV download. Text cells that a spreadsheet would read as a
     * formula are prefixed with a quote (CSV formula injection).
     *
     * @param string[] $headers
     * @param iterable $rows each row a list of scalars
     */
    public static function stream($filename, array $headers, $rows)
    {
        Response::downloadHeaders($filename, 'text/csv; charset=utf-8');
        $out = fopen('php://output', 'w');
        // UTF-8 BOM so Excel detects the encoding.
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, $headers, ',', '"', '\\');
        foreach ($rows as $row) {
            fputcsv($out, array_map([self::class, 'cell'], $row), ',', '"', '\\');
        }
        fclose($out);
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    public static function cell($value)
    {
        if (is_string($value) && $value !== '' && strpbrk($value[0], "=+-@\t\r") !== false) {
            return "'" . $value;
        }
        return $value;
    }
}
