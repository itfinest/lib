<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Support;

use RuntimeException;

/**
 * Cryptographically secure random bytes on every supported PHP version.
 * random_bytes() only exists from PHP 7.0, so PHP 5.6 falls back to OpenSSL
 * or mcrypt, and refuses to continue when neither gives a strong source.
 */
final class Random
{
    public static function bytes($length)
    {
        $length = (int) $length;
        if (function_exists('random_bytes')) {
            return random_bytes($length);
        }
        if (function_exists('openssl_random_pseudo_bytes')) {
            $strong = false;
            $bytes = openssl_random_pseudo_bytes($length, $strong);
            if ($bytes !== false && $strong === true && strlen($bytes) === $length) {
                return $bytes;
            }
        }
        if (function_exists('mcrypt_create_iv') && defined('MCRYPT_DEV_URANDOM')) {
            $bytes = mcrypt_create_iv($length, MCRYPT_DEV_URANDOM);
            if ($bytes !== false && strlen($bytes) === $length) {
                return $bytes;
            }
        }
        throw new RuntimeException('Tidak ada sumber bilangan acak yang aman. Aktifkan ekstensi openssl di PHP.');
    }

    public static function hex($bytes)
    {
        return bin2hex(self::bytes($bytes));
    }
}
