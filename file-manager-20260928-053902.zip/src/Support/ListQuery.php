<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Support;

use App\Http\Request;

/**
 * Search, sort, and page an in-memory list with the shared list contract:
 * page, per_page (10/25/50/100/all), search, sort_by, sort_dir.
 */
final class ListQuery
{
    const PER_PAGE_ALL_CAP = 1000;

    /**
     * @param string[] $searchFields
     * @param string[] $sortable
     */
    public static function apply(Request $request, array $rows, array $searchFields, array $sortable, $defaultSort, $defaultDir = 'asc')
    {
        $search = strtolower($request->queryString('search'));
        if ($search !== '') {
            $rows = array_values(array_filter($rows, function ($row) use ($search, $searchFields) {
                foreach ($searchFields as $field) {
                    $value = (isset($row[$field]) ? $row[$field] : '');
                    if (is_array($value)) {
                        $value = implode(' ', $value);
                    }
                    if (strpos(strtolower((string) $value), $search) !== false) {
                        return true;
                    }
                }
                return false;
            }));
        }
        $sortBy = Validate::oneOf($request->queryString('sort_by'), $sortable, $defaultSort);
        $dir = $request->queryString('sort_dir', $defaultDir) === 'desc' ? -1 : 1;
        usort($rows, function ($a, $b) use ($sortBy, $dir) {
            $x = (isset($a[$sortBy]) ? $a[$sortBy] : '');
            $y = (isset($b[$sortBy]) ? $b[$sortBy] : '');
            $cmp = is_numeric($x) && is_numeric($y) ? Cmp::values($x, $y) : strnatcasecmp((string) $x, (string) $y);
            return $cmp * $dir;
        });
        $pagination = self::paginate($request, count($rows));
        return [
            'items' => array_slice($rows, ($pagination['current_page'] - 1) * $pagination['per_page'], $pagination['per_page']),
            'pagination' => $pagination,
        ];
    }

    public static function paginate(Request $request, $total)
    {
        $perPageParam = $request->queryString('per_page', '10');
        if ($perPageParam === 'all') {
            $count = min($total, self::PER_PAGE_ALL_CAP);
            return ['current_page' => 1, 'last_page' => 1, 'total' => $count, 'per_page' => max(1, $count), 'capped' => $total > self::PER_PAGE_ALL_CAP];
        }
        $perPage = in_array((int) $perPageParam, [10, 25, 50, 100], true) ? (int) $perPageParam : 10;
        $last = max(1, (int) ceil($total / $perPage));
        $page = $request->queryInt('page', 1, 1, $last);
        return ['current_page' => $page, 'last_page' => $last, 'total' => $total, 'per_page' => $perPage, 'capped' => false];
    }
}
