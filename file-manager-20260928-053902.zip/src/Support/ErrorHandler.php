<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Support;

use App\Controller\PageController;
use App\Http\Response;
use ErrorException;

/**
 * Last line of defence for failures no controller handled: PHP warnings, uncaught exceptions,
 * and fatal errors that PHP 5.6 cannot catch at all. Every failure is written to the PHP error
 * log with a reference code. The page shows the full detail only while debugging is on, which
 * is the default for 'environment' => 'local' and can be switched with 'debug' in config/app.php.
 */
final class ErrorHandler
{
    const FATAL = E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR;

    /** @var bool */
    private static $handled = false;

    public static function register()
    {
        ini_set('display_errors', '0');
        error_reporting(E_ALL);
        set_error_handler([__CLASS__, 'convert']);
        set_exception_handler([__CLASS__, 'handle']);
        register_shutdown_function([__CLASS__, 'shutdown']);
    }

    /**
     * Turns a PHP warning or notice into an exception so it stops the request instead of
     * continuing with a broken value.
     */
    public static function convert($severity, $message, $file, $line)
    {
        if (!(error_reporting() & $severity)) {
            return false;
        }
        // A deprecation from a newer PHP release is logged, not fatal, so moving to a newer server does not break the app.
        if ($severity === E_DEPRECATED || $severity === E_USER_DEPRECATED) {
            error_log('[file-permission-manager] Deprecated: ' . $message . ' in ' . $file . ':' . $line);
            return true;
        }
        throw new ErrorException($message, 0, $severity, $file, $line);
    }

    public static function shutdown()
    {
        $error = error_get_last();
        if ($error === null || !($error['type'] & self::FATAL)) {
            return;
        }
        self::handle(new ErrorException($error['message'], 0, $error['type'], $error['file'], $error['line']));
    }

    /**
     * @param \Exception|\Throwable $e
     */
    public static function handle($e)
    {
        // A failure while answering must not start a second answer.
        if (self::$handled) {
            return;
        }
        self::$handled = true;

        $reference = gmdate('YmdHis') . '-' . substr(md5(uniqid('', true)), 0, 6);
        $summary = get_class($e) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine();
        $trace = self::trace($e);
        error_log('[file-permission-manager] ' . $reference . ' ' . $summary . "\n" . implode("\n", $trace));

        $debug = self::debug();
        $message = $debug
            ? 'Terjadi kesalahan pada server: ' . get_class($e) . ': ' . $e->getMessage()
            : 'Terjadi kesalahan pada server. Detail teknis tercatat di log PHP dengan kode referensi ' . $reference . '.';
        $detail = $debug
            ? ['reference' => $reference, 'file' => $e->getFile() . ':' . $e->getLine(), 'trace' => $trace]
            : ['reference' => $reference];

        if (headers_sent()) {
            // Part of a page already went out; the detail can only be appended to it.
            if ($debug) {
                echo "\n<pre>" . htmlspecialchars($summary . "\n" . implode("\n", $trace), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</pre>';
            }
            return;
        }
        try {
            if (self::api()) {
                Response::json(500, $message, $detail);
            } else {
                PageController::errorPage(500, $message, '', $detail);
            }
        } catch (\Exception $inner) {
            self::plain($message, $detail, $inner);
        } catch (\Throwable $inner) {
            // PHP 7+ engine errors. PHP 5.6 has no Throwable, and never reaches this branch.
            self::plain($message, $detail, $inner);
        }
    }

    /**
     * Shows technical detail when 'debug' in config/app.php is true, or when that key is missing
     * and the environment is local. The settings page never stores it.
     */
    public static function debug()
    {
        $debug = Config::fileValue('debug');
        return $debug === null ? Config::local() : (bool) $debug;
    }

    /**
     * The call stack without argument values, which can hold passwords.
     *
     * @param \Exception|\Throwable $e
     * @return string[]
     */
    private static function trace($e)
    {
        $lines = [];
        foreach ($e->getTrace() as $frame) {
            // The handler's own frames (convert, shutdown) say nothing about the failure.
            if (isset($frame['class']) && $frame['class'] === __CLASS__) {
                continue;
            }
            $where = isset($frame['file']) ? $frame['file'] . ':' . (isset($frame['line']) ? $frame['line'] : '?') : '[internal]';
            $call = (isset($frame['class']) ? $frame['class'] . $frame['type'] : '') . (isset($frame['function']) ? $frame['function'] : '') . '()';
            $lines[] = '#' . count($lines) . ' ' . $where . ' ' . $call;
        }
        return $lines;
    }

    private static function api()
    {
        $route = isset($_GET['r']) && is_string($_GET['r']) ? trim($_GET['r'], '/') : '';
        return strncmp($route, 'api/', 4) === 0;
    }

    /**
     * Used when the error page itself cannot be rendered, for example when a view is missing.
     *
     * @param \Exception|\Throwable $inner
     */
    private static function plain($message, array $detail, $inner)
    {
        error_log('[file-permission-manager] ' . $detail['reference'] . ' Error page failed: ' . get_class($inner) . ': ' . $inner->getMessage() . ' in ' . $inner->getFile() . ':' . $inner->getLine());
        if (headers_sent()) {
            return;
        }
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
        echo $message;
        if (isset($detail['trace'])) {
            echo "\n\n" . $detail['file'] . "\n" . implode("\n", $detail['trace']);
        }
    }
}
