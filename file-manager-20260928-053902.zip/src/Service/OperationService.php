<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Http\HttpException;
use App\System\Runner;
use Exception;

/**
 * One entry point for every change the tool makes: build the plan from
 * validated input, show it as a dry run, or snapshot, execute, and log it.
 */
final class OperationService
{
    // Operations on Unix mode bits, owners, and ACLs, which Windows does not have.
    const UNIX_OPS = ['chmod', 'chown', 'preset', 'acl', 'rollback', 'audit_fix'];

    /** @var HistoryService */
    private $history;

    public function __construct()
    {
        $this->history = new HistoryService();
    }

    public function build($op, array $params)
    {
        if (in_array($op, self::UNIX_OPS, true)) {
            Runner::assertUnixPermissions();
        }
        switch ($op) {
            case 'mkdir':
                return (new FileOperations())->mkdir($params);
            case 'create_file':
                return (new FileOperations())->createFile($params);
            case 'save':
                return (new FileOperations())->save($params);
            case 'rename':
                return (new FileOperations())->rename($params);
            case 'copy':
                return (new FileOperations())->copy($params);
            case 'move':
                return (new FileOperations())->move($params);
            case 'duplicate':
                return (new FileOperations())->duplicate($params);
            case 'delete':
                return (new FileOperations())->delete($params);
            case 'trash':
                return (new TrashService())->trashPlan($params);
            case 'restore':
                return (new TrashService())->restorePlan($params);
            case 'trash_purge':
                return (new TrashService())->purgePlan($params);
            case 'compress':
                return (new ArchiveOperations())->compress($params);
            case 'extract':
                return (new ArchiveOperations())->extract($params);
            case 'chmod':
                return (new PermissionOperations())->chmod($params);
            case 'chown':
                return (new PermissionOperations())->chown($params);
            case 'preset':
                return (new PermissionOperations())->preset($params);
            case 'acl':
                return (new PermissionOperations())->acl($params);
            case 'rollback':
                return (new SnapshotService())->rollbackPlan($params);
            case 'audit_fix':
                return (new AuditService())->fixPlan($params);
            case 'quarantine':
                return (new MalwareService())->quarantinePlan($params);
            case 'malware_delete':
                return (new MalwareService())->deletePlan($params);
            case 'malware_cloaking':
                return (new MalwareService())->cloakingPlan($params);
            case 'malware_lock':
                return (new MalwareService())->lockPlan($params);
        }
        throw new HttpException(404, 'Jenis operasi tidak dikenal.');
    }

    /**
     * Dry run: nothing changes on disk.
     */
    public function preview($op, array $params)
    {
        $plan = $this->build($op, $params);
        $impact = $plan->impact ? call_user_func($plan->impact) : null;
        return [
            'op' => $plan->op,
            'summary' => $plan->summary,
            'commands' => $this->displayCommands($plan),
            'impact' => $impact,
            'warnings' => $plan->warnings,
            'destructive' => $plan->destructive,
            'snapshot' => $plan->snapshot !== null,
            'noop' => (isset($plan->noop) ? $plan->noop : ($impact !== null && $impact['count'] === 0 && in_array($plan->op, ['chmod', 'chown', 'preset'], true)
                ? 'Semua entri sudah memiliki izin dan pemilik yang diminta. Tidak ada yang perlu diubah.'
                : null)),
        ];
    }

    public function apply($op, array $params, $user)
    {
        return $this->execute($this->build($op, $params), $user);
    }

    public function execute(Plan $plan, $user)
    {
        if ($plan->noop !== null) {
            return ['ok' => true, 'noop' => true, 'message' => $plan->noop, 'history_id' => null, 'snapshot_id' => null, 'errors' => []];
        }

        $snapshotId = null;
        if ($plan->snapshot !== null) {
            $snapshot = (new SnapshotService())->capture(
                $plan->snapshot['paths'],
                $plan->snapshot['recursive'],
                $plan->snapshot['acl'],
                'Otomatis sebelum: ' . $plan->summary,
                'auto',
                $user
            );
            $snapshotId = $snapshot['id'];
        }

        $errors = [];
        $failed = 0;
        foreach ($plan->commands as $command) {
            if ($command['native'] !== null) {
                try {
                    call_user_func($command['native']);
                } catch (Exception $e) {
                    // A native step fails like a shell command with stderr: the next steps still run and the error is reported.
                    $failed++;
                    $errors[] = $command['label'] . ': ' . $e->getMessage();
                }
                continue;
            }
            $result = Runner::run($command['cmd'], $command['stdin']);
            if (!$result->ok()) {
                $failed++;
                $lines = $result->errorLines(10);
                if ($result->timedOut) {
                    $lines[] = 'Perintah dihentikan karena melebihi batas waktu.';
                }
                $errors[] = $command['label'] . ': ' . ($lines ? implode(' | ', $lines) : 'gagal (kode keluar ' . $result->exitCode . ').');
            }
        }

        if ($plan->after) {
            call_user_func($plan->after, $user, $snapshotId);
        }

        $ok = $failed === 0;
        $record = $this->history->record([
            'user' => $user,
            'op' => $plan->op,
            'summary' => $plan->summary,
            'targets' => $plan->targets,
            'commands' => $this->displayCommands($plan),
            'ok' => $ok,
            'errors' => $errors,
            'snapshot_id' => $snapshotId,
        ]);

        return [
            'ok' => $ok,
            'noop' => false,
            'partial' => !$ok && $failed < count($plan->commands),
            'errors' => $errors,
            'history_id' => $record['id'],
            'snapshot_id' => $snapshotId,
            'summary' => $plan->summary,
            'targets' => $plan->targets,
        ];
    }

    /**
     * @return array<int,array{label:string,cmd:string}>
     */
    private function displayCommands(Plan $plan)
    {
        $out = [];
        foreach ($plan->commands as $command) {
            $cmd = $command['native'] !== null ? $command['cmd'] : Runner::wrap($command['cmd']);
            if ($command['stdin'] !== null) {
                $cmd .= '   # input: ' . strlen($command['stdin']) . ' byte';
            }
            $out[] = ['label' => $command['label'], 'cmd' => $cmd];
        }
        return $out;
    }
}
