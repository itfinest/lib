<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

/**
 * Everything one operation will do, built on the server from validated input.
 * The same plan feeds the preview (dry run) and the apply step, so what the
 * user confirmed is what runs. Commands never come from the client.
 */
final class Plan
{
    /** @var string */
    public $op;

    /** @var string */
    public $summary;

    /** @var array<int,array{cmd:string,stdin:?string,label:string,native:?callable}> */
    public $commands = [];

    /** @var string[] */
    public $targets = [];

    /** @var callable|null returns ['count'=>int,'capped'=>bool,'items'=>array] */
    public $impact;

    /** @var array|null ['paths'=>string[],'recursive'=>bool,'acl'=>bool] */
    public $snapshot;

    /** @var string[] */
    public $warnings = [];

    /** @var bool */
    public $destructive = false;

    /** @var string|null shown when the operation would change nothing */
    public $noop;

    /** @var callable|null bookkeeping after the commands ran, receives the user name and the snapshot id */
    public $after;

    public function __construct($op, $summary)
    {
        $this->op = $op;
        $this->summary = $summary;
    }

    public function add($cmd, $label, $stdin = null)
    {
        $this->commands[] = ['cmd' => $cmd, 'stdin' => $stdin, 'label' => $label, 'native' => null];
    }

    /**
     * A step run through PHP functions instead of a shell (Windows). $display
     * describes the step in the preview and the history; $action throws a
     * RuntimeException with a readable message when the step fails.
     */
    public function addNative($display, $label, callable $action)
    {
        $this->commands[] = ['cmd' => $display, 'stdin' => null, 'label' => $label, 'native' => $action];
    }

    /**
     * Preview text for a native step, e.g. PHP rename("D:/a", "D:/b").
     */
    public static function nativeCall($function, array $args)
    {
        return 'PHP ' . $function . '(' . implode(', ', array_map(function ($arg) {
            return is_string($arg) ? '"' . addcslashes($arg, '"\\') . '"' : var_export($arg, true);
        }, $args)) . ')';
    }
}
