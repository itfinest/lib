<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Entry;
use App\Fs\Finder;
use App\Fs\NativeFs;
use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Storage\DataStore;
use App\Support\Config;
use App\Support\Random;
use App\Support\Validate;
use App\System\Runner;
use App\System\Shell;

/**
 * Permission snapshots: a record of mode, owner, and group (and optionally
 * ACL) for every entry in a scope. Used for comparison and rollback.
 */
final class SnapshotService
{
    const INDEX = 'snapshots.php';

    public function capture(array $paths, $recursive, $acl, $label, $kind, $user)
    {
        $entries = $this->scanState($paths, $recursive);
        $aclText = null;
        if ($acl && AclService::available()) {
            $aclText = Runner::run('getfacl -p -P ' . ($recursive ? '-R ' : '') . '-- ' . Shell::quoteAll($paths))->stdout;
        }
        $id = 'snp_' . gmdate('Ymd_His') . '_' . Random::hex(3);
        $bytes = DataStore::writeBlob('snapshots/' . $id . '.php', [
            'paths' => $paths,
            'recursive' => $recursive,
            'entries' => $entries,
            'acl' => $aclText,
        ]);
        $meta = [
            'id' => $id,
            'label' => $label,
            'kind' => $kind,
            'paths' => $paths,
            'recursive' => $recursive,
            'count' => count($entries),
            'has_acl' => $aclText !== null,
            'bytes' => $bytes,
            'created_at' => gmdate('c'),
            'created_by' => $user,
        ];
        DataStore::mutateJson(self::INDEX, function (array &$index) use ($meta) {
            $index[] = $meta;
        });
        return $meta;
    }

    public function captureManual(array $p, $user)
    {
        Runner::assertUnixPermissions();
        $raw = is_array(isset($p['paths']) ? $p['paths'] : null) ? array_values(array_filter($p['paths'], 'is_string')) : [];
        $entries = PathGuard::resolveEntries($raw, PathGuard::READ);
        $label = Validate::text((string) (isset($p['label']) ? $p['label'] : ''), 'label', 120, false);
        $paths = array_column($entries, 'path');
        return $this->capture(
            $paths,
            !empty($p['recursive']),
            !empty($p['acl']),
            $label !== '' ? $label : 'Snapshot manual ' . (count($paths) === 1 ? basename($paths[0]) : count($paths) . ' item'),
            'manual',
            $user
        );
    }

    public function all()
    {
        $index = DataStore::readJson(self::INDEX);
        usort($index, function ($a, $b) {
            return strcmp($b['created_at'], $a['created_at']);
        });
        return $index;
    }

    public function meta($id)
    {
        foreach (DataStore::readJson(self::INDEX) as $meta) {
            if ((isset($meta['id']) ? $meta['id'] : '') === $id) {
                return $meta;
            }
        }
        throw new HttpException(404, 'Snapshot tidak ditemukan. Snapshot mungkin sudah dihapus.');
    }

    public function load($id)
    {
        $this->meta($id);
        $data = DataStore::readBlob('snapshots/' . $this->safeId($id) . '.php');
        if ($data === null) {
            throw new HttpException(410, 'Berkas data snapshot rusak atau hilang.');
        }
        return $data;
    }

    public function delete($id)
    {
        $meta = $this->meta($id);
        DataStore::mutateJson(self::INDEX, function (array &$index) use ($id) {
            $index = array_values(array_filter($index, function ($m) use ($id) {
                return (isset($m['id']) ? $m['id'] : '') !== $id;
            }));
        });
        DataStore::delete('snapshots/' . $this->safeId($id) . '.php');
        return $meta;
    }

    /**
     * Compares snapshot A with snapshot B, or with the live state when $b is "live".
     */
    public function compare($a, $b)
    {
        Runner::assertUnixPermissions();
        $left = $this->load($a);
        if ($b === 'live') {
            $right = ['entries' => $this->scanLive($left['paths'], (bool) $left['recursive'])];
            $rightLabel = 'Kondisi saat ini';
        } else {
            $right = $this->load($b);
            $rightLabel = $this->meta($b)['label'];
        }
        return [
            'left' => $this->meta($a)['label'],
            'right' => $rightLabel,
            'rows' => $this->diff($left['entries'], $right['entries']),
        ];
    }

    /**
     * Plan that restores mode and ownership (and ACL when captured) from a snapshot.
     */
    public function rollbackPlan(array $p)
    {
        $id = (string) (isset($p['snapshot_id']) ? $p['snapshot_id'] : '');
        $data = $this->load($id);
        $plan = $this->buildRestore($data, $data['paths'], 'Mengembalikan izin dari snapshot "' . $this->meta($id)['label'] . '"');
        $plan->snapshot = ['paths' => $plan->targets, 'recursive' => (bool) $data['recursive'], 'acl' => !empty($data['acl'])];
        return $plan;
    }

    /**
     * Restore used after an item returns from the trash. No new snapshot is taken:
     * the trash snapshot already holds the state being restored.
     *
     * @param string[] $paths subset of the snapshot's scope
     */
    public function restorePlan($id, array $paths)
    {
        $data = $this->load($id);
        $scope = array_values(array_intersect($data['paths'], $paths));
        $plan = $this->buildRestore($data, $scope, 'Memulihkan izin dan pemilik item dari tempat sampah');
        return $plan;
    }

    private function buildRestore(array $data, array $scope, $summary)
    {
        $paths = [];
        foreach ($scope as $path) {
            PathGuard::assertAllowed($path, PathGuard::CONTENT);
            $paths[] = $path;
        }
        $live = $this->scanLive($paths, (bool) $data['recursive']);
        $rows = array_values(array_filter($this->diff($data['entries'], $live), function ($row) {
            return $row['change'] === 'changed';
        }));

        $plan = new Plan('rollback', $summary);
        $plan->targets = $paths;

        $byMode = [];
        $byOwner = [];
        foreach ($rows as $row) {
            $old = $data['entries'][$row['path']];
            if (PathGuard::inApp($row['path'])) {
                continue;
            }
            if ($row['mode_changed'] && $old[0] !== 'l') {
                $byMode[Validate::chmodArg((int) $old[1])][] = $row['path'];
            }
            if ($row['owner_changed']) {
                $byOwner[$old[2] . ':' . $old[3]][] = $row['path'];
            }
        }
        foreach ($byMode as $mode => $list) {
            if (Runner::native()) {
                $value = (int) octdec($mode);
                $plan->addNative('PHP chmod(' . substr($mode, 1) . ') untuk ' . count($list) . ' entri', 'Izin kembali ke ' . substr($mode, 1) . ' (' . count($list) . ' entri)', function () use ($list, $value) {
                    NativeFs::changeEach($list, function ($path) use ($value) {
                        NativeFs::setMode($path, $value);
                    });
                });
                continue;
            }
            foreach (Shell::chunkArgs($list) as $chunk) {
                $plan->add('chmod ' . $mode . ' -- ' . Shell::quoteAll($chunk), 'Izin kembali ke ' . substr($mode, 1) . ' (' . count($chunk) . ' entri)');
            }
        }
        foreach ($byOwner as $owner => $list) {
            if (Runner::native()) {
                list($uid, $gid) = explode(':', $owner, 2);
                $plan->addNative('PHP lchown/lchgrp(' . $owner . ') untuk ' . count($list) . ' entri', 'Pemilik kembali ke UID:GID ' . $owner . ' (' . count($list) . ' entri)', function () use ($list, $uid, $gid) {
                    NativeFs::changeEach($list, function ($path) use ($uid, $gid) {
                        NativeFs::setOwner($path, $uid, $gid);
                    });
                });
                continue;
            }
            foreach (Shell::chunkArgs($list) as $chunk) {
                $plan->add('chown -h ' . $owner . ' -- ' . Shell::quoteAll($chunk), 'Pemilik kembali ke UID:GID ' . $owner . ' (' . count($chunk) . ' entri)');
            }
        }
        if (!empty($data['acl']) && $paths === array_values($data['paths']) && AclService::available()) {
            $plan->add('setfacl --restore=-', 'Memulihkan ACL dari snapshot', (string) $data['acl']);
        }
        if (!$plan->commands) {
            $plan->noop = 'Tidak ada perbedaan izin atau pemilik antara snapshot dan kondisi saat ini.';
        }
        $plan->impact = function () use ($rows) {
            $limit = Config::int('limits.preview_items', 200);
            $items = [];
            foreach (array_slice($rows, 0, $limit) as $row) {
                $items[] = ['path' => $row['path'], 'before' => $row['after'], 'after' => $row['before'], 'note' => ''];
            }
            return ['count' => count($rows), 'capped' => false, 'items' => $items, 'unit' => 'entri akan dikembalikan'];
        };
        return $plan;
    }

    /**
     * @return array<string,array> path => [type, mode, uid, gid, owner, group]
     */
    private function scanState(array $paths, $recursive)
    {
        $limit = Config::int('limits.scan', 100000);
        $opt = ['hidden' => true, 'prune' => PathGuard::pruneFor($paths), 'limit' => $limit];
        if (!$recursive) {
            $opt['maxdepth'] = 0;
        }
        $scan = Finder::scan($paths, $opt);
        if ($scan['truncated']) {
            throw new HttpException(422, 'Cakupan berisi lebih dari ' . number_format($limit, 0, ',', '.') . ' entri sehingga snapshot tidak dapat dibuat. Persempit pilihan, atau naikkan limits.scan di config/app.php.');
        }
        $state = [];
        foreach ($scan['entries'] as $e) {
            $state[$e['path']] = [substr($e['type'], 0, 1), $e['mode'] & 07777, $e['uid'], $e['gid'], $e['owner'], $e['group']];
        }
        return $state;
    }

    private function scanLive(array $paths, $recursive)
    {
        $existing = [];
        foreach (PathGuard::inspect($paths) as $info) {
            if ($info !== null && $info['type'] !== 'n') {
                $existing[] = $info['path'];
            }
        }
        return $existing ? $this->scanState($existing, $recursive) : [];
    }

    private function diff(array $before, array $after)
    {
        $rows = [];
        foreach ($before as $path => $old) {
            if (!isset($after[$path])) {
                $rows[] = $this->row($path, 'removed', $old, null);
                continue;
            }
            $new = $after[$path];
            if ($old[1] !== $new[1] || $old[2] !== $new[2] || $old[3] !== $new[3]) {
                $rows[] = $this->row($path, 'changed', $old, $new);
            }
        }
        foreach ($after as $path => $new) {
            if (!isset($before[$path])) {
                $rows[] = $this->row($path, 'added', null, $new);
            }
        }
        usort($rows, function ($x, $y) {
            return strcmp($x['path'], $y['path']);
        });
        return $rows;
    }

    private function row($path, $change, array $old = null, array $new = null)
    {
        $describe = function (array $s = null) {
            return $s === null ? '' : Entry::octal((int) $s[1]) . ' ' . $s[4] . ':' . $s[5];
        };
        return [
            'path' => $path,
            'change' => $change,
            'before' => $describe($old),
            'after' => $describe($new),
            'mode_changed' => $old !== null && $new !== null && $old[1] !== $new[1],
            'owner_changed' => $old !== null && $new !== null && ($old[2] !== $new[2] || $old[3] !== $new[3]),
        ];
    }

    private function safeId($id)
    {
        if (!preg_match('/^snp_[0-9]{8}_[0-9]{6}_[0-9a-f]{6}$/', $id)) {
            throw new HttpException(404, 'Snapshot tidak ditemukan.');
        }
        return $id;
    }
}
