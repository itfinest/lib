<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Storage\DataStore;
use App\Support\Random;
use App\Support\Validate;

/**
 * Folders saved for quick access from the file manager. Only the path and a label are stored;
 * the folder itself is checked again every time the list is read.
 */
final class FavoriteService
{
    const FILE = 'favorites.php';
    const MAX = 50;

    /**
     * @return array[] saved order, each with "available" set to false when the folder is gone
     *                 or no longer inside the roots
     */
    public function all()
    {
        $rows = DataStore::readJson(self::FILE);
        $real = PathGuard::realpaths(array_column($rows, 'path'));
        foreach ($rows as $i => $row) {
            $rows[$i]['available'] = $real[$i] !== '' && PathGuard::allows($real[$i], PathGuard::READ);
        }
        return $rows;
    }

    public function add($path, $label, $user)
    {
        $dir = PathGuard::resolveDir($path);
        // A drive or filesystem root has no base name, so its path becomes the label.
        $name = PathGuard::base($dir);
        $label = Validate::text($label === '' ? ($name === '' ? $dir : $name) : $label, 'label', 80);
        return DataStore::mutateJson(self::FILE, function (array &$rows) use ($dir, $label, $user) {
            foreach ($rows as $row) {
                if (PathGuard::same($row['path'], $dir)) {
                    throw HttpException::validation(['path' => 'Folder ini sudah ada di daftar favorit.']);
                }
            }
            if (count($rows) >= self::MAX) {
                throw HttpException::validation(['path' => 'Favorit maksimal ' . self::MAX . ' folder. Hapus favorit yang tidak dipakai terlebih dahulu.']);
            }
            $row = ['id' => 'f_' . gmdate('YmdHis') . '_' . Random::hex(3), 'path' => $dir, 'label' => $label, 'created_at' => gmdate('c'), 'created_by' => $user];
            $rows[] = $row;
            return $row;
        });
    }

    public function delete($id)
    {
        return DataStore::mutateJson(self::FILE, function (array &$rows) use ($id) {
            foreach ($rows as $i => $row) {
                if ($row['id'] === $id) {
                    array_splice($rows, $i, 1);
                    return $row;
                }
            }
            throw new HttpException(404, 'Favorit tidak ditemukan. Favorit mungkin sudah dihapus.');
        });
    }
}
