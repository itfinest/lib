<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Finder;
use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Support\Config;
use App\System\Runner;
use App\System\Shell;

/**
 * Finds the lines that contain a text inside the files of a folder and all its subfolders.
 * It only reads: nothing on disk changes, so no plan or history record is involved.
 */
final class SearchService
{
    // Skipped by default. A name without a slash is matched as a folder name at every depth;
    // a name with a slash is relative to the searched folder.
    const SKIP_DIRS = ['node_modules', 'vendor', '.git', '.svn'];
    const SKIP_MAX = 100;
    const QUERY_MAX = 200;
    const NAMES_MAX = 20;

    // Larger files are left unread, so a single log or database dump cannot stall the search.
    const FILE_MAX_BYTES = 5242880;
    const MATCH_MAX = 1000;
    const FILE_MATCH_MAX = 50;

    // Characters of context kept before a match and in total for each line shown.
    const CONTEXT_BEFORE = 80;
    const SNIPPET = 240;

    /**
     * @param string $names file name patterns such as "*.php, .env"; empty searches every file
     * @param string $skip folders to skip, one per line or separated by commas; empty uses SKIP_DIRS
     */
    public function search($path, $query, $caseSensitive, $regex, $names, $skip)
    {
        $dir = PathGuard::resolveDir($path);
        $pattern = $this->pattern($query, $caseSensitive, $regex);
        $namePatterns = $this->namePatterns($names);
        $skipList = $this->skipList($skip);
        $started = microtime(true);

        $prune = PathGuard::pruneFor([$dir]);
        $pruneNames = [];
        $relative = [];
        foreach ($skipList as $item) {
            if (strpos($item, '/') === false) {
                $pruneNames[] = $item;
            } else {
                $relative[] = rtrim($dir, '/') . '/' . $item;
            }
        }
        foreach ($relative ? PathGuard::realpaths($relative) : [] as $real) {
            if ($real !== '') {
                $prune[] = $real;
            }
        }

        $conditions = '-type f';
        if ($namePatterns) {
            $alternatives = [];
            foreach ($namePatterns as $name) {
                $alternatives[] = '-iname ' . Shell::quote($name);
            }
            $conditions .= ' \( ' . implode(' -o ', $alternatives) . ' \)';
        }
        $scan = Finder::scan([$dir], [
            'mindepth' => 1,
            'hidden' => true,
            'xdev' => true,
            'prune' => $prune,
            'prune_names' => $pruneNames,
            'limit' => Config::int('limits.scan', 100000),
            'conditions' => $conditions,
            'match' => ['filter' => function ($entry) use ($namePatterns) {
                return $entry['type'] === 'file' && $this->nameMatches($entry['name'], $namePatterns);
            }],
        ]);

        $reader = new MalwareScanner();
        $files = [];
        $lineCount = 0;
        $stats = ['searched' => 0, 'large' => 0, 'binary' => 0, 'unreadable' => 0];
        $stopped = false;
        $base = rtrim($dir, '/');
        foreach ($scan['entries'] as $entry) {
            if ($lineCount >= self::MATCH_MAX) {
                $stopped = true;
                break;
            }
            if ((int) $entry['size'] > self::FILE_MAX_BYTES) {
                $stats['large']++;
                continue;
            }
            $content = (int) $entry['size'] === 0 ? '' : $reader->head($entry['path'], self::FILE_MAX_BYTES);
            if ($content === '' && (int) $entry['size'] > 0) {
                $stats['unreadable']++;
                continue;
            }
            if (strpos(substr($content, 0, 8000), "\0") !== false) {
                $stats['binary']++;
                continue;
            }
            $stats['searched']++;
            $matches = [];
            $more = false;
            foreach (preg_split('/\r\n|\r|\n/', $content) as $index => $line) {
                if (!preg_match($pattern, $line, $found, PREG_OFFSET_CAPTURE)) {
                    continue;
                }
                if (count($matches) >= self::FILE_MATCH_MAX || $lineCount >= self::MATCH_MAX) {
                    $more = true;
                    break;
                }
                $matches[] = $this->snippet($line, $index + 1, $found[0][1], strlen($found[0][0]));
                $lineCount++;
            }
            if ($matches) {
                $files[] = [
                    'path' => $entry['path'],
                    'rel' => ltrim(substr($entry['path'], strlen($base)), '/'),
                    'matches' => $matches,
                    'more' => $more,
                ];
            }
        }

        return [
            'path' => $dir,
            'files' => $files,
            'matched_files' => count($files),
            'matched_lines' => $lineCount,
            'searched' => $stats['searched'],
            'skipped_large' => $stats['large'],
            'skipped_binary' => $stats['binary'],
            'unreadable' => $stats['unreadable'],
            'limit_lines' => $stopped || ($lineCount >= self::MATCH_MAX),
            'limit_files' => $scan['truncated'],
            'skip' => $skipList,
            'warnings' => $scan['warnings'],
            'duration_ms' => (int) round((microtime(true) - $started) * 1000),
        ];
    }

    /**
     * The regular expression every line is tested with. Plain text is escaped, so only the regex
     * option interprets special characters. The delimiter is a control character, which the query
     * may not contain, so no character typed by the user can end the pattern early.
     */
    private function pattern($query, $caseSensitive, $regex)
    {
        if ($query === '') {
            throw HttpException::validation(['q' => 'Isi teks yang dicari.']);
        }
        if (strlen($query) > self::QUERY_MAX) {
            throw HttpException::validation(['q' => 'Teks yang dicari maksimal ' . self::QUERY_MAX . ' karakter.']);
        }
        if (preg_match('/[\x00-\x1F\x7F]/', $query)) {
            throw HttpException::validation(['q' => 'Teks yang dicari tidak boleh mengandung karakter kontrol.']);
        }
        $pattern = "\x01" . ($regex ? $query : preg_quote($query)) . "\x01" . ($caseSensitive ? '' : 'i');
        if (@preg_match($pattern, '') === false) {
            throw HttpException::validation(['q' => 'Ekspresi reguler tidak valid. Periksa tanda kurung, tanda kurung siku, dan karakter khusus lainnya.']);
        }
        return $pattern;
    }

    /**
     * @return string[] glob patterns tested against the file name, any letter case
     */
    private function namePatterns($raw)
    {
        $out = [];
        foreach (preg_split('/[\r\n,]+/', (string) $raw) as $name) {
            $name = trim($name);
            if ($name === '') {
                continue;
            }
            if (strlen($name) > 100 || preg_match('#[/\\\\\x00-\x1F\x7F]#', $name)) {
                throw HttpException::validation(['names' => 'Pola nama berkas "' . $name . '" tidak valid. Tulis nama atau pola tanpa "/" atau "\\", misalnya *.php.']);
            }
            $out[] = $name;
        }
        $out = array_values(array_unique($out));
        if (count($out) > self::NAMES_MAX) {
            throw HttpException::validation(['names' => 'Pola nama berkas maksimal ' . self::NAMES_MAX . ' pola.']);
        }
        return $out;
    }

    private function nameMatches($name, array $patterns)
    {
        if (!$patterns) {
            return true;
        }
        $flags = Runner::isWindows() ? FNM_NOESCAPE | FNM_CASEFOLD : FNM_CASEFOLD;
        foreach ($patterns as $pattern) {
            if (fnmatch($pattern, $name, $flags)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Folders to skip, one per line or separated by commas. Absolute paths and ".." are dropped,
     * since exclusions only apply inside the searched folder. An empty list means the defaults.
     *
     * @return string[]
     */
    private function skipList($input)
    {
        $out = [];
        foreach (preg_split('/[\r\n,]+/', (string) $input) as $line) {
            $line = trim(str_replace('\\', '/', trim($line)), '/');
            if ($line === '' || strlen($line) > 255 || preg_match('/[\x00-\x1F\x7F]/', $line) || preg_match('#(^|/)\.\.(/|$)#', $line) || preg_match('#^[A-Za-z]:#', $line)) {
                continue;
            }
            $out[] = $line;
        }
        $out = array_values(array_unique($out));
        if (count($out) > self::SKIP_MAX) {
            throw HttpException::validation(['skip' => 'Jumlah folder yang dilewati melebihi ' . self::SKIP_MAX . ' baris.']);
        }
        return $out ?: self::SKIP_DIRS;
    }

    /**
     * The matched line cut around the match, split so the page can mark the match without HTML.
     */
    private function snippet($line, $number, $offset, $length)
    {
        $start = max(0, $offset - self::CONTEXT_BEFORE);
        $before = (string) substr($line, $start, $offset - $start);
        $match = (string) substr($line, $offset, min($length, self::SNIPPET));
        $room = self::SNIPPET - strlen($before) - strlen($match);
        $after = $room > 0 ? (string) substr($line, $offset + $length, $room) : '';
        return [
            'line' => $number,
            'before' => $start === 0 ? ltrim($before) : $before,
            'match' => $match,
            'after' => rtrim($after),
            'cut_start' => $start > 0,
            'cut_end' => $offset + $length + strlen($after) < strlen($line),
        ];
    }
}
