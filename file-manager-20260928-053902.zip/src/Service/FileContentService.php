<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Finder;
use App\Fs\NativeFs;
use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Http\Response;
use App\Storage\DataStore;
use App\Support\Config;
use App\System\Runner;
use App\System\Shell;

/**
 * Reading, downloading, and uploading file contents.
 */
final class FileContentService
{
    // Only types a browser shows without running anything from the file. HTML, XML, and
    // scripts are left out because shown inline they would run with this app's session.
    const PREVIEW_TYPES = [
        'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif',
        'webp' => 'image/webp', 'avif' => 'image/avif', 'bmp' => 'image/bmp', 'ico' => 'image/x-icon',
        'svg' => 'image/svg+xml',
        'pdf' => 'application/pdf',
        'mp4' => 'video/mp4', 'm4v' => 'video/mp4', 'webm' => 'video/webm', 'ogv' => 'video/ogg',
        'mp3' => 'audio/mpeg', 'wav' => 'audio/wav', 'ogg' => 'audio/ogg', 'oga' => 'audio/ogg',
        'opus' => 'audio/ogg', 'm4a' => 'audio/mp4', 'aac' => 'audio/aac', 'flac' => 'audio/flac',
    ];

    // Files above the PHP upload limits arrive in pieces and are joined here before the upload plan runs.
    const CHUNK_DIR = 'uploads';
    // Upper bound for one piece, so every request stays short and the progress bar keeps moving.
    const CHUNK_MAX_BYTES = 8388608;

    public function read($path)
    {
        $entry = PathGuard::resolveEntries([$path], PathGuard::READ)[0];
        if ($entry['type'] !== 'f') {
            throw HttpException::validation(['path' => 'Hanya berkas biasa yang dapat dibuka di editor.']);
        }
        $max = Config::int('limits.edit_bytes', 1048576);
        $content = $this->readBytes($entry['path'], $max + 1);
        $meta = Finder::statOne($entry['path']);

        if (strlen($content) > $max) {
            return ['path' => $entry['path'], 'editable' => false, 'reason' => 'Berkas lebih besar dari batas editor (' . number_format($max / 1048576, 1, ',', '.') . ' MB). Unduh berkas untuk melihat isinya.', 'entry' => $meta];
        }
        if (strpos(substr($content, 0, 8000), "\0") !== false) {
            return ['path' => $entry['path'], 'editable' => false, 'reason' => 'Berkas biner tidak dapat dibuka di editor teks. Unduh berkas untuk melihat isinya.', 'entry' => $meta];
        }
        if (!preg_match('//u', $content)) {
            return ['path' => $entry['path'], 'editable' => false, 'reason' => 'Berkas tidak berenkode UTF-8 sehingga tidak dapat diedit dengan aman di editor ini.', 'entry' => $meta];
        }
        return [
            'path' => $entry['path'],
            'editable' => true,
            'content' => $content,
            'hash' => sha1($content),
            'entry' => $meta,
        ];
    }

    public function hash($path)
    {
        return sha1($this->readBytes($path, Config::int('limits.edit_bytes', 1048576) + 1));
    }

    public function download($path)
    {
        $entry = PathGuard::resolveEntries([$path], PathGuard::READ)[0];
        if ($entry['type'] === 'd') {
            $archive = (new ArchiveOperations())->folderArchive($entry['path']);
            // A cancelled download ends the script early; the shutdown function still removes the temporary archive.
            register_shutdown_function(function () use ($archive) {
                @unlink($archive['path']);
            });
            Response::downloadHeaders($archive['name'], $archive['type'], filesize($archive['path']));
            NativeFs::output($archive['path']);
            return;
        }
        if ($entry['type'] !== 'f') {
            throw HttpException::validation(['path' => 'Symlink tidak dapat diunduh langsung. Buka lokasi tujuannya, lalu unduh berkas atau folder di sana.']);
        }
        $meta = Finder::statOne($entry['path']);
        Response::downloadHeaders(PathGuard::base($entry['path']), 'application/octet-stream', $meta ? $meta['size'] : null);
        if (Runner::native()) {
            NativeFs::output($entry['path']);
            return;
        }
        Runner::passthru('cat -- ' . Shell::quote($entry['path']));
    }

    /**
     * MD5 and SHA-256 of a regular file, for comparing it with a copy kept elsewhere.
     */
    public function checksum($path)
    {
        $entry = PathGuard::resolveEntries([$path], PathGuard::READ)[0];
        if ($entry['type'] !== 'f') {
            throw HttpException::validation(['path' => 'Checksum hanya dapat dihitung untuk berkas biasa.']);
        }
        $file = $entry['path'];
        if (Runner::native()) {
            $md5 = @hash_file('md5', $file);
            $sha256 = @hash_file('sha256', $file);
            if ($md5 === false || $sha256 === false) {
                throw new HttpException(403, 'Berkas tidak dapat dibaca: ' . $file);
            }
            return ['path' => $file, 'md5' => $md5, 'sha256' => $sha256];
        }
        // Reading from stdin keeps the file name out of the output, which md5sum would otherwise escape.
        $result = Runner::run('md5sum < ' . Shell::quote($file) . ' && sha256sum < ' . Shell::quote($file));
        if (!$result->ok() || !preg_match('/^([0-9a-f]{32}) .*\n([0-9a-f]{64}) /', $result->stdout, $m)) {
            $lines = $result->errorLines(2);
            throw new HttpException(403, 'Checksum tidak dapat dihitung' . ($lines ? ': ' . implode(' ', $lines) : '.'));
        }
        return ['path' => $file, 'md5' => $m[1], 'sha256' => $m[2]];
    }

    /**
     * Streams a file inline for the preview dialog, honoring a single byte range so
     * video and audio can seek.
     */
    public function preview($path)
    {
        $entry = PathGuard::resolveEntries([$path], PathGuard::READ)[0];
        if ($entry['type'] !== 'f') {
            throw HttpException::validation(['path' => 'Hanya berkas biasa yang dapat dipratinjau.']);
        }
        $extension = strtolower(pathinfo($entry['path'], PATHINFO_EXTENSION));
        if (!array_key_exists($extension, self::PREVIEW_TYPES)) {
            throw HttpException::validation(['path' => 'Jenis berkas ini tidak dapat dipratinjau. Unduh berkas untuk membukanya.']);
        }
        $type = self::PREVIEW_TYPES[$extension];
        $meta = Finder::statOne($entry['path']);
        $size = $meta ? (int) $meta['size'] : 0;

        $start = 0;
        $end = $size - 1;
        $range = isset($_SERVER['HTTP_RANGE']) ? trim($_SERVER['HTTP_RANGE']) : '';
        $partial = $size > 0 && preg_match('/^bytes=(\d*)-(\d*)$/', $range, $m) && ($m[1] !== '' || $m[2] !== '');
        if ($partial) {
            if ($m[1] === '') {
                $start = max(0, $size - (int) $m[2]);
            } else {
                $start = (int) $m[1];
                if ($m[2] !== '') {
                    $end = min((int) $m[2], $size - 1);
                }
            }
            if ($start > $end) {
                http_response_code(416);
                header('Content-Range: bytes */' . $size);
                return;
            }
        }
        $length = $size > 0 ? $end - $start + 1 : 0;

        $name = PathGuard::base($entry['path']);
        $ascii = preg_replace('/[^A-Za-z0-9._-]/', '_', $name);
        http_response_code($partial ? 206 : 200);
        header('Content-Type: ' . $type);
        header('Content-Disposition: inline; filename="' . $ascii . '"; filename*=UTF-8\'\'' . rawurlencode($name));
        header('Content-Length: ' . $length);
        header('Accept-Ranges: bytes');
        header('Cache-Control: private, no-store');
        header('X-Content-Type-Options: nosniff');
        if ($partial) {
            header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
        }
        if ($type === 'application/pdf') {
            // The preview dialog shows a PDF in a frame of this app; Chrome's PDF viewer does not load in a sandbox.
            header('X-Frame-Options: SAMEORIGIN');
            header("Content-Security-Policy: default-src 'none'; frame-ancestors 'self'");
        } else {
            // Opened directly, an SVG could otherwise run its own scripts on this origin.
            header("Content-Security-Policy: default-src 'none'; img-src 'self' data:; media-src 'self'; style-src 'unsafe-inline'; frame-ancestors 'none'; sandbox");
        }
        if ($length === 0) {
            return;
        }
        if (Runner::native()) {
            NativeFs::output($entry['path'], $start, $length);
            return;
        }
        $command = 'cat -- ' . Shell::quote($entry['path']);
        if ($partial) {
            $command = 'tail -c +' . ($start + 1) . ' -- ' . Shell::quote($entry['path']) . ' | head -c ' . $length;
        }
        Runner::passthru($command);
    }

    /**
     * Validates where an upload would land before any file is sent, so a folder
     * split over several requests is rejected as a whole instead of half way.
     *
     * @param string[] $paths relative paths such as "report.pdf" or "photos/2024/a.jpg"
     * @return array{files:int,folders:int}
     */
    public function uploadCheck($dir, array $paths, $overwrite)
    {
        $layout = $this->uploadLayout($dir, $paths, $overwrite);
        return ['files' => count($layout['targets']), 'folders' => count($layout['create'])];
    }

    /**
     * Builds the plan that writes uploaded files into a folder, creating the
     * subfolders named in their relative paths first.
     *
     * @param array $files normalized entries: name, path, tmp_name, size, error
     */
    public function uploadPlan($dir, array $files, $overwrite)
    {
        if (!$files) {
            throw HttpException::validation(['files' => 'Pilih minimal satu berkas untuk diunggah.']);
        }
        foreach ($files as $file) {
            if ($file['error'] !== UPLOAD_ERR_OK) {
                throw HttpException::validation(['files' => 'Berkas "' . $file['name'] . '" gagal diunggah: ' . $this->uploadError($file['error'])]);
            }
            if (!is_uploaded_file($file['tmp_name'])) {
                throw HttpException::validation(['files' => 'Berkas unggahan tidak valid.']);
            }
            $this->assertUploadSize($file['name'], $file['size']);
        }
        return $this->buildUploadPlan($dir, $files, $overwrite);
    }

    /**
     * Appends one piece of a file larger than the PHP upload limits to its partial file
     * under storage/uploads. The pieces of one file arrive in order, each one starting
     * where the previous one ended.
     *
     * @param array $chunk tmp_name, size, error of the uploaded piece
     * @return int bytes of the file received so far
     */
    public function receiveChunk($uploadId, $name, $offset, $size, array $chunk)
    {
        if ($chunk['error'] !== UPLOAD_ERR_OK) {
            throw HttpException::validation(['files' => 'Berkas "' . $name . '" gagal diunggah: ' . $this->uploadError($chunk['error'])]);
        }
        if (!is_uploaded_file($chunk['tmp_name'])) {
            throw HttpException::validation(['files' => 'Berkas unggahan tidak valid.']);
        }
        $this->assertUploadSize($name, $size);
        if ($size < 1 || $offset < 0 || $chunk['size'] < 1 || $offset + $chunk['size'] > $size) {
            throw HttpException::validation(['files' => 'Potongan berkas "' . $name . '" tidak sesuai dengan ukuran berkasnya.']);
        }
        $part = $this->chunkPath($uploadId);
        if ($offset === 0) {
            $this->sweepChunks();
        } elseif (!is_file($part)) {
            throw new HttpException(409, 'Unggahan berkas "' . $name . '" tidak ditemukan atau sudah kedaluwarsa. Unggah ulang berkas tersebut.');
        }
        $handle = @fopen($part, 'c');
        if ($handle === false) {
            throw new HttpException(500, 'Folder storage/' . self::CHUNK_DIR . ' tidak dapat ditulisi oleh PHP.');
        }
        try {
            flock($handle, LOCK_EX);
            $stat = fstat($handle);
            if ($offset === 0) {
                ftruncate($handle, 0);
            } elseif ($stat['size'] !== $offset) {
                throw new HttpException(409, 'Urutan potongan berkas "' . $name . '" tidak sesuai. Unggah ulang berkas tersebut.');
            }
            fseek($handle, 0, SEEK_END);
            $source = fopen($chunk['tmp_name'], 'rb');
            $copied = $source === false ? false : stream_copy_to_stream($source, $handle);
            if ($source !== false) {
                fclose($source);
            }
            fflush($handle);
            if ($copied !== $chunk['size']) {
                throw new HttpException(500, 'Potongan berkas "' . $name . '" tidak dapat disimpan. Periksa ruang disk server.');
            }
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
        return $offset + $copied;
    }

    /**
     * The upload plan for a file whose pieces have all arrived through receiveChunk().
     */
    public function chunkPlan($uploadId, $dir, $path, $size, $overwrite)
    {
        $part = $this->chunkPath($uploadId);
        clearstatcache(true, $part);
        if (!is_file($part) || filesize($part) !== $size) {
            throw new HttpException(409, 'Berkas belum diterima lengkap. Unggah ulang berkas tersebut.');
        }
        $name = PathGuard::base(str_replace('\\', '/', $path));
        return $this->buildUploadPlan($dir, [['name' => $name, 'path' => $path, 'tmp_name' => $part, 'size' => $size]], $overwrite);
    }

    public function discardChunks($uploadId)
    {
        @unlink($this->chunkPath($uploadId));
    }

    private function chunkPath($uploadId)
    {
        if (!preg_match('/^[a-f0-9]{32}$/', (string) $uploadId)) {
            throw HttpException::validation(['files' => 'Kode unggahan tidak valid.']);
        }
        // Bound to the session, so another session cannot append to or take over this file.
        return DataStore::path(self::CHUNK_DIR) . '/part-' . sha1(session_id() . '|' . $uploadId);
    }

    /**
     * Partial files of uploads that were cancelled or interrupted.
     */
    private function sweepChunks()
    {
        foreach (glob(DataStore::path(self::CHUNK_DIR) . '/part-*') ?: [] as $file) {
            if (@filemtime($file) < time() - 86400) {
                @unlink($file);
            }
        }
    }

    private function assertUploadSize($name, $size)
    {
        $max = Config::int('limits.upload_bytes', 52428800);
        if ($size > $max) {
            throw HttpException::validation(['files' => 'Berkas "' . $name . '" melebihi batas ' . number_format($max / 1048576, 0, ',', '.') . ' MB.']);
        }
    }

    /**
     * @param array $files normalized entries: name, path, tmp_name, size (already validated)
     */
    private function buildUploadPlan($dir, array $files, $overwrite)
    {
        $layout = $this->uploadLayout($dir, array_column($files, 'path'), $overwrite);
        $targets = $layout['targets'];
        $create = $layout['create'];

        $summary = 'Mengunggah ' . count($targets) . ' berkas ke ' . $layout['dir'];
        if ($create) {
            $summary .= ' dan membuat ' . count($create) . ' folder';
        }
        $plan = new Plan('upload', $summary);
        $plan->targets = array_merge($create, array_values($targets));
        if ($create) {
            $label = 'Membuat ' . count($create) . ' folder';
            if (Runner::native()) {
                $plan->addNative(Plan::nativeCall('mkdir', $create), $label, function () use ($create) {
                    foreach ($create as $folder) {
                        NativeFs::makeDir($folder);
                    }
                });
            } else {
                // Parents come before their children, and mkdir handles its arguments in order.
                foreach (Shell::chunkArgs($create) as $chunk) {
                    $plan->add('mkdir -- ' . Shell::quoteAll($chunk), $label);
                }
            }
        }
        foreach ($files as $i => $file) {
            $label = 'Mengunggah ' . PathGuard::base($targets[$i]);
            if (Runner::native()) {
                $source = $file['tmp_name'];
                $target = $targets[$i];
                $plan->addNative(Plan::nativeCall('copy', [$source, $target]), $label, function () use ($source, $target, $overwrite) {
                    NativeFs::copyUpload($source, $target, $overwrite);
                });
                continue;
            }
            // cat keeps the destination's own mode and owner when overwriting, and uses the default umask for new files.
            $redirect = $overwrite ? '' : 'set -C && ';
            $plan->add($redirect . 'cat -- ' . Shell::quote($file['tmp_name']) . ' > ' . Shell::quote($targets[$i]), $label);
        }
        return $plan;
    }

    /**
     * Maps relative upload paths onto the destination folder and works out which
     * subfolders are missing.
     *
     * @param string[] $paths
     * @return array{dir:string,targets:array<int,string>,create:string[]}
     */
    private function uploadLayout($dir, array $paths, $overwrite)
    {
        $dir = PathGuard::resolveDir($dir);
        PathGuard::assertAllowed($dir, PathGuard::CONTENT);
        if (!$paths) {
            throw HttpException::validation(['files' => 'Pilih minimal satu berkas untuk diunggah.']);
        }
        $base = rtrim($dir, '/');
        $targets = [];
        $folders = [];
        foreach ($paths as $i => $path) {
            $segments = $this->relativeSegments($path);
            $name = array_pop($segments);
            $current = $base;
            foreach ($segments as $segment) {
                $current .= '/' . $segment;
                $folders[$this->pathKey($current)] = $current;
            }
            $targets[$i] = $current . '/' . $name;
        }
        $keys = array_map([$this, 'pathKey'], $targets);
        if (count(array_unique($keys)) !== count($targets) || array_intersect($keys, array_keys($folders))) {
            throw HttpException::validation(['files' => 'Ada beberapa berkas atau folder dengan nama yang sama.']);
        }

        // Every existing level must be a real folder: a symlink here could lead the write outside the roots.
        $create = [];
        $folders = array_values($folders);
        foreach (PathGuard::inspect($folders) as $i => $info) {
            $folder = $info === null ? $folders[$i] : $info['path'];
            if ($info !== null && ($info['type'] === 'f' || $info['type'] === 'l')) {
                throw new HttpException(409, 'Folder "' . $this->relative($folder, $base) . '" tidak dapat dibuat karena sudah ada berkas atau symlink dengan nama tersebut di folder tujuan.');
            }
            PathGuard::assertAllowed($folder, PathGuard::CONTENT);
            if ($info === null || $info['type'] === 'n') {
                $create[] = $folder;
            }
        }

        $conflicts = [];
        $list = array_values($targets);
        foreach (PathGuard::inspect($list) as $i => $info) {
            PathGuard::assertAllowed($list[$i], PathGuard::CONTENT);
            if ($info === null || $info['type'] === 'n') {
                continue;
            }
            if ($info['type'] !== 'f') {
                throw new HttpException(409, 'Sudah ada folder atau symlink bernama "' . $this->relative($list[$i], $base) . '" di folder tujuan.');
            }
            $conflicts[] = $list[$i];
        }
        if ($conflicts && !$overwrite) {
            $names = [];
            foreach (array_slice($conflicts, 0, 5) as $path) {
                $names[] = $this->relative($path, $base);
            }
            $more = count($conflicts) > 5 ? ', dan ' . (count($conflicts) - 5) . ' berkas lainnya' : '';
            throw new HttpException(409, 'Berkas berikut sudah ada di folder tujuan: ' . implode(', ', $names) . $more . '. Aktifkan opsi timpa untuk menggantinya.', ['conflicts' => $conflicts]);
        }
        return ['dir' => $dir, 'targets' => $targets, 'create' => $create];
    }

    /**
     * @return string[] validated path segments, the last one being the file name
     */
    private function relativeSegments($path)
    {
        $segments = [];
        foreach (explode('/', str_replace('\\', '/', (string) $path)) as $segment) {
            if ($segment !== '') {
                $segments[] = PathGuard::name($segment, 'files');
            }
        }
        if (!$segments) {
            throw HttpException::validation(['files' => 'Nama berkas unggahan kosong.']);
        }
        return $segments;
    }

    private function relative($path, $base)
    {
        return ltrim(substr($path, strlen($base)), '/');
    }

    /**
     * Windows treats names that differ only in letter case as the same file.
     */
    private function pathKey($path)
    {
        return Runner::isWindows() ? strtolower($path) : $path;
    }

    private function readBytes($path, $limit)
    {
        if (Runner::native()) {
            try {
                return NativeFs::readBytes($path, $limit);
            } catch (\RuntimeException $e) {
                throw new HttpException(403, $e->getMessage());
            }
        }
        $result = Runner::run('head -c ' . $limit . ' -- ' . Shell::quote($path), null, 30);
        if (!$result->ok()) {
            throw new HttpException(403, 'Berkas tidak dapat dibaca: ' . implode(' ', $result->errorLines(2)));
        }
        return $result->stdout;
    }

    private function uploadError($code)
    {
        switch ($code) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return 'ukuran melebihi batas server.';
            case UPLOAD_ERR_PARTIAL:
                return 'unggahan terputus.';
            case UPLOAD_ERR_NO_FILE:
                return 'tidak ada berkas.';
            default:
                return 'kesalahan server (kode ' . $code . ').';
        }
    }
}
