<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Entry;
use App\Http\HttpException;
use App\Storage\DataStore;
use App\Support\Random;
use App\Support\Validate;

final class PresetService
{
    const FILE = 'presets.php';

    const SEED = [
        ['name' => 'Web standar', 'description' => 'Folder 755 dan berkas 644. Cocok untuk kode situs yang hanya dibaca web server.', 'dir_mode' => '0755', 'file_mode' => '0644', 'owner' => '', 'group' => ''],
        ['name' => 'Folder tulis aplikasi', 'description' => 'Folder 775 dan berkas 664 untuk storage, cache, atau uploads yang ditulisi aplikasi.', 'dir_mode' => '0775', 'file_mode' => '0664', 'owner' => '', 'group' => ''],
        ['name' => 'Privat pemilik', 'description' => 'Folder 700 dan berkas 600. Hanya pemilik yang dapat membaca dan mengubah.', 'dir_mode' => '0700', 'file_mode' => '0600', 'owner' => '', 'group' => ''],
        ['name' => 'Konfigurasi sensitif', 'description' => 'Berkas 640 untuk .env atau kredensial: pemilik baca-tulis, grup baca saja.', 'dir_mode' => '', 'file_mode' => '0640', 'owner' => '', 'group' => ''],
    ];

    public function all()
    {
        $this->seed();
        return DataStore::readJson(self::FILE);
    }

    public function find($id)
    {
        foreach ($this->all() as $preset) {
            if ($preset['id'] === $id) {
                return $preset;
            }
        }
        throw new HttpException(404, 'Preset tidak ditemukan. Preset mungkin sudah dihapus.');
    }

    public function save(array $input, $id, $user)
    {
        $data = $this->validate($input);
        $this->seed();
        return DataStore::mutateJson(self::FILE, function (array &$rows) use ($data, $id, $user) {
            foreach ($rows as $row) {
                if (strcasecmp($row['name'], $data['name']) === 0 && $row['id'] !== $id) {
                    throw HttpException::validation(['name' => 'Nama preset sudah dipakai.']);
                }
            }
            $now = gmdate('c');
            if ($id === null) {
                $row = $data + ['id' => 'p_' . Random::hex(6), 'created_at' => $now, 'updated_at' => $now, 'updated_by' => $user];
                $rows[] = $row;
                return $row;
            }
            foreach ($rows as $i => $row) {
                if ($row['id'] === $id) {
                    $rows[$i] = array_merge($row, $data, ['updated_at' => $now, 'updated_by' => $user]);
                    return $rows[$i];
                }
            }
            throw new HttpException(404, 'Preset tidak ditemukan. Preset mungkin sudah dihapus.');
        });
    }

    public function delete($id)
    {
        return DataStore::mutateJson(self::FILE, function (array &$rows) use ($id) {
            foreach ($rows as $i => $row) {
                if ($row['id'] === $id) {
                    array_splice($rows, $i, 1);
                    return $row;
                }
            }
            throw new HttpException(404, 'Preset tidak ditemukan. Preset mungkin sudah dihapus.');
        });
    }

    private function validate(array $input)
    {
        $errors = [];
        $data = [];
        foreach (['name' => [80, true], 'description' => [200, false]] as $field => $rule) {
            try {
                $data[$field] = Validate::text((string) (isset($input[$field]) ? $input[$field] : ''), $field, $rule[0], $rule[1]);
            } catch (HttpException $e) {
                $errors += $e->errors();
            }
        }
        foreach (['dir_mode', 'file_mode'] as $field) {
            try {
                $mode = Validate::mode((string) (isset($input[$field]) ? $input[$field] : ''), $field, false);
                $data[$field] = $mode === null ? '' : Entry::octal($mode);
            } catch (HttpException $e) {
                $errors += $e->errors();
            }
        }
        foreach (['owner', 'group'] as $field) {
            try {
                $data[$field] = (string) Validate::principal((string) (isset($input[$field]) ? $input[$field] : ''), $field);
            } catch (HttpException $e) {
                $errors += $e->errors();
            }
        }
        if (!$errors && $data['dir_mode'] === '' && $data['file_mode'] === '' && $data['owner'] === '' && $data['group'] === '') {
            $errors['dir_mode'] = 'Isi minimal satu nilai: izin folder, izin berkas, pemilik, atau grup.';
        }
        if ($errors) {
            throw HttpException::validation($errors);
        }
        return $data;
    }

    private function seed()
    {
        if (is_file(DataStore::path(self::FILE))) {
            return;
        }
        DataStore::mutateJson(self::FILE, function (array &$rows) {
            if ($rows) {
                return;
            }
            $now = gmdate('c');
            foreach (self::SEED as $preset) {
                $rows[] = $preset + ['id' => 'p_' . Random::hex(6), 'created_at' => $now, 'updated_at' => $now, 'updated_by' => 'sistem'];
            }
        });
    }
}
