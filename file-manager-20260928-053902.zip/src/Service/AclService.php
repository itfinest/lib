<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Http\HttpException;
use App\System\Runner;
use App\System\Shell;

final class AclService
{
    const TAGS = ['u' => 'user', 'user' => 'user', 'g' => 'group', 'group' => 'group', 'm' => 'mask', 'mask' => 'mask', 'o' => 'other', 'other' => 'other'];

    public static function available()
    {
        return Runner::hasTool('getfacl') && Runner::hasTool('setfacl');
    }

    public static function assertAvailable()
    {
        if (!self::available()) {
            throw new HttpException(503, Runner::native()
                ? 'ACL membutuhkan perintah getfacl dan setfacl, yang tidak dapat dijalankan karena fungsi PHP proc_open nonaktif di server ini.'
                : 'Perintah getfacl dan setfacl tidak tersedia di server ini. ACL hanya dapat dikelola bila paket acl terpasang.');
        }
    }

    /**
     * @return array{entries:array[],default:array[],extended:bool}
     */
    public function read($path)
    {
        $out = Runner::run('getfacl -p -- ' . Shell::quote($path), null, 15)->stdout;
        $entries = [];
        $defaults = [];
        foreach (explode("\n", $out) as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#') {
                continue;
            }
            $isDefault = strncmp($line, 'default:', 8) === 0;
            if ($isDefault) {
                $line = substr($line, 8);
            }
            $comment = '';
            if (($pos = strpos($line, '#')) !== false) {
                $comment = trim(substr($line, $pos + 1));
                $line = trim(substr($line, 0, $pos));
            }
            $parts = explode(':', $line);
            if (count($parts) < 3) {
                continue;
            }
            $row = [
                'tag' => $parts[0],
                'qualifier' => $parts[1],
                'perms' => $parts[2],
                'effective' => strpos($comment, 'effective:') === 0 ? substr($comment, 10) : '',
            ];
            if ($isDefault) {
                $defaults[] = $row;
            } else {
                $entries[] = $row;
            }
        }
        $extended = false;
        foreach ($entries as $row) {
            if ($row['qualifier'] !== '' || $row['tag'] === 'mask') {
                $extended = true;
            }
        }
        return ['entries' => $entries, 'default' => $defaults, 'extended' => $extended || (bool) $defaults];
    }

    /**
     * Normalizes an ACL entry, e.g. "user:deploy:rwx" -> "u:deploy:rwx".
     */
    public static function spec($value, $withPerms)
    {
        $parts = explode(':', trim($value));
        $tag = strtolower(isset($parts[0]) ? $parts[0] : '');
        $tags = self::TAGS;
        if (!isset($tags[$tag])) {
            throw HttpException::validation(['spec' => 'Jenis entri ACL harus user, group, mask, atau other.']);
        }
        $short = substr($tags[$tag], 0, 1);
        $qualifier = (isset($parts[1]) ? $parts[1] : '');
        if ($qualifier !== '' && !preg_match('/^[A-Za-z0-9_][A-Za-z0-9._-]{0,63}\$?$/', $qualifier)) {
            throw HttpException::validation(['spec' => 'Nama pengguna atau grup pada entri ACL tidak valid.']);
        }
        if (!$withPerms) {
            if ($qualifier === '' || !in_array($short, ['u', 'g'], true)) {
                throw HttpException::validation(['spec' => 'Entri yang dapat dihapus hanya entri user atau group bernama.']);
            }
            return $short . ':' . $qualifier;
        }
        $perms = (isset($parts[2]) ? $parts[2] : '');
        if (!preg_match('/^[rwxX-]{1,3}$/', $perms) || count($parts) !== 3) {
            throw HttpException::validation(['spec' => 'Format entri ACL: jenis:nama:izin, misalnya user:deploy:rwx.']);
        }
        if (in_array($short, ['m', 'o'], true) && $qualifier !== '') {
            throw HttpException::validation(['spec' => 'Entri mask dan other tidak memakai nama.']);
        }
        return $short . ':' . $qualifier . ':' . $perms;
    }
}
