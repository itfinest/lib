<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Entry;
use App\Fs\Finder;
use App\Fs\NativeFs;
use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Support\Config;
use App\Support\Validate;
use App\System\Accounts;
use App\System\Runner;
use App\System\Shell;

/**
 * chmod, chown, presets, and ACL changes. Every command is a find expression
 * that selects only entries whose current value differs, so the dry run and
 * the real run act on the same set. Without a shell the same selection is a
 * filter on a native walk, and the change is a PHP chmod or chown per entry.
 */
final class PermissionOperations
{
    public function chmod(array $p)
    {
        $dirMode = Validate::mode((string) (isset($p['dir_mode']) ? $p['dir_mode'] : ''), 'dir_mode', false);
        $fileMode = Validate::mode((string) (isset($p['file_mode']) ? $p['file_mode'] : ''), 'file_mode', false);
        if ($dirMode === null && $fileMode === null) {
            throw HttpException::validation(['dir_mode' => 'Isi mode izin untuk folder, berkas, atau keduanya.']);
        }
        list($paths, $recursive, $plan) = $this->begin($p, 'chmod', 'Mengubah izin');
        $this->addChmod($plan, $paths, $recursive, $dirMode, $fileMode);
        $plan->summary = 'Mengubah izin ' . $this->describeScope($paths, $recursive)
            . $this->describeModes($dirMode, $fileMode);
        $this->attachImpact($plan, $paths, $recursive, $dirMode, $fileMode, null, null);
        return $plan;
    }

    public function chown(array $p)
    {
        $owner = Validate::principal((string) (isset($p['owner']) ? $p['owner'] : ''), 'owner');
        $group = Validate::principal((string) (isset($p['group']) ? $p['group'] : ''), 'group');
        if ($owner === null && $group === null) {
            throw HttpException::validation(['owner' => 'Isi pemilik, grup, atau keduanya.']);
        }
        $this->assertPrincipalExists($owner, $group);
        list($paths, $recursive, $plan) = $this->begin($p, 'chown', 'Mengubah pemilik');
        $this->addChown($plan, $paths, $recursive, $owner, $group);
        $plan->summary = 'Mengubah pemilik ' . $this->describeScope($paths, $recursive)
            . ' menjadi ' . (isset($owner) ? $owner : '(tetap)') . ':' . (isset($group) ? $group : '(tetap)');
        $this->attachImpact($plan, $paths, $recursive, null, null, $owner, $group);
        return $plan;
    }

    public function preset(array $p)
    {
        $preset = (new PresetService())->find((string) (isset($p['preset_id']) ? $p['preset_id'] : ''));
        $dirMode = Validate::mode((string) $preset['dir_mode'], 'dir_mode', false);
        $fileMode = Validate::mode((string) $preset['file_mode'], 'file_mode', false);
        $owner = Validate::principal((string) $preset['owner'], 'owner');
        $group = Validate::principal((string) $preset['group'], 'group');
        $this->assertPrincipalExists($owner, $group);
        list($paths, $recursive, $plan) = $this->begin($p, 'preset', 'Menerapkan preset');
        if ($dirMode !== null || $fileMode !== null) {
            $this->addChmod($plan, $paths, $recursive, $dirMode, $fileMode);
        }
        if ($owner !== null || $group !== null) {
            $this->addChown($plan, $paths, $recursive, $owner, $group);
        }
        $plan->summary = 'Menerapkan preset "' . $preset['name'] . '" pada ' . $this->describeScope($paths, $recursive);
        $this->attachImpact($plan, $paths, $recursive, $dirMode, $fileMode, $owner, $group);
        return $plan;
    }

    public function acl(array $p)
    {
        AclService::assertAvailable();
        $action = Validate::oneOf((string) (isset($p['action']) ? $p['action'] : ''), ['modify', 'remove', 'clear'], '');
        if ($action === '') {
            throw HttpException::validation(['action' => 'Pilih tindakan ACL.']);
        }
        $default = !empty($p['default']);
        list($paths, $recursive, $plan) = $this->begin($p, 'acl', 'Mengubah ACL');
        $plan->snapshot['acl'] = true;

        if ($action === 'clear') {
            $args = '-b';
            $label = 'Menghapus seluruh ACL tambahan';
        } else {
            $spec = AclService::spec((string) (isset($p['spec']) ? $p['spec'] : ''), $action === 'modify');
            $args = ($default ? '-d ' : '') . ($action === 'modify' ? '-m ' : '-x ') . Shell::quote($spec);
            $label = ($action === 'modify' ? 'Menetapkan entri ACL ' : 'Menghapus entri ACL ') . $spec . ($default ? ' (default)' : '');
        }
        // Default ACLs only exist on folders.
        $conditions = $default ? '-type d' : '-type d -o -type f';
        $plan->add(
            Finder::command($paths, $this->findOptions($paths, $recursive, $conditions), '-exec setfacl ' . $args . ' -- {} +'),
            $label
        );
        $plan->summary = $label . ' pada ' . $this->describeScope($paths, $recursive);
        $plan->impact = function () use ($paths, $recursive, $conditions) {
            $opt = $this->findOptions($paths, $recursive, $conditions);
            $counted = Finder::count($paths, $opt);
            $items = [];
            foreach (Finder::scan($paths, $opt + ['limit' => $this->previewLimit()])['entries'] as $e) {
                $items[] = ['path' => $e['path'], 'before' => $e['perms'], 'after' => 'ACL diperbarui', 'note' => ''];
            }
            return ['count' => $counted['count'], 'capped' => $counted['capped'], 'items' => $items, 'unit' => 'entri akan diproses'];
        };
        return $plan;
    }

    /**
     * @return array{0:string[],1:bool,2:Plan}
     */
    private function begin(array $p, $op, $summary)
    {
        $raw = (isset($p['paths']) ? $p['paths'] : []);
        $raw = is_array($raw) ? array_values(array_filter($raw, 'is_string')) : [];
        $max = Config::int('limits.list', 5000);
        if (count($raw) > $max) {
            throw HttpException::validation(['paths' => 'Maksimal ' . $max . ' item per operasi.']);
        }
        $entries = PathGuard::resolveEntries($raw, PathGuard::CONTENT);
        $recursive = !empty($p['recursive']);
        $plan = new Plan($op, $summary);
        $paths = [];
        $links = [];
        foreach ($entries as $entry) {
            if ($entry['type'] === 'l' && $op !== 'chown') {
                $links[] = basename($entry['path']);
                continue;
            }
            $paths[] = $entry['path'];
        }
        if ($links) {
            $plan->warnings[] = 'Symlink dilewati karena izin symlink mengikuti berkas tujuannya: ' . implode(', ', array_slice($links, 0, 5)) . (count($links) > 5 ? ', dan lainnya' : '') . '.';
        }
        if (!$paths) {
            throw HttpException::validation(['paths' => 'Tidak ada berkas atau folder yang dapat diproses. Symlink tidak dapat diubah izinnya.']);
        }
        if ($recursive && PathGuard::pruneFor($paths)) {
            $plan->warnings[] = 'Folder aplikasi File Manager dikecualikan dari perubahan rekursif.';
        }
        $plan->targets = $paths;
        $plan->snapshot = ['paths' => $paths, 'recursive' => $recursive, 'acl' => false];
        return [$paths, $recursive, $plan];
    }

    /**
     * @param string $conditions find expression for the shell
     * @param callable|null $filter the same selection for a native walk
     */
    private function findOptions(array $paths, $recursive, $conditions, $filter = null)
    {
        $opt = ['hidden' => true, 'prune' => PathGuard::pruneFor($paths), 'conditions' => $conditions, 'match' => ['filter' => $filter]];
        if (!$recursive) {
            $opt['maxdepth'] = 0;
        }
        return $opt;
    }

    private function addChmod(Plan $plan, array $paths, $recursive, $dirMode, $fileMode)
    {
        foreach (['d' => $dirMode, 'f' => $fileMode] as $type => $mode) {
            if ($mode === null) {
                continue;
            }
            $label = ($type === 'd' ? 'Izin folder menjadi ' : 'Izin berkas menjadi ') . Entry::octal($mode);
            if (Runner::native()) {
                $opt = $this->findOptions($paths, $recursive, '', $this->modeFilter($type, $mode));
                $display = 'PHP chmod(' . Entry::octal($mode) . ') untuk setiap ' . ($type === 'd' ? 'folder' : 'berkas') . ' yang berbeda di ' . $this->describePaths($paths, $recursive);
                $plan->addNative($display, $label, function () use ($paths, $opt, $mode) {
                    NativeFs::changeEach($this->collect($paths, $opt), function ($path) use ($mode) {
                        NativeFs::setMode($path, $mode);
                    });
                });
                continue;
            }
            $arg = Validate::chmodArg($mode);
            $plan->add(
                Finder::command($paths, $this->findOptions($paths, $recursive, '-type ' . $type . ' ! -perm ' . $arg), '-exec chmod ' . $arg . ' -- {} +'),
                $label
            );
        }
    }

    private function addChown(Plan $plan, array $paths, $recursive, $owner, $group)
    {
        $spec = (isset($owner) ? $owner : '') . ($group !== null ? ':' . $group : '');
        if (Runner::native()) {
            $opt = $this->findOptions($paths, $recursive, '', $this->ownerFilter($owner, $group));
            $display = 'PHP chown/chgrp(' . $spec . ') untuk setiap entri yang berbeda di ' . $this->describePaths($paths, $recursive);
            $plan->addNative($display, 'Pemilik menjadi ' . $spec, function () use ($paths, $opt, $owner, $group) {
                NativeFs::changeEach($this->collect($paths, $opt), function ($path) use ($owner, $group) {
                    NativeFs::setOwner($path, $owner, $group);
                });
            });
            return;
        }
        $plan->add(
            Finder::command($paths, $this->findOptions($paths, $recursive, $this->ownerCondition($owner, $group)), '-exec chown -h ' . Shell::quote($spec) . ' -- {} +'),
            'Pemilik menjadi ' . $spec
        );
    }

    /**
     * Paths the walk selects, gathered before anything changes so a change cannot alter the walk.
     *
     * @return string[]
     */
    private function collect(array $paths, array $opt)
    {
        $found = [];
        NativeFs::each($paths, $opt, function (array $entry) use (&$found) {
            $found[] = $entry['path'];
        });
        return $found;
    }

    /**
     * Native counterpart of -type d|f ! -perm MODE.
     */
    private function modeFilter($type, $mode)
    {
        $want = $type === 'd' ? 'dir' : 'file';
        return function (array $e) use ($want, $mode) {
            return $e['type'] === $want && ($e['mode'] & 07777) !== $mode;
        };
    }

    /**
     * Native counterpart of ! -user OWNER -o ! -group GROUP; like find, a name or a numeric id matches.
     */
    private function ownerFilter($owner, $group)
    {
        return function (array $e) use ($owner, $group) {
            $ownerDiffers = $owner !== null && $e['owner'] !== $owner && (string) $e['uid'] !== $owner;
            $groupDiffers = $group !== null && $e['group'] !== $group && (string) $e['gid'] !== $group;
            return $ownerDiffers || $groupDiffers;
        };
    }

    private function describePaths(array $paths, $recursive)
    {
        $shown = implode(', ', array_slice($paths, 0, 3)) . (count($paths) > 3 ? ', dan ' . (count($paths) - 3) . ' lainnya' : '');
        return $shown . ($recursive ? ' beserta isinya' : '');
    }

    private function ownerCondition($owner, $group)
    {
        $parts = [];
        if ($owner !== null) {
            $parts[] = '! -user ' . Shell::quote($owner);
        }
        if ($group !== null) {
            $parts[] = '! -group ' . Shell::quote($group);
        }
        return implode(' -o ', $parts);
    }

    private function attachImpact(Plan $plan, array $paths, $recursive, $dirMode, $fileMode, $owner, $group)
    {
        $alternatives = [];
        if ($dirMode !== null) {
            $alternatives[] = '\( -type d ! -perm ' . Validate::chmodArg($dirMode) . ' \)';
        }
        if ($fileMode !== null) {
            $alternatives[] = '\( -type f ! -perm ' . Validate::chmodArg($fileMode) . ' \)';
        }
        if ($owner !== null || $group !== null) {
            $alternatives[] = '\( ' . $this->ownerCondition($owner, $group) . ' \)';
        }
        $conditions = implode(' -o ', $alternatives);
        $filters = [];
        if ($dirMode !== null) {
            $filters[] = $this->modeFilter('d', $dirMode);
        }
        if ($fileMode !== null) {
            $filters[] = $this->modeFilter('f', $fileMode);
        }
        if ($owner !== null || $group !== null) {
            $filters[] = $this->ownerFilter($owner, $group);
        }
        $filter = function (array $e) use ($filters) {
            foreach ($filters as $one) {
                if ($one($e)) {
                    return true;
                }
            }
            return false;
        };

        $plan->impact = function () use ($paths, $recursive, $conditions, $filter, $dirMode, $fileMode, $owner, $group) {
            $opt = $this->findOptions($paths, $recursive, $conditions, $filter);
            $counted = Finder::count($paths, $opt);
            $items = [];
            foreach (Finder::scan($paths, $opt + ['limit' => $this->previewLimit()])['entries'] as $e) {
                $before = [];
                $after = [];
                $mode = $e['type'] === 'dir' ? $dirMode : ($e['type'] === 'file' ? $fileMode : null);
                if ($mode !== null && ($e['mode'] & 07777) !== $mode) {
                    $before[] = $e['octal'];
                    $after[] = Entry::octal($mode);
                }
                $newOwner = (isset($owner) ? $owner : $e['owner']);
                $newGroup = (isset($group) ? $group : $e['group']);
                if ($newOwner !== $e['owner'] || $newGroup !== $e['group']) {
                    $before[] = $e['owner'] . ':' . $e['group'];
                    $after[] = $newOwner . ':' . $newGroup;
                }
                if ($before) {
                    $items[] = ['path' => $e['path'], 'before' => implode(' ', $before), 'after' => implode(' ', $after), 'note' => ''];
                }
            }
            return ['count' => $counted['count'], 'capped' => $counted['capped'], 'items' => $items, 'unit' => 'entri akan berubah'];
        };
    }

    private function assertPrincipalExists($owner, $group)
    {
        if (Runner::native()) {
            if (!Accounts::available()) {
                return;
            }
            if ($owner !== null && Accounts::user($owner) === null) {
                throw HttpException::validation(['owner' => 'Pengguna "' . $owner . '" tidak ditemukan di server ini.']);
            }
            if ($group !== null && !Accounts::groupExists($group)) {
                throw HttpException::validation(['group' => 'Grup "' . $group . '" tidak ditemukan di server ini.']);
            }
            return;
        }
        if (!Runner::hasTool('getent')) {
            return;
        }
        if ($owner !== null && !ctype_digit($owner) && !Runner::run('getent passwd ' . Shell::quote($owner), null, 10)->ok()) {
            throw HttpException::validation(['owner' => 'Pengguna "' . $owner . '" tidak ditemukan di server ini.']);
        }
        if ($group !== null && !ctype_digit($group) && !Runner::run('getent group ' . Shell::quote($group), null, 10)->ok()) {
            throw HttpException::validation(['group' => 'Grup "' . $group . '" tidak ditemukan di server ini.']);
        }
    }

    private function describeScope(array $paths, $recursive)
    {
        $what = count($paths) === 1 ? basename($paths[0]) : count($paths) . ' item';
        return $what . ($recursive ? ' beserta isinya' : '');
    }

    private function describeModes($dirMode, $fileMode)
    {
        $parts = [];
        if ($dirMode !== null) {
            $parts[] = 'folder ' . Entry::octal($dirMode);
        }
        if ($fileMode !== null) {
            $parts[] = 'berkas ' . Entry::octal($fileMode);
        }
        return ' (' . implode(', ', $parts) . ')';
    }

    private function previewLimit()
    {
        return Config::int('limits.preview_items', 200);
    }
}
