<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Finder;
use App\Fs\NativeFs;
use App\Fs\PathGuard;
use App\Http\Request;
use App\Support\Cmp;
use App\Support\Config;
use App\Support\ListQuery;
use App\Support\Validate;
use App\System\Accounts;
use App\System\Runner;
use App\System\Shell;

final class ExplorerService
{
    const SORTABLE = ['name', 'size', 'mtime', 'mode', 'owner', 'group', 'type'];
    const RECURSIVE_DEPTH = 25;
    const WINDOWS_PROGRAMS = ['exe', 'com', 'bat', 'cmd'];

    public function listing(Request $request)
    {
        $roots = PathGuard::roots();
        $pathParam = $request->queryString('path');
        $cwd = PathGuard::resolveDir($pathParam === '' ? PathGuard::defaultPath() : $pathParam);

        $search = $request->queryString('search');
        $recursive = $request->queryString('recursive') === '1';
        $hidden = $request->queryString('hidden') === '1';
        $dangerOnly = $request->queryString('danger') === '1';
        $type = Validate::oneOf($request->queryString('type'), ['file', 'dir', 'link'], '');
        $owner = Validate::principal($request->queryString('owner'), 'owner');
        $group = Validate::principal($request->queryString('group'), 'group');
        $sortBy = Validate::oneOf($request->queryString('sort_by'), self::SORTABLE, 'name');
        $sortDir = $request->queryString('sort_dir') === 'desc' ? 'desc' : 'asc';

        $conditions = [];
        if ($search !== '') {
            $conditions[] = '-iname ' . Shell::quote('*' . Shell::globLiteral($search) . '*');
        }
        if ($type !== '') {
            $conditions[] = '-type ' . ['file' => 'f', 'dir' => 'd', 'link' => 'l'][$type];
        }
        if ($owner !== null) {
            $conditions[] = '-user ' . Shell::quote($owner);
        }
        if ($group !== null) {
            $conditions[] = '-group ' . Shell::quote($group);
        }

        $scan = Finder::scan([$cwd], [
            'mindepth' => 1,
            'maxdepth' => $recursive ? self::RECURSIVE_DEPTH : 1,
            'xdev' => $recursive,
            'hidden' => $hidden,
            'hide_names' => $hidden ? [] : self::hiddenNames(),
            'conditions' => implode(' ', $conditions),
            'match' => ['search' => $search, 'type' => $type, 'filter' => $this->principalFilter($owner, $group)],
            'limit' => Config::int('limits.list', 5000),
        ]);

        $entries = $scan['entries'];
        if ($dangerOnly) {
            $entries = array_values(array_filter($entries, function ($e) {
                return !empty($e['danger']);
            }));
        }
        $this->sort($entries, $sortBy, $sortDir);

        $pagination = ListQuery::paginate($request, count($entries));
        $items = array_slice($entries, ($pagination['current_page'] - 1) * $pagination['per_page'], $pagination['per_page']);
        foreach ($items as &$item) {
            $item['rel'] = ltrim(substr($item['path'], strlen(rtrim($cwd, '/'))), '/');
            $item['access'] = $this->access($item);
            $item['url'] = $this->publicUrl($item['path'], $item['type'] === 'dir');
        }
        unset($item);

        return [
            'cwd' => $cwd,
            'root' => $this->rootOf($cwd),
            'roots' => $roots,
            'breadcrumbs' => $this->breadcrumbs($cwd),
            'parent' => $this->parentOf($cwd),
            'items' => $items,
            'pagination' => $pagination,
            'truncated' => $scan['truncated'],
            'warnings' => $scan['warnings'],
            'cwd_access' => ['add' => PathGuard::allows($cwd, PathGuard::CONTENT) && $this->writable($cwd)],
        ];
    }

    /**
     * File and folder names left out of listings (setting hidden_names), like dot files,
     * until Tampilkan tersembunyi is checked.
     *
     * @return string[]
     */
    public static function hiddenNames()
    {
        return array_values(array_filter((array) Config::get('hidden_names', []), 'is_string'));
    }

    /**
     * Folder-only listing for the destination picker in copy and move.
     */
    public function folders(Request $request)
    {
        $roots = PathGuard::roots();
        $pathParam = $request->queryString('path');
        $cwd = PathGuard::resolveDir($pathParam === '' ? PathGuard::defaultPath() : $pathParam);
        $hidden = $request->queryString('hidden') === '1';
        $scan = Finder::scan([$cwd], [
            'mindepth' => 1,
            'maxdepth' => 1,
            'hidden' => $hidden,
            'hide_names' => $hidden ? [] : self::hiddenNames(),
            'conditions' => '\( -type d -o \( -type l -xtype d \) \)',
            'match' => ['type' => 'folder'],
            'limit' => 2000,
        ]);
        $folders = $scan['entries'];
        usort($folders, function ($a, $b) {
            return strnatcasecmp($a['name'], $b['name']);
        });
        return [
            'cwd' => $cwd,
            'roots' => $roots,
            'breadcrumbs' => $this->breadcrumbs($cwd),
            'parent' => $this->parentOf($cwd),
            'folders' => array_map(function ($f) {
                $access = null;
                if ($f['type'] === 'dir') {
                    // The picker chooses a destination, so only opening the folder and adding to it matter.
                    $all = $this->access($f);
                    $access = ['read' => $all['read'], 'add' => $all['add']];
                }
                return [
                    'name' => $f['name'],
                    'path' => $f['path'],
                    'link' => $f['type'] === 'link',
                    'octal' => $f['octal'],
                    'perms' => $f['perms'],
                    'owner' => $f['owner'],
                    'group' => $f['group'],
                    'access' => $access,
                ];
            }, $folders),
            'truncated' => $scan['truncated'],
            'cwd_access' => ['add' => PathGuard::allows($cwd, PathGuard::CONTENT) && $this->writable($cwd)],
        ];
    }

    public function detail($path)
    {
        $info = PathGuard::resolveEntries([$path], PathGuard::READ)[0];
        $entry = Finder::statOne($info['path']);
        if ($entry === null) {
            return ['path' => $info['path'], 'readable' => false];
        }
        $acl = null;
        if ($entry['type'] !== 'link' && Runner::hasTool('getfacl')) {
            $acl = (new AclService())->read($info['path']);
        }
        $resolved = null;
        if ($entry['type'] === 'link') {
            $real = PathGuard::realpaths([$info['path']])[0];
            $resolved = [
                'path' => $real,
                'inside_roots' => $real !== '' && PathGuard::inRoots($real),
            ];
        }
        return [
            'entry' => $entry,
            'acl' => $acl,
            'link_resolved' => $resolved,
            'access' => $this->access($entry),
            'url' => $this->publicUrl($info['path'], $entry['type'] === 'dir'),
        ];
    }

    /**
     * Accounts and groups for the owner and group pickers.
     */
    public function principals()
    {
        $users = [];
        $groups = [];
        if (Runner::native() && Runner::unixPermissions()) {
            $all = Accounts::all();
            $users = $all['users'];
            $groups = $all['groups'];
        } elseif (Runner::hasTool('getent')) {
            foreach (explode("\n", Runner::run('getent passwd', null, 15)->stdout) as $line) {
                $parts = explode(':', $line);
                if (count($parts) >= 3) {
                    $users[] = ['name' => $parts[0], 'id' => (int) $parts[2]];
                }
            }
            foreach (explode("\n", Runner::run('getent group', null, 15)->stdout) as $line) {
                $parts = explode(':', $line);
                if (count($parts) >= 3) {
                    $groups[] = ['name' => $parts[0], 'id' => (int) $parts[2]];
                }
            }
        }
        $byName = function ($a, $b) {
            return strcmp($a['name'], $b['name']);
        };
        usort($users, $byName);
        usort($groups, $byName);
        return ['users' => $users, 'groups' => $groups];
    }

    /**
     * What can be done with an entry: read (a file's content, or a folder's
     * listing), edit (a file's content, or a folder's name), delete, add (new
     * items inside a folder), and execute (files only). Read and execute are
     * null for symlinks, add is null for files, and execute is null for
     * folders. The path guard decides first, then the permissions of the
     * account that makes the change on disk.
     *
     * @return array{read:bool|null,edit:bool,delete:bool,add:bool|null,exec:bool|null,note:string}
     */
    private function access(array $entry)
    {
        $path = $entry['path'];
        $notes = [];
        $read = null;
        $exec = null;
        if ($entry['type'] === 'file') {
            $read = $this->permitted($entry, 4);
            $exec = $this->permitted($entry, 1);
            if (!$read) {
                $notes[] = 'Berkas tidak dapat dibaca oleh akun PHP.';
            }
        } elseif ($entry['type'] === 'dir') {
            // Listing a folder needs both its read (r) and its search (x) permission.
            $search = $this->permitted($entry, 1);
            $read = $search && $this->permitted($entry, 4);
            if (!$search) {
                $notes[] = 'Akun PHP tidak memiliki izin masuk (x) ke folder ini.';
            } elseif (!$read) {
                $notes[] = 'Akun PHP tidak memiliki izin baca (r) pada folder ini, sehingga isinya tidak dapat ditampilkan.';
            }
        }
        $content = PathGuard::allows($path, PathGuard::CONTENT);
        $structure = PathGuard::allows($path, PathGuard::STRUCTURE);
        if (!$content) {
            $notes[] = 'Folder aplikasi dilindungi dari perubahan.';
        } elseif (!$structure) {
            $notes[] = PathGuard::isRoot($path) ? 'Folder root tidak dapat dihapus atau diganti namanya.' : 'Berisi folder aplikasi sehingga tidak dapat dihapus atau diganti namanya.';
        }
        $parent = PathGuard::parent($path);
        $parentWritable = $this->writable($parent) && $this->stickyAllows($entry, $parent);
        if ($structure && !$parentWritable) {
            $notes[] = 'Folder induk tidak dapat ditulisi oleh akun PHP.';
        }
        $delete = $structure && $parentWritable;
        $edit = false;
        $add = null;
        if ($entry['type'] === 'file') {
            $edit = $content && $this->writable($path);
            if ($content && !$edit && $read) {
                $notes[] = 'Berkas hanya dapat dibaca oleh akun PHP.';
            }
        } elseif ($entry['type'] === 'dir') {
            // Editing a folder means renaming it, which needs the same rights as deleting it.
            $edit = $delete;
            $add = $content && $this->writable($path);
            if ($content && !$add) {
                $notes[] = 'Isi folder tidak dapat ditambah oleh akun PHP.';
            }
        }
        return ['read' => $read, 'edit' => $edit, 'delete' => $delete, 'add' => $add, 'exec' => $exec, 'note' => implode(' ', $notes)];
    }

    /**
     * Whether the account that acts on disk holds one permission bit (4 read, 1 execute or search).
     * On Linux the owner, group, or other bits apply, as the kernel checks them; POSIX ACLs are not
     * counted. Windows has no mode bits: reading follows the file system, a folder can always be
     * entered, and only program files (.exe, .com, .bat, .cmd) run.
     */
    private function permitted(array $entry, $bit)
    {
        $path = $entry['path'];
        if (!Runner::unixPermissions()) {
            if ($bit === 4) {
                return @is_readable($path);
            }
            return $entry['type'] === 'dir' || in_array(strtolower(pathinfo($path, PATHINFO_EXTENSION)), self::WINDOWS_PROGRAMS, true);
        }
        $mode = (int) $entry['mode'];
        $uid = function_exists('posix_geteuid') ? posix_geteuid() : null;
        // With sudo every change runs as root. Root reads everything and enters every folder, but runs a
        // file only when at least one execute bit is set.
        if (Runner::sudo() || $uid === 0) {
            return $bit === 4 || $entry['type'] === 'dir' || ($mode & 0111) !== 0;
        }
        if ($uid === null) {
            return $bit === 4 ? @is_readable($path) : @is_executable($path);
        }
        if ($uid === (int) $entry['uid']) {
            return ($mode & ($bit << 6)) !== 0;
        }
        if (in_array((int) $entry['gid'], $this->groupIds(), true)) {
            return ($mode & ($bit << 3)) !== 0;
        }
        return ($mode & $bit) !== 0;
    }

    /**
     * Effective and supplementary group ids of the PHP account.
     */
    private function groupIds()
    {
        static $ids = null;
        if ($ids === null) {
            $ids = function_exists('posix_getgroups') ? array_map('intval', (array) posix_getgroups()) : [];
            if (function_exists('posix_getegid')) {
                $ids[] = posix_getegid();
            }
        }
        return $ids;
    }

    private function writable($path)
    {
        static $cache = [];
        // With sudo every change runs as root, so only the path guard limits it.
        if (Runner::sudo()) {
            return true;
        }
        if (!isset($cache[$path])) {
            $cache[$path] = @is_writable($path);
        }
        return $cache[$path];
    }

    /**
     * In a folder with the sticky bit only the owner of an entry, or of the
     * folder, may delete or rename it.
     */
    private function stickyAllows(array $entry, $parent)
    {
        if (!Runner::unixPermissions() || Runner::sudo() || !function_exists('posix_geteuid')) {
            return true;
        }
        $stat = @stat($parent);
        if (!is_array($stat) || ($stat['mode'] & 01000) === 0) {
            return true;
        }
        $uid = posix_geteuid();
        return $uid === 0 || $uid === $entry['uid'] || $uid === $stat['uid'];
    }

    /**
     * Native counterpart of find -user and -group, which accept a name or a numeric id.
     *
     * @return callable|null
     */
    private function principalFilter($owner, $group)
    {
        if ($owner === null && $group === null) {
            return null;
        }
        return function (array $e) use ($owner, $group) {
            if ($owner !== null && $e['owner'] !== $owner && (string) $e['uid'] !== $owner) {
                return false;
            }
            return $group === null || $e['group'] === $group || (string) $e['gid'] === $group;
        };
    }

    private function sort(array &$entries, $by, $dir)
    {
        $sign = $dir === 'desc' ? -1 : 1;
        usort($entries, function ($a, $b) use ($by, $sign) {
            // Folders stay above files for every sort column, as in common file managers.
            $aDir = $a['target_type'] === 'dir' ? 0 : 1;
            $bDir = $b['target_type'] === 'dir' ? 0 : 1;
            if ($aDir !== $bDir) {
                return $aDir - $bDir;
            }
            switch ($by) {
                case 'size':
                    $cmp = Cmp::values($a['size'], $b['size']);
                    break;
                case 'mtime':
                    $cmp = Cmp::values($a['mtime'], $b['mtime']);
                    break;
                case 'mode':
                    $cmp = Cmp::values($a['mode'] & 07777, $b['mode'] & 07777);
                    break;
                case 'owner':
                case 'group':
                case 'type':
                    $cmp = strcmp($a[$by], $b[$by]);
                    break;
                default:
                    $cmp = 0;
            }
            if ($cmp === 0) {
                $cmp = strnatcasecmp($a['path'], $b['path']);
            }
            return $cmp * $sign;
        });
    }

    private function rootOf($path)
    {
        $best = '';
        foreach (PathGuard::roots() as $root) {
            if (PathGuard::within($path, $root) && strlen($root) > strlen($best)) {
                $best = $root;
            }
        }
        return $best;
    }

    /**
     * Address of $path on a web server, or null when no known site serves it.
     */
    private function publicUrl($path, $isDir)
    {
        $bases = $this->urlBases();
        $best = null;
        foreach (array_keys($bases) as $dir) {
            if (PathGuard::within($path, $dir) && ($best === null || strlen($dir) > strlen($best))) {
                $best = $dir;
            }
        }
        if ($best === null) {
            return null;
        }
        $rest = trim(substr($path, strlen(rtrim($best, '/'))), '/');
        $url = $bases[$best] . '/' . ($rest === '' ? '' : implode('/', array_map('rawurlencode', explode('/', $rest))));
        return $isDir && $rest !== '' ? $url . '/' : $url;
    }

    /**
     * Folder => base address: the document root of this application at the host it was
     * opened with, plus the sites listed in public_urls.
     *
     * @return array<string,string>
     */
    private function urlBases()
    {
        static $bases = null;
        if ($bases !== null) {
            return $bases;
        }
        $bases = [];
        $host = isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : '';
        $docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? (string) $_SERVER['DOCUMENT_ROOT'] : '';
        if ($docRoot !== '' && preg_match('/^([A-Za-z0-9.-]+|\[[0-9A-Fa-f:.]+\])(:\d+)?$/', $host)) {
            $scheme = (new Request())->isHttps() ? 'https://' : 'http://';
            $this->addUrlBase($bases, $docRoot, $scheme . $host);
        }
        foreach ((array) Config::get('public_urls', []) as $dir => $url) {
            // Only web addresses: the value ends up in a link the user opens.
            if (is_string($dir) && is_string($url) && preg_match('#^https?://[^\s/?\#]+(/[^\s?\#]*)?$#i', $url)) {
                $this->addUrlBase($bases, $dir, rtrim($url, '/'));
            }
        }
        return $bases;
    }

    private function addUrlBase(array &$bases, $dir, $url)
    {
        $real = NativeFs::realpath($dir);
        if ($real !== '') {
            $bases[$real] = $url;
        }
    }

    private function parentOf($path)
    {
        if (PathGuard::isRoot($path) || $path === '/') {
            return null;
        }
        $parent = PathGuard::parent($path);
        return $parent !== $path && PathGuard::inRoots($parent) ? $parent : null;
    }

    /**
     * @return array<int,array{name:string,path:string}>
     */
    private function breadcrumbs($path)
    {
        $root = $this->rootOf($path);
        $crumbs = [['name' => $root, 'path' => $root]];
        $rest = trim(substr($path, strlen(rtrim($root, '/'))), '/');
        $current = rtrim($root, '/');
        if ($rest !== '') {
            foreach (explode('/', $rest) as $segment) {
                $current .= '/' . $segment;
                $crumbs[] = ['name' => $segment, 'path' => $current];
            }
        }
        return $crumbs;
    }
}
