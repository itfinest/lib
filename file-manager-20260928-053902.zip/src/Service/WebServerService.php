<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Finder;
use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Support\Config;
use App\Support\Validate;
use App\System\Accounts;
use App\System\Runner;
use App\System\Shell;

/**
 * Detects the Apache, Nginx, and PHP-FPM accounts on the host and checks
 * whether a site folder has the access those accounts need, and no more.
 */
final class WebServerService
{
    const SAMPLE = 100;
    const PROCESS_PATTERN = '/^(nginx|apache2|httpd|php-fpm[0-9.]*|php[0-9.]*-fpm|lsphp|litespeed|lshttpd|caddy)/';

    public function detect()
    {
        Runner::assertUnixPermissions();
        $processes = [];
        foreach ($this->processList() as $line) {
            $parts = preg_split('/\s+/', trim($line), 2);
            if (count($parts) === 2 && preg_match(self::PROCESS_PATTERN, $parts[1])) {
                $key = $parts[1] . '|' . $parts[0];
                $processes[$key] = ['process' => $parts[1], 'user' => $parts[0], 'count' => (isset($processes[$key]['count']) ? $processes[$key]['count'] : 0) + 1];
            }
        }

        $config = [];
        $nginx = Runner::native()
            ? $this->grepFiles(['/etc/nginx/nginx.conf'], '/^\s*user\s/', false)
            : Runner::run("grep -hsE '^[[:space:]]*user[[:space:]]' /etc/nginx/nginx.conf", null, 10)->stdout;
        if (preg_match('/^\s*user\s+([^\s;]+)(?:\s+([^\s;]+))?/m', $nginx, $m)) {
            $config[] = ['service' => 'Nginx', 'user' => $m[1], 'group' => (isset($m[2]) ? $m[2] : ''), 'source' => '/etc/nginx/nginx.conf'];
        }
        $apache = Runner::native()
            ? $this->grepFiles(['/etc/apache2/envvars'], '/^export APACHE_RUN_(USER|GROUP)=/', false)
                . $this->grepFiles(['/etc/httpd/conf/httpd.conf'], '/^\s*(User|Group)\s/', false)
            : Runner::run("grep -hsE '^export APACHE_RUN_(USER|GROUP)=' /etc/apache2/envvars; grep -hsE '^[[:space:]]*(User|Group)[[:space:]]' /etc/httpd/conf/httpd.conf", null, 10)->stdout;
        $apacheUser = preg_match('/(?:APACHE_RUN_USER=|^\s*User\s+)"?([^\s"]+)/m', $apache, $m) ? $m[1] : '';
        $apacheGroup = preg_match('/(?:APACHE_RUN_GROUP=|^\s*Group\s+)"?([^\s"]+)/m', $apache, $m) ? $m[1] : '';
        if ($apacheUser !== '') {
            $config[] = ['service' => 'Apache', 'user' => $apacheUser, 'group' => $apacheGroup, 'source' => 'envvars atau httpd.conf'];
        }

        $pools = $this->fpmPools();
        foreach ($pools as $pool) {
            if ($pool['user'] !== '') {
                $config[] = ['service' => 'PHP-FPM (' . $pool['name'] . ')', 'user' => $pool['user'], 'group' => $pool['group'], 'source' => $pool['file']];
            }
        }

        $candidates = [];
        foreach ($config as $row) {
            $candidates[$row['user']] = true;
        }
        foreach ($processes as $row) {
            if ($row['user'] !== 'root') {
                $candidates[$row['user']] = true;
            }
        }
        $accounts = [];
        foreach (array_keys($candidates) as $user) {
            $identity = $this->identity($user);
            if ($identity !== null) {
                $accounts[] = $identity;
            }
        }

        $webUsers = array_values(array_unique(array_merge(
            array_column(array_filter($config, function ($r) {
                return strpos($r['service'], 'PHP-FPM') !== 0;
            }), 'user'),
            array_column(array_filter($processes, function ($r) {
                return $r['user'] !== 'root' && !preg_match('/fpm|lsphp/', $r['process']);
            }), 'user')
        )));

        return [
            'processes' => array_values($processes),
            'config' => $config,
            'accounts' => $accounts,
            'sockets' => $this->socketChecks($pools, $webUsers),
            'php_user' => $this->identity(Runner::processUser()),
            'sudo' => Runner::sudo(),
        ];
    }

    public function check(array $p)
    {
        Runner::assertUnixPermissions();
        $path = PathGuard::resolveDir((string) (isset($p['path']) ? $p['path'] : ''));
        $user = Validate::principal((string) (isset($p['user']) ? $p['user'] : ''), 'user', true);
        $identity = $this->identity($user);
        if ($identity === null) {
            throw HttpException::validation(['user' => 'Pengguna "' . $user . '" tidak ditemukan di server ini.']);
        }
        $patterns = array_values(array_filter((array) Config::get('web_writable_patterns', []), 'is_string'));

        $ancestors = [];
        $current = $path;
        while ($current !== '/') {
            $current = dirname($current);
            $ancestors[] = $current;
        }
        $blocked = [];
        foreach (Finder::stat($ancestors) as $entry) {
            if (!$this->can($entry, $identity, 1)) {
                $blocked[] = $this->row($entry, 'Tidak memiliki izin x (masuk folder)');
            }
        }

        $scan = Finder::scan([$path], ['hidden' => true, 'xdev' => true, 'prune' => PathGuard::pruneFor([$path]), 'limit' => Config::int('limits.scan', 100000)]);
        $unreadable = ['count' => 0, 'items' => []];
        $unexpectedWritable = ['count' => 0, 'items' => []];
        $notWritable = ['count' => 0, 'items' => []];
        foreach ($scan['entries'] as $entry) {
            if ($entry['type'] === 'link') {
                continue;
            }
            $readable = $this->can($entry, $identity, 4) && ($entry['type'] !== 'dir' || $this->can($entry, $identity, 1));
            $writable = $this->can($entry, $identity, 2);
            $expectWrite = $this->matchesAny($entry['path'], $patterns);
            if (!$readable) {
                $this->push($unreadable, $this->row($entry, $entry['type'] === 'dir' ? 'Folder tidak dapat dibaca atau dimasuki' : 'Berkas tidak dapat dibaca'));
            }
            if ($writable && !$expectWrite) {
                $this->push($unexpectedWritable, $this->row($entry, 'Dapat ditulisi di luar pola folder tulis'));
            }
            if ($expectWrite && $entry['type'] === 'dir' && !$writable) {
                $this->push($notWritable, $this->row($entry, 'Cocok dengan pola folder tulis tetapi tidak dapat ditulisi'));
            }
        }

        return [
            'path' => $path,
            'user' => $identity,
            'patterns' => $patterns,
            'scanned' => count($scan['entries']),
            'truncated' => $scan['truncated'],
            'warnings' => $scan['warnings'],
            'traverse_blocked' => $blocked,
            'unreadable' => $unreadable,
            'unexpected_writable' => $unexpectedWritable,
            'not_writable' => $notWritable,
        ];
    }

    private function fpmPools()
    {
        if (Runner::native()) {
            $files = [];
            foreach (['/etc/php/*/fpm/pool.d/*.conf', '/etc/php-fpm.d/*.conf', '/etc/opt/remi/*/php-fpm.d/*.conf', '/usr/local/etc/php-fpm.d/*.conf'] as $pattern) {
                $found = @glob($pattern);
                $files = array_merge($files, is_array($found) ? $found : []);
            }
            $output = $this->grepFiles($files, '/^\s*(\[|user|group|listen|listen\.owner|listen\.group|listen\.mode)/', true);
        } else {
            $cmd = "for f in /etc/php/*/fpm/pool.d/*.conf /etc/php-fpm.d/*.conf /etc/opt/remi/*/php-fpm.d/*.conf /usr/local/etc/php-fpm.d/*.conf; do "
                . "[ -f \"\$f\" ] && grep -HsE '^[[:space:]]*(\\[|user|group|listen|listen\\.owner|listen\\.group|listen\\.mode)' \"\$f\"; done";
            $output = Runner::run($cmd, null, 10)->stdout;
        }
        $pools = [];
        $current = null;
        foreach (explode("\n", $output) as $line) {
            if (!preg_match('/^([^:]+):\s*(.*)$/', $line, $m)) {
                continue;
            }
            list(, $file, $text) = $m;
            if (preg_match('/^\[([^\]]+)\]/', $text, $pm)) {
                $current = $file . '#' . $pm[1];
                $pools[$current] = ['file' => $file, 'name' => $pm[1], 'user' => '', 'group' => '', 'listen' => '', 'listen_owner' => '', 'listen_group' => '', 'listen_mode' => ''];
                continue;
            }
            if ($current === null || !preg_match('/^\s*([a-z.]+)\s*=\s*(.+?)\s*$/', $text, $kv)) {
                continue;
            }
            $key = str_replace('.', '_', $kv[1]);
            if (array_key_exists($key, $pools[$current])) {
                $pools[$current][$key] = trim($kv[2], "\"'");
            }
        }
        return array_values($pools);
    }

    private function socketChecks(array $pools, array $webUsers)
    {
        $out = [];
        $sockets = [];
        foreach ($pools as $pool) {
            if ($pool['listen'] !== '' && $pool['listen'][0] === '/') {
                $sockets[$pool['listen']] = $pool;
            }
        }
        if (!$sockets) {
            return [];
        }
        $stats = Finder::stat(array_keys($sockets));
        foreach ($sockets as $socket => $pool) {
            $entry = (isset($stats[$socket]) ? $stats[$socket] : null);
            $row = ['socket' => $socket, 'pool' => $pool['name'], 'exists' => $entry !== null, 'octal' => (isset($entry['octal']) ? $entry['octal'] : ''), 'owner' => (isset($entry['owner']) ? $entry['owner'] : ''), 'group' => (isset($entry['group']) ? $entry['group'] : ''), 'access' => []];
            foreach ($webUsers as $user) {
                $identity = $this->identity($user);
                if ($identity !== null && $entry !== null) {
                    $row['access'][] = ['user' => $user, 'ok' => $this->can($entry, $identity, 2)];
                }
            }
            $out[] = $row;
        }
        return $out;
    }

    private function identity($user)
    {
        if ($user === '') {
            return null;
        }
        if (Runner::native()) {
            $account = Accounts::user($user);
            if ($account === null) {
                return null;
            }
            $membership = Accounts::membership($account);
            return ['name' => $user, 'uid' => $account['uid'], 'gids' => $membership['gids'], 'groups' => $membership['groups']];
        }
        $result = Runner::run('id -u -- ' . Shell::quote($user) . ' && id -G -- ' . Shell::quote($user) . ' && id -Gn -- ' . Shell::quote($user), null, 5);
        if (!$result->ok()) {
            return null;
        }
        $lines = explode("\n", trim($result->stdout));
        if (count($lines) < 3) {
            return null;
        }
        return [
            'name' => $user,
            'uid' => (int) $lines[0],
            'gids' => array_map('intval', preg_split('/\s+/', trim($lines[1]))),
            'groups' => preg_split('/\s+/', trim($lines[2])),
        ];
    }

    /**
     * "user command" per running process, like ps -eo user=,comm=. Without a shell the
     * list comes from /proc, which open_basedir or hidepid may hide; it is then empty.
     *
     * @return string[]
     */
    private function processList()
    {
        if (!Runner::native()) {
            return Runner::hasTool('ps') ? explode("\n", Runner::run('ps -eo user=,comm=', null, 10)->stdout) : [];
        }
        $lines = [];
        $dirs = @glob('/proc/[0-9]*', GLOB_ONLYDIR);
        foreach (is_array($dirs) ? $dirs : [] as $dir) {
            $comm = @file_get_contents($dir . '/comm');
            $status = @file_get_contents($dir . '/status');
            if (!is_string($comm) || !is_string($status) || !preg_match('/^Uid:\s+(\d+)/m', $status, $m)) {
                continue;
            }
            $name = Accounts::userName((int) $m[1]);
            $lines[] = ($name === null ? $m[1] : $name) . ' ' . trim($comm);
        }
        return $lines;
    }

    /**
     * Lines of the files that match $regex, like grep -hs (or grep -Hs with the file name).
     */
    private function grepFiles(array $files, $regex, $withName)
    {
        $out = '';
        foreach ($files as $file) {
            $content = @file_get_contents($file);
            if (!is_string($content)) {
                continue;
            }
            foreach (explode("\n", $content) as $line) {
                if (preg_match($regex, $line)) {
                    $out .= ($withName ? $file . ':' : '') . $line . "\n";
                }
            }
        }
        return $out;
    }

    /**
     * Classic Unix permission check. ACL entries are not evaluated.
     */
    private function can(array $entry, array $identity, $bit)
    {
        if ($identity['uid'] === 0) {
            return $bit !== 1 || $entry['type'] === 'dir' || ($entry['mode'] & 0111) !== 0;
        }
        if ($entry['uid'] === $identity['uid']) {
            return (($entry['mode'] >> 6) & $bit) !== 0;
        }
        if (in_array($entry['gid'], $identity['gids'], true)) {
            return (($entry['mode'] >> 3) & $bit) !== 0;
        }
        return ($entry['mode'] & $bit) !== 0;
    }

    private function matchesAny($path, array $patterns)
    {
        foreach ($patterns as $pattern) {
            if (fnmatch($pattern, $path)) {
                return true;
            }
        }
        return false;
    }

    private function push(array &$bucket, array $row)
    {
        $bucket['count']++;
        if (count($bucket['items']) < self::SAMPLE) {
            $bucket['items'][] = $row;
        }
    }

    private function row(array $e, $reason)
    {
        return ['path' => $e['path'], 'type' => $e['type'], 'octal' => $e['octal'], 'owner' => $e['owner'], 'group' => $e['group'], 'reason' => $reason];
    }
}
