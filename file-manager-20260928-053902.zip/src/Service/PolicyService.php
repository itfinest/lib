<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Entry;
use App\Http\HttpException;
use App\Storage\DataStore;
use App\Support\Random;
use App\Support\Validate;

/**
 * User-defined permission rules the audit checks every entry against.
 */
final class PolicyService
{
    const FILE = 'policies.php';
    const SEVERITIES = ['low', 'medium', 'high', 'critical'];

    const SEED = [
        ['name' => 'Berkas .env hanya untuk pemilik dan grup', 'pattern' => '*/.env', 'applies_to' => 'file', 'max_mode' => '0640', 'owner' => '', 'group' => '', 'severity' => 'high', 'enabled' => true],
        ['name' => 'Kunci privat hanya untuk pemilik', 'pattern' => '*.pem', 'applies_to' => 'file', 'max_mode' => '0600', 'owner' => '', 'group' => '', 'severity' => 'critical', 'enabled' => true],
        ['name' => 'Berkas PHP tidak dapat dieksekusi', 'pattern' => '*.php', 'applies_to' => 'file', 'max_mode' => '0664', 'owner' => '', 'group' => '', 'severity' => 'low', 'enabled' => true],
    ];

    public function all()
    {
        $this->seed();
        return DataStore::readJson(self::FILE);
    }

    public function enabled()
    {
        return array_values(array_filter($this->all(), function ($p) {
            return !empty($p['enabled']);
        }));
    }

    /**
     * @return string[] violation descriptions; empty when the entry complies
     */
    public static function violations(array $policy, array $entry)
    {
        $applies = $policy['applies_to'];
        if (($applies === 'file' && $entry['type'] !== 'file') || ($applies === 'dir' && $entry['type'] !== 'dir') || $entry['type'] === 'link') {
            return [];
        }
        if (!fnmatch($policy['pattern'], $entry['path'])) {
            return [];
        }
        $out = [];
        if ($policy['max_mode'] !== '') {
            $max = (int) octdec($policy['max_mode']);
            if (($entry['mode'] & 07777 & ~$max) !== 0) {
                $out[] = 'Izin ' . $entry['octal'] . ' lebih longgar dari batas ' . $policy['max_mode'];
            }
        }
        if ($policy['owner'] !== '' && $entry['owner'] !== $policy['owner']) {
            $out[] = 'Pemilik ' . $entry['owner'] . ', seharusnya ' . $policy['owner'];
        }
        if ($policy['group'] !== '' && $entry['group'] !== $policy['group']) {
            $out[] = 'Grup ' . $entry['group'] . ', seharusnya ' . $policy['group'];
        }
        return $out;
    }

    public function save(array $input, $id, $user)
    {
        $data = $this->validate($input);
        $this->seed();
        return DataStore::mutateJson(self::FILE, function (array &$rows) use ($data, $id, $user) {
            foreach ($rows as $row) {
                if (strcasecmp($row['name'], $data['name']) === 0 && $row['id'] !== $id) {
                    throw HttpException::validation(['name' => 'Nama kebijakan sudah dipakai.']);
                }
            }
            $now = gmdate('c');
            if ($id === null) {
                $row = $data + ['id' => 'k_' . Random::hex(6), 'created_at' => $now, 'updated_at' => $now, 'updated_by' => $user];
                $rows[] = $row;
                return $row;
            }
            foreach ($rows as $i => $row) {
                if ($row['id'] === $id) {
                    $rows[$i] = array_merge($row, $data, ['updated_at' => $now, 'updated_by' => $user]);
                    return $rows[$i];
                }
            }
            throw new HttpException(404, 'Kebijakan tidak ditemukan. Kebijakan mungkin sudah dihapus.');
        });
    }

    public function setEnabled($id, $enabled, $user)
    {
        return DataStore::mutateJson(self::FILE, function (array &$rows) use ($id, $enabled, $user) {
            foreach ($rows as $i => $row) {
                if ($row['id'] === $id) {
                    $rows[$i]['enabled'] = $enabled;
                    $rows[$i]['updated_at'] = gmdate('c');
                    $rows[$i]['updated_by'] = $user;
                    return $rows[$i];
                }
            }
            throw new HttpException(404, 'Kebijakan tidak ditemukan. Kebijakan mungkin sudah dihapus.');
        });
    }

    public function delete($id)
    {
        return DataStore::mutateJson(self::FILE, function (array &$rows) use ($id) {
            foreach ($rows as $i => $row) {
                if ($row['id'] === $id) {
                    array_splice($rows, $i, 1);
                    return $row;
                }
            }
            throw new HttpException(404, 'Kebijakan tidak ditemukan. Kebijakan mungkin sudah dihapus.');
        });
    }

    private function validate(array $input)
    {
        $errors = [];
        $data = [];
        try {
            $data['name'] = Validate::text((string) (isset($input['name']) ? $input['name'] : ''), 'name', 120);
        } catch (HttpException $e) {
            $errors += $e->errors();
        }
        $pattern = trim((string) (isset($input['pattern']) ? $input['pattern'] : ''));
        if ($pattern === '') {
            $errors['pattern'] = 'Pola path wajib diisi, misalnya */.env atau /var/www/*/storage/*.';
        } elseif (strlen($pattern) > 300 || preg_match('/[\x00-\x1F]/', $pattern)) {
            $errors['pattern'] = 'Pola path tidak valid.';
        }
        $data['pattern'] = $pattern;
        $data['applies_to'] = Validate::oneOf((string) (isset($input['applies_to']) ? $input['applies_to'] : ''), ['any', 'file', 'dir'], 'any');
        try {
            $mode = Validate::mode((string) (isset($input['max_mode']) ? $input['max_mode'] : ''), 'max_mode', false);
            $data['max_mode'] = $mode === null ? '' : Entry::octal($mode);
        } catch (HttpException $e) {
            $errors += $e->errors();
        }
        foreach (['owner', 'group'] as $field) {
            try {
                $data[$field] = (string) Validate::principal((string) (isset($input[$field]) ? $input[$field] : ''), $field);
            } catch (HttpException $e) {
                $errors += $e->errors();
            }
        }
        $data['severity'] = Validate::oneOf((string) (isset($input['severity']) ? $input['severity'] : ''), self::SEVERITIES, 'medium');
        $data['enabled'] = !isset($input['enabled']) || !empty($input['enabled']);
        if (!$errors && $data['max_mode'] === '' && $data['owner'] === '' && $data['group'] === '') {
            $errors['max_mode'] = 'Isi minimal satu syarat: batas izin, pemilik, atau grup.';
        }
        if ($errors) {
            throw HttpException::validation($errors);
        }
        return $data;
    }

    private function seed()
    {
        if (is_file(DataStore::path(self::FILE))) {
            return;
        }
        DataStore::mutateJson(self::FILE, function (array &$rows) {
            if ($rows) {
                return;
            }
            $now = gmdate('c');
            foreach (self::SEED as $policy) {
                $rows[] = $policy + ['id' => 'k_' . Random::hex(6), 'created_at' => $now, 'updated_at' => $now, 'updated_by' => 'sistem'];
            }
        });
    }
}
