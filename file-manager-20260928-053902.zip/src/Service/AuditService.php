<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Entry;
use App\Fs\Finder;
use App\Fs\NativeFs;
use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Storage\DataStore;
use App\Support\Cmp;
use App\Support\Config;
use App\Support\Random;
use App\Support\Validate;
use App\System\Runner;
use App\System\Shell;

/**
 * Permission audit: scans a folder, applies the built-in dangerous-permission
 * rules plus the enabled policies, and keeps each run for export and fixes.
 */
final class AuditService
{
    const INDEX = 'audits.php';
    const KEEP_RUNS = 30;

    const RULES = [
        'mode_777' => ['label' => 'Izin 777', 'severity' => 'critical', 'fix' => 'o-w', 'hint' => 'Semua pengguna di server dapat membaca, mengubah, dan menjalankan item ini.'],
        'world_writable_file' => ['label' => 'Berkas dapat ditulisi semua pengguna', 'severity' => 'high', 'fix' => 'o-w', 'hint' => 'Pengguna mana pun di server dapat mengubah isi berkas ini.'],
        'world_writable_dir' => ['label' => 'Folder dapat ditulisi semua pengguna tanpa sticky bit', 'severity' => 'high', 'fix' => 'o-w', 'hint' => 'Pengguna mana pun dapat menghapus atau mengganti berkas milik orang lain di folder ini.'],
        'sensitive_readable' => ['label' => 'Berkas sensitif dapat dibaca semua pengguna', 'severity' => 'high', 'fix' => 'o-rwx', 'hint' => 'Kredensial atau kunci dapat dibaca oleh akun lain di server.'],
        'setuid' => ['label' => 'Berkas setuid', 'severity' => 'high', 'fix' => null, 'hint' => 'Berkas berjalan dengan hak pemiliknya. Pastikan memang disengaja.'],
        'setgid' => ['label' => 'Berkas setgid', 'severity' => 'medium', 'fix' => null, 'hint' => 'Berkas berjalan dengan hak grupnya. Pastikan memang disengaja.'],
        'orphan_owner' => ['label' => 'Pemilik atau grup tidak dikenal', 'severity' => 'medium', 'fix' => null, 'hint' => 'UID atau GID tidak memiliki akun. Akun baru dengan ID yang sama akan mewarisi akses ini.'],
        'symlink_outside' => ['label' => 'Symlink mengarah ke luar root', 'severity' => 'medium', 'fix' => null, 'hint' => 'Tautan ini membuka jalan ke lokasi di luar folder yang dikelola.'],
        'broken_symlink' => ['label' => 'Symlink rusak', 'severity' => 'low', 'fix' => null, 'hint' => 'Tujuan tautan tidak ada.'],
        'exec_content' => ['label' => 'Berkas konten memiliki izin eksekusi', 'severity' => 'low', 'fix' => 'a-x', 'hint' => 'Berkas konten seperti PHP, HTML, atau gambar tidak perlu bit eksekusi.'],
    ];

    const CONTENT_EXT = ['php', 'html', 'htm', 'css', 'js', 'json', 'txt', 'md', 'jpg', 'jpeg', 'png', 'gif', 'svg', 'webp', 'ico', 'xml', 'csv', 'log', 'ini', 'yml', 'yaml', 'sql', 'env', 'twig', 'blade'];
    const SEVERITY_RANK = ['critical' => 4, 'high' => 3, 'medium' => 2, 'low' => 1];

    public function run(array $p, $user)
    {
        Runner::assertUnixPermissions();
        $path = PathGuard::resolveDir((string) (isset($p['path']) ? $p['path'] : ''));
        $usePolicies = !isset($p['policies']) || !empty($p['policies']);
        $limit = Config::int('limits.scan', 100000);
        $started = microtime(true);
        $scan = Finder::scan([$path], ['hidden' => true, 'xdev' => true, 'prune' => PathGuard::pruneFor([$path]), 'limit' => $limit]);
        $policies = $usePolicies ? (new PolicyService())->enabled() : [];

        $findings = [];
        foreach ($scan['entries'] as $entry) {
            foreach ($this->evaluate($entry, $policies) as $finding) {
                $findings[] = $finding;
            }
        }
        usort($findings, function ($a, $b) {
            $rank = self::SEVERITY_RANK;
            return Cmp::values($rank[$b['severity']], $rank[$a['severity']]) ?: strcmp($a['path'], $b['path']);
        });

        $counts = ['critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0];
        $byRule = [];
        foreach ($findings as $f) {
            $counts[$f['severity']]++;
            $byRule[$f['rule']] = (isset($byRule[$f['rule']]) ? $byRule[$f['rule']] : 0) + 1;
        }

        $id = 'aud_' . gmdate('Ymd_His') . '_' . Random::hex(3);
        $meta = [
            'id' => $id,
            'path' => $path,
            'scanned' => count($scan['entries']),
            'truncated' => $scan['truncated'],
            'warnings' => $scan['warnings'],
            'policies' => count($policies),
            'counts' => $counts,
            'by_rule' => $byRule,
            'total' => count($findings),
            'duration_ms' => (int) round((microtime(true) - $started) * 1000),
            'created_at' => gmdate('c'),
            'created_by' => $user,
        ];
        DataStore::writeBlob('audits/' . $id . '.php', ['meta' => $meta, 'findings' => $findings]);
        $expired = DataStore::mutateJson(self::INDEX, function (array &$index) use ($meta) {
            $index[] = $meta;
            usort($index, function ($a, $b) {
                return strcmp($b['created_at'], $a['created_at']);
            });
            $expired = array_slice($index, self::KEEP_RUNS);
            $index = array_slice($index, 0, self::KEEP_RUNS);
            return $expired;
        });
        foreach ($expired as $old) {
            DataStore::delete('audits/' . $old['id'] . '.php');
        }
        return $meta;
    }

    public function runs()
    {
        return DataStore::readJson(self::INDEX);
    }

    public function load($id)
    {
        if (!preg_match('/^aud_[0-9]{8}_[0-9]{6}_[0-9a-f]{6}$/', $id)) {
            throw new HttpException(404, 'Hasil audit tidak ditemukan.');
        }
        $data = DataStore::readBlob('audits/' . $id . '.php');
        if ($data === null) {
            throw new HttpException(404, 'Hasil audit tidak ditemukan. Audit lama dihapus otomatis setelah ' . self::KEEP_RUNS . ' kali audit.');
        }
        return $data;
    }

    /**
     * @return array[] findings for one entry
     */
    public function evaluate(array $entry, array $policies)
    {
        $out = [];
        $catalog = self::RULES;
        $rules = $entry['danger'];
        if ($entry['type'] === 'link' && !$entry['broken'] && $this->linkLeavesRoots($entry)) {
            $rules[] = 'symlink_outside';
        }
        if ($entry['type'] === 'file' && ($entry['mode'] & 0111) && !in_array('mode_777', $rules, true)) {
            $ext = strtolower(pathinfo($entry['name'], PATHINFO_EXTENSION));
            if (in_array($ext, self::CONTENT_EXT, true)) {
                $rules[] = 'exec_content';
            }
        }
        foreach ($rules as $rule) {
            $def = $catalog[$rule];
            $out[] = $this->finding($entry, $rule, $def['label'], $def['severity'], $def['hint'], $def['fix'] !== null);
        }
        foreach ($policies as $policy) {
            $violations = PolicyService::violations($policy, $entry);
            if ($violations) {
                $out[] = $this->finding($entry, 'policy:' . $policy['id'], $policy['name'], $policy['severity'], implode('. ', $violations) . '.', true);
            }
        }
        return $out;
    }

    /**
     * Plan that fixes the selected rules for the findings of one audit run.
     * Each entry is re-checked against its current state first, so a finding
     * already fixed elsewhere is skipped.
     */
    public function fixPlan(array $p)
    {
        $data = $this->load((string) (isset($p['audit_id']) ? $p['audit_id'] : ''));
        $rules = is_array(isset($p['rules']) ? $p['rules'] : null) ? array_values(array_filter($p['rules'], 'is_string')) : [];
        if (!$rules) {
            throw HttpException::validation(['rules' => 'Pilih minimal satu jenis temuan yang akan diperbaiki.']);
        }
        $policies = [];
        foreach ((new PolicyService())->all() as $policy) {
            $policies['policy:' . $policy['id']] = $policy;
        }
        $catalog = self::RULES;

        $paths = [];
        foreach ($data['findings'] as $f) {
            if (in_array($f['rule'], $rules, true) && $f['fixable']) {
                $paths[$f['path']] = true;
            }
        }
        $paths = array_keys($paths);
        $allowed = [];
        foreach ($paths as $path) {
            try {
                PathGuard::assertAllowed($path, PathGuard::CONTENT);
                $allowed[] = $path;
            } catch (HttpException $e) {
                continue;
            }
        }
        $current = $allowed ? Finder::stat($allowed) : [];

        $symbolic = [];
        $modes = [];
        $owners = [];
        $items = [];
        foreach ($current as $path => $entry) {
            if ($entry['type'] === 'link') {
                continue;
            }
            $newMode = $entry['mode'] & 07777;
            $newOwner = $entry['owner'];
            $newGroup = $entry['group'];
            foreach ($this->evaluate($entry, array_values(array_filter($policies, function ($key) use ($rules) {
                return in_array($key, $rules, true);
            }, ARRAY_FILTER_USE_KEY))) as $finding) {
                if (!in_array($finding['rule'], $rules, true)) {
                    continue;
                }
                if (isset($catalog[$finding['rule']])) {
                    $fix = $catalog[$finding['rule']]['fix'];
                    if ($fix !== null) {
                        $newMode &= ~$this->symbolicMask($fix);
                    }
                    continue;
                }
                $policy = (isset($policies[$finding['rule']]) ? $policies[$finding['rule']] : null);
                if ($policy === null) {
                    continue;
                }
                if ($policy['max_mode'] !== '') {
                    $newMode &= (int) octdec($policy['max_mode']);
                }
                if ($policy['owner'] !== '') {
                    $newOwner = $policy['owner'];
                }
                if ($policy['group'] !== '') {
                    $newGroup = $policy['group'];
                }
            }
            if ($newMode !== ($entry['mode'] & 07777)) {
                $modes[Validate::chmodArg($newMode)][] = $path;
            }
            if ($newOwner !== $entry['owner'] || $newGroup !== $entry['group']) {
                $owners[$newOwner . ':' . $newGroup][] = $path;
            }
            if ($newMode !== ($entry['mode'] & 07777) || $newOwner !== $entry['owner'] || $newGroup !== $entry['group']) {
                $items[] = [
                    'path' => $path,
                    'before' => $entry['octal'] . ' ' . $entry['owner'] . ':' . $entry['group'],
                    'after' => Entry::octal($newMode) . ' ' . $newOwner . ':' . $newGroup,
                    'note' => '',
                ];
            }
        }

        $plan = new Plan('audit_fix', 'Memperbaiki ' . count($items) . ' temuan audit di ' . $data['meta']['path']);
        foreach ($modes as $mode => $list) {
            if (Runner::native()) {
                $value = (int) octdec($mode);
                $plan->addNative('PHP chmod(' . substr($mode, 1) . ') untuk ' . count($list) . ' entri', 'Izin menjadi ' . substr($mode, 1) . ' (' . count($list) . ' entri)', function () use ($list, $value) {
                    NativeFs::changeEach($list, function ($path) use ($value) {
                        NativeFs::setMode($path, $value);
                    });
                });
                continue;
            }
            foreach (Shell::chunkArgs($list) as $chunk) {
                $plan->add('chmod ' . $mode . ' -- ' . Shell::quoteAll($chunk), 'Izin menjadi ' . substr($mode, 1) . ' (' . count($chunk) . ' entri)');
            }
        }
        foreach ($owners as $spec => $list) {
            if (Runner::native()) {
                list($owner, $group) = explode(':', $spec, 2);
                $plan->addNative('PHP lchown/lchgrp(' . $spec . ') untuk ' . count($list) . ' entri', 'Pemilik menjadi ' . $spec . ' (' . count($list) . ' entri)', function () use ($list, $owner, $group) {
                    NativeFs::changeEach($list, function ($path) use ($owner, $group) {
                        NativeFs::setOwner($path, $owner, $group);
                    });
                });
                continue;
            }
            foreach (Shell::chunkArgs($list) as $chunk) {
                $plan->add('chown -h ' . Shell::quote($spec) . ' -- ' . Shell::quoteAll($chunk), 'Pemilik menjadi ' . $spec . ' (' . count($chunk) . ' entri)');
            }
        }
        $changed = array_column($items, 'path');
        $plan->targets = $changed;
        if ($changed) {
            $plan->snapshot = ['paths' => $changed, 'recursive' => false, 'acl' => false];
        } else {
            $plan->noop = 'Temuan yang dipilih sudah tidak ada atau tidak dapat diperbaiki otomatis. Jalankan audit ulang untuk data terbaru.';
        }
        $limit = Config::int('limits.preview_items', 200);
        $plan->impact = function () use ($items, $limit) {
            return ['count' => count($items), 'capped' => false, 'items' => array_slice($items, 0, $limit), 'unit' => 'entri akan diperbaiki'];
        };
        return $plan;
    }

    private function finding(array $entry, $rule, $label, $severity, $detail, $fixable)
    {
        return [
            'rule' => $rule,
            'label' => $label,
            'severity' => $severity,
            'path' => $entry['path'],
            'type' => $entry['type'],
            'octal' => $entry['octal'],
            'perms' => $entry['perms'],
            'owner' => $entry['owner'],
            'group' => $entry['group'],
            'link' => $entry['link'],
            'detail' => $detail,
            'fixable' => $fixable,
        ];
    }

    private function linkLeavesRoots(array $entry)
    {
        $target = $entry['link'];
        if ($target === '') {
            return false;
        }
        $absolute = $target[0] === '/' ? $target : dirname($entry['path']) . '/' . $target;
        try {
            return !PathGuard::inRoots(PathGuard::clean($absolute));
        } catch (HttpException $e) {
            return false;
        }
    }

    /**
     * Bits removed by a symbolic "who-perms" fix such as o-w or a-x.
     */
    private function symbolicMask($fix)
    {
        list($who, $perms) = explode('-', $fix);
        $bits = (strpos($perms, 'r') !== false ? 4 : 0) | (strpos($perms, 'w') !== false ? 2 : 0) | (strpos($perms, 'x') !== false ? 1 : 0);
        $mask = 0;
        foreach (str_split($who === 'a' ? 'ugo' : $who) as $w) {
            $mask |= $bits << ['u' => 6, 'g' => 3, 'o' => 0][$w];
        }
        return $mask;
    }
}
