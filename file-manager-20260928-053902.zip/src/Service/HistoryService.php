<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Storage\DataStore;
use App\Support\Random;

/**
 * Append-only change history. Every applied operation and every login or
 * settings change lands here with who, when, what, and the exact commands.
 */
final class HistoryService
{
    const FILE = 'history.php';

    public function record(array $record)
    {
        $record = array_merge([
            'id' => 'h_' . gmdate('YmdHis') . '_' . Random::hex(3),
            'at' => gmdate('c'),
            'user' => '',
            'op' => '',
            'category' => 'operation',
            'summary' => '',
            'targets' => [],
            'target_count' => 0,
            'commands' => [],
            'ok' => true,
            'errors' => [],
            'snapshot_id' => null,
            'ip' => (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''),
        ], $record);
        $record['target_count'] = $record['target_count'] ?: count($record['targets']);
        $record['targets'] = array_slice($record['targets'], 0, 50);
        $record['commands'] = array_slice($record['commands'], 0, 50);
        $record['errors'] = array_slice($record['errors'], 0, 30);
        DataStore::appendLine(self::FILE, $record);
        return $record;
    }

    public function event($user, $op, $summary, $ok = true)
    {
        $this->record(['user' => $user, 'op' => $op, 'category' => 'event', 'summary' => $summary, 'ok' => $ok]);
    }

    /**
     * @return array[] newest first
     */
    public function all()
    {
        return array_reverse(DataStore::readLines(self::FILE));
    }

    public function find($id)
    {
        foreach (DataStore::readLines(self::FILE) as $record) {
            if ((isset($record['id']) ? $record['id'] : '') === $id) {
                return $record;
            }
        }
        return null;
    }
}
