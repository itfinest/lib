<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Finder;
use App\Fs\NativeFs;
use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Storage\DataStore;
use App\Support\Config;
use App\Support\Random;
use App\System\Runner;
use App\System\Shell;

/**
 * Deleted items are moved into a private folder inside storage and can be
 * restored to their original location until the trash is emptied.
 */
final class TrashService
{
    const INDEX = 'trash.php';
    const STATE = 'state.php';

    public function dir()
    {
        $name = DataStore::mutateJson(self::STATE, function (array &$state) {
            if (empty($state['trash_dir'])) {
                // A random folder name keeps trashed files unreachable by URL even where .htaccess is ignored.
                $state['trash_dir'] = 'trash_' . Random::hex(12);
            }
            return $state['trash_dir'];
        });
        $dir = DataStore::path($name);
        if (!is_dir($dir)) {
            mkdir($dir, 0700, true);
        }
        return Runner::isWindows() ? NativeFs::normalize($dir) : str_replace('\\', '/', $dir);
    }

    /**
     * @param bool $quarantine files flagged by the malware scanner: stored under a name ending in
     *                         .karantina and made read-only for the owner, so no interpreter
     *                         recognises the extension and nothing can run or change the file
     */
    public function trashPlan(array $p, $quarantine = false)
    {
        $raw = is_array(isset($p['paths']) ? $p['paths'] : null) ? array_values(array_filter($p['paths'], 'is_string')) : [];
        $entries = PathGuard::resolveEntries($raw, PathGuard::STRUCTURE);
        $trash = $this->dir();
        $plan = $quarantine
            ? new Plan('quarantine', 'Mengarantina ' . count($entries) . ' berkas')
            : new Plan('trash', 'Memindahkan ' . count($entries) . ' item ke tempat sampah');
        $items = [];
        foreach ($entries as $entry) {
            $id = 't_' . gmdate('YmdHis') . '_' . Random::hex(4);
            $slot = $trash . '/' . $id;
            $path = $entry['path'];
            $name = PathGuard::base($path);
            $stored = $slot . '/' . $name . ($quarantine ? '.karantina' : '');
            $items[] = ['id' => $id, 'original' => $path, 'stored' => $stored, 'type' => $entry['type'], 'quarantine' => $quarantine];
            $label = $quarantine ? 'Mengarantina ' . $name : 'Memindahkan ' . $name . ' ke tempat sampah';
            if (Runner::native()) {
                $plan->addNative(Plan::nativeCall('rename', [$path, $quarantine ? $stored : $slot]), $label, function () use ($path, $slot, $name, $stored, $quarantine) {
                    NativeFs::makeDir($slot, 0700);
                    NativeFs::transfer($path, $slot, false, true);
                    if ($quarantine) {
                        NativeFs::rename($slot . '/' . $name, $stored);
                        // Windows only has a read-only attribute, which would block the purge; the suffix is enough there.
                        if (Runner::unixPermissions()) {
                            NativeFs::setMode($stored, 0400);
                        }
                    }
                });
                continue;
            }
            $command = 'mkdir -m 700 -- ' . Shell::quote($slot) . ' && mv -n -- ' . Shell::quote($path) . ' ' . Shell::quote($slot . '/');
            if ($quarantine) {
                $command = 'mkdir -m 700 -- ' . Shell::quote($slot) . ' && mv -n -T -- ' . Shell::quote($path) . ' ' . Shell::quote($stored)
                    . ' && chmod 400 -- ' . Shell::quote($stored);
            }
            $plan->add($command, $label);
        }
        $plan->targets = array_column($entries, 'path');
        // The trash folder may sit on another filesystem, where a move drops owner and mode.
        // This snapshot lets restore put them back.
        // Windows has no owner or mode to restore, so no snapshot is taken there.
        if (Runner::unixPermissions()) {
            $plan->snapshot = ['paths' => $plan->targets, 'recursive' => true, 'acl' => AclService::available()];
        }
        $plan->impact = function () use ($items, $quarantine) {
            $paths = array_column($items, 'original');
            $counted = Finder::count($paths, ['hidden' => true]);
            $rows = [];
            foreach ($items as $item) {
                $note = $item['type'] === 'd' ? 'Folder beserta seluruh isinya' : '';
                if ($quarantine) {
                    $note = 'Disimpan sebagai ' . PathGuard::base($item['stored']) . ', dapat dipulihkan dari Tempat Sampah';
                }
                $rows[] = ['path' => $item['original'], 'before' => '', 'after' => $quarantine ? 'karantina' : 'tempat sampah', 'note' => $note];
            }
            return ['count' => $counted['count'], 'capped' => $counted['capped'], 'items' => $rows, 'unit' => $quarantine ? 'berkas akan dikarantina' : 'entri akan dipindahkan ke tempat sampah'];
        };
        $plan->after = function ($user, $snapshotId) use ($items) {
            $stored = PathGuard::inspect(array_column($items, 'stored'));
            $kept = [];
            foreach ($items as $i => $item) {
                if ($stored[$i] !== null && $stored[$i]['type'] !== 'n') {
                    $kept[] = $item + ['deleted_at' => gmdate('c'), 'deleted_by' => $user, 'size' => $this->size($item['stored']), 'snapshot_id' => $snapshotId];
                } else {
                    // The move failed, so the empty slot folder is removed again.
                    $this->removeEmptySlot(PathGuard::parent($item['stored']));
                }
            }
            if ($kept) {
                DataStore::mutateJson(self::INDEX, function (array &$index) use ($kept) {
                    foreach ($kept as $item) {
                        $index[] = $item;
                    }
                });
            }
        };
        return $plan;
    }

    public function restorePlan(array $p)
    {
        $ids = is_array(isset($p['ids']) ? $p['ids'] : null) ? array_values(array_filter($p['ids'], 'is_string')) : [];
        $items = $this->findMany($ids);
        $plan = new Plan('restore', 'Memulihkan ' . count($items) . ' item dari tempat sampah');
        $originals = array_column($items, 'original');
        $state = PathGuard::inspect($originals);
        foreach ($items as $i => $item) {
            PathGuard::assertAllowed($item['original'], PathGuard::STRUCTURE);
            if ($state[$i] === null) {
                throw new HttpException(409, 'Folder asal untuk "' . PathGuard::base($item['original']) . '" sudah tidak ada. Buat kembali folder ' . PathGuard::parent($item['original']) . ' terlebih dahulu.');
            }
            if ($state[$i]['type'] !== 'n') {
                throw new HttpException(409, 'Sudah ada item lain di lokasi asal: ' . $item['original'] . '. Ganti nama atau pindahkan item tersebut terlebih dahulu.');
            }
            $stored = $item['stored'];
            $original = $item['original'];
            if (Runner::native()) {
                $plan->addNative(Plan::nativeCall('rename', [$stored, $original]), 'Memulihkan ' . $original, function () use ($stored, $original) {
                    // A quarantined file is stored under another name; it gets its own name back inside the slot first.
                    $named = PathGuard::parent($stored) . '/' . PathGuard::base($original);
                    if ($named !== $stored) {
                        NativeFs::rename($stored, $named);
                    }
                    NativeFs::transfer($named, PathGuard::parent($original), false, true);
                    @rmdir(PathGuard::parent($stored));
                });
                continue;
            }
            $plan->add(
                'mv -n -T -- ' . Shell::quote($stored) . ' ' . Shell::quote($original) . ' && rmdir -- ' . Shell::quote(dirname($stored)),
                'Memulihkan ' . $original
            );
        }
        $plan->targets = $originals;
        $plan->after = function ($user) use ($items) {
            $this->forgetMissing($items);
            $this->restorePermissions($items, $user);
        };
        return $plan;
    }

    /**
     * Re-applies owner, group, and mode captured when the items were trashed.
     */
    private function restorePermissions(array $items, $user)
    {
        $snapshots = new SnapshotService();
        foreach (array_unique(array_filter(array_column($items, 'snapshot_id'))) as $snapshotId) {
            try {
                $plan = $snapshots->restorePlan($snapshotId, array_column($items, 'original'));
            } catch (HttpException $e) {
                continue;
            }
            if ($plan->commands) {
                (new OperationService())->execute($plan, $user);
            }
        }
    }

    public function purgePlan(array $p)
    {
        $all = !empty($p['all']);
        $items = $all ? $this->all() : $this->findMany(is_array(isset($p['ids']) ? $p['ids'] : null) ? array_values(array_filter($p['ids'], 'is_string')) : []);
        if (!$items) {
            throw HttpException::validation(['ids' => 'Tempat sampah sudah kosong.']);
        }
        $plan = new Plan('trash_purge', ($all ? 'Mengosongkan tempat sampah' : 'Menghapus permanen ' . count($items) . ' item dari tempat sampah'));
        $plan->destructive = true;
        $slots = array_map(function ($item) {
            return PathGuard::parent($item['stored']);
        }, $items);
        if (Runner::native()) {
            foreach ($slots as $slot) {
                $plan->addNative(Plan::nativeCall('NativeFs::remove', [$slot]), 'Menghapus permanen', function () use ($slot) {
                    NativeFs::remove($slot);
                });
            }
        } else {
            foreach (Shell::chunkArgs($slots) as $chunk) {
                $plan->add('rm -rf -- ' . Shell::quoteAll($chunk), 'Menghapus permanen');
            }
        }
        $plan->targets = array_column($items, 'original');
        $plan->impact = function () use ($items) {
            $rows = [];
            foreach ($items as $item) {
                $rows[] = ['path' => $item['original'], 'before' => '', 'after' => 'dihapus permanen', 'note' => ''];
            }
            return ['count' => count($items), 'capped' => false, 'items' => $rows, 'unit' => 'item akan dihapus permanen'];
        };
        $plan->after = function () use ($items) {
            $this->forgetMissing($items);
        };
        return $plan;
    }

    public function all()
    {
        $index = DataStore::readJson(self::INDEX);
        usort($index, function ($a, $b) {
            return strcmp($b['deleted_at'], $a['deleted_at']);
        });
        return $index;
    }

    private function findMany(array $ids)
    {
        if (!$ids) {
            throw HttpException::validation(['ids' => 'Pilih minimal satu item di tempat sampah.']);
        }
        $byId = [];
        foreach (DataStore::readJson(self::INDEX) as $item) {
            $byId[$item['id']] = $item;
        }
        $out = [];
        foreach ($ids as $id) {
            if (!isset($byId[$id])) {
                throw new HttpException(404, 'Item tempat sampah tidak ditemukan. Muat ulang daftar.');
            }
            $out[] = $byId[$id];
        }
        return $out;
    }

    /**
     * Drops index rows whose stored copy no longer exists.
     */
    private function forgetMissing(array $items)
    {
        $state = PathGuard::inspect(array_column($items, 'stored'));
        $gone = [];
        foreach ($items as $i => $item) {
            if ($state[$i] === null || $state[$i]['type'] === 'n') {
                $gone[] = $item['id'];
            }
        }
        if ($gone) {
            DataStore::mutateJson(self::INDEX, function (array &$index) use ($gone) {
                $index = array_values(array_filter($index, function ($item) use ($gone) {
                    return !in_array($item['id'], $gone, true);
                }));
            });
        }
    }

    private function removeEmptySlot($slot)
    {
        if (Runner::native()) {
            @rmdir($slot);
            return;
        }
        Runner::run('rmdir -- ' . Shell::quote($slot) . ' 2>/dev/null', null, 10);
    }

    private function size($path)
    {
        if (Runner::native()) {
            $budget = Config::int('limits.scan', 100000);
            list($bytes) = NativeFs::size($path, $budget);
            return $bytes;
        }
        $out = Runner::run('du -sb -- ' . Shell::quote($path) . ' 2>/dev/null', null, 60)->stdout;
        return (int) strtok($out, "\t");
    }
}
