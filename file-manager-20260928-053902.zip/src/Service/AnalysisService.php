<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Finder;
use App\Fs\NativeFs;
use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Support\Cmp;
use App\Support\Config;
use App\Support\Validate;
use App\System\Runner;
use App\System\Shell;

/**
 * Ownership analyzer and folder size analyzer.
 */
final class AnalysisService
{
    const SAMPLE = 200;

    public function ownership(array $p)
    {
        Runner::assertUnixPermissions();
        $path = PathGuard::resolveDir((string) (isset($p['path']) ? $p['path'] : ''));
        $expectedOwner = Validate::principal((string) (isset($p['expected_owner']) ? $p['expected_owner'] : ''), 'expected_owner');
        $expectedGroup = Validate::principal((string) (isset($p['expected_group']) ? $p['expected_group'] : ''), 'expected_group');
        $scan = Finder::scan([$path], ['hidden' => true, 'xdev' => true, 'prune' => PathGuard::pruneFor([$path]), 'limit' => Config::int('limits.scan', 100000)]);

        $owners = [];
        $groups = [];
        $orphans = [];
        $orphanCount = 0;
        $mismatch = [];
        $mismatchCount = 0;
        foreach ($scan['entries'] as $e) {
            foreach (['owner' => &$owners, 'group' => &$groups] as $field => &$bucket) {
                $key = $e[$field];
                if (!isset($bucket[$key])) {
                    $bucket[$key] = ['name' => $key, 'id' => $field === 'owner' ? $e['uid'] : $e['gid'], 'files' => 0, 'dirs' => 0, 'other' => 0, 'bytes' => 0];
                }
                $slot = $e['type'] === 'file' ? 'files' : ($e['type'] === 'dir' ? 'dirs' : 'other');
                $bucket[$key][$slot]++;
                $bucket[$key]['bytes'] += $e['type'] === 'file' ? $e['size'] : 0;
            }
            unset($bucket);
            if ($e['orphan']) {
                $orphanCount++;
                if (count($orphans) < self::SAMPLE) {
                    $orphans[] = $this->row($e);
                }
            }
            if (($expectedOwner !== null && $e['owner'] !== $expectedOwner) || ($expectedGroup !== null && $e['group'] !== $expectedGroup)) {
                $mismatchCount++;
                if (count($mismatch) < self::SAMPLE) {
                    $mismatch[] = $this->row($e);
                }
            }
        }
        $byCount = function ($a, $b) {
            return Cmp::values($b['files'] + $b['dirs'] + $b['other'], $a['files'] + $a['dirs'] + $a['other']);
        };
        $owners = array_values($owners);
        $groups = array_values($groups);
        usort($owners, $byCount);
        usort($groups, $byCount);

        return [
            'path' => $path,
            'scanned' => count($scan['entries']),
            'truncated' => $scan['truncated'],
            'warnings' => $scan['warnings'],
            'owners' => $owners,
            'groups' => $groups,
            'orphans' => ['count' => $orphanCount, 'items' => $orphans],
            'expected' => ['owner' => $expectedOwner, 'group' => $expectedGroup],
            'mismatch' => ['count' => $mismatchCount, 'items' => $mismatch],
        ];
    }

    public function sizes(array $p)
    {
        $path = PathGuard::resolveDir((string) (isset($p['path']) ? $p['path'] : ''));
        $hidden = !empty($p['hidden']);
        if (Runner::native()) {
            return $this->sizesNative($path, $hidden);
        }
        $result = Runner::run('du -x -a -B1 -d 1 -0 -- ' . Shell::quote($path));
        if ($result->stdout === '') {
            throw new HttpException(403, 'Ukuran folder tidak dapat dihitung: ' . implode(' ', $result->errorLines(2)));
        }
        $total = 0;
        $items = [];
        foreach (explode("\0", $result->stdout) as $line) {
            if ($line === '' || strpos($line, "\t") === false) {
                continue;
            }
            list($bytes, $child) = explode("\t", $line, 2);
            if ($child === $path) {
                $total = (int) $bytes;
                continue;
            }
            if (!$hidden && substr(basename($child), 0, 1) === '.') {
                continue;
            }
            if (PathGuard::inApp($child)) {
                continue;
            }
            $items[] = ['path' => $child, 'name' => basename($child), 'bytes' => (int) $bytes];
        }
        return $this->sizeResult($path, $total, $items, $result->ok());
    }

    /**
     * Native counterpart of du: sums every child without following links
     * points, and stops after limits.scan entries so a huge tree cannot hang the request.
     */
    private function sizesNative($path, $hidden)
    {
        $budget = Config::int('limits.scan', 100000);
        $total = 0;
        $complete = true;
        $items = [];
        foreach (NativeFs::scan([$path], ['mindepth' => 1, 'maxdepth' => 1, 'hidden' => true, 'limit' => $budget])['entries'] as $entry) {
            list($bytes, $done) = NativeFs::size($entry['path'], $budget);
            $total += $bytes;
            $complete = $complete && $done;
            if ((!$hidden && $entry['name'][0] === '.') || PathGuard::inApp($entry['path'])) {
                continue;
            }
            $items[] = ['path' => $entry['path'], 'name' => $entry['name'], 'bytes' => $bytes];
        }
        return $this->sizeResult($path, $total, $items, $complete);
    }

    private function sizeResult($path, $total, array $items, $complete)
    {
        $stats = $items ? Finder::stat(array_column($items, 'path')) : [];
        foreach ($items as &$item) {
            $entry = isset($stats[$item['path']]) ? $stats[$item['path']] : null;
            $item['type'] = $entry ? $entry['type'] : 'other';
            $item['percent'] = $total > 0 ? round($item['bytes'] * 100 / $total, 1) : 0;
        }
        unset($item);
        usort($items, function ($a, $b) {
            return Cmp::values($b['bytes'], $a['bytes']);
        });
        $parent = PathGuard::parent($path);
        return [
            'path' => $path,
            'total' => $total,
            'items' => $items,
            'parent' => PathGuard::isRoot($path) || $parent === $path ? null : (PathGuard::inRoots($parent) ? $parent : null),
            'warnings' => $complete ? [] : ['Sebagian isi folder tidak dapat dibaca atau melebihi batas pemindaian, sehingga total mungkin lebih kecil dari ukuran sebenarnya.'],
        ];
    }

    private function row(array $e)
    {
        return ['path' => $e['path'], 'type' => $e['type'], 'owner' => $e['owner'], 'group' => $e['group'], 'uid' => $e['uid'], 'gid' => $e['gid'], 'octal' => $e['octal']];
    }
}
