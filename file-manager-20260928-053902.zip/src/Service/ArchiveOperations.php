<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\NativeFs;
use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Storage\DataStore;
use App\Support\Config;
use App\Support\Random;
use App\System\Runner;
use App\System\Shell;
use RuntimeException;

final class ArchiveOperations
{
    const TAR_TYPES = ['.tar.gz', '.tgz', '.tar.bz2', '.tbz2', '.tar.xz', '.txz', '.tar'];
    const DOWNLOAD_DIR = 'downloads';
    const DEFAULT_EXCLUDE = [
        'node_modules', 'vendor', '.git', '.svn', '.idea', '.vscode', '__pycache__',
        'cache', 'temp', 'tmp', 'sessions', '.DS_Store', 'Thumbs.db',
        '*.txt', '*.json', '*.log',
    ];

    /**
     * Patterns filled in the compress dialog (setting compress_exclude); the dialog can still change them.
     *
     * @return string[]
     */
    public static function defaultExclude()
    {
        return array_values(array_filter((array) Config::get('compress_exclude', self::DEFAULT_EXCLUDE), 'is_string'));
    }

    public function compress(array $p)
    {
        $raw = is_array(isset($p['paths']) ? $p['paths'] : null) ? array_values(array_filter($p['paths'], 'is_string')) : [];
        $entries = PathGuard::resolveEntries($raw, PathGuard::READ);
        $parent = PathGuard::parent($entries[0]['path']);
        foreach ($entries as $entry) {
            if (PathGuard::parent($entry['path']) !== $parent) {
                throw HttpException::validation(['paths' => 'Item yang dikompres harus berada di folder yang sama.']);
            }
        }
        // The archive is written to the chosen folder; without one it lands next to the items.
        $destParam = (string) (isset($p['dest']) ? $p['dest'] : '');
        $destDir = $destParam === '' ? $parent : PathGuard::resolveDir($destParam);
        PathGuard::assertAllowed($destDir, PathGuard::CONTENT);
        foreach ($entries as $entry) {
            // An archive written inside a folder it is packing would try to include itself.
            if ($entry['type'] === 'd' && PathGuard::within($destDir, $entry['path'])) {
                throw HttpException::validation(['dest' => 'Folder tujuan berada di dalam folder yang dikompres (' . PathGuard::base($entry['path']) . '). Pilih folder lain.']);
            }
        }
        $format = (isset($p['format']) ? $p['format'] : '') === 'zip' ? 'zip' : 'tar.gz';
        if (Runner::native()) {
            if ($format !== 'zip') {
                throw HttpException::validation(['format' => (Runner::isWindows() ? 'Server Windows' : 'Server tanpa fungsi proc_open') . ' hanya mendukung format .zip.']);
            }
            if (!Runner::hasTool('zip')) {
                throw HttpException::validation(['format' => 'Ekstensi PHP zip tidak aktif, sehingga arsip .zip tidak dapat dibuat.']);
            }
        } elseif ($format === 'zip' && !Runner::hasTool('zip')) {
            throw HttpException::validation(['format' => 'Perintah zip tidak tersedia di server ini. Gunakan format .tar.gz.']);
        }
        $name = PathGuard::name((string) (isset($p['name']) ? $p['name'] : ''));
        $ext = '.' . $format;
        if (substr($name, -strlen($ext)) !== $ext) {
            $name .= $ext;
        }
        $dest = rtrim($destDir, '/') . '/' . $name;
        $info = PathGuard::resolveNew($dest);
        if ($info['type'] !== 'n') {
            throw HttpException::validation(['name' => 'Sudah ada berkas bernama "' . $name . '" di folder tujuan. Gunakan nama arsip lain atau folder tujuan lain.']);
        }

        $names = array_map([PathGuard::class, 'base'], array_column($entries, 'path'));
        $patterns = $this->excludePatterns((string) (isset($p['exclude']) ? $p['exclude'] : ''));
        $kept = array_filter($names, function ($n) use ($patterns) {
            return !NativeFs::patternExcluded($n, $patterns);
        });
        if (!$kept) {
            throw HttpException::validation(['exclude' => 'Semua item yang dipilih cocok dengan pola pengecualian, sehingga arsip akan kosong.']);
        }
        $exclude = PathGuard::pruneFor(array_column($entries, 'path'));
        $plan = new Plan('compress', 'Mengompres ' . count($names) . ' item menjadi ' . $name . (PathGuard::same($destDir, $parent) ? '' : ' di ' . $destDir));
        $plan->targets = [$dest];
        if ($exclude) {
            $plan->warnings[] = 'Folder aplikasi File Manager tidak ikut dikompres.';
        }
        if ($patterns['names'] || $patterns['paths']) {
            $plan->warnings[] = 'Berkas dan folder yang cocok dengan pola berikut, beserta seluruh isinya, tidak ikut dikompres: ' . implode(', ', array_merge($patterns['names'], $patterns['paths'])) . '.';
        }
        if (Runner::native()) {
            $plan->addNative(Plan::nativeCall('ZipArchive::addFile', [$dest]), 'Membuat arsip ' . $name, function () use ($dest, $parent, $names, $exclude, $patterns) {
                NativeFs::zipCreate($dest, $parent, $names, $exclude, $patterns);
            });
            return $plan;
        }
        $plan->add($this->archiveCommand($format, $parent, $names, $dest, $exclude, $patterns), 'Membuat arsip ' . $name);
        return $plan;
    }

    /**
     * Packs one folder into a temporary archive under storage/downloads, so it can be downloaded
     * like a file. Nothing inside the roots changes. The caller streams the file and deletes it.
     *
     * @return array{path:string,name:string,type:string}
     */
    public function folderArchive($dir)
    {
        $name = PathGuard::base($dir);
        if ($name === '') {
            throw HttpException::validation(['path' => 'Folder akar sistem berkas tidak dapat diunduh sebagai arsip. Pilih subfolder di dalamnya.']);
        }
        $format = Runner::hasTool('zip') ? 'zip' : 'tar.gz';
        if ($format !== 'zip' && (Runner::native() || !Runner::hasTool('tar'))) {
            throw new HttpException(422, Runner::native()
                ? 'Ekstensi PHP zip tidak aktif, sehingga folder tidak dapat diunduh. Unduh berkas di dalamnya satu per satu.'
                : 'Perintah zip dan tar tidak tersedia di server ini, sehingga folder tidak dapat diunduh.');
        }
        $folder = rtrim(str_replace('\\', '/', DataStore::path(self::DOWNLOAD_DIR)), '/');
        $this->sweepDownloads($folder);
        $temp = $folder . '/tmp-' . Random::hex(8) . '.' . $format;
        $parent = PathGuard::parent($dir);
        $exclude = PathGuard::pruneFor([$dir]);
        $none = ['names' => [], 'paths' => []];

        if (Runner::native()) {
            try {
                NativeFs::zipCreate($temp, $parent, [$name], $exclude, $none);
            } catch (RuntimeException $e) {
                // A skipped symlink or junction is reported after the archive was written; the rest is still worth sending.
                if (!is_file($temp)) {
                    throw new HttpException(500, 'Arsip folder tidak dapat dibuat. ' . $e->getMessage());
                }
            }
        } else {
            $result = Runner::run($this->archiveCommand($format, $parent, [$name], $temp, $exclude, $none));
            // tar exits with 1 and zip with 18 when a file changed or could not be read; the archive holds everything else.
            $partial = ($format === 'zip' && $result->exitCode === 18) || ($format !== 'zip' && $result->exitCode === 1);
            if ((!$result->ok() && !$partial) || !is_file($temp)) {
                @unlink($temp);
                $lines = $result->errorLines(3);
                throw new HttpException(500, 'Arsip folder tidak dapat dibuat' . ($lines ? ': ' . implode(' ', $lines) : '.'));
            }
        }
        return [
            'path' => $temp,
            'name' => $name . '.' . $format,
            'type' => $format === 'zip' ? 'application/zip' : 'application/gzip',
        ];
    }

    /**
     * Temporary archives left behind by a request that was killed before its shutdown handler ran.
     */
    private function sweepDownloads($folder)
    {
        foreach (glob($folder . '/tmp-*') ?: [] as $file) {
            if (@filemtime($file) < time() - 86400) {
                @unlink($file);
            }
        }
    }

    /**
     * The zip or tar command that writes $names (entries of $parent) into $dest, leaving out
     * $exclude (absolute paths) and everything matching $patterns (see excludePatterns()).
     */
    private function archiveCommand($format, $parent, array $names, $dest, array $exclude, array $patterns)
    {
        if ($format === 'zip') {
            $cmd = 'cd ' . Shell::quote($parent) . ' && zip -r -y -q ' . Shell::quote($dest) . ' '
                . Shell::quoteAll(array_map(function ($n) {
                    return './' . $n;
                }, $names));
            foreach ($exclude as $path) {
                $cmd .= ' -x ' . Shell::quote(substr($path, strlen(rtrim($parent, '/')) + 1) . '/*');
            }
            // zip matches -x patterns against the whole stored path and its "*" crosses "/", so a name
            // pattern needs a variant for every depth and one for the contents of a matched folder.
            // A leading "-" is written as "[-]" so zip does not read the pattern as an option.
            foreach ($patterns['names'] as $pattern) {
                $pattern = preg_replace('/^-/', '[-]', $pattern);
                $cmd .= ' -x ' . Shell::quoteAll([$pattern, '*/' . $pattern, $pattern . '/*', '*/' . $pattern . '/*']);
            }
            foreach ($patterns['paths'] as $pattern) {
                $pattern = preg_replace('/^-/', '[-]', $pattern);
                $cmd .= ' -x ' . Shell::quoteAll([$pattern, $pattern . '/*']);
            }
        } else {
            $cmd = 'tar -czf ' . Shell::quote($dest) . ' -C ' . Shell::quote($parent);
            foreach ($exclude as $path) {
                $cmd .= ' --anchored --exclude=' . Shell::quote(substr($path, strlen(rtrim($parent, '/')) + 1));
            }
            // --anchored and --no-anchored apply to every --exclude that follows them.
            if ($patterns['names']) {
                $cmd .= ' --no-anchored';
                foreach ($patterns['names'] as $pattern) {
                    $cmd .= ' --exclude=' . Shell::quote($pattern);
                }
            }
            if ($patterns['paths']) {
                $cmd .= ' --anchored';
                foreach ($patterns['paths'] as $pattern) {
                    $cmd .= ' --exclude=' . Shell::quote($pattern);
                }
            }
            $cmd .= ' -- ' . Shell::quoteAll($names);
        }
        return $cmd;
    }

    /**
     * One pattern per line. A pattern without "/" matches a file or folder name at any
     * depth; a pattern with "/" is a path relative to the folder that holds the items.
     *
     * @return array{names:string[],paths:string[]}
     */
    public function excludePatterns($raw)
    {
        $out = ['names' => [], 'paths' => []];
        $count = 0;
        foreach (preg_split('/\r\n|\r|\n/', $raw) as $line) {
            $line = trim($line);
            // On Linux a backslash stays, since tar, zip, and fnmatch all read it as an escape.
            if (Runner::isWindows()) {
                $line = str_replace('\\', '/', $line);
            }
            $pattern = rtrim(preg_replace('#^(\./)+#', '', $line), '/');
            if ($pattern === '') {
                continue;
            }
            if (preg_match('/[\x00-\x1F\x7F]/', $pattern) || strlen($pattern) > 255) {
                throw HttpException::validation(['exclude' => 'Pola "' . $pattern . '" tidak valid. Pola maksimal 255 byte dan tidak boleh mengandung karakter kontrol.']);
            }
            if ($pattern[0] === '/' || preg_match('#^[A-Za-z]:#', $pattern)) {
                throw HttpException::validation(['exclude' => 'Pola "' . $pattern . '" berupa path absolut. Tulis path relatif terhadap folder yang berisi item yang dipilih.']);
            }
            if (preg_match('#(^|/)\.{1,2}(/|$)|//#', $pattern)) {
                throw HttpException::validation(['exclude' => 'Pola "' . $pattern . '" tidak boleh memuat ".", "..", atau "//" sebagai bagian path.']);
            }
            $key = strpos($pattern, '/') === false ? 'names' : 'paths';
            if (in_array($pattern, $out[$key], true)) {
                continue;
            }
            if (++$count > 50) {
                throw HttpException::validation(['exclude' => 'Pola pengecualian maksimal 50 baris.']);
            }
            $out[$key][] = $pattern;
        }
        return $out;
    }

    public function extract(array $p)
    {
        $archive = PathGuard::resolveEntries([(string) (isset($p['path']) ? $p['path'] : '')], PathGuard::READ)[0];
        if ($archive['type'] !== 'f') {
            throw HttpException::validation(['path' => 'Pilih berkas arsip.']);
        }
        $destParam = (string) (isset($p['dest']) ? $p['dest'] : '');
        $dest = PathGuard::resolveDir($destParam === '' ? PathGuard::parent($archive['path']) : $destParam);
        PathGuard::assertAllowed($dest, PathGuard::CONTENT);
        $kind = $this->kind($archive['path']);

        $plan = new Plan('extract', 'Mengekstrak ' . PathGuard::base($archive['path']) . ' ke ' . $dest);
        $plan->targets = [$archive['path'], $dest];
        $blocked = PathGuard::blockedPatterns();
        if ($blocked) {
            $plan->warnings[] = 'Berkas skrip dan konfigurasi server web di dalam arsip (misalnya .php atau .htaccess) dilewati sesuai kebijakan keamanan.';
        }
        if (Runner::native()) {
            return $this->extractNative($plan, $archive['path'], $dest, $kind);
        }
        if ($kind === 'zip') {
            if (!Runner::hasTool('unzip')) {
                throw HttpException::validation(['path' => 'Perintah unzip tidak tersedia di server ini, sehingga arsip .zip tidak dapat diekstrak.']);
            }
            // -n never overwrites existing files; unzip also refuses members that climb out with "../".
            // -C matches the exclusion patterns case-insensitively.
            $exclude = $blocked ? ' -x ' . Shell::quoteAll($blocked) : '';
            $plan->add('unzip -n -q -C ' . Shell::quote($archive['path']) . $exclude . ' -d ' . Shell::quote($dest), 'Mengekstrak arsip zip');
            $listCmd = 'unzip -Z1 ' . Shell::quote($archive['path']);
        } else {
            // Ownership and modes from the archive are not trusted; extracted files get the current user and umask.
            $exclude = '';
            foreach ($blocked as $pattern) {
                $exclude .= ' --exclude=' . Shell::quote($pattern);
            }
            if ($exclude !== '') {
                $exclude = ' --ignore-case --wildcards' . $exclude;
            }
            $plan->add('tar -xf ' . Shell::quote($archive['path']) . ' -C ' . Shell::quote($dest) . ' --skip-old-files --no-same-owner --no-same-permissions' . $exclude, 'Mengekstrak arsip tar');
            $listCmd = 'tar -tf ' . Shell::quote($archive['path']);
        }
        $plan->impact = function () use ($listCmd, $dest) {
            $limit = Config::int('limits.preview_items', 200);
            $result = Runner::run($listCmd . ' | head -n 100001');
            if (!$result->ok() && $result->stdout === '') {
                throw new HttpException(422, 'Isi arsip tidak dapat dibaca. Berkas mungkin rusak atau bukan arsip yang didukung.');
            }
            $names = array_values(array_filter(explode("\n", $result->stdout), 'strlen'));
            return $this->memberImpact($names, $dest, $limit);
        };
        return $plan;
    }

    private function extractNative(Plan $plan, $archive, $dest, $kind)
    {
        if ($kind !== 'zip') {
            throw HttpException::validation(['path' => (Runner::isWindows() ? 'Server Windows' : 'Server tanpa fungsi proc_open') . ' hanya dapat mengekstrak arsip .zip.']);
        }
        if (!Runner::hasTool('unzip')) {
            throw HttpException::validation(['path' => 'Ekstensi PHP zip tidak aktif, sehingga arsip .zip tidak dapat diekstrak.']);
        }
        $plan->addNative(Plan::nativeCall('ZipArchive::getStream', [$archive, $dest]), 'Mengekstrak arsip zip', function () use ($archive, $dest) {
            NativeFs::zipExtract($archive, $dest, [PathGuard::class, 'blockedName']);
        });
        $plan->impact = function () use ($archive, $dest) {
            try {
                $names = NativeFs::zipList($archive, 100001);
            } catch (RuntimeException $e) {
                throw new HttpException(422, 'Isi arsip tidak dapat dibaca. Berkas mungkin rusak atau bukan arsip yang didukung.');
            }
            return $this->memberImpact($names, $dest, Config::int('limits.preview_items', 200));
        };
        return $plan;
    }

    private function memberImpact(array $names, $dest, $limit)
    {
        $items = [];
        foreach (array_slice($names, 0, $limit) as $name) {
            $normalized = str_replace('\\', '/', $name);
            $unsafe = $normalized === '' || $normalized[0] === '/' || preg_match('#(^|/)\.\.(/|$)#', $normalized) || (Runner::native() && !NativeFs::safeMember($normalized));
            $note = '';
            if ($unsafe) {
                $note = 'Path tidak aman, akan dilewati';
            } elseif (PathGuard::blockedName(PathGuard::base(rtrim($normalized, '/')))) {
                $note = 'Diblokir kebijakan keamanan, akan dilewati';
            }
            $items[] = ['path' => rtrim($dest, '/') . '/' . ltrim($normalized, '/'), 'before' => '', 'after' => 'diekstrak', 'note' => $note];
        }
        return ['count' => min(count($names), 100000), 'capped' => count($names) > 100000, 'items' => $items, 'unit' => 'entri di dalam arsip (berkas yang sudah ada tidak ditimpa)'];
    }

    private function kind($path)
    {
        $lower = strtolower($path);
        if (substr($lower, -4) === '.zip') {
            return 'zip';
        }
        foreach (self::TAR_TYPES as $ext) {
            if (substr($lower, -strlen($ext)) === $ext) {
                return 'tar';
            }
        }
        throw HttpException::validation(['path' => 'Format arsip tidak didukung. Gunakan .zip, .tar, .tar.gz, .tgz, .tar.bz2, atau .tar.xz.']);
    }
}
