<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\Finder;
use App\Fs\NativeFs;
use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Support\Config;
use App\System\Runner;
use App\System\Shell;

/**
 * Create, rename, copy, move, and delete. Each method returns a Plan; nothing
 * runs until OperationService applies it. Without a shell (Windows, or Linux
 * with proc_open disabled) each step is a native PHP call instead of a shell command.
 */
final class FileOperations
{
    public function mkdir(array $p)
    {
        $target = $this->newChild($p, 'folder');
        $plan = new Plan('mkdir', 'Membuat folder ' . $target);
        $plan->targets = [$target];
        if (Runner::native()) {
            $plan->addNative(Plan::nativeCall('mkdir', [$target]), 'Membuat folder', function () use ($target) {
                NativeFs::makeDir($target);
            });
            return $plan;
        }
        $plan->add('mkdir -- ' . Shell::quote($target), 'Membuat folder');
        return $plan;
    }

    public function createFile(array $p)
    {
        $target = $this->newChild($p, 'berkas');
        $content = $this->content($p);
        $plan = new Plan('create_file', 'Membuat berkas ' . $target);
        $plan->targets = [$target];
        $label = 'Membuat berkas dengan isi ' . strlen($content) . ' byte';
        if (Runner::native()) {
            $plan->addNative(Plan::nativeCall('fopen', [$target, 'xb']), $label, function () use ($target, $content) {
                NativeFs::createFile($target, $content);
            });
            return $plan;
        }
        // noclobber makes the redirect fail instead of truncating a file created in the meantime.
        $plan->add('set -C && cat > ' . Shell::quote($target), $label, $content);
        return $plan;
    }

    /**
     * Saves editor content over an existing file. The write goes through the
     * same inode, so owner, group, mode, and ACL stay as they were.
     */
    public function save(array $p)
    {
        $entry = PathGuard::resolveEntries([(string) (isset($p['path']) ? $p['path'] : '')], PathGuard::CONTENT)[0];
        if ($entry['type'] !== 'f') {
            throw HttpException::validation(['path' => 'Hanya berkas biasa yang dapat disimpan dari editor.']);
        }
        $content = $this->content($p);
        $expected = (string) (isset($p['expected_hash']) ? $p['expected_hash'] : '');
        $current = (new FileContentService())->hash($entry['path']);
        if ($expected !== '' && !hash_equals($current, $expected)) {
            throw new HttpException(409, 'Berkas sudah diubah oleh proses lain sejak dibuka. Muat ulang isi berkas, lalu terapkan kembali perubahan Anda.');
        }
        $path = $entry['path'];
        $plan = new Plan('save', 'Menyimpan isi berkas ' . $path);
        $plan->targets = [$path];
        $label = 'Menyimpan isi ' . strlen($content) . ' byte';
        if (Runner::native()) {
            $plan->addNative(Plan::nativeCall('file_put_contents', [$path]), $label, function () use ($path, $content) {
                NativeFs::writeFile($path, $content);
            });
            return $plan;
        }
        $plan->add('cat > ' . Shell::quote($path), $label, $content);
        return $plan;
    }

    private function content(array $p)
    {
        $content = isset($p['content']) ? $p['content'] : '';
        if (!is_string($content)) {
            throw HttpException::validation(['content' => 'Isi berkas tidak valid.']);
        }
        $max = Config::int('limits.edit_bytes', 1048576);
        if (strlen($content) > $max) {
            throw HttpException::validation(['content' => 'Isi berkas melebihi batas ' . number_format($max / 1048576, 1, ',', '.') . ' MB.']);
        }
        return $content;
    }

    public function rename(array $p)
    {
        $source = PathGuard::resolveEntries([(string) (isset($p['path']) ? $p['path'] : '')], PathGuard::STRUCTURE)[0];
        $name = PathGuard::name((string) (isset($p['name']) ? $p['name'] : ''));
        $from = $source['path'];
        $target = rtrim(PathGuard::parent($from), '/') . '/' . $name;
        if ($target === $from) {
            throw HttpException::validation(['name' => 'Nama baru sama dengan nama lama.']);
        }
        // On Windows a change of letter case only refers to the same entry, so it is not a conflict.
        if (!PathGuard::same($target, $from)) {
            $this->assertFree($target);
        }
        $plan = new Plan('rename', 'Mengganti nama ' . PathGuard::base($from) . ' menjadi ' . $name);
        $plan->targets = [$from, $target];
        if (Runner::native()) {
            $plan->addNative(Plan::nativeCall('rename', [$from, $target]), 'Mengganti nama', function () use ($from, $target) {
                NativeFs::rename($from, $target);
            });
            return $plan;
        }
        $plan->add('mv -n -T -- ' . Shell::quote($from) . ' ' . Shell::quote($target), 'Mengganti nama');
        return $plan;
    }

    public function copy(array $p)
    {
        return $this->transfer($p, 'copy');
    }

    public function move(array $p)
    {
        return $this->transfer($p, 'move');
    }

    /**
     * Copies each item next to itself under a free name, such as "config (salinan).php".
     */
    public function duplicate(array $p)
    {
        $entries = PathGuard::resolveEntries($this->paths($p), PathGuard::READ);
        $sources = [];
        $targets = [];
        $taken = [];
        foreach ($entries as $entry) {
            $parent = PathGuard::parent($entry['path']);
            PathGuard::assertAllowed($parent, PathGuard::CONTENT);
            $sources[] = $entry['path'];
            $targets[] = $this->copyName($parent, PathGuard::base($entry['path']), $entry['type'] === 'd', $taken);
        }
        $summary = count($sources) === 1
            ? 'Menduplikasi ' . PathGuard::base($sources[0]) . ' menjadi ' . PathGuard::base($targets[0])
            : 'Menduplikasi ' . count($sources) . ' item';
        $plan = new Plan('duplicate', $summary);
        $plan->targets = $targets;
        foreach ($sources as $i => $src) {
            $target = $targets[$i];
            $label = 'Menduplikasi ' . PathGuard::base($src);
            if (Runner::native()) {
                $plan->addNative(Plan::nativeCall('NativeFs::copyAs', [$src, $target]), $label, function () use ($src, $target) {
                    NativeFs::copyAs($src, $target);
                });
                continue;
            }
            $plan->add('cp -a -n -T -- ' . Shell::quote($src) . ' ' . Shell::quote($target), $label);
        }
        $plan->impact = function () use ($sources, $targets) {
            $items = [];
            foreach ($sources as $i => $src) {
                $items[] = ['path' => $src, 'before' => '', 'after' => $targets[$i], 'note' => ''];
            }
            $counted = Finder::count($sources, ['hidden' => true]);
            return ['count' => $counted['count'], 'capped' => $counted['capped'], 'items' => $items, 'unit' => 'entri akan disalin'];
        };
        return $plan;
    }

    /**
     * The first free "<name> (salinan N)" in the folder. A file keeps its extension at the end;
     * a name that starts with a dot (".env") has none.
     *
     * @param array $taken names already given to other items of the same operation
     */
    private function copyName($parent, $name, $isDir, array &$taken)
    {
        $dot = $isDir ? false : strpos($name, '.', 1);
        $stem = $dot === false ? $name : substr($name, 0, $dot);
        $ext = $dot === false ? '' : substr($name, $dot);
        for ($i = 1; $i <= 100; $i++) {
            $candidate = PathGuard::name($stem . ' (salinan' . ($i > 1 ? ' ' . $i : '') . ')' . $ext, 'paths');
            $info = PathGuard::resolveNew(rtrim($parent, '/') . '/' . $candidate, 'paths');
            $key = Runner::isWindows() ? strtolower($info['path']) : $info['path'];
            if ($info['type'] === 'n' && !isset($taken[$key])) {
                $taken[$key] = true;
                return $info['path'];
            }
        }
        throw HttpException::validation(['paths' => 'Tidak ada nama salinan yang tersedia untuk "' . $name . '". Hapus atau ganti nama salinan lama terlebih dahulu.']);
    }

    public function delete(array $p)
    {
        $entries = PathGuard::resolveEntries($this->paths($p), PathGuard::STRUCTURE);
        $paths = array_column($entries, 'path');
        $plan = new Plan('delete', 'Menghapus ' . count($paths) . ' item secara permanen');
        $plan->targets = $paths;
        $plan->destructive = true;
        if (Runner::native()) {
            foreach ($paths as $path) {
                $plan->addNative(Plan::nativeCall('NativeFs::remove', [$path]), 'Menghapus ' . PathGuard::base($path), function () use ($path) {
                    NativeFs::remove($path);
                });
            }
        } else {
            foreach (Shell::chunkArgs($paths) as $chunk) {
                $plan->add('rm -rf --one-file-system -- ' . Shell::quoteAll($chunk), 'Menghapus');
            }
        }
        $plan->impact = function () use ($paths) {
            $counted = Finder::count($paths, ['hidden' => true]);
            $stats = Finder::stat($paths);
            $items = [];
            foreach ($paths as $path) {
                $entry = isset($stats[$path]) ? $stats[$path] : null;
                $items[] = [
                    'path' => $path,
                    'before' => $entry ? $entry['perms'] : '',
                    'after' => 'dihapus',
                    'note' => $entry && $entry['type'] === 'dir' ? 'Folder beserta seluruh isinya' : '',
                ];
            }
            return ['count' => $counted['count'], 'capped' => $counted['capped'], 'items' => $items, 'unit' => 'entri akan dihapus, termasuk isi folder'];
        };
        return $plan;
    }

    private function transfer(array $p, $kind)
    {
        $level = $kind === 'move' ? PathGuard::STRUCTURE : PathGuard::READ;
        $entries = PathGuard::resolveEntries($this->paths($p), $level);
        $dest = PathGuard::resolveDir((string) (isset($p['dest']) ? $p['dest'] : ''));
        PathGuard::assertAllowed($dest, PathGuard::CONTENT);
        $overwrite = !empty($p['overwrite']);

        $sources = [];
        $targets = [];
        foreach ($entries as $entry) {
            $src = $entry['path'];
            if (PathGuard::within($dest, $src)) {
                throw HttpException::validation(['dest' => 'Folder tujuan tidak boleh berada di dalam item yang ' . ($kind === 'move' ? 'dipindahkan' : 'disalin') . ': ' . $src]);
            }
            $target = rtrim($dest, '/') . '/' . PathGuard::base($src);
            if (PathGuard::same($target, $src)) {
                throw HttpException::validation(['dest' => 'Folder tujuan sama dengan lokasi asal: ' . PathGuard::base($src)]);
            }
            $sources[] = $src;
            $targets[] = $target;
        }

        $conflicts = [];
        foreach (PathGuard::inspect($targets) as $i => $info) {
            if ($info !== null && $info['type'] !== 'n') {
                $conflicts[] = $targets[$i];
            }
        }
        if ($conflicts && !$overwrite) {
            throw new HttpException(409, 'Sudah ada item dengan nama yang sama di folder tujuan: ' . implode(', ', array_map([PathGuard::class, 'base'], array_slice($conflicts, 0, 5)))
                . (count($conflicts) > 5 ? ', dan ' . (count($conflicts) - 5) . ' lainnya' : '') . '. Aktifkan opsi timpa untuk menggantinya.', ['conflicts' => $conflicts]);
        }

        $verb = $kind === 'move' ? 'Memindahkan' : 'Menyalin';
        $plan = new Plan($kind, $verb . ' ' . count($sources) . ' item ke ' . $dest);
        $plan->targets = array_merge($sources, [$dest]);
        $plan->destructive = $overwrite && (bool) $conflicts;
        if ($conflicts) {
            $plan->warnings[] = count($conflicts) . ' item di folder tujuan akan ditimpa.';
        }
        if (Runner::native()) {
            $move = $kind === 'move';
            if ($conflicts) {
                $plan->warnings[] = 'Folder yang ditimpa diganti seluruhnya, tidak digabung dengan isi folder tujuan.';
            }
            foreach ($sources as $src) {
                $plan->addNative(Plan::nativeCall('NativeFs::transfer', [$src, $dest, $overwrite, $move]), $verb . ' ' . PathGuard::base($src), function () use ($src, $dest, $overwrite, $move) {
                    NativeFs::transfer($src, $dest, $overwrite, $move);
                });
            }
        } else {
            $flag = $overwrite ? '-f' : '-n';
            foreach (Shell::chunkArgs($sources) as $chunk) {
                $cmd = $kind === 'move'
                    ? 'mv ' . $flag . ' -- ' . Shell::quoteAll($chunk) . ' ' . Shell::quote(rtrim($dest, '/') . '/')
                    : 'cp -a ' . $flag . ' -- ' . Shell::quoteAll($chunk) . ' ' . Shell::quote(rtrim($dest, '/') . '/');
                $plan->add($cmd, $verb);
            }
        }
        $plan->impact = function () use ($sources, $targets, $conflicts, $kind) {
            $items = [];
            foreach ($sources as $i => $src) {
                $items[] = [
                    'path' => $src,
                    'before' => '',
                    'after' => $targets[$i],
                    'note' => in_array($targets[$i], $conflicts, true) ? 'Menimpa item yang sudah ada' : '',
                ];
            }
            $counted = Finder::count($sources, ['hidden' => true]);
            return [
                'count' => $counted['count'],
                'capped' => $counted['capped'],
                'items' => $items,
                'unit' => $kind === 'move' ? 'entri akan dipindahkan' : 'entri akan disalin',
            ];
        };
        return $plan;
    }

    private function newChild(array $p, $label)
    {
        $dir = PathGuard::resolveDir((string) (isset($p['dir']) ? $p['dir'] : ''));
        PathGuard::assertAllowed($dir, PathGuard::CONTENT);
        $name = PathGuard::name((string) (isset($p['name']) ? $p['name'] : ''));
        $target = rtrim($dir, '/') . '/' . $name;
        $this->assertFree($target);
        return $target;
    }

    private function assertFree($target)
    {
        $info = PathGuard::resolveNew($target);
        if ($info['type'] !== 'n') {
            throw HttpException::validation(['name' => 'Sudah ada berkas atau folder dengan nama ini.']);
        }
    }

    /**
     * @return string[]
     */
    private function paths(array $p)
    {
        $paths = isset($p['paths']) ? $p['paths'] : [];
        if (!is_array($paths)) {
            return [];
        }
        $max = Config::int('limits.list', 5000);
        if (count($paths) > $max) {
            throw HttpException::validation(['paths' => 'Maksimal ' . $max . ' item per operasi.']);
        }
        return array_values(array_filter($paths, 'is_string'));
    }
}
