<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Controller;

use App\Http\Response;
use App\Service\OperationService;

final class OperationController extends Controller
{
    public function preview()
    {
        $params = $this->request->input('params', []);
        $data = (new OperationService())->preview($this->request->string('op'), is_array($params) ? $params : []);
        Response::ok($data);
    }

    public function apply()
    {
        $params = $this->request->input('params', []);
        $result = (new OperationService())->apply($this->request->string('op'), is_array($params) ? $params : [], $this->user());
        if ($result['noop']) {
            Response::ok($result, $result['message']);
            return;
        }
        if (!$result['ok']) {
            $message = $result['partial']
                ? 'Sebagian perubahan gagal diterapkan. Periksa detail kesalahan di bawah.'
                : 'Perubahan gagal diterapkan. Periksa detail kesalahan di bawah.';
            Response::json(500, $message, $result);
            return;
        }
        Response::ok($result, 'Selesai: ' . $result['summary'] . '.');
    }
}
