<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Controller;

use App\Http\Response;
use App\Service\AnalysisService;
use App\Service\WebServerService;

final class AnalysisController extends Controller
{
    public function ownership()
    {
        Response::ok((new AnalysisService())->ownership($this->scalarQuery()));
    }

    public function sizes()
    {
        Response::ok((new AnalysisService())->sizes($this->scalarQuery()));
    }

    public function webserverDetect()
    {
        Response::ok((new WebServerService())->detect());
    }

    public function webserverCheck()
    {
        Response::ok((new WebServerService())->check($this->scalarQuery()));
    }
}
