<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Controller;

use App\Http\Request;

abstract class Controller
{
    /** @var Request */
    protected $request;

    /** @var string|null */
    protected $user;

    /** @var string */
    protected $nonce;

    public function __construct(Request $request, $user, $nonce)
    {
        $this->request = $request;
        $this->user = $user;
        $this->nonce = $nonce;
    }

    protected function user()
    {
        return (string) $this->user;
    }

    /**
     * Query parameters with array values dropped, so services can cast each value to string safely.
     */
    protected function scalarQuery()
    {
        return array_filter($_GET, 'is_scalar');
    }
}
