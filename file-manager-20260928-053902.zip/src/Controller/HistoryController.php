<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Controller;

use App\Http\Response;
use App\Service\HistoryService;
use App\Support\Csv;
use App\Support\ListQuery;

final class HistoryController extends Controller
{
    public function index()
    {
        $rows = $this->filtered();
        foreach ($rows as &$row) {
            $row['targets_text'] = implode(' ', (isset($row['targets']) ? $row['targets'] : []));
        }
        unset($row);
        $page = ListQuery::apply($this->request, $rows, ['summary', 'targets_text', 'user', 'op'], ['at', 'op', 'user'], 'at', 'desc');
        foreach ($page['items'] as &$item) {
            unset($item['targets_text']);
        }
        unset($item);
        Response::ok($page);
    }

    public function export()
    {
        $rows = $this->filtered();
        $search = strtolower($this->request->queryString('search'));
        Csv::stream('riwayat-perubahan_' . gmdate('Y-m-d') . '.csv', ['Waktu (UTC)', 'Pengguna', 'Operasi', 'Ringkasan', 'Status', 'Jumlah target', 'Target', 'Perintah', 'Kesalahan', 'Snapshot'], call_user_func(function () use ($rows, $search) {
            foreach ($rows as $r) {
                if ($search !== '' && strpos(strtolower($r['summary'] . ' ' . implode(' ', (isset($r['targets']) ? $r['targets'] : [])) . ' ' . $r['user']), $search) === false) {
                    continue;
                }
                yield [
                    $r['at'],
                    $r['user'],
                    $r['op'],
                    $r['summary'],
                    $r['ok'] ? 'Berhasil' : 'Gagal',
                    (isset($r['target_count']) ? $r['target_count'] : count(isset($r['targets']) ? $r['targets'] : [])),
                    implode("\n", (isset($r['targets']) ? $r['targets'] : [])),
                    implode("\n", array_column((isset($r['commands']) ? $r['commands'] : []), 'cmd')),
                    implode("\n", (isset($r['errors']) ? $r['errors'] : [])),
                    (isset($r['snapshot_id']) ? $r['snapshot_id'] : ''),
                ];
            }
        }));
    }

    private function filtered()
    {
        $rows = (new HistoryService())->all();
        $op = $this->request->queryString('op');
        $status = $this->request->queryString('status');
        $category = $this->request->queryString('category');
        return array_values(array_filter($rows, function ($r) use ($op, $status, $category) {
            if ($op !== '' && $r['op'] !== $op) {
                return false;
            }
            if ($status === 'ok' && !$r['ok']) {
                return false;
            }
            if ($status === 'failed' && $r['ok']) {
                return false;
            }
            if ($category !== '' && (isset($r['category']) ? $r['category'] : 'operation') !== $category) {
                return false;
            }
            return true;
        }));
    }
}
