<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Controller;

use App\Http\Response;
use App\Service\HistoryService;
use App\Service\PolicyService;
use App\Service\PresetService;
use App\Service\SettingsService;
use App\Support\ListQuery;

final class SettingsController extends Controller
{
    public function app()
    {
        Response::ok((new SettingsService())->current($this->request));
    }

    public function saveApp()
    {
        $changed = (new SettingsService())->save($this->request->body(), $this->request);
        if (!$changed) {
            Response::ok(['changed' => []], 'Tidak ada pengaturan yang berubah.');
            return;
        }
        (new HistoryService())->event($this->user(), 'settings_save', 'Mengubah pengaturan: ' . implode(', ', $changed));
        Response::ok(['changed' => $changed], 'Pengaturan disimpan: ' . implode(', ', $changed) . '.');
    }

    public function resetApp()
    {
        (new SettingsService())->reset($this->request->body(), $this->request);
        (new HistoryService())->event($this->user(), 'settings_reset', 'Mengembalikan semua pengaturan ke config/app.php');
        Response::ok(null, 'Semua pengaturan kembali mengikuti config/app.php.');
    }

    public function presets()
    {
        Response::ok(ListQuery::apply($this->request, (new PresetService())->all(), ['name', 'description', 'owner', 'group'], ['name', 'dir_mode', 'file_mode', 'updated_at'], 'name'));
    }

    public function savePreset()
    {
        $id = $this->request->string('id');
        $preset = (new PresetService())->save($this->request->body(), $id === '' ? null : $id, $this->user());
        $verb = $id === '' ? 'Menambah' : 'Mengubah';
        (new HistoryService())->event($this->user(), 'preset_save', $verb . ' preset "' . $preset['name'] . '"');
        Response::json($id === '' ? 201 : 200, 'Preset "' . $preset['name'] . '" disimpan.', $preset);
    }

    public function deletePreset()
    {
        $preset = (new PresetService())->delete($this->request->string('id'));
        (new HistoryService())->event($this->user(), 'preset_delete', 'Menghapus preset "' . $preset['name'] . '"');
        Response::ok(null, 'Preset "' . $preset['name'] . '" dihapus.');
    }

    public function policies()
    {
        $rows = (new PolicyService())->all();
        $status = $this->request->queryString('status');
        if ($status === 'active' || $status === 'inactive') {
            $rows = array_values(array_filter($rows, function ($r) use ($status) {
                return !empty($r['enabled']) === ($status === 'active');
            }));
        }
        Response::ok(ListQuery::apply($this->request, $rows, ['name', 'pattern', 'owner', 'group'], ['name', 'pattern', 'severity', 'updated_at'], 'name'));
    }

    public function savePolicy()
    {
        $id = $this->request->string('id');
        $policy = (new PolicyService())->save($this->request->body(), $id === '' ? null : $id, $this->user());
        $verb = $id === '' ? 'Menambah' : 'Mengubah';
        (new HistoryService())->event($this->user(), 'policy_save', $verb . ' kebijakan "' . $policy['name'] . '"');
        Response::json($id === '' ? 201 : 200, 'Kebijakan "' . $policy['name'] . '" disimpan.', $policy);
    }

    public function togglePolicy()
    {
        $enabled = $this->request->bool('enabled');
        $policy = (new PolicyService())->setEnabled($this->request->string('id'), $enabled, $this->user());
        (new HistoryService())->event($this->user(), 'policy_toggle', ($enabled ? 'Mengaktifkan' : 'Menonaktifkan') . ' kebijakan "' . $policy['name'] . '"');
        Response::ok($policy, 'Kebijakan "' . $policy['name'] . '" ' . ($enabled ? 'diaktifkan.' : 'dinonaktifkan.'));
    }

    public function deletePolicy()
    {
        $policy = (new PolicyService())->delete($this->request->string('id'));
        (new HistoryService())->event($this->user(), 'policy_delete', 'Menghapus kebijakan "' . $policy['name'] . '"');
        Response::ok(null, 'Kebijakan "' . $policy['name'] . '" dihapus.');
    }
}
