<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Controller;

use App\Http\Response;
use App\Service\AuditService;
use App\Service\HistoryService;
use App\Service\PolicyService;
use App\Support\Csv;
use App\Support\ListQuery;

final class AuditController extends Controller
{
    const SEVERITY_LABEL = ['critical' => 'Kritis', 'high' => 'Tinggi', 'medium' => 'Sedang', 'low' => 'Rendah'];

    public function run()
    {
        $meta = (new AuditService())->run($this->request->body(), $this->user());
        (new HistoryService())->event($this->user(), 'audit', 'Menjalankan audit izin di ' . $meta['path'] . ': ' . $meta['total'] . ' temuan dari ' . $meta['scanned'] . ' entri');
        Response::ok($meta, 'Audit selesai: ' . number_format($meta['total'], 0, ',', '.') . ' temuan dari ' . number_format($meta['scanned'], 0, ',', '.') . ' entri.');
    }

    public function runs()
    {
        Response::ok(['items' => (new AuditService())->runs(), 'rules' => $this->ruleCatalog()]);
    }

    public function findings()
    {
        $data = (new AuditService())->load($this->request->queryString('id'));
        $rows = $this->filter($data['findings']);
        $page = ListQuery::apply($this->request, $rows, ['path', 'label', 'owner', 'group'], ['path', 'severity_rank', 'label', 'octal', 'owner'], 'severity_rank', 'desc');
        Response::ok($page + ['meta' => $data['meta'], 'rules' => $this->ruleCatalog()]);
    }

    public function export()
    {
        $data = (new AuditService())->load($this->request->queryString('id'));
        $rows = $this->filter($data['findings']);
        $meta = $data['meta'];
        $base = 'laporan-audit-izin_' . substr($meta['created_at'], 0, 10);
        if ($this->request->queryString('format') === 'json') {
            $body = json_encode(['audit' => $meta, 'findings' => array_map(function ($r) {
                unset($r['severity_rank']);
                return $r;
            }, $rows)], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
            Response::downloadHeaders($base . '.json', 'application/json; charset=utf-8', strlen($body));
            echo $body;
            return;
        }
        Csv::stream($base . '.csv', ['Tingkat', 'Temuan', 'Path', 'Jenis', 'Izin', 'Simbolik', 'Pemilik', 'Grup', 'Tujuan symlink', 'Keterangan', 'Dapat diperbaiki otomatis'], call_user_func(function () use ($rows) {
            $labels = self::SEVERITY_LABEL;
            foreach ($rows as $r) {
                yield [
                    isset($labels[$r['severity']]) ? $labels[$r['severity']] : $r['severity'],
                    $r['label'],
                    $r['path'],
                    $r['type'],
                    $r['octal'],
                    $r['perms'],
                    $r['owner'],
                    $r['group'],
                    $r['link'],
                    $r['detail'],
                    $r['fixable'] ? 'Ya' : 'Tidak',
                ];
            }
        }));
    }

    private function filter(array $findings)
    {
        $severity = $this->request->queryString('severity');
        $rule = $this->request->queryString('rule');
        $rank = ['critical' => 4, 'high' => 3, 'medium' => 2, 'low' => 1];
        $out = [];
        foreach ($findings as $f) {
            if ($severity !== '' && $f['severity'] !== $severity) {
                continue;
            }
            if ($rule !== '' && $f['rule'] !== $rule) {
                continue;
            }
            $f['severity_rank'] = (isset($rank[$f['severity']]) ? $rank[$f['severity']] : 0);
            $out[] = $f;
        }
        return $out;
    }

    /**
     * Rule ids and labels for the filter and fix pickers, including policies.
     */
    private function ruleCatalog()
    {
        $rules = [];
        foreach (AuditService::RULES as $id => $def) {
            $rules[] = ['id' => $id, 'label' => $def['label'], 'severity' => $def['severity'], 'fixable' => $def['fix'] !== null, 'fix' => $def['fix']];
        }
        foreach ((new PolicyService())->all() as $policy) {
            $rules[] = ['id' => 'policy:' . $policy['id'], 'label' => 'Kebijakan: ' . $policy['name'], 'severity' => $policy['severity'], 'fixable' => true, 'fix' => null];
        }
        return $rules;
    }
}
