<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Controller;

use App\Http\Response;
use App\Service\HistoryService;
use App\Service\SnapshotService;
use App\Support\ListQuery;

final class SnapshotController extends Controller
{
    public function index()
    {
        $rows = (new SnapshotService())->all();
        foreach ($rows as &$row) {
            $row['paths_text'] = implode(', ', $row['paths']);
        }
        unset($row);
        $kind = $this->request->queryString('kind');
        if (in_array($kind, ['auto', 'manual'], true)) {
            $rows = array_values(array_filter($rows, function ($r) use ($kind) {
                return $r['kind'] === $kind;
            }));
        }
        Response::ok(ListQuery::apply($this->request, $rows, ['label', 'paths_text', 'created_by'], ['label', 'created_at', 'count', 'bytes'], 'created_at', 'desc'));
    }

    public function create()
    {
        $meta = (new SnapshotService())->captureManual($this->request->body(), $this->user());
        (new HistoryService())->record([
            'user' => $this->user(),
            'op' => 'snapshot',
            'category' => 'event',
            'summary' => 'Membuat snapshot "' . $meta['label'] . '" (' . $meta['count'] . ' entri)',
            'targets' => $meta['paths'],
            'snapshot_id' => $meta['id'],
        ]);
        Response::json(201, 'Snapshot "' . $meta['label'] . '" dibuat dengan ' . number_format($meta['count'], 0, ',', '.') . ' entri.', $meta);
    }

    public function delete()
    {
        $meta = (new SnapshotService())->delete($this->request->string('id'));
        (new HistoryService())->event($this->user(), 'snapshot_delete', 'Menghapus snapshot "' . $meta['label'] . '"');
        Response::ok(null, 'Snapshot "' . $meta['label'] . '" dihapus.');
    }

    public function compare()
    {
        $result = (new SnapshotService())->compare($this->request->queryString('a'), $this->request->queryString('b', 'live'));
        $rows = $result['rows'];
        $counts = ['changed' => 0, 'added' => 0, 'removed' => 0];
        foreach ($rows as $row) {
            $counts[$row['change']]++;
        }
        $change = $this->request->queryString('change');
        if (isset($counts[$change])) {
            $rows = array_values(array_filter($rows, function ($r) use ($change) {
                return $r['change'] === $change;
            }));
        }
        $page = ListQuery::apply($this->request, $rows, ['path'], ['path', 'change'], 'path');
        Response::ok($page + ['left' => $result['left'], 'right' => $result['right'], 'counts' => $counts]);
    }
}
