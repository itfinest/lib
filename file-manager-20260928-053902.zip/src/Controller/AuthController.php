<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Controller;

use App\Http\HttpException;
use App\Http\Response;
use App\Security\Auth;
use App\Service\HistoryService;

final class AuthController extends Controller
{
    public function login()
    {
        $username = $this->request->string('username');
        $password = (string) $this->request->input('password', '');
        $errors = [];
        if ($username === '') {
            $errors['username'] = 'Nama pengguna wajib diisi.';
        }
        if ($password === '') {
            $errors['password'] = 'Kata sandi wajib diisi.';
        }
        if ($errors) {
            throw HttpException::validation($errors);
        }
        $history = new HistoryService();
        if (!Auth::attempt($this->request, $username, $password)) {
            $history->event($username, 'login', 'Percobaan masuk gagal dari ' . $this->request->ip(), false);
            throw new HttpException(401, 'Nama pengguna atau kata sandi salah.');
        }
        $how = Auth::usedRecovery() ? 'Masuk dengan kata sandi cadangan dari ' : 'Masuk dari ';
        $history->event($username, 'login', $how . $this->request->ip());
        Response::ok(['redirect' => PageController::returnUrl($this->request->string('next')), 'csrf' => Auth::csrfToken()], 'Berhasil masuk.');
    }

    public function logout()
    {
        (new HistoryService())->event($this->user(), 'logout', 'Keluar');
        Auth::logout();
        Response::ok(['redirect' => '?r=login'], 'Anda telah keluar.');
    }

    /**
     * Logout by navigation, used by the active-user monitor in views/partials/user-active.php.
     */
    public function logoutPage()
    {
        (new HistoryService())->event($this->user(), 'logout', 'Keluar melalui pemantau pengguna aktif');
        Auth::logout();
        header('Location: ?r=login');
    }
}
