<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Controller;

use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Http\Response;
use App\Service\AclService;
use App\Service\ArchiveOperations;
use App\Service\ExplorerService;
use App\Service\FavoriteService;
use App\Service\FileContentService;
use App\Service\HistoryService;
use App\Service\OperationService;
use App\Service\SearchService;
use App\Service\TrashService;
use App\Support\Config;
use App\Support\ListQuery;
use App\System\Runner;

final class FileController extends Controller
{
    public function system()
    {
        Response::ok([
            'user' => Runner::processUser(),
            'platform' => Runner::isWindows() ? 'windows' : 'linux',
            'unix_permissions' => Runner::unixPermissions(),
            'shell' => Runner::shell(),
            'roots' => PathGuard::roots(),
            'default_path' => PathGuard::defaultPath(),
            'compress_path' => PathGuard::compressPath(),
            'compress_exclude' => ArchiveOperations::defaultExclude(),
            'sudo' => Runner::sudo(),
            'tools' => Runner::tools(),
            'acl' => AclService::available(),
            'blocks_scripts' => (bool) PathGuard::blockedPatterns(),
            'preview_types' => FileContentService::PREVIEW_TYPES,
            'limits' => [
                'edit_bytes' => Config::int('limits.edit_bytes', 1048576),
                'upload_bytes' => Config::int('limits.upload_bytes', 52428800),
                // Larger files are sent in pieces of this size; part of post_max_size is left for the multipart headers.
                'chunk_bytes' => max(65536, min(FileContentService::CHUNK_MAX_BYTES, $this->iniBytes('upload_max_filesize'), (int) floor($this->iniBytes('post_max_size') * 0.9))),
                'max_file_uploads' => (int) ini_get('max_file_uploads'),
                'post_bytes' => $this->iniBytes('post_max_size'),
            ],
        ]);
    }

    public function index()
    {
        $data = (new ExplorerService())->listing($this->request);
        $message = $data['pagination']['capped'] ? 'Menampilkan ' . ListQuery::PER_PAGE_ALL_CAP . ' item pertama. Gunakan pencarian atau filter untuk mempersempit daftar.' : '';
        Response::ok($data, $message);
    }

    public function folders()
    {
        Response::ok((new ExplorerService())->folders($this->request));
    }

    public function detail()
    {
        Response::ok((new ExplorerService())->detail($this->request->queryString('path')));
    }

    public function content()
    {
        Response::ok((new FileContentService())->read($this->request->queryString('path')));
    }

    public function download()
    {
        (new FileContentService())->download($this->request->queryString('path'));
    }

    public function preview()
    {
        (new FileContentService())->preview($this->request->queryString('path'));
    }

    public function favorites()
    {
        Response::ok(['items' => (new FavoriteService())->all()]);
    }

    public function saveFavorite()
    {
        $favorite = (new FavoriteService())->add($this->request->string('path'), $this->request->string('label'), $this->user());
        (new HistoryService())->event($this->user(), 'favorite_save', 'Menambah folder favorit ' . $favorite['path']);
        Response::json(201, 'Folder "' . $favorite['label'] . '" ditambahkan ke favorit.', $favorite);
    }

    public function deleteFavorite()
    {
        $favorite = (new FavoriteService())->delete($this->request->string('id'));
        (new HistoryService())->event($this->user(), 'favorite_delete', 'Menghapus folder favorit ' . $favorite['path']);
        Response::ok(null, 'Folder "' . $favorite['label'] . '" dihapus dari favorit.');
    }

    public function checksum()
    {
        Response::ok((new FileContentService())->checksum($this->request->queryString('path')));
    }

    public function search()
    {
        Response::ok((new SearchService())->search(
            $this->request->queryString('path'),
            $this->request->queryString('q'),
            $this->request->queryString('case') === '1',
            $this->request->queryString('regex') === '1',
            $this->request->queryString('names'),
            $this->request->queryString('skip')
        ));
    }

    public function principals()
    {
        Response::ok((new ExplorerService())->principals());
    }

    public function trash()
    {
        $items = (new TrashService())->all();
        foreach ($items as &$item) {
            $item['name'] = basename($item['original']);
            unset($item['stored']);
        }
        unset($item);
        Response::ok(ListQuery::apply($this->request, $items, ['original'], ['name', 'original', 'deleted_at', 'size'], 'deleted_at', 'desc'));
    }

    public function upload()
    {
        $raw = (isset($_FILES['files']) ? $_FILES['files'] : null);
        if (!is_array($raw) || !isset($raw['name'])) {
            // PHP drops the whole body when it exceeds post_max_size.
            throw HttpException::validation(['files' => 'Tidak ada berkas yang diterima. Ukuran total mungkin melebihi batas server (post_max_size).']);
        }
        $files = [];
        $names = (array) $raw['name'];
        // PHP keeps only the base name of an uploaded file, so the folder part arrives in a separate field.
        $paths = $this->request->stringList('paths');
        foreach (array_keys($names) as $i) {
            $files[] = [
                'name' => (string) $names[$i],
                'path' => isset($paths[$i]) ? $paths[$i] : (string) $names[$i],
                'tmp_name' => (string) ((array) $raw['tmp_name'])[$i],
                'size' => (int) ((array) $raw['size'])[$i],
                'error' => (int) ((array) $raw['error'])[$i],
            ];
        }
        $plan = (new FileContentService())->uploadPlan($this->request->string('dir'), $files, $this->request->bool('overwrite'));
        $result = (new OperationService())->execute($plan, $this->user());
        if (!$result['ok']) {
            Response::json(500, 'Sebagian berkas gagal diunggah.', $result);
            return;
        }
        Response::ok($result, count($files) . ' berkas berhasil diunggah.');
    }

    public function uploadChunk()
    {
        $raw = (isset($_FILES['chunk']) ? $_FILES['chunk'] : null);
        if (!is_array($raw) || !isset($raw['tmp_name']) || !is_string($raw['tmp_name'])) {
            throw HttpException::validation(['files' => 'Potongan berkas tidak diterima. Ukurannya mungkin melebihi batas server (post_max_size).']);
        }
        $uploadId = $this->request->string('upload_id');
        $path = $this->request->string('path');
        $size = (int) $this->request->string('size');
        $service = new FileContentService();
        try {
            $received = $service->receiveChunk($uploadId, PathGuard::base(str_replace('\\', '/', $path)), (int) $this->request->string('offset'), $size, [
                'tmp_name' => $raw['tmp_name'],
                'size' => (int) $raw['size'],
                'error' => (int) $raw['error'],
            ]);
            if ($received < $size) {
                Response::ok(['received' => $received, 'complete' => false]);
                return;
            }
            $plan = $service->chunkPlan($uploadId, $this->request->string('dir'), $path, $size, $this->request->bool('overwrite'));
            $result = (new OperationService())->execute($plan, $this->user());
        } catch (\Exception $e) {
            $service->discardChunks($uploadId);
            throw $e;
        }
        $service->discardChunks($uploadId);
        $result['complete'] = true;
        if (!$result['ok']) {
            Response::json(500, 'Berkas gagal diunggah.', $result);
            return;
        }
        Response::ok($result, 'Berkas berhasil diunggah.');
    }

    public function uploadCheck()
    {
        $data = (new FileContentService())->uploadCheck($this->request->string('dir'), $this->request->stringList('paths'), $this->request->bool('overwrite'));
        Response::ok($data);
    }

    private function iniBytes($key)
    {
        $value = trim((string) ini_get($key));
        if ($value === '' || $value === '0') {
            return PHP_INT_MAX;
        }
        $unit = strtolower(substr($value, -1));
        $number = (int) $value;
        $multipliers = ['k' => 1024, 'm' => 1048576, 'g' => 1073741824];
        $multiplier = isset($multipliers[$unit]) ? $multipliers[$unit] : 1;
        return $number * $multiplier;
    }
}
