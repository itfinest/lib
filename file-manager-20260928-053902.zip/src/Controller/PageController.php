<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Controller;

use App\Security\Auth;
use App\Support\Config;
use App\System\Runner;

final class PageController extends Controller
{
    const PAGES = [
        'explorer' => ['title' => 'Pengelola Berkas', 'script' => 'explorer'],
        'editor' => [
            'title' => 'Editor Teks',
            'script' => 'editor',
            'vendorStyles' => ['vendor/codemirror/codemirror.css'],
            'vendorScripts' => ['vendor/codemirror/codemirror.min.js'],
        ],
        'trash' => ['title' => 'Tempat Sampah', 'script' => 'trash'],
        'snapshots' => ['title' => 'Snapshot Izin', 'script' => 'snapshots'],
        'history' => ['title' => 'Riwayat Perubahan', 'script' => 'history'],
        'audit' => ['title' => 'Audit Izin', 'script' => 'audit'],
        'malware' => ['title' => 'Pemindai Malware', 'script' => 'malware'],
        'ownership' => ['title' => 'Analisis Kepemilikan', 'script' => 'ownership'],
        'sizes' => ['title' => 'Ukuran Folder', 'script' => 'sizes'],
        'webserver' => ['title' => 'Pemeriksaan Web Server', 'script' => 'webserver'],
        'presets' => ['title' => 'Preset Izin', 'script' => 'presets'],
        'policies' => ['title' => 'Kebijakan Izin', 'script' => 'policies'],
        'settings' => ['title' => 'Pengaturan', 'script' => 'settings'],
        'updates' => ['title' => 'Pembaruan Aplikasi', 'script' => 'updates'],
    ];

    public function login()
    {
        $next = self::returnUrl($this->request->queryString('next'));
        if (Auth::user() !== null) {
            header('Location: ' . $next);
            return;
        }
        $flash = (isset($_SESSION['flash']) ? $_SESSION['flash'] : null);
        unset($_SESSION['flash']);
        self::render('login', [
            'title' => 'Masuk',
            'nonce' => $this->nonce,
            'csrf' => Auth::csrfToken(),
            'flash' => is_string($flash) ? $flash : null,
            'supported' => Runner::supported(),
            'next' => $next,
        ]);
    }

    /**
     * Login page address that remembers the page being opened, so signing in returns there.
     */
    public static function loginUrl()
    {
        $query = isset($_SERVER['QUERY_STRING']) && is_string($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';
        $next = self::returnUrl($query);
        return $next === '?r=explorer' ? '?r=login' : '?r=login&next=' . rawurlencode(substr($next, 1));
    }

    /**
     * Turns a requested return address (a query string such as "r=editor&path=/var/www/a.txt")
     * into a relative URL of one of the application pages. Anything else falls back to the
     * file manager, so the value can never send the browser to another site.
     */
    public static function returnUrl($next)
    {
        $fallback = '?r=explorer';
        $next = ltrim((string) $next, '?');
        if ($next === '' || strlen($next) > 2000) {
            return $fallback;
        }
        parse_str($next, $params);
        $route = isset($params['r']) && is_string($params['r']) ? trim($params['r'], '/') : '';
        $pages = self::PAGES;
        if (!isset($pages[$route])) {
            return $fallback;
        }
        $params['r'] = $route;
        $params = array_filter($params, 'is_string');
        return '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    }

    public function explorer()
    {
        $this->page('explorer');
    }

    public function editor()
    {
        $this->page('editor');
    }

    public function trash()
    {
        $this->page('trash');
    }

    public function snapshots()
    {
        $this->page('snapshots');
    }

    public function history()
    {
        $this->page('history');
    }

    public function audit()
    {
        $this->page('audit');
    }

    public function malware()
    {
        $this->page('malware');
    }

    public function ownership()
    {
        $this->page('ownership');
    }

    public function sizes()
    {
        $this->page('sizes');
    }

    public function webserver()
    {
        $this->page('webserver');
    }

    public function presets()
    {
        $this->page('presets');
    }

    public function policies()
    {
        $this->page('policies');
    }

    public function settings()
    {
        $this->page('settings');
    }

    public function updates()
    {
        $this->page('updates');
    }

    /**
     * @param array $detail reference code, plus file and trace while debugging (ErrorHandler)
     */
    public static function errorPage($status, $message, $nonce, array $detail = [])
    {
        http_response_code($status);
        self::render('error', ['title' => 'Terjadi Kendala', 'status' => $status, 'message' => $message, 'nonce' => $nonce, 'detail' => $detail]);
    }

    private function page($key)
    {
        $pages = self::PAGES;
        $page = $pages[$key];
        self::render('layout', [
            'page' => $key,
            'title' => $page['title'],
            'script' => $page['script'],
            'vendorStyles' => isset($page['vendorStyles']) ? $page['vendorStyles'] : [],
            'vendorScripts' => isset($page['vendorScripts']) ? $page['vendorScripts'] : [],
            'nonce' => $this->nonce,
            'csrf' => Auth::csrfToken(),
            'user' => $this->user(),
            'appName' => (string) Config::get('app_name', 'File Manager'),
            'instansi' => (string) Config::get('instansi', ''),
            'clientIp' => $this->request->ip(),
            'supported' => Runner::supported(),
            'unixPermissions' => Runner::unixPermissions(),
            'idleMinutes' => Config::int('session_idle_minutes', 30),
        ]);
    }

    private static function render($view, array $vars)
    {
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-store');
        extract($vars, EXTR_SKIP);
        $e = function ($value) {
            return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        };
        $asset = function ($path) {
            $file = APP_ROOT . '/assets/' . $path;
            $version = is_file($file) ? (string) filemtime($file) : '0';
            return 'assets/' . $path . '?v=' . $version;
        };
        require APP_ROOT . '/views/' . $view . '.php';
    }
}
