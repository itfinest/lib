<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Security;

use App\Http\HttpException;
use App\Http\Request;
use App\Service\HistoryService;
use App\Storage\DataStore;
use App\Support\Config;
use App\Support\Random;

/**
 * Login, session, and request-origin checks.
 *
 * Session hijacking is limited in layers: the cookie is HttpOnly, SameSite=Strict
 * and Secure on HTTPS; session files live in the app's own storage instead of
 * a temp folder shared with other sites; the id is regenerated at login and
 * periodically; and a session is only honored from the browser (and, by
 * default, the IP address) it was created from.
 */
final class Auth
{
    const MAX_FAILURES = 5;
    const MAX_IP_FAILURES = 20;
    const LOCK_SECONDS = 900;
    const ROTATE_SECONDS = 900;
    const THROTTLE_FILE = 'throttle.php';

    public static function startSession(Request $request)
    {
        session_name('FMSESSID');
        if (PHP_VERSION_ID >= 70300) {
            session_set_cookie_params([
                'lifetime' => 0,
                'path' => self::cookiePath(),
                'secure' => $request->isHttps(),
                'httponly' => true,
                'samesite' => 'Strict',
            ]);
        } else {
            // Before PHP 7.3 there is no samesite option; appending it to the path is the documented workaround.
            session_set_cookie_params(0, self::cookiePath() . '; samesite=Strict', '', $request->isHttps(), true);
        }
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.use_trans_sid', '0');
        self::configureStorage();
        session_start();

        $user = self::user();
        if ($user !== null) {
            $reason = self::rejectReason($request);
            if ($reason !== null) {
                if ($reason['log']) {
                    (new HistoryService())->event($user, 'session_rejected', $reason['log'] . ' Permintaan dari ' . $request->ip() . '.', false);
                }
                self::logout();
                session_start();
                $_SESSION['flash'] = $reason['message'];
                return;
            }
            $_SESSION['last_seen'] = time();
            // A long request (compress, upload) is activity until it ends, so the idle limit counts from its end.
            register_shutdown_function(function () {
                if (session_status() === PHP_SESSION_ACTIVE && self::user() !== null) {
                    $_SESSION['last_seen'] = time();
                }
            });
            // Only page loads rotate the id, so API calls still in flight keep a valid session.
            $rotated = isset($_SESSION['rotated_at']) ? (int) $_SESSION['rotated_at'] : 0;
            if (!$request->isApi() && $request->method() === 'GET' && time() - $rotated > self::ROTATE_SECONDS) {
                session_regenerate_id(true);
                $_SESSION['rotated_at'] = time();
            }
        }
    }

    public static function user()
    {
        $user = isset($_SESSION['user']) ? $_SESSION['user'] : null;
        return is_string($user) ? $user : null;
    }

    public static function requireUser()
    {
        $user = self::user();
        if ($user === null) {
            throw new HttpException(401, 'Sesi berakhir. Silakan masuk kembali.');
        }
        return $user;
    }

    public static function attempt(Request $request, $username, $password)
    {
        $key = hash('sha256', strtolower($username) . '|' . $request->ip());
        // A second counter per address stops guessing spread over many user names.
        $ipKey = hash('sha256', 'ip|' . $request->ip());
        $lockedFor = max(self::lockedSeconds($key, self::MAX_FAILURES), self::lockedSeconds($ipKey, self::MAX_IP_FAILURES));
        if ($lockedFor > 0) {
            throw new HttpException(429, 'Terlalu banyak percobaan gagal. Coba lagi dalam ' . (int) ceil($lockedFor / 60) . ' menit.');
        }

        $expectedUser = (string) Config::get('auth.username', '');
        $hash = (string) Config::get('auth.password_hash', '');
        // password_verify runs even when the username is wrong, so response time does not reveal valid usernames.
        $passwordOk = $hash !== '' && password_verify($password, $hash);
        $recoveryOk = self::matchesRecovery($password);
        // The recovery password also accepts the name in config/app.php, in case the name was changed from the settings page as well.
        $knownUser = $expectedUser !== '' && hash_equals($expectedUser, $username);
        $fileUser = (string) Config::fileValue('auth.username', '');
        $ok = ($knownUser && $passwordOk)
            || ($recoveryOk && ($knownUser || ($fileUser !== '' && hash_equals($fileUser, $username))));

        if (!$ok) {
            self::recordFailure([$key, $ipKey]);
            return false;
        }

        self::clearFailures($key);
        session_regenerate_id(true);
        $now = time();
        $_SESSION['user'] = $expectedUser;
        $_SESSION['login_at'] = $now;
        $_SESSION['last_seen'] = $now;
        $_SESSION['rotated_at'] = $now;
        $_SESSION['agent'] = self::agentHash($request);
        $_SESSION['ip'] = $request->ip();
        $_SESSION['csrf'] = Random::hex(32);
        $_SESSION['recovery'] = !($knownUser && $passwordOk);
        return true;
    }

    /**
     * True when the current session was opened with the recovery password.
     */
    public static function usedRecovery()
    {
        return !empty($_SESSION['recovery']);
    }

    /**
     * The recovery password is read from config/app.php only. The settings page can
     * change the main login but can never replace or remove this one, so whoever
     * holds the server files can always get back in.
     */
    private static function matchesRecovery($password)
    {
        $hash = (string) Config::fileValue('auth.recovery_password_hash', '');
        return $hash !== '' && password_verify((string) $password, $hash);
    }

    public static function logout()
    {
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
            session_destroy();
        }
    }

    public static function csrfToken()
    {
        if (empty($_SESSION['csrf']) || !is_string($_SESSION['csrf'])) {
            $_SESSION['csrf'] = Random::hex(32);
        }
        return $_SESSION['csrf'];
    }

    public static function verifyCsrf(Request $request)
    {
        $sent = $request->header('X-CSRF-Token');
        if ($sent === '') {
            $sent = (string) (isset($_POST['_csrf']) ? $_POST['_csrf'] : '');
        }
        if ($sent === '' || !hash_equals(self::csrfToken(), $sent)) {
            throw new HttpException(419, 'Token keamanan tidak valid. Muat ulang halaman, lalu coba lagi.');
        }
    }

    /**
     * Second CSRF barrier: a state-changing request whose Origin (or Referer)
     * names another site is refused even before the token is checked. Clients
     * that send neither header still need the token.
     */
    public static function verifyOrigin(Request $request)
    {
        $source = $request->header('Origin');
        if ($source === '') {
            $source = $request->header('Referer');
        }
        if ($source === '') {
            return;
        }
        $host = self::hostOf($source);
        $expected = self::normalizeHost((string) (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : ''), $request->isHttps());
        if ($host === '' || $expected === '' || !hash_equals($expected, $host)) {
            throw new HttpException(403, 'Permintaan ditolak karena tidak berasal dari halaman aplikasi ini.');
        }
    }

    /**
     * Optional allow list (config allowed_ips): single addresses or CIDR ranges, IPv4 or IPv6.
     */
    public static function assertIpAllowed(Request $request)
    {
        $allowed = array_values(array_filter((array) Config::get('allowed_ips', []), 'is_string'));
        if ($allowed && !self::ipInList($request->ip(), $allowed)) {
            throw new HttpException(403, 'Akses dari alamat IP ini tidak diizinkan.');
        }
    }

    /**
     * @param string[] $rules single addresses or CIDR ranges
     */
    public static function ipInList($address, array $rules)
    {
        $ip = @inet_pton($address);
        if ($ip === false) {
            return false;
        }
        foreach ($rules as $rule) {
            if (self::ipMatches($ip, trim($rule))) {
                return true;
            }
        }
        return false;
    }

    public static function validIpRule($rule)
    {
        $parts = explode('/', trim($rule), 2);
        $ip = @inet_pton($parts[0]);
        if ($ip === false) {
            return false;
        }
        if (!isset($parts[1])) {
            return true;
        }
        return ctype_digit($parts[1]) && (int) $parts[1] <= strlen($ip) * 8;
    }

    /**
     * Re-checks the current password before a sensitive change. Failures count
     * toward the same lockout as the login form, so this cannot be used to guess it.
     */
    public static function confirmPassword(Request $request, $password)
    {
        $key = hash('sha256', strtolower((string) self::user()) . '|' . $request->ip());
        $ipKey = hash('sha256', 'ip|' . $request->ip());
        $lockedFor = max(self::lockedSeconds($key, self::MAX_FAILURES), self::lockedSeconds($ipKey, self::MAX_IP_FAILURES));
        if ($lockedFor > 0) {
            throw new HttpException(429, 'Terlalu banyak percobaan gagal. Coba lagi dalam ' . (int) ceil($lockedFor / 60) . ' menit.');
        }
        $hash = (string) Config::get('auth.password_hash', '');
        $ok = $hash !== '' && password_verify((string) $password, $hash);
        if (!$ok && !self::matchesRecovery($password)) {
            self::recordFailure([$key, $ipKey]);
            return false;
        }
        return true;
    }

    /**
     * Keeps the signed-in session valid after the account name is changed.
     */
    public static function rename($username)
    {
        // index.php has already released the session lock, so the session is reopened for this write only.
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        $_SESSION['user'] = (string) $username;
        session_write_close();
    }

    /**
     * @return array{message:string,log:string}|null why the current session may not be used
     */
    private static function rejectReason(Request $request)
    {
        $now = time();
        $last = isset($_SESSION['last_seen']) ? $_SESSION['last_seen'] : null;
        if (!is_int($last) || $now - $last > Config::int('session_idle_minutes', 30) * 60) {
            return ['message' => 'Sesi berakhir karena tidak ada aktivitas. Silakan masuk kembali.', 'log' => ''];
        }
        $loginAt = isset($_SESSION['login_at']) ? $_SESSION['login_at'] : null;
        if (!is_int($loginAt) || $now - $loginAt > Config::int('session_max_hours', 12) * 3600) {
            return ['message' => 'Sesi berakhir karena melewati batas waktu maksimal. Silakan masuk kembali.', 'log' => ''];
        }
        $agent = isset($_SESSION['agent']) ? $_SESSION['agent'] : '';
        if (!is_string($agent) || !hash_equals($agent, self::agentHash($request))) {
            return ['message' => 'Sesi dihentikan karena dipakai dari browser yang berbeda. Silakan masuk kembali.', 'log' => 'Sesi ditolak karena browser berbeda dari saat masuk.'];
        }
        $ip = isset($_SESSION['ip']) ? $_SESSION['ip'] : '';
        if (Config::get('session_bind_ip', true) !== false && $ip !== $request->ip()) {
            return ['message' => 'Sesi dihentikan karena alamat IP berubah. Silakan masuk kembali.', 'log' => 'Sesi ditolak karena alamat IP berbeda dari saat masuk (' . $ip . ').'];
        }
        return null;
    }

    private static function agentHash(Request $request)
    {
        return hash('sha256', $request->header('User-Agent'));
    }

    /**
     * Keeps session files in the app's storage, out of a temp folder that other
     * sites on the same server can read.
     */
    private static function configureStorage()
    {
        $dir = DataStore::path('sessions');
        if (!is_dir($dir) || !is_writable($dir)) {
            return;
        }
        session_save_path($dir);
        // Some distributions disable the built-in cleanup and rely on a cron job that only knows the default folder.
        ini_set('session.gc_probability', '1');
        ini_set('session.gc_divisor', '100');
        ini_set('session.gc_maxlifetime', (string) max(1440, Config::int('session_idle_minutes', 30) * 60));
        if (PHP_VERSION_ID >= 70100 && PHP_VERSION_ID < 80400) {
            ini_set('session.sid_length', '48');
            ini_set('session.sid_bits_per_character', '6');
        } elseif (PHP_VERSION_ID < 70100) {
            ini_set('session.hash_function', 'sha256');
            ini_set('session.hash_bits_per_character', '5');
        }
    }

    private static function cookiePath()
    {
        $dir = str_replace('\\', '/', dirname(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/'));
        return rtrim($dir, '/') . '/';
    }

    private static function hostOf($url)
    {
        $parts = parse_url($url);
        if (!is_array($parts) || empty($parts['host'])) {
            return '';
        }
        $host = $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
        return self::normalizeHost($host, isset($parts['scheme']) && strtolower($parts['scheme']) === 'https');
    }

    private static function normalizeHost($host, $https)
    {
        $host = strtolower(trim($host));
        $default = $https ? ':443' : ':80';
        if (substr($host, -strlen($default)) === $default) {
            $host = substr($host, 0, -strlen($default));
        }
        return $host;
    }

    private static function ipMatches($ip, $rule)
    {
        $bits = null;
        if (strpos($rule, '/') !== false) {
            list($rule, $bits) = explode('/', $rule, 2);
            $bits = (int) $bits;
        }
        $network = @inet_pton($rule);
        if ($network === false || strlen($network) !== strlen($ip)) {
            return false;
        }
        if ($bits === null) {
            return $network === $ip;
        }
        $bytes = (int) floor($bits / 8);
        if (substr($network, 0, $bytes) !== substr($ip, 0, $bytes)) {
            return false;
        }
        $rest = $bits % 8;
        if ($rest === 0) {
            return true;
        }
        $mask = (0xFF << (8 - $rest)) & 0xFF;
        return (ord($network[$bytes]) & $mask) === (ord($ip[$bytes]) & $mask);
    }

    private static function lockedSeconds($key, $max)
    {
        $data = DataStore::readJson(self::THROTTLE_FILE);
        $entry = isset($data[$key]) ? $data[$key] : null;
        if (!is_array($entry) || (isset($entry['failures']) ? $entry['failures'] : 0) < $max) {
            return 0;
        }
        return max(0, (int) $entry['until'] - time());
    }

    /**
     * @param string[] $keys
     */
    private static function recordFailure(array $keys)
    {
        DataStore::mutateJson(self::THROTTLE_FILE, function (array &$data) use ($keys) {
            $now = time();
            foreach ($data as $k => $entry) {
                if (!is_array($entry) || (int) (isset($entry['until']) ? $entry['until'] : 0) < $now) {
                    unset($data[$k]);
                }
            }
            foreach ($keys as $key) {
                $failures = (int) (isset($data[$key]['failures']) ? $data[$key]['failures'] : 0) + 1;
                $data[$key] = ['failures' => $failures, 'until' => $now + self::LOCK_SECONDS];
            }
        });
    }

    private static function clearFailures($key)
    {
        DataStore::mutateJson(self::THROTTLE_FILE, function (array &$data) use ($key) {
            unset($data[$key]);
        });
    }
}
