<?php
/** @author Ertha Dwi Setiyawan */

if (PHP_VERSION_ID < 50600) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'File Manager membutuhkan PHP 5.6 atau lebih baru. Versi PHP server ini: ' . PHP_VERSION;
    exit;
}

define('APP_ROOT', dirname(__DIR__));

// PHP 5.6 to 7.1 have no JSON_INVALID_UTF8_SUBSTITUTE (added in 7.2). Partial output keeps a
// response readable there by nulling a string with invalid UTF-8 instead of failing the whole encode.
if (!defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
    define('JSON_INVALID_UTF8_SUBSTITUTE', JSON_PARTIAL_OUTPUT_ON_ERROR);
}

spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }
    $file = __DIR__ . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

// Every stored timestamp is UTC; the browser converts it to the viewer's timezone.
date_default_timezone_set('UTC');

// Registered before the configuration loads, so a failure there is reported too.
App\Support\ErrorHandler::register();

if (!is_file(APP_ROOT . '/config/app.php')) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Konfigurasi belum ada. Salin config/app.example.php menjadi config/app.php, lalu isi auth.password_hash dan roots.';
    exit;
}

App\Support\Config::load(require APP_ROOT . '/config/app.php');
// Values changed on the settings page are kept in storage and win over config/app.php.
App\Support\Config::merge(App\Storage\DataStore::readJson(App\Service\SettingsService::FILE));
