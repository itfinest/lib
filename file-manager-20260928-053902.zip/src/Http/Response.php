<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Http;

final class Response
{
    /**
     * Sends the fixed JSON envelope used by every API endpoint.
     *
     * @param mixed $data
     */
    public static function json($status, $message, $data = null)
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode(
            [
                'status' => $status < 400 ? 'success' : 'error',
                'message' => $message,
                'data' => $data,
            ],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE
        );
    }

    /**
     * @param mixed $data
     */
    public static function ok($data = null, $message = '')
    {
        self::json(200, $message, $data);
    }

    public static function securityHeaders($nonce)
    {
        if (function_exists('header_remove')) {
            // The PHP version banner helps an attacker pick a known exploit.
            header_remove('X-Powered-By');
        }
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: same-origin');
        header('Cross-Origin-Opener-Policy: same-origin');
        header('Cross-Origin-Resource-Policy: same-origin');
        header('X-Permitted-Cross-Domain-Policies: none');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=()');
        // Alpine.js evaluates its directives with Function(), which needs 'unsafe-eval'. The itfinest.github.io,
        // api.ipify.org, and asamediautama.co.id hosts belong to the active-user monitor (views/partials/user-active.php).
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-eval' 'nonce-{$nonce}' https://itfinest.github.io; "
            . "style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; "
            . "connect-src 'self' https://api.ipify.org wss://asamediautama.co.id:7676; "
            . "frame-ancestors 'none'; form-action 'self'; base-uri 'none'; object-src 'none'");
    }

    public static function downloadHeaders($filename, $contentType, $length = null)
    {
        $ascii = preg_replace('/[^A-Za-z0-9._-]/', '_', $filename);
        header('Content-Type: ' . $contentType);
        header('Content-Disposition: attachment; filename="' . $ascii . '"; filename*=UTF-8\'\'' . rawurlencode($filename));
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');
        if ($length !== null) {
            header('Content-Length: ' . $length);
        }
    }
}
