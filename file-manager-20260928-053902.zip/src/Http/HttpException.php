<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Http;

use RuntimeException;

/**
 * An expected, user-facing failure. The message is safe to show as-is.
 */
final class HttpException extends RuntimeException
{
    /** @var int */
    private $status;

    /** @var array */
    private $errors;

    public function __construct($status, $message, array $errors = [])
    {
        parent::__construct($message);
        $this->status = $status;
        $this->errors = $errors;
    }

    public function status()
    {
        return $this->status;
    }

    public function errors()
    {
        return $this->errors;
    }

    public static function validation(array $errors, $message = 'Periksa kembali isian yang ditandai.')
    {
        return new self(422, $message, $errors);
    }
}
