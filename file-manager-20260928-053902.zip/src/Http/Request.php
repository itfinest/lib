<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Http;

final class Request
{
    /** @var array|null */
    private $body;

    public function method()
    {
        return strtoupper(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET');
    }

    public function route()
    {
        $route = (isset($_GET['r']) ? $_GET['r'] : '');
        return is_string($route) ? trim($route, '/') : '';
    }

    public function isApi()
    {
        return strncmp($this->route(), 'api/', 4) === 0;
    }

    public function header($name)
    {
        $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        return isset($_SERVER[$key]) && is_string($_SERVER[$key]) ? $_SERVER[$key] : '';
    }

    public function isHttps()
    {
        return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || ((isset($_SERVER['SERVER_PORT']) ? $_SERVER['SERVER_PORT'] : '') === '443');
    }

    public function ip()
    {
        return (string) (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown');
    }

    /**
     * @return mixed
     */
    public function query($key, $default = null)
    {
        return array_key_exists($key, $_GET) ? $_GET[$key] : $default;
    }

    /**
     * Reads a field from the JSON body, falling back to form fields for multipart uploads.
     *
     * @return mixed
     */
    public function input($key, $default = null)
    {
        $body = $this->body();
        return array_key_exists($key, $body) ? $body[$key] : $default;
    }

    public function body()
    {
        if ($this->body === null) {
            $this->body = $_POST;
            $type = (isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '');
            if (stripos($type, 'application/json') !== false) {
                $raw = file_get_contents('php://input');
                $decoded = json_decode($raw === false ? '' : $raw, true);
                if (!is_array($decoded)) {
                    throw new HttpException(400, 'Format permintaan tidak valid.');
                }
                $this->body = $decoded;
            }
        }
        return $this->body;
    }

    public function string($key, $default = '')
    {
        $value = $this->input($key, $default);
        return is_scalar($value) ? trim((string) $value) : $default;
    }

    public function bool($key)
    {
        $value = $this->input($key, false);
        return $value === true || $value === 1 || $value === '1' || $value === 'true';
    }

    /**
     * @return string[]
     */
    public function stringList($key)
    {
        $value = $this->input($key, []);
        if (!is_array($value)) {
            return [];
        }
        $out = [];
        foreach ($value as $item) {
            if (is_scalar($item)) {
                $out[] = (string) $item;
            }
        }
        return $out;
    }

    public function queryString($key, $default = '')
    {
        $value = $this->query($key, $default);
        return is_scalar($value) ? trim((string) $value) : $default;
    }

    public function queryInt($key, $default, $min, $max)
    {
        $value = $this->query($key, $default);
        if (!is_numeric($value)) {
            return $default;
        }
        return max($min, min($max, (int) $value));
    }
}
