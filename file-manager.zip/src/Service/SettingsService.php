<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Http\Request;
use App\Security\Auth;
use App\Storage\DataStore;
use App\Support\Config;
use App\Support\Validate;
use App\System\Runner;

/**
 * Settings changed from the settings page. They are stored as JSON in
 * storage/settings.php and applied over config/app.php at startup, so the
 * PHP configuration file is never rewritten from browser input. Only values
 * that differ from config/app.php are stored, which keeps "reset" exact.
 */
final class SettingsService
{
    const FILE = 'settings.php';
    const MB = 1048576;

    const LABELS = [
        'app_name' => 'Nama aplikasi',
        'roots' => 'Folder root',
        'default_path' => 'Folder awal',
        'compress_path' => 'Folder tujuan kompres',
        'compress_exclude' => 'Pengecualian kompres bawaan',
        'hidden_names' => 'Nama yang disembunyikan',
        'update_url' => 'URL pembaruan',
        'session_idle_minutes' => 'Batas sesi tanpa aktivitas',
        'session_max_hours' => 'Batas umur sesi',
        'session_bind_ip' => 'Kunci sesi ke alamat IP',
        'allowed_ips' => 'Alamat IP yang diizinkan',
        'blocked_extensions' => 'Ekstensi yang diblokir',
        'blocked_names' => 'Nama berkas yang diblokir',
        'protect_app_folder' => 'Lindungi folder aplikasi',
        'limit_list' => 'Batas item daftar folder',
        'limit_scan' => 'Batas entri pemindaian',
        'edit_mb' => 'Batas ukuran editor',
        'upload_mb' => 'Batas ukuran unggahan',
        'preview_items' => 'Batas item pratinjau',
        'command_timeout' => 'Batas waktu perintah',
        'no_time_limit' => 'Proses tanpa batas waktu',
        'username' => 'Nama pengguna',
        'password' => 'Kata sandi',
    ];

    /**
     * Current values for the form, plus which of them were changed from this page.
     */
    public function current(Request $request)
    {
        $stored = DataStore::readJson(self::FILE);
        $overridden = array_keys(array_diff_key($this->flatten($stored), ['password' => true]));
        if (isset($stored['auth']['password_hash'])) {
            $overridden[] = 'password';
        }
        $values = $this->values(function ($key, $default) {
            return Config::get($key, $default);
        });
        $values['roots'] = PathGuard::roots();
        return [
            'values' => $values,
            'overridden' => $overridden,
            'client_ip' => $request->ip(),
            'unix' => Runner::unixPermissions(),
            'recovery' => (string) Config::fileValue('auth.recovery_password_hash', '') !== '',
        ];
    }

    /**
     * @return string[] labels of the settings that changed
     */
    public function save(array $input, Request $request)
    {
        $new = $this->validate($input, $request);
        $newPassword = (string) (isset($input['new_password']) ? $input['new_password'] : '');
        $this->confirm($input, $request);

        $base = $this->base();
        $old = $this->values(function ($key, $default) {
            return Config::get($key, $default);
        });
        $old['roots'] = PathGuard::roots();
        $stored = DataStore::readJson(self::FILE);

        $overrides = [];
        foreach ($new as $key => $value) {
            if ($value !== $base[$key]) {
                $this->put($overrides, $key, $value);
            }
        }
        $labels = self::LABELS;
        $changed = [];
        foreach ($new as $key => $value) {
            if ($value !== $old[$key]) {
                $changed[] = $labels[$key];
            }
        }
        if ($newPassword !== '') {
            $overrides['auth']['password_hash'] = password_hash($newPassword, PASSWORD_DEFAULT);
            $changed[] = $labels['password'];
        } elseif (isset($stored['auth']['password_hash'])) {
            $overrides['auth']['password_hash'] = $stored['auth']['password_hash'];
        }

        DataStore::mutateJson(self::FILE, function (array &$data) use ($overrides) {
            $data = $overrides;
        });
        if ($new['username'] !== $old['username']) {
            Auth::rename($new['username']);
        }
        return $changed;
    }

    /**
     * Drops every stored setting, so config/app.php applies again (including its login account).
     */
    public function reset(array $input, Request $request)
    {
        $this->confirm($input, $request);
        $base = $this->base();
        DataStore::mutateJson(self::FILE, function (array &$data) {
            $data = [];
        });
        Auth::rename($base['username']);
    }

    private function confirm(array $input, Request $request)
    {
        $password = (string) (isset($input['current_password']) ? $input['current_password'] : '');
        if ($password === '') {
            throw HttpException::validation(['current_password' => 'Masukkan kata sandi saat ini untuk menyimpan pengaturan.']);
        }
        if (!Auth::confirmPassword($request, $password)) {
            throw HttpException::validation(['current_password' => 'Kata sandi saat ini salah.']);
        }
    }

    /**
     * Values from config/app.php alone, without the stored settings.
     */
    private function base()
    {
        $config = require APP_ROOT . '/config/app.php';
        $values = $this->values(function ($key, $default) use ($config) {
            $value = $config;
            foreach (explode('.', $key) as $segment) {
                if (!is_array($value) || !array_key_exists($segment, $value)) {
                    return $default;
                }
                $value = $value[$segment];
            }
            return $value;
        });
        $roots = [];
        foreach ((array) $values['roots'] as $root) {
            try {
                $roots[] = PathGuard::realpaths([PathGuard::clean((string) $root, 'roots')])[0];
            } catch (HttpException $e) {
                continue;
            }
        }
        $values['roots'] = array_values(array_unique(array_filter($roots)));
        return $values;
    }

    /**
     * Form values in their stored shape, read through $get(key, default).
     */
    private function values($get)
    {
        $list = function ($value) {
            return array_values(array_filter((array) $value, 'is_string'));
        };
        return [
            'app_name' => (string) $get('app_name', 'File Manager'),
            'roots' => $list($get('roots', [])),
            'default_path' => (string) $get('default_path', ''),
            'compress_path' => (string) $get('compress_path', ''),
            'compress_exclude' => $list($get('compress_exclude', ArchiveOperations::DEFAULT_EXCLUDE)),
            'hidden_names' => $list($get('hidden_names', [])),
            'update_url' => trim((string) $get('update_url', '')),
            'session_idle_minutes' => (int) $get('session_idle_minutes', 30),
            'session_max_hours' => (int) $get('session_max_hours', 12),
            'session_bind_ip' => $get('session_bind_ip', true) !== false,
            'allowed_ips' => $list($get('allowed_ips', [])),
            'blocked_extensions' => $list($get('blocked_extensions', PathGuard::DEFAULT_BLOCKED_EXTENSIONS)),
            'blocked_names' => $list($get('blocked_names', PathGuard::DEFAULT_BLOCKED_NAMES)),
            'protect_app_folder' => $get('protect_app_folder', true) !== false,
            'limit_list' => (int) $get('limits.list', 5000),
            'limit_scan' => (int) $get('limits.scan', 100000),
            'edit_mb' => (int) max(1, round((int) $get('limits.edit_bytes', self::MB) / self::MB)),
            'upload_mb' => (int) max(1, round((int) $get('limits.upload_bytes', 50 * self::MB) / self::MB)),
            'preview_items' => (int) $get('limits.preview_items', 200),
            'command_timeout' => (int) $get('command_timeout', 120),
            'no_time_limit' => $get('no_time_limit', true) !== false,
            'username' => (string) $get('auth.username', ''),
        ];
    }

    private function validate(array $in, Request $request)
    {
        $errors = [];
        $out = [];
        $text = function ($key) use ($in) {
            return isset($in[$key]) && is_scalar($in[$key]) ? trim((string) $in[$key]) : '';
        };

        try {
            $out['app_name'] = Validate::text($text('app_name'), 'app_name', 60);
        } catch (HttpException $e) {
            $errors += $e->errors();
        }

        $out['roots'] = [];
        $roots = $this->lines(isset($in['roots']) ? $in['roots'] : []);
        if (!$roots) {
            $errors['roots'] = 'Isi minimal satu folder root.';
        } elseif (count($roots) > 20) {
            $errors['roots'] = 'Maksimal 20 folder root.';
        } else {
            foreach ($roots as $root) {
                try {
                    $real = PathGuard::realpaths([PathGuard::clean($root, 'roots')])[0];
                } catch (HttpException $e) {
                    $errors['roots'] = 'Path tidak valid: ' . $root . '. ' . current($e->errors());
                    break;
                }
                if ($real === '' || !@is_dir($real)) {
                    $errors['roots'] = 'Folder tidak ditemukan: ' . $root;
                    break;
                }
                $out['roots'][] = $real;
            }
            $out['roots'] = array_values(array_unique($out['roots']));
        }

        // Read before the folder settings so they are checked against the protection being saved.
        $out['protect_app_folder'] = !empty($in['protect_app_folder']);
        $protectsApp = $out['protect_app_folder'];

        $out['default_path'] = '';
        $default = $text('default_path');
        if ($default !== '' && !isset($errors['roots'])) {
            try {
                $real = PathGuard::realpaths([PathGuard::clean($default, 'default_path')])[0];
                $inside = false;
                foreach ($out['roots'] as $root) {
                    $inside = $inside || PathGuard::within($real, $root);
                }
                if ($real === '' || !@is_dir($real)) {
                    $errors['default_path'] = 'Folder tidak ditemukan.';
                } elseif (!$inside) {
                    $errors['default_path'] = 'Folder awal harus berada di dalam salah satu folder root.';
                } elseif ($protectsApp && PathGuard::within($real, PathGuard::appRoot())) {
                    $errors['default_path'] = 'Folder aplikasi tidak dapat dijadikan folder awal selama pilihan Lindungi folder aplikasi aktif.';
                } else {
                    $out['default_path'] = $real;
                }
            } catch (HttpException $e) {
                $errors += $e->errors();
            }
        }

        $out['compress_path'] = '';
        $compress = $text('compress_path');
        if ($compress !== '' && !isset($errors['roots'])) {
            try {
                $real = PathGuard::realpaths([PathGuard::clean($compress, 'compress_path')])[0];
                $inside = false;
                foreach ($out['roots'] as $root) {
                    $inside = $inside || PathGuard::within($real, $root);
                }
                if ($real === '' || !@is_dir($real)) {
                    $errors['compress_path'] = 'Folder tidak ditemukan.';
                } elseif (!$inside) {
                    $errors['compress_path'] = 'Folder tujuan kompres harus berada di dalam salah satu folder root.';
                } elseif ($protectsApp && PathGuard::within($real, PathGuard::appRoot())) {
                    $errors['compress_path'] = 'Folder aplikasi tidak dapat dijadikan folder tujuan kompres selama pilihan Lindungi folder aplikasi aktif.';
                } else {
                    $out['compress_path'] = $real;
                }
            } catch (HttpException $e) {
                $errors += $e->errors();
            }
        }

        // Checked with the same rules the compress dialog applies, so a saved list is always accepted there.
        $out['compress_exclude'] = array_values(array_unique($this->lines(isset($in['compress_exclude']) ? $in['compress_exclude'] : [])));
        try {
            (new ArchiveOperations())->excludePatterns(implode("\n", $out['compress_exclude']));
        } catch (HttpException $e) {
            $errors['compress_exclude'] = current($e->errors());
        }

        $out['hidden_names'] = array_values(array_unique($this->lines(isset($in['hidden_names']) ? $in['hidden_names'] : [])));
        if (count($out['hidden_names']) > 100) {
            $errors['hidden_names'] = 'Maksimal 100 nama.';
        }
        foreach ($out['hidden_names'] as $name) {
            if (strlen($name) > 255 || preg_match('#[/\\\\\x00-\x1F]#', $name)) {
                $errors['hidden_names'] = 'Nama berkas atau folder tidak valid: ' . $name;
                break;
            }
        }

        $out['update_url'] = $text('update_url');
        if ($out['update_url'] !== '' && !Validate::httpUrl($out['update_url'])) {
            $errors['update_url'] = 'Isi alamat lengkap yang diawali http:// atau https://, maksimal 2.048 karakter.';
        }

        $out['session_idle_minutes'] = $this->number($in, 'session_idle_minutes', 5, 480, $errors);
        $out['session_max_hours'] = $this->number($in, 'session_max_hours', 1, 72, $errors);
        $out['session_bind_ip'] = !empty($in['session_bind_ip']);

        $out['allowed_ips'] = $this->lines(isset($in['allowed_ips']) ? $in['allowed_ips'] : []);
        foreach ($out['allowed_ips'] as $rule) {
            if (!Auth::validIpRule($rule)) {
                $errors['allowed_ips'] = 'Alamat IP atau rentang CIDR tidak valid: ' . $rule;
                break;
            }
        }
        if (!isset($errors['allowed_ips']) && $out['allowed_ips'] && !Auth::ipInList($request->ip(), $out['allowed_ips'])) {
            $errors['allowed_ips'] = 'Alamat IP Anda saat ini (' . $request->ip() . ') tidak termasuk daftar, sehingga Anda akan terkunci dari aplikasi.';
        }

        $out['blocked_extensions'] = [];
        foreach ($this->lines(isset($in['blocked_extensions']) ? $in['blocked_extensions'] : [], true) as $ext) {
            $ext = strtolower(ltrim($ext, '.'));
            if (!preg_match('/^[a-z0-9]{1,16}$/', $ext)) {
                $errors['blocked_extensions'] = 'Ekstensi hanya boleh berisi huruf dan angka, misalnya php atau phtml: ' . $ext;
                break;
            }
            $out['blocked_extensions'][] = $ext;
        }
        $out['blocked_extensions'] = array_values(array_unique($out['blocked_extensions']));

        $out['blocked_names'] = [];
        foreach ($this->lines(isset($in['blocked_names']) ? $in['blocked_names'] : [], true) as $name) {
            if (strlen($name) > 255 || preg_match('#[/\\\\\x00-\x1F]#', $name)) {
                $errors['blocked_names'] = 'Nama berkas tidak valid: ' . $name;
                break;
            }
            $out['blocked_names'][] = strtolower($name);
        }
        $out['blocked_names'] = array_values(array_unique($out['blocked_names']));

        $out['limit_list'] = $this->number($in, 'limit_list', 100, 50000, $errors);
        $out['limit_scan'] = $this->number($in, 'limit_scan', 1000, 1000000, $errors);
        $out['edit_mb'] = $this->number($in, 'edit_mb', 1, 20, $errors);
        $out['upload_mb'] = $this->number($in, 'upload_mb', 1, 2048, $errors);
        $out['preview_items'] = $this->number($in, 'preview_items', 10, 1000, $errors);
        $out['command_timeout'] = $this->number($in, 'command_timeout', 10, 3600, $errors);
        $out['no_time_limit'] = !empty($in['no_time_limit']);

        $out['username'] = $text('username');
        if (!preg_match('/^[A-Za-z0-9._@-]{3,64}$/', $out['username'])) {
            $errors['username'] = 'Nama pengguna 3 sampai 64 karakter, berisi huruf, angka, titik, garis bawah, tanda hubung, atau @.';
        }
        $password = (string) (isset($in['new_password']) ? $in['new_password'] : '');
        $confirmation = (string) (isset($in['new_password_confirm']) ? $in['new_password_confirm'] : '');
        if ($password !== '') {
            // bcrypt ignores everything after 72 bytes.
            if (strlen($password) < 8 || strlen($password) > 72) {
                $errors['new_password'] = 'Kata sandi baru 8 sampai 72 karakter.';
            } elseif (!hash_equals($password, $confirmation)) {
                $errors['new_password_confirm'] = 'Konfirmasi kata sandi tidak sama.';
            }
        }

        if ($errors) {
            throw HttpException::validation($errors);
        }
        return $out;
    }

    private function number(array $in, $key, $min, $max, array &$errors)
    {
        $value = isset($in[$key]) && is_scalar($in[$key]) ? trim((string) $in[$key]) : '';
        if (!ctype_digit($value) || (int) $value < $min || (int) $value > $max) {
            $errors[$key] = 'Isi angka ' . number_format($min, 0, ',', '.') . ' sampai ' . number_format($max, 0, ',', '.') . '.';
            return $min;
        }
        return (int) $value;
    }

    /**
     * Accepts a list or text with one value per line (and, for $commas, separated by commas or spaces).
     *
     * @return string[]
     */
    private function lines($value, $commas = false)
    {
        $items = is_array($value) ? $value : preg_split($commas ? '/[\s,]+/' : '/\R/', (string) $value);
        $out = [];
        foreach ($items as $item) {
            if (is_scalar($item) && trim((string) $item) !== '') {
                $out[] = trim((string) $item);
            }
        }
        return $out;
    }

    /**
     * Writes a form value into the nested shape Config::merge expects.
     */
    private function put(array &$overrides, $key, $value)
    {
        $limits = ['limit_list' => 'list', 'limit_scan' => 'scan', 'edit_mb' => 'edit_bytes', 'upload_mb' => 'upload_bytes', 'preview_items' => 'preview_items'];
        if (isset($limits[$key])) {
            $overrides['limits'][$limits[$key]] = in_array($key, ['edit_mb', 'upload_mb'], true) ? $value * self::MB : $value;
            return;
        }
        if ($key === 'username') {
            $overrides['auth']['username'] = $value;
            return;
        }
        $overrides[$key] = $value;
    }

    /**
     * Stored overrides as form keys, used to mark changed fields.
     */
    private function flatten(array $stored)
    {
        $out = [];
        $limits = ['list' => 'limit_list', 'scan' => 'limit_scan', 'edit_bytes' => 'edit_mb', 'upload_bytes' => 'upload_mb', 'preview_items' => 'preview_items'];
        foreach ($stored as $key => $value) {
            if ($key === 'limits' && is_array($value)) {
                foreach ($value as $limit => $unused) {
                    if (isset($limits[$limit])) {
                        $out[$limits[$limit]] = true;
                    }
                }
            } elseif ($key === 'auth' && is_array($value)) {
                if (isset($value['username'])) {
                    $out['username'] = true;
                }
            } elseif (array_key_exists($key, self::LABELS)) {
                $out[$key] = true;
            }
        }
        return $out;
    }
}
