<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Service;

use App\Fs\NativeFs;
use App\Fs\PathGuard;
use App\Http\HttpException;
use App\Http\Request;
use App\Security\Auth;
use App\Storage\DataStore;
use App\Support\Config;
use App\Support\Random;
use App\Support\Validate;
use App\System\Runner;
use App\System\Shell;
use Exception;
use RuntimeException;
use ZipArchive;

/**
 * Updates the application from a .zip package, uploaded from the browser or
 * downloaded from update_url, without git. A package is checked and extracted to storage first;
 * installing copies the checked files over the application, removes files
 * the new version no longer has, verifies every written file against its
 * hash, and restores a backup taken just before when any step fails.
 *
 * Packages made by bundle() carry a manifest with the SHA-256 of every file,
 * which lets the check prove that nothing is missing, changed, or added.
 */
final class UpdateService
{
    const DIR = 'updates';
    const STATE = 'updates/state.php';
    const MANIFEST = 'fm-manifest.json';
    // Manifest name used by packages and backups made before the rename; still read so they can be installed and restored.
    const LEGACY_MANIFEST = 'fpm-manifest.json';
    // Written into every manifest and checked on install, so it keeps the application's former name:
    // changing it would make packages from older versions unrecognisable, and the reverse.
    const APP_ID = 'file-permission-manager';
    // Start of the download name of a package built on the update page.
    const PACKAGE_NAME = 'file-manager';
    const MAX_ENTRIES = 20000;
    const MAX_BYTES = 314572800;
    const KEEP_BACKUPS = 5;
    const CHANGE_LIST_LIMIT = 1000;

    // Never bundled, never taken from a package, never deleted: server configuration,
    // runtime data, and local development folders.
    const PROTECTED_PATHS = ['config/app.php', 'storage', '.git', 'node_modules', 'vendor', '.claude', '.impeccable'];

    // Development-only files (see README, Pengembangan): the server does not need them, so they are
    // ignored the same way.
    const DEV_PATHS = ['resources', 'tools', 'package.json', 'package-lock.json', 'tailwind.config.js', 'README.md', 'CLAUDE.md', '.gitignore', '.gitattributes'];

    // Folders whose files missing from a package are kept, because they may hold server-side files
    // such as a copy of config/app.php.
    const KEEP_EXTRA_IN = ['config'];

    const JUNK_NAMES = ['.ds_store', 'thumbs.db', 'desktop.ini'];

    // A package must contain these to be recognised as this application. The update page and this
    // service are included so an installed version can always install the next one.
    const REQUIRED = [
        'index.php',
        '.htaccess',
        'config/app.example.php',
        'src/bootstrap.php',
        'src/Controller/PageController.php',
        'src/Controller/UpdateController.php',
        'src/Service/UpdateService.php',
        'src/Security/Auth.php',
        'src/Storage/DataStore.php',
        'views/layout.php',
        'views/pages/updates.php',
        'assets/app.css',
        'assets/js/core.js',
        'assets/js/updates.js',
        'assets/vendor/alpine.min.js',
    ];

    /**
     * Staged package (with its comparison against the installed files) and the backups.
     */
    public function status()
    {
        $state = DataStore::readJson(self::STATE);
        $staged = null;
        if ($state) {
            $staged = $state;
            unset($staged['files']);
            $staged['changes'] = !empty($state['files']) ? $this->publicDiff($this->diff($state['files'])) : null;
        }
        return [
            'zip' => class_exists('ZipArchive'),
            'bundle' => self::local(),
            'upload_bytes' => Config::int('limits.upload_bytes', 52428800),
            'update_url' => self::updateUrl(),
            'fetch' => self::canFetch(),
            'staged' => $staged,
            'backups' => $this->backups(),
        ];
    }

    /**
     * Builds a package of the installed application and returns its path and download name.
     * The caller deletes the file after sending it.
     */
    public function bundle($user)
    {
        if (!self::local()) {
            throw new HttpException(403, 'Paket hanya dapat dibuat di komputer lokal. Server ini memakai environment production di config/app.php.');
        }
        $this->requireZip();
        $this->ensureDirs();
        $name = self::PACKAGE_NAME . '-' . gmdate('Ymd-His') . '.zip';
        $path = $this->dir('tmp-' . Random::hex(6) . '.zip');
        $this->writePackage($path, $this->appFiles(), $user, 'Paket dibuat dari halaman Pembaruan');
        return ['path' => $path, 'name' => $name];
    }

    /**
     * Stores an uploaded package and checks it.
     */
    public function upload($file, $user)
    {
        $this->requireZip();
        if (!is_array($file) || !isset($file['error'])) {
            throw HttpException::validation(['package' => 'Tidak ada berkas yang diterima. Ukuran berkas mungkin melebihi batas server (post_max_size).']);
        }
        if ((int) $file['error'] === UPLOAD_ERR_INI_SIZE || (int) $file['error'] === UPLOAD_ERR_FORM_SIZE) {
            throw HttpException::validation(['package' => 'Ukuran berkas melebihi batas unggahan server (upload_max_filesize).']);
        }
        if ((int) $file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file((string) $file['tmp_name'])) {
            throw HttpException::validation(['package' => 'Berkas gagal diunggah. Coba unggah kembali.']);
        }
        $name = (string) $file['name'];
        if (strtolower(substr($name, -4)) !== '.zip') {
            throw HttpException::validation(['package' => 'Paket pembaruan harus berupa berkas .zip.']);
        }
        $max = Config::int('limits.upload_bytes', 52428800);
        if ((int) $file['size'] > $max) {
            throw HttpException::validation(['package' => 'Ukuran berkas melebihi batas unggahan aplikasi (' . number_format($max / 1048576, 0, ',', '.') . ' MB).']);
        }
        $this->discard();
        $this->ensureDirs();
        if (!move_uploaded_file((string) $file['tmp_name'], $this->dir('package.zip'))) {
            throw new RuntimeException('Berkas unggahan tidak dapat dipindahkan ke folder storage/updates.');
        }
        return $this->stage(basename(str_replace('\\', '/', $name)), 'upload', $user);
    }

    /**
     * Downloads the package from update_url and checks it, the same way as an upload.
     */
    public function download($user)
    {
        $this->requireZip();
        $url = self::updateUrl();
        if ($url === '') {
            throw new HttpException(409, 'URL pembaruan belum diatur. Isi URL pembaruan di halaman Pengaturan.');
        }
        if (!Validate::httpUrl($url)) {
            throw new HttpException(422, 'URL pembaruan tidak valid. Gunakan alamat lengkap yang diawali http:// atau https://.');
        }
        if (!self::canFetch()) {
            throw new HttpException(501, 'Server ini tidak dapat mengunduh berkas. Aktifkan ekstensi PHP curl atau allow_url_fopen di php.ini.');
        }
        $this->ensureDirs();
        // Downloaded beside the staged package, so a failed download leaves the package already checked in place.
        $temp = $this->dir('download.tmp');
        try {
            $this->fetch($url, $temp, Config::int('limits.upload_bytes', 52428800));
        } catch (Exception $e) {
            if (is_file($temp)) {
                unlink($temp);
            }
            throw $e;
        }
        $this->discard();
        if (!rename($temp, $this->dir('package.zip'))) {
            throw new RuntimeException('Paket unduhan tidak dapat dipindahkan di folder storage/updates.');
        }
        $name = basename((string) parse_url($url, PHP_URL_PATH));
        return $this->stage(strtolower(substr($name, -4)) === '.zip' ? $name : 'paket-unduhan.zip', 'download', $user);
    }

    /**
     * Stages one of the backups as a package, so restoring it goes through the same checks and preview.
     */
    public function stageBackup($id, $user)
    {
        $this->requireZip();
        $file = $this->backupFile($id);
        $this->discard();
        $this->ensureDirs();
        if (!copy($file, $this->dir('package.zip'))) {
            throw new RuntimeException('Cadangan tidak dapat disalin ke folder storage/updates.');
        }
        return $this->stage($id . '.zip', 'backup', $user);
    }

    public function discard()
    {
        $this->removeTree($this->dir('staging'));
        if (is_file($this->dir('package.zip'))) {
            unlink($this->dir('package.zip'));
        }
        DataStore::delete(self::STATE);
    }

    /**
     * Installs the staged package after the current password is confirmed.
     *
     * @return array counts of the applied changes and the backup name
     */
    public function install(array $input, Request $request, $user)
    {
        $state = DataStore::readJson(self::STATE);
        if (!$state) {
            throw new HttpException(409, 'Belum ada paket yang diperiksa. Unggah paket pembaruan terlebih dahulu.');
        }
        if (empty($state['installable'])) {
            throw new HttpException(422, 'Paket tidak lolos pemeriksaan sehingga tidak dapat dipasang.');
        }
        $password = (string) (isset($input['current_password']) ? $input['current_password'] : '');
        if ($password === '') {
            throw HttpException::validation(['current_password' => 'Masukkan kata sandi saat ini untuk memasang pembaruan.']);
        }
        if (!Auth::confirmPassword($request, $password)) {
            throw HttpException::validation(['current_password' => 'Kata sandi saat ini salah.']);
        }

        $this->ensureDirs();
        $lock = fopen($this->dir('install.lock'), 'c');
        if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
            throw new HttpException(409, 'Pemasangan lain sedang berjalan. Tunggu hingga selesai, lalu muat ulang halaman ini.');
        }
        try {
            return $this->installLocked($state, $user);
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    private function installLocked(array $state, $user)
    {
        $files = $state['files'];
        $staging = $this->dir('staging');
        // The staged copy is what the preview described; a change in between means it is no longer trusted.
        foreach ($files as $rel => $hash) {
            if (!is_file($staging . '/' . $rel) || hash_file('sha256', $staging . '/' . $rel) !== $hash) {
                throw new HttpException(409, 'Berkas paket di storage/updates berubah setelah diperiksa. Unggah paket kembali.');
            }
        }
        $diff = $this->diff($files);
        $blocked = Runner::sudo() ? [] : $this->unwritable($diff);
        if ($blocked) {
            throw new HttpException(422, 'Berkas atau folder berikut tidak dapat ditulisi oleh PHP: ' . implode(', ', array_slice($blocked, 0, 5)) . '.');
        }
        if (!$diff['added'] && !$diff['changed'] && !$diff['deleted']) {
            $this->discard();
            return ['added' => 0, 'changed' => 0, 'deleted' => 0, 'backup' => null];
        }

        // Classes used after the copy are loaded now, so this request never mixes old and new code.
        class_exists(HistoryService::class);
        class_exists(\App\Http\Response::class);

        $backup = 'backup-' . gmdate('Ymd-His') . '-' . Random::hex(3);
        $this->writePackage($this->dir('backups/' . $backup . '.zip'), $this->appFiles(), $user, 'Cadangan sebelum memasang ' . $state['name']);

        $root = $this->appRoot();
        $failure = null;
        try {
            foreach (array_merge($diff['added'], $diff['changed']) as $rel) {
                $this->copyVerified($staging . '/' . $rel, $root . '/' . $rel, $files[$rel]);
            }
            foreach ($diff['deleted'] as $rel) {
                $this->deleteFile($root . '/' . $rel);
            }
            $this->removeEmptyParents($diff['deleted']);
        } catch (Exception $e) {
            $failure = $e;
        } catch (\Throwable $e) {
            // PHP 7+ engine errors; PHP 5.6 has no Throwable and never reaches this branch.
            $failure = $e;
        }
        if ($failure !== null) {
            $restored = $this->restore($backup, $diff['added']);
            $reason = rtrim($failure->getMessage(), '.') . '.';
            (new HistoryService())->event($user, 'update_install', 'Pembaruan dari paket ' . $state['name'] . ' gagal: ' . $reason . ($restored ? ' Versi sebelumnya dipulihkan.' : ' Pemulihan otomatis gagal.'), false);
            if (!$restored) {
                throw new HttpException(500, 'Pembaruan gagal dan pemulihan otomatis juga gagal. Ekstrak storage/updates/backups/' . $backup . '.zip ke folder aplikasi secara manual. Penyebab: ' . $reason);
            }
            throw new HttpException(500, 'Pembaruan gagal dan versi sebelumnya sudah dipulihkan. Penyebab: ' . $reason);
        }

        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }
        $this->discard();
        $this->pruneBackups();
        $summary = count($diff['added']) . ' berkas baru, ' . count($diff['changed']) . ' diubah, ' . count($diff['deleted']) . ' dihapus';
        (new HistoryService())->event($user, 'update_install', 'Memasang pembaruan dari paket ' . $state['name'] . ': ' . $summary . '. Cadangan: ' . $backup . '.zip');
        return ['added' => count($diff['added']), 'changed' => count($diff['changed']), 'deleted' => count($diff['deleted']), 'backup' => $backup];
    }

    /**
     * Runs every check on storage/updates/package.zip, extracts it to storage/updates/staging
     * when the archive itself is sound, and saves the result as the staged state.
     */
    private function stage($name, $origin, $user)
    {
        $package = $this->dir('package.zip');
        $checks = [];
        $state = [
            'id' => Random::hex(8),
            'name' => $name,
            'origin' => $origin,
            'size' => (int) filesize($package),
            'sha256' => hash_file('sha256', $package),
            'uploaded_at' => gmdate('c'),
            'uploaded_by' => (string) $user,
            'manifest' => null,
            'skipped' => 0,
            'installable' => false,
            'checks' => [],
            'files' => [],
        ];

        $zip = new ZipArchive();
        if ($zip->open($package) !== true) {
            $checks[] = $this->check('archive', 'fail', 'Arsip zip dapat dibaca', 'Berkas bukan arsip zip atau rusak.');
            return $this->saveState($state, $checks);
        }
        $checks[] = $this->check('archive', 'ok', 'Arsip zip dapat dibaca', number_format($zip->numFiles, 0, ',', '.') . ' entri.');

        try {
            $entries = $this->readEntries($zip, $checks);
            if ($entries === null) {
                return $this->saveState($state, $checks);
            }
            $manifest = $this->readManifest($zip, $entries['manifest']);
            $state['skipped'] = $entries['skipped'];
            $files = $this->extract($zip, $entries['files'], $checks);
            if ($files === null) {
                return $this->saveState($state, $checks);
            }
        } finally {
            $zip->close();
        }
        $state['files'] = $files;
        $checks[] = $this->manifestCheck($manifest, $files);
        if (is_array($manifest)) {
            $state['manifest'] = [
                'created_at' => isset($manifest['created_at']) ? (string) $manifest['created_at'] : '',
                'created_by' => isset($manifest['created_by']) ? (string) $manifest['created_by'] : '',
                'note' => isset($manifest['note']) ? (string) $manifest['note'] : '',
            ];
        }
        $checks[] = $this->syntaxCheck(array_keys($files));
        if (Runner::sudo()) {
            $checks[] = $this->sudoCheck();
            return $this->saveState($state, $checks);
        }
        $blocked = $this->unwritable($this->diff($files));
        $checks[] = $blocked
            ? $this->check('writable', 'fail', 'Folder aplikasi dapat ditulisi', 'Tidak dapat ditulisi oleh PHP: ' . implode(', ', array_slice($blocked, 0, 5)) . (count($blocked) > 5 ? ', dan ' . (count($blocked) - 5) . ' lainnya' : '') . '.')
            : $this->check('writable', 'ok', 'Folder aplikasi dapat ditulisi', 'Semua berkas yang akan diubah dapat ditulisi oleh PHP.');
        return $this->saveState($state, $checks);
    }

    /**
     * Lists the members, rejecting unsafe paths, symlinks, and archives above the size limits,
     * and finds the application folder inside the archive.
     *
     * @return array|null ['files' => [relative => member name], 'manifest' => member name or null, 'skipped' => count]
     */
    private function readEntries(ZipArchive $zip, array &$checks)
    {
        $names = [];
        $unsafe = [];
        $bytes = 0;
        if ($zip->numFiles > self::MAX_ENTRIES) {
            $checks[] = $this->check('limits', 'fail', 'Ukuran dan jumlah berkas dalam batas', 'Arsip berisi lebih dari ' . number_format(self::MAX_ENTRIES, 0, ',', '.') . ' entri.');
            return null;
        }
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            if (!is_array($stat)) {
                continue;
            }
            $original = (string) $stat['name'];
            $name = str_replace('\\', '/', $original);
            if (substr($name, -1) === '/' || strpos($name, '__MACOSX/') === 0) {
                continue;
            }
            if (strpos($name, "\0") !== false || !NativeFs::safeMember($name) || $this->isSymlink($zip, $i)) {
                $unsafe[] = $name;
                continue;
            }
            $bytes += (int) $stat['size'];
            // Archives made on Windows may use backslashes; the original name is still needed to read the member.
            $names[$name] = $original;
        }
        if ($bytes > self::MAX_BYTES) {
            $checks[] = $this->check('limits', 'fail', 'Ukuran dan jumlah berkas dalam batas', 'Isi arsip setelah diekstrak lebih dari ' . number_format(self::MAX_BYTES / 1048576, 0, ',', '.') . ' MB.');
            return null;
        }
        $checks[] = $this->check('limits', 'ok', 'Ukuran dan jumlah berkas dalam batas', number_format($bytes / 1048576, 1, ',', '.') . ' MB setelah diekstrak, di bawah batas ' . number_format(self::MAX_BYTES / 1048576, 0, ',', '.') . ' MB dan ' . number_format(self::MAX_ENTRIES, 0, ',', '.') . ' entri.');
        if ($unsafe) {
            $checks[] = $this->check('paths', 'fail', 'Semua path aman', 'Path absolut, berisi "..", symlink, atau nama yang tidak valid: ' . implode(', ', array_slice($unsafe, 0, 5)) . '.');
            return null;
        }
        $checks[] = $this->check('paths', 'ok', 'Semua path aman', 'Tidak ada path absolut, "..", atau symlink.');

        // The application folder is the one holding src/bootstrap.php next to index.php: the archive root,
        // or a single wrapper folder such as the one a repository download adds.
        $prefixes = [];
        foreach (array_keys($names) as $name) {
            if (substr($name, -17) === 'src/bootstrap.php') {
                $prefix = substr($name, 0, -17);
                $folder = $prefix === '' || (substr($prefix, -1) === '/' && substr_count($prefix, '/') === 1);
                if ($folder && isset($names[$prefix . 'index.php'])) {
                    $prefixes[] = $prefix;
                }
            }
        }
        if (count($prefixes) !== 1) {
            $checks[] = $this->check('structure', 'fail', 'Struktur folder aplikasi lengkap', count($prefixes)
                ? 'Arsip berisi lebih dari satu folder aplikasi. Unggah paket yang berisi satu aplikasi saja.'
                : 'Folder aplikasi tidak ditemukan. Paket harus berisi index.php dan src/bootstrap.php, langsung di akar arsip atau di dalam satu folder.');
            return null;
        }
        $prefix = $prefixes[0];
        $files = [];
        $outside = [];
        $skipped = 0;
        $manifest = null;
        $seen = [];
        foreach ($names as $name => $original) {
            if ($prefix !== '' && strpos($name, $prefix) !== 0) {
                $outside[] = $name;
                continue;
            }
            $rel = substr($name, strlen($prefix));
            if ($rel === self::MANIFEST || $rel === self::LEGACY_MANIFEST) {
                if ($manifest === null || $rel === self::MANIFEST) {
                    $manifest = $original;
                }
                continue;
            }
            if ($this->isProtected($rel) || $this->isJunk($rel)) {
                $skipped++;
                continue;
            }
            // Two members that differ only in letter case would overwrite each other on Windows.
            $key = Runner::isWindows() ? strtolower($rel) : $rel;
            if (isset($seen[$key])) {
                $outside[] = $name;
                continue;
            }
            $seen[$key] = true;
            $files[$rel] = $original;
        }
        $missing = array_values(array_filter(self::REQUIRED, function ($rel) use ($files) {
            return !isset($files[$rel]);
        }));
        if ($outside || $missing) {
            $detail = $missing ? 'Berkas wajib tidak ada: ' . implode(', ', array_slice($missing, 0, 8)) . (count($missing) > 8 ? ', dan ' . (count($missing) - 8) . ' lainnya' : '') . '. ' : '';
            $detail .= $outside ? 'Berkas di luar folder aplikasi atau ganda: ' . implode(', ', array_slice($outside, 0, 5)) . '.' : '';
            $checks[] = $this->check('structure', 'fail', 'Struktur folder aplikasi lengkap', trim($detail));
            return null;
        }
        $checks[] = $this->check('structure', 'ok', 'Struktur folder aplikasi lengkap', ($prefix === '' ? 'Aplikasi berada di akar arsip.' : 'Aplikasi berada di folder ' . rtrim($prefix, '/') . '.') . ' Semua ' . count(self::REQUIRED) . ' berkas wajib ada.' . ($skipped ? ' ' . $skipped . ' berkas konfigurasi server, data, atau berkas pengembangan dilewati.' : ''));
        return ['files' => $files, 'manifest' => $manifest, 'skipped' => $skipped];
    }

    /**
     * Extracts the application files to storage/updates/staging and hashes them on the way.
     *
     * @return array|null [relative => sha256]
     */
    private function extract(ZipArchive $zip, array $members, array &$checks)
    {
        $staging = $this->dir('staging');
        $this->removeTree($staging);
        $hashes = [];
        $total = 0;
        foreach ($members as $rel => $name) {
            $target = $staging . '/' . $rel;
            $dir = dirname($target);
            if (!is_dir($dir) && !@mkdir($dir, 0770, true) && !is_dir($dir)) {
                throw new RuntimeException('Folder staging tidak dapat dibuat: ' . $dir);
            }
            $in = $zip->getStream($name);
            $out = @fopen($target, 'wb');
            if ($in === false || $out === false) {
                if ($out !== false) {
                    fclose($out);
                }
                $checks[] = $this->check('extract', 'fail', 'Semua berkas dapat diekstrak', 'Berkas tidak dapat dibaca dari arsip: ' . $rel . '.');
                return null;
            }
            $context = hash_init('sha256');
            while (!feof($in)) {
                $chunk = fread($in, 65536);
                if ($chunk === false) {
                    break;
                }
                $total += strlen($chunk);
                // The sizes in the archive directory can be forged, so the limit is enforced on the real bytes too.
                if ($total > self::MAX_BYTES) {
                    fclose($in);
                    fclose($out);
                    $checks[] = $this->check('extract', 'fail', 'Semua berkas dapat diekstrak', 'Isi arsip melebihi ' . number_format(self::MAX_BYTES / 1048576, 0, ',', '.') . ' MB saat diekstrak.');
                    return null;
                }
                hash_update($context, $chunk);
                fwrite($out, $chunk);
            }
            fclose($in);
            fclose($out);
            $hashes[$rel] = hash_final($context);
        }
        ksort($hashes);
        return $hashes;
    }

    private function readManifest(ZipArchive $zip, $member)
    {
        if ($member === null) {
            return null;
        }
        $raw = $zip->getFromName($member);
        $data = is_string($raw) ? json_decode($raw, true) : null;
        return is_array($data) ? $data : false;
    }

    private function manifestCheck($manifest, array $files)
    {
        $label = 'Integritas berkas sesuai manifest';
        if ($manifest === null) {
            return $this->check('manifest', 'warn', $label, 'Paket tidak memiliki manifest, sehingga hanya struktur dan sintaks yang diperiksa. Paket dari tombol Buat Paket selalu memiliki manifest.');
        }
        if ($manifest === false || !isset($manifest['app'], $manifest['files']) || $manifest['app'] !== self::APP_ID || !is_array($manifest['files'])) {
            return $this->check('manifest', 'fail', $label, 'Manifest rusak atau bukan milik aplikasi ini.');
        }
        $expected = [];
        foreach ($manifest['files'] as $rel => $hash) {
            if (!$this->isProtected((string) $rel)) {
                $expected[(string) $rel] = (string) $hash;
            }
        }
        $missing = array_keys(array_diff_key($expected, $files));
        $extra = array_keys(array_diff_key($files, $expected));
        $changed = [];
        foreach (array_intersect_key($files, $expected) as $rel => $hash) {
            if (!hash_equals($expected[$rel], $hash)) {
                $changed[] = $rel;
            }
        }
        if ($missing || $extra || $changed) {
            $parts = [];
            if ($missing) {
                $parts[] = 'Berkas hilang: ' . implode(', ', array_slice($missing, 0, 5));
            }
            if ($changed) {
                $parts[] = 'Isi berkas berbeda dari manifest: ' . implode(', ', array_slice($changed, 0, 5));
            }
            if ($extra) {
                $parts[] = 'Berkas tidak tercatat di manifest: ' . implode(', ', array_slice($extra, 0, 5));
            }
            return $this->check('manifest', 'fail', $label, implode('. ', $parts) . '.');
        }
        return $this->check('manifest', 'ok', $label, 'Hash SHA-256 dari ' . number_format(count($files), 0, ',', '.') . ' berkas cocok dengan manifest.');
    }

    private function syntaxCheck(array $rels)
    {
        $label = 'Sintaks PHP valid';
        $php = array_values(array_filter($rels, function ($rel) {
            return strtolower(substr($rel, -4)) === '.php';
        }));
        if (!defined('TOKEN_PARSE')) {
            return $this->check('syntax', 'warn', $label, 'Pemeriksaan sintaks membutuhkan PHP 7 atau lebih baru. Server ini memakai PHP ' . PHP_VERSION . '.');
        }
        $errors = [];
        foreach ($php as $rel) {
            try {
                token_get_all((string) file_get_contents($this->dir('staging/' . $rel)), TOKEN_PARSE);
            } catch (\ParseError $e) {
                $errors[] = $rel . ' baris ' . $e->getLine() . ': ' . $e->getMessage();
            }
        }
        if ($errors) {
            return $this->check('syntax', 'fail', $label, 'Kesalahan sintaks untuk PHP ' . PHP_VERSION . ': ' . implode('; ', array_slice($errors, 0, 3)) . (count($errors) > 3 ? '; dan ' . (count($errors) - 3) . ' berkas lainnya' : '') . '.');
        }
        return $this->check('syntax', 'ok', $label, number_format(count($php), 0, ',', '.') . ' berkas PHP dapat dibaca oleh PHP ' . PHP_VERSION . '.');
    }

    private function saveState(array $state, array $checks)
    {
        $state['checks'] = $checks;
        $state['installable'] = (bool) $state['files'];
        foreach ($checks as $check) {
            if ($check['status'] === 'fail') {
                $state['installable'] = false;
            }
        }
        if (!$state['installable']) {
            $state['files'] = [];
            $this->removeTree($this->dir('staging'));
        }
        DataStore::mutateJson(self::STATE, function (array &$data) use ($state) {
            $data = $state;
        });
        return $this->status();
    }

    private function check($key, $status, $label, $detail)
    {
        return ['key' => $key, 'status' => $status, 'label' => $label, 'detail' => $detail];
    }

    /**
     * Compares package files with the installed application.
     *
     * @param array $files [relative => sha256]
     * @return array lists of relative paths: added, changed, deleted, and the unchanged count
     */
    private function diff(array $files)
    {
        $installed = $this->appFiles();
        $added = [];
        $changed = [];
        $same = 0;
        foreach ($files as $rel => $hash) {
            if (!isset($installed[$rel])) {
                $added[] = $rel;
            } elseif ($this->fileHash($installed[$rel]) !== $hash) {
                $changed[] = $rel;
            } else {
                $same++;
            }
        }
        // Old files are removed only inside folders the package also has, so unrelated files the server
        // keeps next to the application (at the top level, or in config/) are never touched.
        $folders = [];
        foreach (array_keys($files) as $rel) {
            $slash = strpos($rel, '/');
            if ($slash !== false) {
                $folders[substr($rel, 0, $slash)] = true;
            }
        }
        foreach (self::KEEP_EXTRA_IN as $folder) {
            unset($folders[$folder]);
        }
        $deleted = [];
        foreach (array_keys($installed) as $rel) {
            $slash = strpos($rel, '/');
            if ($slash !== false && isset($folders[substr($rel, 0, $slash)]) && !isset($files[$rel])) {
                $deleted[] = $rel;
            }
        }
        return ['added' => $added, 'changed' => $changed, 'deleted' => $deleted, 'same' => $same];
    }

    private function publicDiff(array $diff)
    {
        $items = [];
        foreach (['changed', 'added', 'deleted'] as $kind) {
            foreach ($diff[$kind] as $rel) {
                if (count($items) < self::CHANGE_LIST_LIMIT) {
                    $items[] = ['path' => $rel, 'kind' => $kind];
                }
            }
        }
        return [
            'added' => count($diff['added']),
            'changed' => count($diff['changed']),
            'deleted' => count($diff['deleted']),
            'same' => $diff['same'],
            'items' => $items,
            'capped' => count($diff['added']) + count($diff['changed']) + count($diff['deleted']) > count($items),
        ];
    }

    /**
     * @return string[] relative paths PHP cannot write, create, or delete
     */
    private function unwritable(array $diff)
    {
        $root = $this->appRoot();
        $blocked = [];
        foreach ($diff['changed'] as $rel) {
            if (!is_writable($root . '/' . $rel)) {
                $blocked[] = $rel;
            }
        }
        foreach ($diff['deleted'] as $rel) {
            if (!is_writable(dirname($root . '/' . $rel))) {
                $blocked[] = $rel;
            }
        }
        foreach ($diff['added'] as $rel) {
            // A new file whose path is already taken by a folder or a symlink cannot be written.
            if (file_exists($root . '/' . $rel) || is_link($root . '/' . $rel)) {
                $blocked[] = $rel;
                continue;
            }
            $dir = dirname($root . '/' . $rel);
            while (!is_dir($dir) && strlen($dir) > strlen($root)) {
                $dir = dirname($dir);
            }
            if (!is_writable($dir)) {
                $blocked[] = $rel;
            }
        }
        return $blocked;
    }

    /**
     * Copies a file over its installed counterpart and confirms the written bytes.
     */
    private function copyVerified($from, $to, $hash)
    {
        $this->putFile($from, $to);
        if ($this->fileHash($to) !== $hash) {
            throw new RuntimeException('Isi berkas setelah ditulis tidak sama dengan paket: ' . $this->relative($to));
        }
    }

    /**
     * Writes one application file. With sudo enabled the write runs as root, so an application folder
     * owned by another account (for example one uploaded over SSH) can still be updated; otherwise PHP
     * writes as its own account. Both copy into an existing file, which keeps its owner and mode. A new
     * file or folder made through sudo takes the owner and group of the folder that holds it, not root.
     */
    private function putFile($from, $to)
    {
        $dir = dirname($to);
        if (!Runner::sudo()) {
            if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
                throw new RuntimeException('Folder tidak dapat dibuat: ' . $this->relative($dir));
            }
            if (!@copy($from, $to)) {
                throw new RuntimeException('Berkas tidak dapat ditulis: ' . $this->relative($to));
            }
            clearstatcache(true, $to);
            return;
        }
        $commands = [];
        if (!is_dir($dir)) {
            // The highest missing folder, and the existing folder above it that lends its owner.
            $top = $dir;
            while (!is_dir(dirname($top))) {
                $top = dirname($top);
            }
            $commands[] = 'mkdir -p -- ' . Shell::quote($dir);
            $commands[] = 'chown -R --reference=' . Shell::quote(dirname($top)) . ' -- ' . Shell::quote($top);
        }
        $new = !file_exists($to);
        $commands[] = 'cp -- ' . Shell::quote($from) . ' ' . Shell::quote($to);
        if ($new) {
            $commands[] = 'chown --reference=' . Shell::quote($dir) . ' -- ' . Shell::quote($to);
        }
        $this->sudo(implode(' && ', $commands), 'Berkas tidak dapat ditulis: ' . $this->relative($to));
        clearstatcache(true, $to);
    }

    private function deleteFile($path)
    {
        if (Runner::sudo()) {
            $this->sudo('rm -f -- ' . Shell::quote($path), 'Berkas lama tidak dapat dihapus: ' . $this->relative($path));
        } elseif (!@unlink($path)) {
            throw new RuntimeException('Berkas lama tidak dapat dihapus: ' . $this->relative($path));
        }
        clearstatcache(true, $path);
    }

    /**
     * SHA-256 of an installed file. PHP reads it when it can; under sudo a file the PHP account cannot
     * read is hashed as root instead.
     */
    private function fileHash($path)
    {
        clearstatcache(true, $path);
        if (is_readable($path) || !Runner::sudo()) {
            return (string) @hash_file('sha256', $path);
        }
        $result = Runner::run('sha256sum -- ' . Shell::quote($path), null, 30);
        return $result->ok() ? strtolower(substr(trim($result->stdout), 0, 64)) : '';
    }

    /**
     * Writes $url to $target through curl, or through the PHP http wrapper when curl is missing.
     * Redirects are followed only over http and https, and the transfer stops above $max bytes.
     */
    private function fetch($url, $target, $max)
    {
        $out = fopen($target, 'wb');
        if ($out === false) {
            throw new RuntimeException('Berkas sementara tidak dapat dibuat di folder storage/updates.');
        }
        $size = 0;
        try {
            if (function_exists('curl_init')) {
                $curl = curl_init($url);
                curl_setopt_array($curl, [
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS => 5,
                    CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
                    CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
                    CURLOPT_FAILONERROR => true,
                    CURLOPT_CONNECTTIMEOUT => 20,
                    // A stalled transfer is dropped; a slow but moving one may take as long as it needs.
                    CURLOPT_LOW_SPEED_LIMIT => 1,
                    CURLOPT_LOW_SPEED_TIME => 60,
                    CURLOPT_USERAGENT => self::APP_ID . '-updater',
                    CURLOPT_WRITEFUNCTION => function ($curl, $data) use ($out, $max, &$size) {
                        $size += strlen($data);
                        return $size > $max ? 0 : fwrite($out, $data);
                    },
                ]);
                $ok = curl_exec($curl) !== false;
                $error = curl_error($curl);
                curl_close($curl);
            } else {
                $context = stream_context_create(['http' => ['follow_location' => 1, 'max_redirects' => 6, 'timeout' => 60, 'user_agent' => self::APP_ID . '-updater']]);
                // Checked on the next line: a refused connection or an HTTP error status returns false with a warning.
                $in = @fopen($url, 'rb', false, $context);
                $ok = $in !== false;
                $error = '';
                if (!$ok) {
                    $last = error_get_last();
                    $error = $last ? trim(preg_replace('/^.*?: /', '', $last['message'])) : '';
                } else {
                    $size = (int) stream_copy_to_stream($in, $out, $max + 1);
                    fclose($in);
                }
            }
        } finally {
            fclose($out);
        }
        if ($size > $max) {
            throw new HttpException(413, 'Ukuran paket di URL pembaruan melebihi batas unggahan aplikasi (' . number_format($max / 1048576, 0, ',', '.') . ' MB).');
        }
        if (!$ok) {
            throw new HttpException(502, 'Paket tidak dapat diunduh dari URL pembaruan' . ($error !== '' ? ': ' . $error : '') . '.');
        }
    }

    private static function updateUrl()
    {
        return trim((string) Config::get('update_url', ''));
    }

    private static function canFetch()
    {
        return function_exists('curl_init') || filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN);
    }

    private function sudo($command, $message)
    {
        $result = Runner::run($command, null, 60);
        if (!$result->ok()) {
            throw new RuntimeException($message . ' (' . trim(implode(' ', $result->errorLines(3))) . ')');
        }
    }

    /**
     * Under sudo every write runs as root, so the check is whether sudo runs without a password prompt.
     */
    private function sudoCheck()
    {
        $label = 'Folder aplikasi dapat ditulisi';
        $result = Runner::run('id -u', null, 10);
        if (!$result->ok() || trim($result->stdout) !== '0') {
            return $this->check('writable', 'fail', $label, 'Opsi sudo aktif, tetapi sudo tidak dapat dijalankan tanpa kata sandi. Periksa aturan NOPASSWD untuk akun PHP (lihat README).');
        }
        return $this->check('writable', 'ok', $label, 'Berkas ditulis lewat sudo sebagai root. Berkas dan folder baru mengikuti pemilik folder induknya.');
    }

    /**
     * Puts every file of a backup back and removes the files an interrupted install added.
     */
    private function restore($backup, array $added)
    {
        $zip = new ZipArchive();
        if ($zip->open($this->dir('backups/' . $backup . '.zip')) !== true) {
            return false;
        }
        $root = $this->appRoot();
        $ok = true;
        // Each member goes through a file in storage, so the restore writes the same way the install did.
        $temp = $this->dir('restore.tmp');
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = (string) $zip->getNameIndex($i);
            if ($name === self::MANIFEST || $name === self::LEGACY_MANIFEST || substr($name, -1) === '/') {
                continue;
            }
            $content = $zip->getFromIndex($i);
            try {
                if (!is_string($content) || @file_put_contents($temp, $content) === false) {
                    throw new RuntimeException('Cadangan tidak dapat dibaca: ' . $name);
                }
                $this->putFile($temp, $root . '/' . $name);
            } catch (Exception $e) {
                $ok = false;
            }
        }
        $zip->close();
        @unlink($temp);
        foreach ($added as $rel) {
            try {
                if (is_file($root . '/' . $rel)) {
                    $this->deleteFile($root . '/' . $rel);
                }
            } catch (Exception $e) {
                $ok = false;
            }
        }
        $this->removeEmptyParents($added);
        return $ok;
    }

    /**
     * Writes a package: the given files plus a manifest with the SHA-256 of each.
     *
     * @param array $files [relative => absolute path]
     */
    private function writePackage($path, array $files, $user, $note)
    {
        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Arsip tidak dapat dibuat: ' . $path);
        }
        $hashes = [];
        foreach ($files as $rel => $absolute) {
            if (!$zip->addFile($absolute, $rel)) {
                $zip->close();
                @unlink($path);
                throw new RuntimeException('Berkas tidak dapat ditambahkan ke arsip: ' . $rel);
            }
            $hashes[$rel] = hash_file('sha256', $absolute);
        }
        $manifest = [
            'format' => 1,
            'app' => self::APP_ID,
            'created_at' => gmdate('c'),
            'created_by' => (string) $user,
            'note' => $note,
            'files' => $hashes,
        ];
        $zip->addFromString(self::MANIFEST, json_encode($manifest, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
        if (!$zip->close()) {
            @unlink($path);
            throw new RuntimeException('Arsip tidak dapat ditulis: ' . $path);
        }
    }

    private function backups()
    {
        $items = [];
        foreach (glob($this->dir('backups/backup-*.zip')) ?: [] as $file) {
            $id = basename($file, '.zip');
            $items[] = ['id' => $id, 'size' => (int) filesize($file), 'created_at' => gmdate('c', (int) filemtime($file))];
        }
        usort($items, function ($a, $b) {
            return strcmp($b['id'], $a['id']);
        });
        return $items;
    }

    private function backupFile($id)
    {
        $id = (string) $id;
        if (!preg_match('/^backup-\d{8}-\d{6}-[a-f0-9]{6}$/', $id) || !is_file($this->dir('backups/' . $id . '.zip'))) {
            throw new HttpException(404, 'Cadangan tidak ditemukan.');
        }
        return $this->dir('backups/' . $id . '.zip');
    }

    private function pruneBackups()
    {
        foreach (array_slice($this->backups(), self::KEEP_BACKUPS) as $old) {
            @unlink($this->dir('backups/' . $old['id'] . '.zip'));
        }
    }

    /**
     * Installed application files, without protected folders, symlinks, and system junk.
     *
     * @return array [relative => absolute path]
     */
    private function appFiles()
    {
        $root = $this->appRoot();
        $files = [];
        $pending = [''];
        while ($pending) {
            $rel = array_pop($pending);
            $dir = $rel === '' ? $root : $root . '/' . $rel;
            $names = @scandir($dir);
            if ($names === false) {
                throw new RuntimeException('Folder aplikasi tidak dapat dibaca: ' . ($rel === '' ? '/' : $rel));
            }
            foreach ($names as $name) {
                if ($name === '.' || $name === '..') {
                    continue;
                }
                $child = $rel === '' ? $name : $rel . '/' . $name;
                $path = $root . '/' . $child;
                if ($this->isProtected($child) || $this->isJunk($child) || is_link($path)) {
                    continue;
                }
                if (is_dir($path)) {
                    $pending[] = $child;
                } elseif (is_file($path)) {
                    $files[$child] = $path;
                }
            }
        }
        ksort($files);
        return $files;
    }

    private function isProtected($rel)
    {
        $windows = Runner::isWindows();
        $rel = $windows ? strtolower($rel) : $rel;
        foreach ($this->protectedPaths() as $path) {
            $path = $windows ? strtolower($path) : $path;
            if ($rel === $path || strpos($rel, $path . '/') === 0) {
                return true;
            }
        }
        return false;
    }

    private function protectedPaths()
    {
        $paths = array_merge(self::PROTECTED_PATHS, self::DEV_PATHS);
        // storage_path may point elsewhere inside the application folder.
        $storage = realpath((string) Config::get('storage_path'));
        if ($storage !== false) {
            $storage = str_replace('\\', '/', $storage);
            $root = $this->appRoot();
            if (stripos($storage, $root . '/') === 0) {
                $paths[] = substr($storage, strlen($root) + 1);
            }
        }
        return $paths;
    }

    private function isJunk($rel)
    {
        return in_array(strtolower(basename($rel)), self::JUNK_NAMES, true);
    }

    /**
     * Unix symlinks keep the file type in the high bits of the external attributes.
     */
    private function isSymlink(ZipArchive $zip, $index)
    {
        if (!method_exists($zip, 'getExternalAttributesIndex')) {
            return false;
        }
        $system = 0;
        $attributes = 0;
        if (!$zip->getExternalAttributesIndex($index, $system, $attributes) || $system !== ZipArchive::OPSYS_UNIX) {
            return false;
        }
        return (($attributes >> 16) & 0170000) === 0120000;
    }

    private function removeEmptyParents(array $rels)
    {
        $root = $this->appRoot();
        $dirs = [];
        foreach ($rels as $rel) {
            for ($dir = dirname($rel); $dir !== '.' && $dir !== ''; $dir = dirname($dir)) {
                $dirs[$dir] = true;
            }
        }
        $dirs = array_keys($dirs);
        // Deepest first, so a folder emptied by removing its subfolder is removed too.
        usort($dirs, function ($a, $b) {
            return substr_count($b, '/') - substr_count($a, '/');
        });
        foreach ($dirs as $dir) {
            $names = @scandir($root . '/' . $dir);
            if (!is_array($names) || count($names) !== 2) {
                continue;
            }
            if (Runner::sudo()) {
                Runner::run('rmdir -- ' . Shell::quote($root . '/' . $dir), null, 10);
            } else {
                @rmdir($root . '/' . $dir);
            }
        }
    }

    /**
     * Deletes a folder under storage/updates recursively.
     */
    private function removeTree($path)
    {
        $base = $this->dir('');
        if (strpos(str_replace('\\', '/', $path), $base) !== 0 || !is_dir($path) || is_link($path)) {
            return;
        }
        foreach (scandir($path) ?: [] as $name) {
            if ($name === '.' || $name === '..') {
                continue;
            }
            $child = $path . '/' . $name;
            if (is_dir($child) && !is_link($child)) {
                $this->removeTree($child);
            } else {
                @unlink($child);
            }
        }
        @rmdir($path);
    }

    private function ensureDirs()
    {
        foreach (['', 'backups'] as $sub) {
            $dir = $this->dir($sub);
            if (!is_dir($dir) && !@mkdir($dir, 0770, true) && !is_dir($dir)) {
                throw new HttpException(500, 'Folder ' . $dir . ' tidak dapat dibuat. Pastikan folder storage dapat ditulisi oleh PHP.');
            }
        }
    }

    /**
     * Packages are built only on the local machine where the application is developed.
     */
    private static function local()
    {
        return Config::local();
    }

    private function requireZip()
    {
        if (!class_exists('ZipArchive')) {
            throw new HttpException(422, 'Ekstensi PHP zip tidak aktif, sehingga paket pembaruan tidak dapat dibuat atau dibaca.');
        }
    }

    private function dir($sub)
    {
        return str_replace('\\', '/', DataStore::path(self::DIR . '/' . $sub));
    }

    private function appRoot()
    {
        return rtrim(str_replace('\\', '/', PathGuard::appRoot()), '/');
    }

    private function relative($path)
    {
        return substr(str_replace('\\', '/', $path), strlen($this->appRoot()) + 1);
    }
}
