<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Controller;

use App\Http\Response;
use App\Service\UpdateService;

final class UpdateController extends Controller
{
    public function status()
    {
        Response::ok((new UpdateService())->status());
    }

    public function upload()
    {
        $file = isset($_FILES['package']) ? $_FILES['package'] : null;
        $status = (new UpdateService())->upload($file, $this->user());
        Response::ok($status, $status['staged']['installable'] ? 'Paket lolos pemeriksaan dan siap dipasang.' : 'Paket tidak lolos pemeriksaan.');
    }

    public function download()
    {
        $status = (new UpdateService())->download($this->user());
        Response::ok($status, $status['staged']['installable'] ? 'Paket lolos pemeriksaan dan siap dipasang.' : 'Paket tidak lolos pemeriksaan.');
    }

    public function stageBackup()
    {
        $status = (new UpdateService())->stageBackup($this->request->string('id'), $this->user());
        Response::ok($status, $status['staged']['installable'] ? 'Cadangan siap dipulihkan.' : 'Cadangan tidak lolos pemeriksaan.');
    }

    public function discard()
    {
        (new UpdateService())->discard();
        Response::ok(null, 'Paket dibatalkan dan dihapus dari server.');
    }

    public function install()
    {
        $result = (new UpdateService())->install($this->request->body(), $this->request, $this->user());
        if ($result['backup'] === null) {
            Response::ok($result, 'Tidak ada berkas yang berubah. Aplikasi sudah sama dengan paket.');
            return;
        }
        Response::ok($result, 'Pembaruan terpasang: ' . $result['added'] . ' berkas baru, ' . $result['changed'] . ' diubah, ' . $result['deleted'] . ' dihapus.');
    }

    public function bundle()
    {
        $package = (new UpdateService())->bundle($this->user());
        Response::downloadHeaders($package['name'], 'application/zip', filesize($package['path']));
        readfile($package['path']);
        unlink($package['path']);
    }
}
