<?php
/** @author Ertha Dwi Setiyawan */

namespace App\Support;

use App\Http\HttpException;

final class Validate
{
    /**
     * Octal permission mode (3 or 4 digits). Returns null for an empty optional value.
     */
    public static function mode($value, $field, $required = true)
    {
        $value = trim($value);
        if ($value === '') {
            if ($required) {
                throw HttpException::validation([$field => 'Mode izin wajib diisi.']);
            }
            return null;
        }
        if (!preg_match('/^0?[0-7]{3,4}$/', $value)) {
            throw HttpException::validation([$field => 'Mode izin harus berupa 3 atau 4 digit oktal, misalnya 0755.']);
        }
        return (int) octdec($value);
    }

    /**
     * Five-digit form so chmod also clears setuid/setgid on folders when the mode says so.
     */
    public static function chmodArg($mode)
    {
        return sprintf('%05o', $mode & 07777);
    }

    public static function principal($value, $field, $required = false)
    {
        $value = trim($value);
        if ($value === '') {
            if ($required) {
                throw HttpException::validation([$field => 'Wajib diisi.']);
            }
            return null;
        }
        if (strlen($value) > 64 || !preg_match('/^[A-Za-z0-9_][A-Za-z0-9._-]*\$?$/', $value)) {
            throw HttpException::validation([$field => 'Nama pengguna atau grup tidak valid.']);
        }
        return $value;
    }

    public static function text($value, $field, $max, $required = true)
    {
        $value = trim($value);
        if ($required && $value === '') {
            throw HttpException::validation([$field => 'Wajib diisi.']);
        }
        // preg_match_all counts UTF-8 characters without depending on the mbstring extension.
        if ((int) preg_match_all('/./us', $value) > $max) {
            throw HttpException::validation([$field => 'Maksimal ' . $max . ' karakter.']);
        }
        return $value;
    }

    /**
     * An absolute http or https address. Other schemes (file, ftp, php, data) are refused, so a
     * configured address can never make the server read a local file.
     */
    public static function httpUrl($value)
    {
        $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));
        return strlen($value) <= 2048
            && filter_var($value, FILTER_VALIDATE_URL) !== false
            && in_array($scheme, ['http', 'https'], true)
            && (string) parse_url($value, PHP_URL_HOST) !== '';
    }

    public static function oneOf($value, array $allowed, $default)
    {
        return in_array($value, $allowed, true) ? $value : $default;
    }
}
