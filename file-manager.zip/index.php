<?php
/** @author Ertha Dwi Setiyawan */

require __DIR__ . '/src/bootstrap.php';

use App\Controller\AnalysisController;
use App\Controller\AuditController;
use App\Controller\AuthController;
use App\Controller\FileController;
use App\Controller\HistoryController;
use App\Controller\MalwareController;
use App\Controller\OperationController;
use App\Controller\PageController;
use App\Controller\SettingsController;
use App\Controller\SnapshotController;
use App\Controller\UpdateController;
use App\Http\HttpException;
use App\Http\Request;
use App\Http\Response;
use App\Security\Auth;
use App\Storage\DataStore;
use App\Support\ErrorHandler;
use App\Support\Random;
use App\System\Runner;

// route => [HTTP method, controller, action, requires login]
$routes = [
    'login' => ['GET', PageController::class, 'login', false],
    '' => ['GET', PageController::class, 'explorer', true],
    'explorer' => ['GET', PageController::class, 'explorer', true],
    'editor' => ['GET', PageController::class, 'editor', true],
    'trash' => ['GET', PageController::class, 'trash', true],
    'snapshots' => ['GET', PageController::class, 'snapshots', true],
    'history' => ['GET', PageController::class, 'history', true],
    'audit' => ['GET', PageController::class, 'audit', true],
    'malware' => ['GET', PageController::class, 'malware', true],
    'ownership' => ['GET', PageController::class, 'ownership', true],
    'sizes' => ['GET', PageController::class, 'sizes', true],
    'webserver' => ['GET', PageController::class, 'webserver', true],
    'presets' => ['GET', PageController::class, 'presets', true],
    'policies' => ['GET', PageController::class, 'policies', true],
    'settings' => ['GET', PageController::class, 'settings', true],
    'updates' => ['GET', PageController::class, 'updates', true],

    'api/auth/login' => ['POST', AuthController::class, 'login', false],
    'api/auth/logout' => ['POST', AuthController::class, 'logout', true],
    'logout' => ['GET', AuthController::class, 'logoutPage', true],

    'api/system' => ['GET', FileController::class, 'system', true],
    'api/files' => ['GET', FileController::class, 'index', true],
    'api/folders' => ['GET', FileController::class, 'folders', true],
    'api/files/detail' => ['GET', FileController::class, 'detail', true],
    'api/files/content' => ['GET', FileController::class, 'content', true],
    'api/files/download' => ['GET', FileController::class, 'download', true],
    'api/files/preview' => ['GET', FileController::class, 'preview', true],
    'api/files/checksum' => ['GET', FileController::class, 'checksum', true],
    'api/files/search' => ['GET', FileController::class, 'search', true],
    'api/favorites' => ['GET', FileController::class, 'favorites', true],
    'api/favorites/save' => ['POST', FileController::class, 'saveFavorite', true],
    'api/favorites/delete' => ['POST', FileController::class, 'deleteFavorite', true],
    'api/files/upload' => ['POST', FileController::class, 'upload', true],
    'api/files/upload-check' => ['POST', FileController::class, 'uploadCheck', true],
    'api/files/upload-chunk' => ['POST', FileController::class, 'uploadChunk', true],
    'api/principals' => ['GET', FileController::class, 'principals', true],
    'api/trash' => ['GET', FileController::class, 'trash', true],

    'api/ops/preview' => ['POST', OperationController::class, 'preview', true],
    'api/ops/apply' => ['POST', OperationController::class, 'apply', true],

    'api/snapshots' => ['GET', SnapshotController::class, 'index', true],
    'api/snapshots/create' => ['POST', SnapshotController::class, 'create', true],
    'api/snapshots/delete' => ['POST', SnapshotController::class, 'delete', true],
    'api/snapshots/compare' => ['GET', SnapshotController::class, 'compare', true],

    'api/history' => ['GET', HistoryController::class, 'index', true],
    'api/history/export' => ['GET', HistoryController::class, 'export', true],

    'api/audit/run' => ['POST', AuditController::class, 'run', true],
    'api/audit/runs' => ['GET', AuditController::class, 'runs', true],
    'api/audit/findings' => ['GET', AuditController::class, 'findings', true],
    'api/audit/export' => ['GET', AuditController::class, 'export', true],

    'api/malware/run' => ['POST', MalwareController::class, 'run', true],
    'api/malware/runs' => ['GET', MalwareController::class, 'runs', true],
    'api/malware/findings' => ['GET', MalwareController::class, 'findings', true],
    'api/malware/inspect' => ['GET', MalwareController::class, 'inspect', true],

    'api/analysis/ownership' => ['GET', AnalysisController::class, 'ownership', true],
    'api/analysis/sizes' => ['GET', AnalysisController::class, 'sizes', true],
    'api/webserver/detect' => ['GET', AnalysisController::class, 'webserverDetect', true],
    'api/webserver/check' => ['GET', AnalysisController::class, 'webserverCheck', true],

    'api/presets' => ['GET', SettingsController::class, 'presets', true],
    'api/presets/save' => ['POST', SettingsController::class, 'savePreset', true],
    'api/presets/delete' => ['POST', SettingsController::class, 'deletePreset', true],
    'api/policies' => ['GET', SettingsController::class, 'policies', true],
    'api/policies/save' => ['POST', SettingsController::class, 'savePolicy', true],
    'api/policies/toggle' => ['POST', SettingsController::class, 'togglePolicy', true],
    'api/policies/delete' => ['POST', SettingsController::class, 'deletePolicy', true],

    'api/settings' => ['GET', SettingsController::class, 'app', true],
    'api/settings/save' => ['POST', SettingsController::class, 'saveApp', true],
    'api/settings/reset' => ['POST', SettingsController::class, 'resetApp', true],

    'api/updates' => ['GET', UpdateController::class, 'status', true],
    'api/updates/bundle' => ['GET', UpdateController::class, 'bundle', true],
    'api/updates/upload' => ['POST', UpdateController::class, 'upload', true],
    'api/updates/download' => ['POST', UpdateController::class, 'download', true],
    'api/updates/stage-backup' => ['POST', UpdateController::class, 'stageBackup', true],
    'api/updates/discard' => ['POST', UpdateController::class, 'discard', true],
    'api/updates/install' => ['POST', UpdateController::class, 'install', true],
];

$request = new Request();
$nonce = base64_encode(Random::bytes(16));
Response::securityHeaders($nonce);

try {
    Auth::assertIpAllowed($request);
    DataStore::ensureReady();
    Auth::startSession($request);

    $route = $request->route();
    if (!isset($routes[$route])) {
        throw new HttpException(404, 'Halaman tidak ditemukan.');
    }
    list($method, $class, $action, $needsLogin) = $routes[$route];
    if ($request->method() !== $method) {
        throw new HttpException(405, 'Metode permintaan tidak diizinkan.');
    }
    $user = null;
    if ($needsLogin) {
        $user = Auth::user();
        if ($user === null) {
            if (!$request->isApi()) {
                header('Location: ' . PageController::loginUrl());
                exit;
            }
            throw new HttpException(401, 'Sesi berakhir. Silakan masuk kembali.');
        }
    }
    if ($method === 'POST') {
        Auth::verifyOrigin($request);
        Auth::verifyCsrf($request);
    }
    // PHP locks the session file until the request ends, so one slow request (compress, copy, bulk
    // delete, scan, download) would stall every other request of the same user. Only the routes that
    // start, end, or clear the session keep it open; Auth::rename reopens it briefly for its one write.
    if (!in_array($route, ['login', 'api/auth/login', 'api/auth/logout', 'logout'], true)) {
        session_write_close();
    }
    // Compressing, copying, deleting, or uploading a large folder can outlast max_execution_time.
    if ($user !== null && $request->isApi() && Runner::noTimeLimit()) {
        Runner::liftTimeLimit($method === 'POST');
    }
    (new $class($request, $user, $nonce))->$action();
} catch (HttpException $e) {
    if ($request->isApi()) {
        Response::json($e->status(), $e->getMessage(), $e->errors() ? ['errors' => $e->errors()] : null);
    } else {
        PageController::errorPage($e->status(), $e->getMessage(), $nonce);
    }
} catch (Exception $e) {
    ErrorHandler::handle($e);
} catch (Throwable $e) {
    // PHP 7+ engine errors (TypeError, Error). PHP 5.6 has no Throwable, and never reaches this branch.
    ErrorHandler::handle($e);
}
