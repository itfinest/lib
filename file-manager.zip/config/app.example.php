<?php
/**
 * File Manager configuration.
 *
 * Copy this file to config/app.php and fill in auth.password_hash and roots.
 *
 * Every path the application touches must sit inside one of the "roots" below.
 * The folder holding this application is hidden from the tool while
 * protect_app_folder is on, so it cannot delete or lock itself out.
 */

return [
    'app_name' => 'File Manager',

    // Institution name sent to the active-user monitor as "app_name - instansi".
    // Empty sends app_name alone.
    'instansi' => '',

    // Login account. The password is stored as a bcrypt hash, never as plain
    // text. Login stays disabled until a hash is filled in. Create one with:
    //   php -r "echo password_hash('PasswordBaru', PASSWORD_DEFAULT), PHP_EOL;"
    'auth' => [
        'username' => 'admin',
        'password_hash' => '',
        // Optional recovery password, also a bcrypt hash. It is read from this file only:
        // the settings page can change the login above but never this one, so it still
        // signs in (with this username or the one set on the settings page) if someone
        // else changes the main password. Leave empty to disable.
        'recovery_password_hash' => '',
    ],

    // Absolute folders the tool may browse and modify. Default: the folder that
    // contains this application (for example /var/www/html when installed at
    // /var/www/html/filemanager). Replace with explicit paths in production.
    // On Windows use a drive letter, for example 'D:/laragon/www'.
    'roots' => [
        dirname(dirname(__DIR__)),
    ],

    // Folder opened first in the file manager and the analysis pages. Must sit
    // inside one of the roots; empty uses the first root.
    'default_path' => '',

    // Folder filled in as the destination when compressing. Must sit inside one
    // of the roots; empty keeps the archive next to the compressed items. The
    // compress dialog can still change it for each archive.
    'compress_path' => '',

    // Patterns filled in the Kecualikan field of the compress dialog, one entry per
    // pattern, with * and ? allowed (at most 50). A pattern without "/" matches a file
    // or folder name in every subfolder; one with "/" is a path relative to the folder
    // holding the compressed items. A matched folder is left out with all its
    // contents. The dialog can still change the list for each archive. Set an empty
    // list for no default exclusions; without this key the list below applies.
    'compress_exclude' => [
        'node_modules', 'vendor', '.git', '.svn', '.idea', '.vscode', '__pycache__',
        'cache', 'temp', 'tmp', 'sessions', '.DS_Store', 'Thumbs.db',
        '*.txt', '*.json', '*.log',
    ],

    // File or folder names (exact, any letter case) left out of the file manager and the
    // folder tree, like names starting with a dot, until Tampilkan tersembunyi is checked.
    // A hidden folder is not searched either. At most 100 names. Editable from the
    // settings page. Without this key only names starting with a dot are hidden.
    'hidden_names' => [
        'node_modules', 'vendor', '__pycache__', 'Thumbs.db', 'ehthumbs.db', 'desktop.ini',
        '$RECYCLE.BIN', 'System Volume Information',
    ],

    // Public web address of folders served by a web server, used for Salin Link and the
    // Link row in the detail panel. The server document root of this application is
    // mapped to the address it was opened with; add other sites here, for example
    // '/var/www/toko/public' => 'https://toko.example.com'. The longest matching folder
    // wins. Not editable from the settings page.
    'public_urls' => [],

    // 'production' on a server, 'local' on the machine where the application is developed. Only
    // local shows Buat Paket on the Pembaruan Aplikasi page, which packs the installed application
    // into an update package. Without this key the application counts as production. Not editable
    // from the settings page.
    'environment' => 'production',

    // Address of an update package (.zip) that the Pembaruan Aplikasi page downloads with
    // Unduh dan Periksa, instead of an upload from the browser. http or https only; use https so
    // the package cannot be changed on the way. The download goes through the same checks as an
    // upload and is limited by limits.upload_bytes. Editable from the settings page.
    'update_url' => '',

    // Show the technical detail of a server error (message, file, line, and call stack) on the
    // page and in API answers. Without this key it follows 'environment': on for local, off for
    // production. Turn it on for a server only while tracing a failure: the detail reveals server
    // paths. Every error is written to the PHP error log with a reference code either way. Not
    // editable from the settings page.
    // 'debug' => false,

    // Run every shell command through "sudo -n". Only enable this when a
    // NOPASSWD sudoers rule exists for the PHP user; see README.md. Linux only:
    // Windows never runs shell commands.
    'sudo' => false,

    // Minutes of inactivity before a session expires.
    'session_idle_minutes' => 30,

    // Hours after login before a session expires, even while it is in use.
    'session_max_hours' => 12,

    // End a session when a request arrives from an IP address other than the
    // one used to log in. Turn off only when users switch networks during work.
    'session_bind_ip' => true,

    // Addresses allowed to open the application, as single IPs or CIDR ranges
    // (for example '192.168.1.0/24'). Empty: every address may reach the login page.
    'allowed_ips' => [],

    // New files and folders (upload, create, rename, archive extraction) may not
    // use these extensions or names, so the tool cannot be used to plant a web
    // shell or change server configuration. The check covers every extension in
    // a name, so "shell.php.jpg" is refused too. Set an empty list to allow them.
    'blocked_extensions' => [
        'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'pht', 'phar', 'phps',
        'shtml', 'cgi', 'pl', 'asp', 'aspx', 'ashx', 'asmx', 'jsp', 'jspx', 'cfm',
    ],
    'blocked_names' => ['.htaccess', '.htpasswd', '.user.ini', 'php.ini', 'web.config'],

    // Keep the folder holding this application out of reach: it cannot be
    // opened or changed, and its parent folders cannot be deleted, moved, or
    // renamed. false treats it like any other folder, including the login
    // configuration and the change history in storage/.
    'protect_app_folder' => true,

    // Let long work (compress, extract, copy, move, delete, upload, save) run to the end:
    // max_execution_time is lifted for signed-in requests, a change keeps running when
    // the browser disconnects, and shell commands ignore command_timeout. The web server
    // can still end a request on its own timeout (Apache Timeout or ProxyTimeout, Nginx
    // fastcgi_read_timeout, PHP-FPM request_terminate_timeout); raise those separately.
    'no_time_limit' => true,

    // Maximum seconds a single shell command may run while no_time_limit is false.
    'command_timeout' => 120,

    'limits' => [
        // Entries read for one folder listing or recursive search.
        'list' => 5000,
        // Entries read by audit, ownership analysis, and snapshots; candidate files read by the malware scan.
        'scan' => 100000,
        // Largest file (bytes) the text editor opens.
        'edit_bytes' => 1048576,
        // Largest upload (bytes); PHP upload_max_filesize still applies.
        'upload_bytes' => 52428800,
        // Affected entries listed in a dry run.
        'preview_items' => 200,
    ],

    // Glob patterns (matched against the full path) where the web server user
    // is expected to write. Used by the web server check.
    'web_writable_patterns' => [
        '*/storage/*',
        '*/storage',
        '*/bootstrap/cache*',
        '*/uploads*',
        '*/cache*',
        '*/wp-content/uploads*',
    ],

    // Malware scan. hashes: MD5 of files confirmed as malicious, with a description; fill it in when an
    // incident leaves identical copies in many places, so every copy is found without relying on
    // content patterns. domains: parts of addresses (matched anywhere, any case) whose presence in a
    // PHP file is reported as contact with an unwanted outside host.
    'malware' => [
        'hashes' => [
            '1bee1b6fc204dddc61141784c47e8b2e' => 'Halaman blokir firewall sisa upaya penanaman backdoor.',
        ],
        'domains' => [],
    ],

    'storage_path' => dirname(__DIR__) . '/storage',
];
