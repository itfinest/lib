<?php
/** @author Ertha Dwi Setiyawan */
defined('APP_ROOT') || exit;
?>
<div x-data="updatesPage" class="flex flex-col gap-4">
  <div>
    <h1 class="font-display text-lg font-semibold">Pembaruan Aplikasi</h1>
    <p class="mt-1 text-sm text-muted">Perbarui aplikasi dengan mengunggah paket .zip atau mengunduhnya dari URL pembaruan. Paket diperiksa sebelum dipasang, dan cadangan versi saat ini dibuat otomatis. <code>config/app.php</code> dan folder <code>storage</code> tidak pernah diubah.</p>
  </div>

  <template x-if="phase === 'loading'">
    <div class="grid gap-4 lg:grid-cols-2" aria-busy="true" aria-label="Memuat halaman pembaruan">
      <template x-for="n in 2" :key="n">
        <div class="panel space-y-3 p-4"><span class="skeleton block h-3 w-40"></span><span class="skeleton block h-3 w-full"></span><span class="skeleton block h-10 w-48"></span></div>
      </template>
    </div>
  </template>

  <template x-if="phase === 'error'">
    <div class="panel flex flex-col items-center gap-2 px-4 py-12 text-center" role="alert">
      <?= $icon('circle-alert', 'icon-lg text-danger-700') ?>
      <p class="font-medium text-ink">Halaman pembaruan gagal dimuat</p>
      <p class="max-w-md text-sm text-muted" x-text="errorMessage"></p>
      <button type="button" class="btn-secondary mt-2" @click="load()"><?= $icon('refresh-cw') ?>Muat Ulang</button>
    </div>
  </template>

  <div x-show="phase === 'content'" x-cloak class="flex flex-col gap-4">
    <div class="panel flex gap-3 border-danger-600/40 bg-danger-50 p-4 text-sm text-danger-700" role="alert" x-show="!zip">
      <?= $icon('circle-alert', 'icon-lg') ?>
      <div>
        <p class="font-semibold">Ekstensi PHP zip tidak aktif</p>
        <p>Paket pembaruan tidak dapat dibuat atau dibaca. Aktifkan ekstensi <code>zip</code> di php.ini, lalu muat ulang halaman ini.</p>
      </div>
    </div>

    <div class="grid gap-4" :class="bundle && 'lg:grid-cols-2'">
      <section class="panel flex flex-col gap-3 p-4" aria-labelledby="upd-bundle" x-show="bundle">
        <h2 id="upd-bundle" class="panel-title">Buat paket</h2>
        <p class="text-sm text-body">Unduh aplikasi yang terpasang di server ini sebagai paket .zip, lengkap dengan manifest berisi hash SHA-256 setiap berkas. Unggah paket ini di halaman yang sama pada server lain untuk memperbaruinya.</p>
        <p class="text-xs text-muted">Tidak ikut dikemas dan tidak diubah saat paket dipasang: <code>config/app.php</code>, <code>storage/</code>, serta berkas pengembangan seperti <code>README.md</code>, <code>package.json</code>, <code>tailwind.config.js</code>, <code>.gitignore</code>, <code>resources/</code>, <code>tools/</code>, dan <code>node_modules/</code>.</p>
        <div class="mt-auto">
          <a class="btn-secondary" :href="bundleUrl()" :class="!zip && 'pointer-events-none opacity-60'" :aria-disabled="(!zip).toString()"><?= $icon('package') ?>Buat Paket</a>
        </div>
      </section>

      <section class="panel flex flex-col gap-3 p-4" aria-labelledby="upd-upload">
        <h2 id="upd-upload" class="panel-title">Unggah paket</h2>
        <form class="flex flex-col gap-3" @submit.prevent="upload()" novalidate>
          <div>
            <label for="upd-file" class="field-label">Berkas paket (.zip) <span class="text-danger-700" aria-hidden="true">*</span></label>
            <input id="upd-file" type="file" accept=".zip,application/zip" class="input h-auto py-1.5 file:mr-3 file:rounded-chip file:border-0 file:bg-surface-2 file:px-2 file:py-1 file:text-sm file:text-ink" x-ref="fileInput" @change="pickFile($event)"
                   :disabled="!zip || busy !== ''" :aria-invalid="errors.package ? 'true' : null" aria-describedby="upd-file-hint">
            <p id="upd-file-hint" class="mt-1 text-xs text-muted">Paket dari tombol Buat Paket di komputer lokal, atau arsip .zip dari repositori aplikasi. Maksimal <span x-text="FM.formatBytes(uploadBytes)"></span>.</p>
            <p class="field-error" x-show="errors.package" x-text="errors.package"></p>
          </div>
          <div>
            <button type="submit" class="btn-primary" :disabled="!zip || busy !== ''"><?= $icon('upload') ?><span x-text="busy === 'upload' ? 'Memeriksa...' : 'Unggah dan Periksa'"></span></button>
          </div>
        </form>
        <div class="flex flex-col gap-2 border-t border-line pt-3">
          <h3 class="text-sm font-medium text-ink">Unduh dari URL pembaruan</h3>
          <template x-if="updateUrl">
            <div class="flex flex-col gap-2">
              <p class="break-all font-mono text-xs text-ink" x-text="updateUrl"></p>
              <p class="text-xs text-muted" x-show="fetch">Server mengunduh paket dari alamat ini, lalu memeriksanya seperti paket yang diunggah. Batas ukurannya sama dengan batas unggahan.</p>
              <p class="text-xs text-danger-700" x-show="!fetch">Server ini tidak dapat mengunduh berkas. Aktifkan ekstensi PHP curl atau allow_url_fopen di php.ini.</p>
              <div>
                <button type="button" class="btn-secondary" @click="download()" :disabled="!zip || !fetch || busy !== ''"><?= $icon('download') ?><span x-text="busy === 'download' ? 'Mengunduh...' : 'Unduh dan Periksa'"></span></button>
              </div>
            </div>
          </template>
          <p class="text-xs text-muted" x-show="!updateUrl">URL pembaruan belum diatur. Isi alamat paket .zip di <a href="?r=settings" class="text-primary-700 underline">halaman Pengaturan</a> agar server dapat mengunduh pembaruan tanpa unggah manual.</p>
        </div>
      </section>
    </div>

    <section class="panel" aria-labelledby="upd-result" x-show="staged" x-cloak>
      <div class="flex flex-col gap-1 border-b border-line p-4">
        <h2 id="upd-result" class="panel-title focus:outline-none" tabindex="-1" x-ref="result">Hasil pemeriksaan</h2>
        <p class="break-all font-mono text-xs text-ink" x-text="staged ? staged.name : ''"></p>
        <p class="text-xs text-muted" x-show="staged">
          <span x-text="originText()"></span> ·
          <span x-text="staged ? FM.formatBytes(staged.size) : ''"></span> ·
          <span x-text="staged ? 'diperiksa ' + FM.formatDate(staged.uploaded_at) + ' oleh ' + staged.uploaded_by : ''"></span>
          <template x-if="staged && staged.manifest && staged.manifest.created_at">
            <span x-text="' · paket dibuat ' + FM.formatDate(staged.manifest.created_at) + (staged.manifest.created_by ? ' oleh ' + staged.manifest.created_by : '')"></span>
          </template>
        </p>
      </div>

      <ul class="divide-y divide-line">
        <template x-for="item in (staged ? staged.checks : [])" :key="item.key">
          <li class="flex items-start gap-3 px-4 py-2.5">
            <svg class="icon mt-0.5" :class="check(item.status).tone" aria-hidden="true"><use :href="FM.icons + '#' + check(item.status).icon"></use></svg>
            <div class="min-w-0 flex-1">
              <p class="text-sm font-medium text-ink"><span x-text="item.label"></span><span class="sr-only" x-text="': ' + check(item.status).label"></span></p>
              <p class="break-words text-xs text-muted" x-text="item.detail"></p>
            </div>
          </li>
        </template>
      </ul>

      <template x-if="staged && staged.installable && staged.changes">
        <div class="border-t border-line">
          <div class="flex flex-wrap items-center gap-2 px-4 pt-3 text-xs">
            <span class="chip-success" x-text="FM.formatNumber(staged.changes.added) + ' baru'"></span>
            <span class="chip-warning" x-text="FM.formatNumber(staged.changes.changed) + ' diubah'"></span>
            <span class="chip-danger" x-text="FM.formatNumber(staged.changes.deleted) + ' dihapus'"></span>
            <span class="chip-neutral" x-text="FM.formatNumber(staged.changes.same) + ' tidak berubah'"></span>
          </div>
          <p class="px-4 py-3 text-sm text-muted" x-show="!staged.changes.items.length">Isi paket sama dengan aplikasi yang terpasang, sehingga tidak ada berkas yang perlu diubah.</p>
          <div class="table-scroll mx-4 my-3 max-h-80 rounded-control border border-line" x-show="staged.changes.items.length">
            <table class="data-table">
              <caption class="sr-only">Berkas yang akan berubah</caption>
              <thead><tr><th scope="col" class="w-24">Perubahan</th><th scope="col">Berkas</th></tr></thead>
              <tbody>
                <template x-for="change in staged.changes.items" :key="change.kind + change.path">
                  <tr>
                    <td><span :class="kind(change.kind).chip" x-text="kind(change.kind).label"></span></td>
                    <td class="break-all font-mono text-xs" x-text="change.path"></td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
          <p class="px-4 pb-3 text-xs text-muted" x-show="staged.changes.capped">Daftar hanya menampilkan 1.000 perubahan pertama.</p>
        </div>
      </template>

      <form class="flex flex-col gap-3 border-t border-line p-4" x-show="staged && staged.installable" @submit.prevent="install()" novalidate>
        <p class="text-sm text-body">Cadangan versi saat ini dibuat otomatis sebelum berkas ditimpa. Bila ada langkah yang gagal, cadangan tersebut langsung dipulihkan.</p>
        <div class="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div class="sm:w-80">
            <label for="upd-password" class="field-label">Kata sandi saat ini <span class="text-danger-700" aria-hidden="true">*</span></label>
            <input id="upd-password" type="password" class="input" x-model="password" autocomplete="current-password" required @input="errors.current_password = ''" :aria-invalid="errors.current_password ? 'true' : null">
            <p class="field-error" x-show="errors.current_password" x-text="errors.current_password"></p>
          </div>
          <div class="flex flex-wrap gap-2">
            <button type="button" class="btn-secondary" @click="discard()" :disabled="busy !== ''">Batalkan Paket</button>
            <button type="submit" class="btn-primary" :disabled="busy !== ''"><?= $icon('package-check') ?><span x-text="busy === 'install' ? 'Memasang...' : (staged && staged.origin === 'backup' ? 'Pulihkan Cadangan' : 'Pasang Pembaruan')"></span></button>
          </div>
        </div>
      </form>

      <div class="flex flex-col gap-3 border-t border-line p-4 sm:flex-row sm:items-center" x-show="staged && !staged.installable">
        <p class="flex-1 text-sm text-danger-700">Paket tidak dapat dipasang. Perbaiki masalah yang ditandai, lalu unggah paket kembali.</p>
        <button type="button" class="btn-secondary" @click="discard()" :disabled="busy !== ''">Batalkan Paket</button>
      </div>
    </section>

    <section class="panel" aria-labelledby="upd-backups">
      <div class="border-b border-line p-4">
        <h2 id="upd-backups" class="panel-title">Cadangan</h2>
        <p class="mt-1 text-xs text-muted">Dibuat otomatis setiap kali pembaruan dipasang. Lima cadangan terbaru disimpan di <code>storage/updates/backups</code>. Memulihkan cadangan melewati pemeriksaan yang sama dengan paket pembaruan.</p>
      </div>
      <p class="px-4 py-6 text-center text-sm text-muted" x-show="!backups.length">Belum ada cadangan. Cadangan pertama dibuat saat pembaruan pertama dipasang.</p>
      <ul class="divide-y divide-line" x-show="backups.length">
        <template x-for="backup in backups" :key="backup.id">
          <li class="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center">
            <div class="min-w-0 flex-1">
              <p class="text-sm font-medium text-ink" x-text="FM.formatDate(backup.created_at)"></p>
              <p class="break-all font-mono text-xs text-muted" x-text="backup.id + '.zip · ' + FM.formatBytes(backup.size)"></p>
            </div>
            <button type="button" class="btn-secondary" @click="restore(backup)" :disabled="!zip || busy !== ''"><?= $icon('archive-restore') ?><span x-text="busy === backup.id ? 'Memeriksa...' : 'Pulihkan'"></span></button>
          </li>
        </template>
      </ul>
    </section>
  </div>
</div>
